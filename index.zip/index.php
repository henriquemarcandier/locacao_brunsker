<?php
error_reporting(0);
ini_set('display_erros', 'off');
@session_start();
$url = $_SERVER['REQUEST_URI'];
$vet = explode("/", $url);
array_shift($vet);
$exp = explode('?', $vet[0]);
$vet[0] = $exp[0];
if ($_SERVER['HTTP_HOST'] == 'localhost'){
    $link = "https://localhost/locacao/";
}
else{
    $link = "https://www.bhcommerce.com.br/locacao/";
}
if ($vet[0] == ""){
    $vet[0] = "principal";
}
if($vet[0]){
    $link .= $vet[0]."/";
}
if ($vet[1]){
    $link .= $vet[1]."/";
}
if ($vet[2]){
    $link .= $vet[2]."/";
}
if (!$_SERVER['HTTPS']){
    header('location: '.$link);
}
require_once('connect.php');
if (!$_SESSION['user'] && !preg_match("/login/", $_SERVER['REQUEST_URI'])  && !preg_match("/esqueceu-sua-senha/", $_SERVER['REQUEST_URI'])  && !preg_match("/cadastro/", $_SERVER['REQUEST_URI'])){
    ?>
    <script>
            location.href="<?=URL?>login/<?=$vet[1]?>";
    </script>
    <?php
}
$param = $vet[1];
if ($vet[1] == 'logout'){
    $sql = "INSERT INTO logs (user, action, created_at, updated_at) VALUES ('".$_SESSION['user']['id']."', 'Efetuou logout no sistema!', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
    mysqli_query($con, $sql);
    $_SESSION['user'] = "";
    ?>
    <script>
            location.href="<?=URL?>login";
    </script>
    <?php
}
if ($vet[1] == 'login'){
    require_once(DIRETORIO."paginas/formLogin.php");
}
elseif ($vet[1] == 'esqueceu-sua-senha'){
    require_once(DIRETORIO."paginas/formForgotPassword.php");
}
else{
    require_once(DIRETORIO."pegaSqls.php");
    require_once(DIRETORIO."paginas/cabecalho.php");
    if (!$vet[1] || $vet[1] == 'principal'){
        require_once(DIRETORIO."paginas/index.php");
    }
    elseif ($vet[1] == 'semPermissao'){ 
        require_once(DIRETORIO."paginas/semPermissao.php");
    }
    elseif ($permissao->view){
    if ($vet[1] == 'estados'){
        require_once(DIRETORIO."paginas/estados.php");
    }
    elseif ($vet[1] == 'itens-excluidos'){
        require_once(DIRETORIO."paginas/itensExcluidos.php");
    }
    elseif ($vet[1] == 'paramSite'){
        require_once(DIRETORIO."paginas/paramSite.php");
    }
    elseif ($vet[1] == 'paramAdmin'){
        require_once(DIRETORIO."paginas/paramAdmin.php");
    }
    elseif ($vet[1] == 'versao'){
        require_once(DIRETORIO."paginas/versao.php");
    }
    elseif ($vet[1] == 'imoveis'){
        require_once(DIRETORIO."paginas/imoveis.php");
    }
    elseif ($vet[1] == 'usuarios'){
        require_once(DIRETORIO."paginas/usuarios.php");
    }
    elseif ($vet[1] == 'tiposModulo'){
        require_once(DIRETORIO."paginas/tiposModulo.php");
    }
    elseif ($vet[1] == 'modulos'){
        require_once(DIRETORIO."paginas/modulo.php");
    }
    elseif ($vet[1] == 'permissao'){
        require_once(DIRETORIO."paginas/permissao.php");
    }
    elseif ($vet[1] == 'logsAcesso'){
        require_once(DIRETORIO."paginas/logsAcesso.php");
    }
    else{
        require_once(DIRETORIO."paginas/paginaNaoEncontrada.php");
    }
    }
    else{
        require_once(DIRETORIO."paginas/semPermissao.php");
    }
    require_once(DIRETORIO."paginas/rodape.php");
}
?>