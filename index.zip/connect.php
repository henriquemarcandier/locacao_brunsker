<?php
ini_set('display_erros', 'off');
error_reporting(0);
@session_start();
date_default_timezone_set("America/Sao_Paulo");
setlocale(LC_ALL, 'pt_BR');
$db_prefix = "catalogo_";
if ($_SERVER['HTTP_HOST'] == 'localhost'){
    $url = "https://localhost/locacao/";
    $diretorio = "C:/xampp/htdocs/locacao/";
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $dbname = "locacao";
}
else{
    $url = "";
    $diretorio = "";
    $dbhost = "";
    $dbuser = "";
    $dbpass = "";
    $dbname = "";
}
$con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname) or die(mysqli_error($con));
define("URL", $url);
define("DIRETORIO", $diretorio);
?>