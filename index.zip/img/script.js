$("#comprarProduto").submit(function(evt){
    evt.preventDefault();
    var url = $("#urlComprarProduto").val();
    var formData = new FormData($(this)[0]);
    $.ajax({
        url: url+'ajax.php?acao=comprarProduto',
        type: 'POST',
        data: formData,
        async: false,
        cache: false,
        contentType: false,
        enctype: 'multipart/form-data',
        processData: false,
        success: function (result) {
            var vet = result.split('|-|');
            if (vet[0] == 0) {
                alert('Erro: '+vet[1]);
            }
            else if (vet[0] == 1) {
                location.href=url+"carrinho";
            }
        },
    });
    return false;
});
$("#formComentario").submit(function(evt){
    evt.preventDefault();
    var url = $("#urlComentario").val();
    var formData = new FormData($(this)[0]);
    $.ajax({
        url: url+'ajax.php?acao=salvarComentario',
        type: 'POST',
        data: formData,
        async: false,
        cache: false,
        contentType: false,
        enctype: 'multipart/form-data',
        processData: false,
        success: function (result) {
            var vet = result.split('|-|');
            if (vet[0] == 0) {
                alert('Erro: '+vet[1]);
            }
            else if (vet[0] == 1) {
                alert('Comentário salvo com sucesso! Aguarde a nossa aprovação para ele começar a aparecer no site!');
                $("#nomeComentario").val(vet[1]);
                $("#emailComentario").val(vet[2]);
                $("#comentario").val('');
                //marcarNota('5', $("#urlComentario").val());
            }
        },
    });
    return false;
});
$("#formRealizarPedido").submit(function(evt){
    evt.preventDefault();
    var url = $("#urlRealizarPedido").val();
    var formData = new FormData($(this)[0]);
    $.ajax({
        url: 'ajax.php?acao=salvarCarrinho',
        type: 'POST',
        data: formData,
        async: false,
        cache: false,
        contentType: false,
        enctype: 'multipart/form-data',
        processData: false,
        success: function (result) {
            var vet = result.split('|-|');
            if (vet[0] == 0) {
                alert('Erro: '+vet[1]);
            }
            else if (vet[0] == 1) {
                alert('Produto inserido com sucesso! Fecha essa tela e clique sobre Carrinho de Compras para prosseguir com a sua compra!');
                $("#produtoRealizarPedido").val('');
                selecionaProduto('', url);
            }
        },
    });
    return false;
});
$("#formNews").submit(function(evt){
    evt.preventDefault();
    var url = $("#urlNews").val();
    var formData = new FormData($(this)[0]);
    $.ajax({
        url: url+'ajax.php?acao=salvarNews',
        type: 'POST',
        data: formData,
        async: false,
        cache: false,
        contentType: false,
        enctype: 'multipart/form-data',
        processData: false,
        success: function (result) {
            var vet = result.split('|-|');
            if (vet[0] == 0) {
            }
            else if (vet[0] == 1) {
                $("#emailNews").val('');
                alert('Email cadastrado com sucesso! Aguarde a nossa próxima news!');
            }
        },
    });
    return false;
});
$("#formBugTracking").submit(function(evt){
    evt.preventDefault();
    var formData = new FormData($(this)[0]);
    $.ajax({
        url: 'ajax.php?acao=salvarBugTracking',
        type: 'POST',
        data: formData,
        async: false,
        cache: false,
        contentType: false,
        enctype: 'multipart/form-data',
        processData: false,
        success: function (result) {
            var vet = result.split('|-|');
            if (vet[0] == 0) {
            }
            else if (vet[0] == 1) {
                $("#nameBugTracking").val('');
                $("#emailBugTracking").val('');
                $("#titleBugTracking").val('');
                $("#typeService").val('');
                $("#typeVersion").val('');
                $("#priority").val('');
                $("#category").val('');
                $("#message").val('');
                alert('Bug Tracking enviado com sucesso! Aguarde um retorno por email!');
            }
        },
    });
    return false;
});
$("#formContato").submit(function(evt){
    evt.preventDefault();
    var formData = new FormData($(this)[0]);
    $.ajax({
        url: 'ajax.php?acao=salvarContato',
        type: 'POST',
        data: formData,
        async: false,
        cache: false,
        contentType: false,
        enctype: 'multipart/form-data',
        processData: false,
        success: function (result) {
            var vet = result.split('|-|');
            if (vet[0] == 0) {
            }
            else if (vet[0] == 1) {
                $("#name").val('');
                $("#email").val('');
                $("#subject").val('');
                $("#phone").val('');
                $("#text").val('');
                alert('Email enviado com sucesso! Aguarde um retorno por telefone ou email!');
            }
        },
    });
    return false;
});
$("#formLogin").submit(function(evt){
    evt.preventDefault();
    var formData = new FormData($(this)[0]);
    var url = $('#url').val();
    $.ajax({
        url: url+'ajax.php?acao=realizarLogin',
        type: 'POST',
        data: formData,
        async: false,
        cache: false,
        contentType: false,
        enctype: 'multipart/form-data',
        processData: false,
        success: function (result) {
            var vet = result.split('|-|');
            if (vet[0] == 0) {
                alert(vet[1]);
            }
            else if (vet[0] == 1) {
                if(!$("#urlVaiLogin").val()) {
                    location.href = url + "pagina/central-do-cliente";
                }
                else{
                    location.href = url + $("#urlVaiLogin").val();
                }
            }
        },
    });
    return false;
});
$("#formLogin2").submit(function(evt){
    evt.preventDefault();
    var formData = new FormData($(this)[0]);
    var url = $('#url2').val();
    $.ajax({
        url: url+'ajax.php?acao=realizarLogin',
        type: 'POST',
        data: formData,
        async: false,
        cache: false,
        contentType: false,
        enctype: 'multipart/form-data',
        processData: false,
        success: function (result) {
            var vet = result.split('|-|');
            if (vet[0] == 0) {
                alert(vet[1]);
            }
            else if (vet[0] == 1) {
                if(!$("#urlVaiLogin2").val()) {
                    location.href = url + "pagina/central-do-cliente";
                }
                else{
                    location.href = url + $("#urlVaiLogin2").val();
                }
            }
        },
    });
    return false;
});
$("#formAlterarSenha").submit(function(evt){
    evt.preventDefault();
    var formData = new FormData($(this)[0]);
    var url = $('#url').val();
    $.ajax({
        url: 'ajax.php?acao=alterarSenha',
        type: 'POST',
        data: formData,
        async: false,
        cache: false,
        contentType: false,
        enctype: 'multipart/form-data',
        processData: false,
        success: function (result) {
            var vet = result.split('|-|');
            if (vet[0] == 0) {
                alert(vet[1]);
            }
            else if (vet[0] == 1) {
                alert('Senha alterada com sucesso! Aguarde o refresh da página!');
                location.href=url+"pagina/central-do-cliente";
            }
        },
    });
    return false;
});
$("#formCadastro").submit(function(evt){
    evt.preventDefault();
    var formData = new FormData($(this)[0]);
    var url = $('#url').val();
    $.ajax({
        url: url+'ajax.php?acao=cadastro',
        type: 'POST',
        data: formData,
        async: false,
        cache: false,
        contentType: false,
        enctype: 'multipart/form-data',
        processData: false,
        success: function (result) {
            var vet = result.split('|-|');
            if (vet[0] == 0) {
                alert(vet[1]);
            }
            else if (vet[0] == 1) {
                $("#nomeCliente").html(vet[1]);
                alert('Cadastro atualizado com sucesso! Você já está logado no sistema e será redirecionado para a página "Central do Cliente"!');
                location.href=url+"pagina/central-do-cliente";

            }
        },
    });
    return false;
});
$("#formCadastro2").submit(function(evt){
    evt.preventDefault();
    var formData = new FormData($(this)[0]);
    var url = $('#url').val();
    $.ajax({
        url: 'ajax.php?acao=atualizarCadastro',
        type: 'POST',
        data: formData,
        async: false,
        cache: false,
        contentType: false,
        enctype: 'multipart/form-data',
        processData: false,
        success: function (result) {
            var vet = result.split('|-|');
            if (vet[0] == 0) {
                alert(vet[1]);
            } else if (vet[0] == 1) {
                $("#nomeCliente").html(vet[1]);
                alert('Cadastro atualizado com sucesso!');
            }
        },
    });
    return false;
});
$("#formAtualizarSenha").submit(function(evt){
    evt.preventDefault();
    var formData = new FormData($(this)[0]);
    var url = $('#url').val();
    $.ajax({
        type: 'POST',
        url: 'ajax.php?acao=atualizarSenha',
        data: formData,
        async: false,
        cache: false,
        contentType: false,
        enctype: 'multipart/form-data',
        processData: false,
        success: function (result) {
            var vet = result.split('|-|');
            if (vet[0] == 0) {
                $("#"+vet[2]).focus();
                alert(vet[1]);
            } else if (vet[0] == 1) {
                $("#senhaAlterarSenha").val('');
                $("#novaSenhaAlterarSenha").val('');
                $("#redigitoSenhaAlterarSenha").val('');
                alert('Senha atualizada com sucesso!');
            }
        },
    });
    return false;
});
$("#formEsqueceuSuaSenha").submit(function(evt){
    evt.preventDefault();
    var formData = new FormData($(this)[0]);
    var url = $("#urlEsqueceuSuaSenha").val();
    $.ajax({
        url: url+'ajax.php?acao=enviarEsqueceuSuaSenha',
        type: 'POST',
        data: formData,
        async: false,
        cache: false,
        contentType: false,
        enctype: 'multipart/form-data',
        processData: false,
        success: function (result) {
            var vet = result.split('|-|');
            if (vet[0] == 0) {
                $('#emailEsqueceuSuaSenha').val('');
                alert('Não foi encontrado esse email em nossa base de dados.');
            }
            else if (vet[0] == 1) {
                $('#emailEsqueceuSuaSenha').val('');
                alert('Email enviado com sucesso. Procure pelo email e clique no link.');
            }
        },
    });
    return false;
});
$("#formEsqueceuSuaSenha2").submit(function(evt){
    evt.preventDefault();
    var formData = new FormData($(this)[0]);
    var url = $("#urlEsqueceuSuaSenha2").val();
    $.ajax({
        url: url+'ajax.php?acao=enviarEsqueceuSuaSenha',
        type: 'POST',
        data: formData,
        async: false,
        cache: false,
        contentType: false,
        enctype: 'multipart/form-data',
        processData: false,
        success: function (result) {
            var vet = result.split('|-|');
            if (vet[0] == 0) {
                $('#emailEsqueceuSuaSenha2').val('');
                alert('Não foi encontrado esse email em nossa base de dados.');
            }
            else if (vet[0] == 1) {
                $('#emailEsqueceuSuaSenha2').val('');
                alert('Email enviado com sucesso. Procure pelo email e clique no link.');
            }
        },
    });
    return false;
});
$("#contact-form").submit(function(evt){
    evt.preventDefault();
    var formData = new FormData($(this)[0]);
    var url = $("#urlContato").val();
    $.ajax({
        url: url+'ajax.php?acao=enviarFaleConosco',
        type: 'POST',
        data: formData,
        async: false,
        cache: false,
        contentType: false,
        enctype: 'multipart/form-data',
        processData: false,
        success: function (result) {
            var vet = result.split('|-|');
            if (vet[0] == 0) {
                $('#nome').val(vet[1]);
                $('#email').val(vet[2]);
                $('#assunto').val('');
                $('#phone').val('');
                $('#message').val('');
                alert('Não foi enviado o email devido a um problema na base de dados. Tente novamente mais tarde!');
            }
            else if (vet[0] == 1) {
                $('#nome').val(vet[1]);
                $('#email').val(vet[2]);
                $('#assunto').val('');
                $('#phone').val('');
                $('#message').val('');
                alert('Email enviado com sucesso. Aguarde nosso retorno por email!');
            }
        },
    });
    return false;
});
$("#formItemVenda").submit(function(evt){
    if ($("#id").val() == "") {
        evt.preventDefault();
        var formData = new FormData($(this)[0]);
        $.ajax({
            url: 'ajax.php?acao=cadastrarItemVenda',
            type: 'POST',
            data: formData,
            async: false,
            cache: false,
            contentType: false,
            enctype: 'multipart/form-data',
            processData: false,
            success: function (result) {
                var vet = result.split('|-|');
                if (vet[0] == 0) {
                    alert(vet[1]);
                } else if (vet[0] == 1) {
                    alert('Item Venda cadastrado com sucesso!');
                    listarItensVenda($('#product').val(), $("#url").val());
                    $("#id").val('');
                    $("#product_type").val('');
                    $("#code").val('');
                    $("#name").val('');
                    $("#value").val('');
                    $("#promotion").val('');
                    $("#validity_promotion").val('');
                    $("#status").val('0');
                }
            },
        });
        return false;
    }
    else{
        evt.preventDefault();
        var formData = new FormData($(this)[0]);
        $.ajax({
            url: 'ajax.php?acao=editarItemVenda',
            type: 'POST',
            data: formData,
            async: false,
            cache: false,
            contentType: false,
            enctype: 'multipart/form-data',
            processData: false,
            success: function (result) {
                var vet = result.split('|-|');
                if (vet[0] == 0) {
                    alert(vet[1]);
                } else if (vet[0] == 1) {
                    alert('Item Venda atualizado com sucesso!');
                    listarItensVenda($('#product').val(), $("#url").val());
                    $("#id").val('');
                    $("#product_type").val('');
                    $("#code").val('');
                    $("#name").val('');
                    $("#value").val('');
                    $("#promotion").val('');
                    $("#validity_promotion").val('');
                    $("#status").val('0');
                }
            },
        });
        return false;
    }
});
function mudaImgNotasEdicao(qual, id, url){
	var html = "";
	for (i = 1; i <= 5; i++){
		html += '<img src="'+url+'img/star';
		if (i > qual){
			html += 'Apagada';
		}
		html += '.png" style=\'cursor:pointer\' title=\'Nota '+i+'\' onclick=mudaImgNotasEdicao(\''+i+'\',\''+id+'\',\''+url+'\')> ';
	}
	html += '<input type="hidden" name="avaliacaoComentarioProduto'+id+'" id="avaliacaoComentarioProduto'+id+'" value="'+qual+'"></div>';
	$("#estrelasComentarioProduto"+id).html(html);
}
function validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}
function selecionaTipoPessoaAtualiza(qual){
    if (qual == 'F'){
        $("#pessoaJuridica").hide('fast');
        $("#pessoaFisica").show('slow');
    }
    else{
        $("#pessoaFisica").hide('fast');
        $("#pessoaJuridica").show('slow');
    }
}
function validarCPF(cpf) {
    cpf = cpf.replace(/[^\d]+/g,'');
    if(cpf == '') return false;
    // Elimina CPFs invalidos conhecidos
    if (cpf.length != 11 ||
        cpf == "00000000000" ||
        cpf == "11111111111" ||
        cpf == "22222222222" ||
        cpf == "33333333333" ||
        cpf == "44444444444" ||
        cpf == "55555555555" ||
        cpf == "66666666666" ||
        cpf == "77777777777" ||
        cpf == "88888888888" ||
        cpf == "99999999999")
        return false;
    // Valida 1o digito
    add = 0;
    for (i=0; i < 9; i ++)
        add += parseInt(cpf.charAt(i)) * (10 - i);
    rev = 11 - (add % 11);
    if (rev == 10 || rev == 11)
        rev = 0;
    if (rev != parseInt(cpf.charAt(9)))
        return false;
    // Valida 2o digito
    add = 0;
    for (i = 0; i < 10; i ++)
        add += parseInt(cpf.charAt(i)) * (11 - i);
    rev = 11 - (add % 11);
    if (rev == 10 || rev == 11)
        rev = 0;
    if (rev != parseInt(cpf.charAt(10)))
        return false;
    return true;
}
function validarCNPJ(cnpj) {

    cnpj = cnpj.replace(/[^\d]+/g,'');

    if(cnpj == '') return false;

    if (cnpj.length != 14)
        return false;

    // Elimina CNPJs invalidos conhecidos
    if (cnpj == "00000000000000" ||
        cnpj == "11111111111111" ||
        cnpj == "22222222222222" ||
        cnpj == "33333333333333" ||
        cnpj == "44444444444444" ||
        cnpj == "55555555555555" ||
        cnpj == "66666666666666" ||
        cnpj == "77777777777777" ||
        cnpj == "88888888888888" ||
        cnpj == "99999999999999")
        return false;

    // Valida DVs
    tamanho = cnpj.length - 2
    numeros = cnpj.substring(0,tamanho);
    digitos = cnpj.substring(tamanho);
    soma = 0;
    pos = tamanho - 7;
    for (i = tamanho; i >= 1; i--) {
        soma += numeros.charAt(tamanho - i) * pos--;
        if (pos < 2)
            pos = 9;
    }
    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (resultado != digitos.charAt(0))
        return false;

    tamanho = tamanho + 1;
    numeros = cnpj.substring(0,tamanho);
    soma = 0;
    pos = tamanho - 7;
    for (i = tamanho; i >= 1; i--) {
        soma += numeros.charAt(tamanho - i) * pos--;
        if (pos < 2)
            pos = 9;
    }
    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (resultado != digitos.charAt(1))
        return false;

    return true;

}
function checarEmail(email){
    if( email==""
        || email.indexOf('@')==-1
        || email.indexOf('.')==-1 )
    {
        return false;
    }
    else{
        return true;
    }
}
function abreImagemProduto(id, url){
	$.ajax({
        url: url + 'ajax.php?&acao=abreImagemProduto&id=' + id,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#tituloFoto").html(data[1]);
                $("#foto").html(data[2]);
				$("#rodapeFoto").html(data[3]);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
			$("#tituloFoto").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
			$("#foto").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
			$("#rodapeFoto").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
        }
    });
}
function pegaUrlBanner(id, url) {
    $.ajax({
        url: url + 'ajax.php?&acao=marcarBannerVisitadoEPegarUrl&id=' + id,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                location.href = data[1];
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
                location.href=url;
            }
        },
        beforeSend: function () {
        }
    });
}
function contabilizaExibicoesBanner(id, url) {
    $.ajax({
        url: url + 'ajax.php?&acao=contabilizaExibicoesBanner&id=' + id,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
        }
    });
}
function validaCadastro(url){
    if ($("#tipoCadastro").val() == 'F'){
        if ($("#nomeCadastro").val() == ""){
            alert('Informe o seu nome corretamente.');
            $("#nomeCadastro").focus();
        }
        else if ($("#cpfCadastro").val() == "" || !validarCPF($('#cpfCadastro').val())){
            alert('Informe o seu CPF corretamente.');
            $("#cpfCadastro").focus();
        }
        else if ($("#rgCadastro").val() == ""){
            alert('Informe o seu RG corretamente.');
            $("#rgCadastro").focus();
        }
        else if ($("#nacionalidadeCadastro").val() == ""){
            alert('Informe a sua nacionalidade corretamente.');
            document.getElementById("#nacionalidadeCadastro").focus();
        }
        else if ($("#dtNascCadastro").val() == ""){
            alert('Informe a sua data de nascimento corretamente.');
            $("#dtNascCadastro").focus();
        }
        else if (document.getElementById('dddCelularCadastro').value.length < 2){
            alert('Informe o DDD do seu celular corretamente.');
            $("#dddCelularCadastro").focus();
        }
        else if (document.getElementById('celularCadastro').value.length < 10){
            alert('Informe o seu celular corretamente.');
            $("#celularCadastro").focus();
        }
        else if (!checarEmail($("#emailCadastro").val())){
            alert('Informe o seu email corretamente.');
            $("#emailCadastro").focus();
        }
        else if (document.getElementById('senhaCadastro').value.length < 6){
            alert('Informe a sua senha com no mínimo 6 dígitos corretamente.');
            $("#senhaCadastro").focus();
        }
        else{
            $.ajax({
                url: url+'ajax.php?&acao=cadastro&tipoCadastro=' + $("#tipoCadastro").val()+"&nomeCadastro="+$('#nomeCadastro').val()+"&cpfCadastro="+$('#cpfCadastro').val()+"&rgCadastro="+$("#rgCadastro").val()+"&nacionalidadeCadastro="+$("#nacionalidadeCadastro").val()+"&dtNascCadastro="+$("#dtNascCadastro").val()+"&dddCelularCadastro="+$("#dddCelularCadastro").val()+"&dddCelularCadastro="+$("#dddCelularCadastro").val()+"&celularCadastro="+$("#celularCadastro").val()+"&emailCadastro="+$("#emailCadastro").val()+"&senhaCadastro="+$("#senhaCadastro").val(),
                success: function (data) {
                    var data = data.split('|-|');
                    if (data[0] == 1) {
                        alert('Cliente Cadastrado com sucesso! Você já está logado no sistema e será redirecionado para a página "Central do Cliente"!');
                        location.href=url+"pagina/central-do-cliente";
                    } else if (data[0] == 0) {
                        alert('Erro: Não foi encontrada a função pesquisada!');
                    }
                },
                beforeSend: function () {
                }
            });
        }
    }
    else{
        if ($("#razaoSocialCadastro").val() == ""){
            alert('Informe a razão social da empresa corretamente.');
            $("#razaoSocialCadastro").focus();
        }
        else if ($("#nomeFantasiaCadastro").val() == ""){
            alert('Informe o nome fantasia da empresa corretamente.');
            $("#nomeFantasiaCadastro").focus();
        }
        else if ($("#contatoCadastro").val() == ""){
            alert('Informe o nome do contato da empresa corretamente.');
            $("#contatoCadastro").focus();
        }
        else if ($("#cnpjCadastro").val() == "" || !validarCNPJ($('#cnpjCadastro').val())){
            alert('Informe o seu CNPJ corretamente.');
            $("#cnpjCadastro").focus();
        }
        else if ($("#ieCadastro").val() == ""){
            alert('Informe a inscrição estadual da empresa corretamente.');
            $("#ieCadastro").focus();
        }
        else if ($("#imCadastro").val() == ""){
            alert('Informe a inscrição municipal da empresa corretamente.');
            $("#imCadastro").focus();
        }
        else if ($("#nacionalidadeEmpresaCadastro").val() == ""){
            alert('Informe a nacionalidade da empresa corretamente.');
            document.getElementById("nacionalidadeEmpresaCadastro").focus();
        }
        else if ($("#dataAberturaCadastro").val() == ""){
            alert('Informe a data de abertura da empresa corretamente.');
            $("#dataAberturaCadastro").focus();
        }
        else if (document.getElementById('dddCelularCadastro').value.length < 2){
            alert('Informe o DDD do celular da empresa corretamente.');
            $("#dddCelularCadastro").focus();
        }
        else if (document.getElementById('celularCadastro').value.length < 10){
            alert('Informe o celular da empresa corretamente.');
            $("#celularCadastro").focus();
        }
        else if (document.getElementById('dddTelefoneCadastro').value.length < 2){
            alert('Informe o DDD do telefone da empresa corretamente.');
            $("#dddTelefoneCadastro").focus();
        }
        else if (document.getElementById('telefoneCadastro').value.length < 9){
            alert('Informe o telefone da empresa corretamente.');
            $("#telefoneCadastro").focus();
        }
        else if (!checarEmail($("#emailCadastro").val())){
            alert('Informe o seu email corretamente.');
            $("#emailCadastro").focus();
        }
        else if (document.getElementById('senhaCadastro').value.length < 6){
            alert('Informe a sua senha com no mínimo 6 dígitos corretamente.');
            $("#senhaCadastro").focus();
        }
        else{
            $.ajax({
                url: url+'ajax.php?&acao=cadastro&tipoCadastro=' + $("#tipoCadastro").val()+"&razaoSocialCadastro="+$('#razaoSocialCadastro').val()+"&nomeFantasiaCadastro="+$('#nomeFantasiaCadastro').val()+"&contatoCadastro="+$("#contatoCadastro").val()+"&cnpjCadastro="+$("#cnpjCadastro").val()+"&ieCadastro="+$("#ieCadastro").val()+"&imCadastro="+$("#imCadastro").val()+"&nacionalidadeEmpresaCadastro="+$('#nacionalidadeEmpresaCadastro').val()+"&dataAberturaCadastro="+$("#dataAberturaCadastro").val()+"&dddCelularCadastro="+$("#dddCelularCadastro").val()+"&dddCelularCadastro="+$("#dddCelularCadastro").val()+"&celularCadastro="+$("#celularCadastro").val()+"&dddTelefoneCadastro="+$("#dddTelefoneCadastro").val()+"&telefoneCadastro="+$("#telefoneCadastro").val()+"&emailCadastro="+$("#emailCadastro").val()+"&senhaCadastro="+$("#senhaCadastro").val(),
                success: function (data) {
                    var data = data.split('|-|');
                    if (data[0] == 1) {
                        alert('Cliente Cadastrado com sucesso! Você já está logado no sistema e será redirecionado para a página "Central do Cliente"!');
                        location.href=url+"pagina/central-do-cliente";
                    } else if (data[0] == 0) {
                        alert('Erro: '+data[1]);
                    }
                },
                beforeSend: function () {
                }
            });
        }
    }
}
function validaAlteraCliente(url){
    if ($("#tipoAtualiza").val() == 'F'){
        if ($("#nomeAtualiza").val() == ""){
            alert('Informe o seu nome corretamente.');
            $("#nomeAtualiza").focus();
        }
        else if ($("#cpfAtualiza").val() == "" || !validarCPF($('#cpfAtualiza').val())){
            alert('Informe o seu CPF corretamente.');
            $("#cpfAtualiza").focus();
        }
        else if ($("#rgAtualiza").val() == ""){
            alert('Informe o seu RG corretamente.');
            $("#rgAtualiza").focus();
        }
        else if ($("#naturalidadeAtualiza").val() == ""){
            alert('Informea sua naturalidade corretamente.');
            $("#naturalidadeAtualiza").focus();
        }
        else if ($("#dtNascAtualiza").val() == ""){
            alert('Informe a sua data de nascimento corretamente.');
            $("#dtNascAtualiza").focus();
        }
        else if ($("#celularAtualiza").val() == ""){
            alert('Informe o seu celular corretamente.');
            $("#celularAtualiza").focus();
        }
        else if (!checarEmail($("#emailAtualiza").val())){
            alert('Informe o seu email corretamente.');
            $("#emailAtualiza").focus();
        }
        else{
            $.ajax({
                url: url+'ajax.php?&acao=atualizarCadastro&tipoAtualiza=' + $("#tipoAtualiza").val()+"&nomeAtualiza="+$('#nomeAtualiza').val()+"&cpfAtualiza="+$('#cpfAtualiza').val()+"&rgAtualiza="+$("#rgAtualiza").val()+"&nacionalidadeAtualiza="+$("#naturalidadeAtualiza").val()+"&dtNascAtualiza="+$("#dtNascAtualiza").val()+"&celularAtualiza="+$("#celularAtualiza").val()+"&emailAtualiza="+$("#emailAtualiza").val(),
                success: function (data) {
                    var data = data.split('|-|');
                    if (data[0] == 1) {
                        alert('Cadastro atualizado com sucesso!');
                        $("#nomeClientePrincipal").html(data[1]);
                    } else if (data[0] == 0) {
                        alert('Erro: '+data[1]);
                    }
                },
                beforeSend: function () {
                }
            });
        }
    }
    else{
        if ($("#razaoSocialAtualiza").val() == ""){
            alert('Informe a razão social da empresa corretamente.');
            $("#razaoSocialAtualiza").focus();
        }
        else if ($("#nomeFantasiaAtualiza").val() == ""){
            alert('Informe o nome fantasia da empresa corretamente.');
            $("#nomeFantasiaAtualiza").focus();
        }
        else if ($("#contatoAtualiza").val() == ""){
            alert('Informe o nome do contato da empresa corretamente.');
            $("#contatoAtualiza").focus();
        }
        else if ($("#cnpjAtualiza").val() == "" || !validarCNPJ($('#cnpjAtualiza').val())){
            alert('Informe o seu CNPJ corretamente.');
            $("#cnpjAtualiza").focus();
        }
        else if ($("#ieAtualiza").val() == ""){
            alert('Informe a inscrição estadual da empresa corretamente.');
            $("#ieAtualiza").focus();
        }
        else if ($("#imAtualiza").val() == ""){
            alert('Informe a inscrição municipal da empresa corretamente.');
            $("#imAtualiza").focus();
        }
        else if ($("#naturalidadeEmpresaAtualiza").val() == ""){
            alert('Informe a nacionalidade da empresa corretamente.');
            $("#naturalidadeEmpresaAtualiza").focus();
        }
        else if ($("#dataAberturaAtualiza").val() == ""){
            alert('Informe a data de abertura da empresa corretamente.');
            $("#dataAberturaAtualiza").focus();
        }
        else if (document.getElementById('telefoneAtualiza').value.length < 9){
            alert('Informe o telefone da empresa corretamente.');
            $("#telefoneAtualiza").focus();
        }
        else if (document.getElementById('cel2Atualiza').value.length < 10){
            alert('Informe o celular da empresa corretamente.');
            $("#cel2Atualiza").focus();
        }
        else if (!checarEmail($("#emailAtualiza").val())){
            alert('Informe o seu email corretamente.');
            $("#emailAtualiza").focus();
        }
        else{
            $.ajax({
                url: url+'ajax.php?&acao=atualizarCadastro&tipoAtualiza=' + $("#tipoAtualiza").val()+"&razaoSocialAtualiza="+$('#razaoSocialAtualiza').val()+"&nomeFantasiaAtualiza="+$('#nomeFantasiaAtualiza').val()+"&contatoAtualiza="+$('#contatoAtualiza').val()+"&cnpjAtualiza="+$("#cnpjAtualiza").val()+"&ieAtualiza="+$("#ieAtualiza").val()+"&imAtualiza="+$("#imAtualiza").val()+"&nacionalidadeEmpresaAtualiza="+$('#naturalidadeEmpresaAtualiza').val()+"&dataAberturaAtualiza="+$("#dataAberturaAtualiza").val()+"&celularAtualiza="+$("#cel2Atualiza").val()+"&telefoneAtualiza="+$("#telefoneAtualiza").val()+"&emailAtualiza="+$("#emailAtualiza").val(),
                success: function (data) {
                    var data = data.split('|-|');
                    if (data[0] == 1) {
                        alert('Cadastro atualizado com sucesso!');
                        $("#nomeClientePrincipal").html(data[1]);
                    } else if (data[0] == 0) {
                        alert('Erro: '+data[1]);
                    }
                },
                beforeSend: function () {
                }
            });
        }
    }
}
function abreFecha(id){
    if (document.getElementById(id).style.display == 'none'){
        $("#"+id).show('slow');
    }
    else{
        $("#"+id).hide('fast');
    }
}
function fecha(id){
    $("#"+id).hide('fast');
}
function abrePedido(id, url){
    $("#detalhesPedido").show('slow');
    $.ajax({
        url: url+'ajax.php?&acao=detalhesPedido&id=' + id+"&meusPedidos=1",
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#detalhesPedido").html(data[1]);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#detalhesPedido").html('<div style="position: absolute; float:left; left:95%; cursor:pointer" onclick=$("#detalhesPedido").hide("fast")>&times</div><img src="'+url+'img/loader.gif" width="25"> Aguarde... Carregando...');
        }
    });
}
function adicionarEnderecoCliente(){
    $("#adicionarEndereco").show('slow');
    $("#nomeEnderecoCadastro").val('');
    $("#cepCadastro").val('');
    $("#logradouroCadastro").val('');
    $("#numeroCadastro").val('');
    $("#complementoCadastro").val('');
    $("#bairroCadastro").val('');
    $("#cidadeCadastro").val('');
    $("#estadoCadastro").val('');
}
function validaAlteraSenha(url){
    if (document.getElementById('senhaAtualAtualiza').value.length < '6'){
        alert('Informe a senha atual com no mínimo 6 dígitos corretamente!');
        document.getElementById('senhaAtualAtualiza').focus();
    }
    else if (document.getElementById('novaSenhaAtualiza').value.length < '6'){
        alert('Informe a nova senha com no mínimo 6 dígitos corretamente!');
        document.getElementById('novaSenhaAtualiza').focus();
    }
    else if (document.getElementById('novaSenha2Atualiza').value.length < '6'){
        alert('Redigite a nova senha com no mínimo 6 dígitos corretamente!');
        document.getElementById('novaSenha2Atualiza').focus();
    }
    else if ($("#novaSenhaAtualiza").val() != $("#novaSenha2Atualiza").val()){
        alert('A nova senha e o redígito da nova senha devem ser iguais!');
        document.getElementById('novaSenha2Atualiza').focus();
    }
    else {
        $.ajax({
            url: url + 'ajax.php?&acao=atualizarSenha&senhaAtual=' + $("#senhaAtualAtualiza").val() + "&novaSenha=" + $('#novaSenhaAtualiza').val(),
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    alert('Senha atualizada com sucesso!');
                    $("#senhaAtualAtualiza").val('');
                    $("#novaSenhaAtualiza").val('');
                    $("#novaSenha2Atualiza").val('');
                } else if (data[0] == 0) {
                    alert('Erro: ' + data[1]);
                }
            },
            beforeSend: function () {
            }
        });
    }
}
function passaProximo(id, lenght, id2){
    if (document.getElementById(id).value.length == lenght){
        document.getElementById(id2).focus();
    }
}
function editarComentarioProduto(id, url){
	$.ajax({
		url: url + 'ajax.php?&acao=editarComentarioProduto&id=' + id,
		success: function (data) {
			var data = data.split('|-|');
			if (data[0] == 1) {
			$("#editarComentarioProduto"+id).html(data[1]);				
			} else if (data[0] == 0) {
				alert('Erro: ' + data[1]);
			}
		},
		beforeSend: function () {
			$("#editarComentarioProduto"+id).show('slow');
			$("#editarComentarioProduto"+id).html("<img src='"+url+"img/loader.gif' width='20'> Aguarde... Carregando...");
		}
	});
}
function solicitaAlteracaoComentarioProduto(id, url){
	if ($("#mensagemComentarioProduto"+id).val() == ''){
		alert('Informe a mensagem corretamente!');
		$("#mensagemComentarioProduto"+id).focus();
	}
	else{
		$.ajax({
			url: url + 'ajax.php?&acao=solicitarAlteracaoComentarioProduto&avaliacao='+$("#avaliacaoComentarioProduto"+id).val()+'&mensagem='+$("#mensagemComentarioProduto"+id).val()+'&id=' + id,
			success: function (data) {
				var data = data.split('|-|');
				if (data[0] == 1) {
					alert('Comentário gravado com sucesso! Ele será analisado pela nossa equipe e em breve estará no ar!');
					$("#editarComentarioProduto"+id).hide('fast');				
				} else if (data[0] == 0) {
					alert('Erro: ' + data[1]);
				}
			},
			beforeSend: function () {
				$("#editarComentarioProduto"+id).show('slow');
			}
		});
	}
}
function selecionaTipoPessoa(tipo, url){
    $.ajax({
        url: url+'ajax.php?&acao=selecionaTipoPessoa&tipo=' + tipo,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#tipoPessoa").html(data[1]);
                location.href="#";
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#tipoPessoa").html('<img src="'+url+'img/loader.gif" width="20">  Aguarde... Carregando...');
        }
    });
}
function paginacao(vet0, vet1, pagina, url){
    $.ajax({
        url: url+'ajax.php?&acao=paginacao&vet0=' + vet0+"&vet1="+vet1+"&pagina="+pagina,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#registros").html(data[1]);
                $("#paginacao").html(data[2]);
                location.href="#";
            } else if (data[0] == 0) {
                alert('Erro: Não foi encontrada a função pesquisada!');
            }
        },
        beforeSend: function () {
            $("#registros").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
            $("#paginacao").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
        }
    });
}
function verificaCodigoCupom(freteValor, valorTotal, url){
    $.ajax({
        url: url+'ajax.php?&acao=calculaCupomDesconto&codigo=' + $("#codigoCupom").val()+"&freteValor="+freteValor+"&valorTotal="+valorTotal,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#freteValor").html(data[2]);
                $("#cupomDesconto").html(data[1]);
                $("#totalCompra").html(data[3]);
            } else if (data[0] == 0) {
                alert('Erro: Código não encontrado! Verifique e tente novamente!');
                $("#freteValor").html(data[2]);
                $("#cupomDesconto").html(data[1]);
                $("#totalCompra").html(data[3]);
            }
        },
        beforeSend: function () {
            $("#freteValor").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
            $("#cupomDesconto").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
            $("#totalCompra").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
        }
    });
}
function selecionaFormaFrete(key, cep, peso, comprimento, altura, largura, diametro, valorTotal, desconto, tela, valorFrete, prazoFrete, codigoFrete, tipo, produtos, vale_presentes, url, sessao){
    $.ajax({
        url: url+'ajax.php?acao=selecionaFormaFrete&cep=' + cep+'&peso='+peso+'&altura=' + altura+'&largura=' + largura+'&comprimento=' + comprimento+"&diametro="+diametro+"&valorTotal="+valorTotal+"&desconto="+desconto+"&valorFrete="+valorFrete+"&prazoFrete="+prazoFrete+"&codigoFrete="+codigoFrete+"&tipo="+tipo+"&produtos="+produtos+"&vale_presentes="+vale_presentes+"&sessao="+sessao,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                var htmlFrete = '<img src=\''+url+'img/informacao.png\' width=\'20\' style=\'cursor:pointer\' onclick=\'abreFecha("informacoesFrete")\'><div id=\'informacoesFrete\' style=\'display:none; position:absolute; border:1px solid #e7e7e7; background-color:#FFFFFF; text-align:left; width:350px\'><div style=\'position:absolute; float:left; left:95%; cursor:pointer\' onclick=\'fecha("informacoesFrete")\'>&times;</div><h3>Informações do Frete</h3>Tipo de Frete Escolhido: <b>##tipoFrete##</b><br>Prazo do Frete Escolhido: <b>##prazoFrete##</b><br>Valor do Frete: <b>##valorFrete##</b></div>';
                if(data[5] == 'Frete_Gratis'){
                    data[5] = "Frete Grátis";
                }
                htmlFrete = htmlFrete.replace('##tipoFrete##', data[5]);
                if (data[6] >= 2){
                    var diasUteis = " dias úteis";
                }
                else{
                    var diasUteis = " dia útil";
                }
                htmlFrete = htmlFrete.replace('##prazoFrete##', data[6]+diasUteis);
                htmlFrete = htmlFrete.replace('##valorFrete##', data[1]);
                $("#freteValor").html(data[1]+' '+htmlFrete);
                $("#totalCompra").html(data[2]);
                if(data[13] != 0) {
                    var htmlCupomDesconto = '<img src=\'' + url + 'img/informacao.png\' width=\'20\' style=\'cursor:pointer\' onclick=\'abreFecha("informacoesValePresente")\'><div id=\'informacoesValePresente\' style=\'display:none; position:absolute; border:1px solid #e7e7e7; background-color:#FFFFFF; text-align:left; width:350px\'><div style=\'position:absolute; float:left; left:95%; cursor:pointer\' onclick=\'fecha("informacoesValePresente")\'>&times;</div><h3>Informações do Vale Presente</h3>ID do Vale: <b>##idCupom##</b><br>Código do Vale: <b>##codigoCupom##</b><br>Valor do Vale: <b>##valorCupom##</b><br>Validade do Vale: <b>##validadeCupom##</b></div>';
                }
                else if(data[7] != 0) {
                    var htmlCupomDesconto = '<img src=\'' + url + 'img/informacao.png\' width=\'20\' style=\'cursor:pointer\' onclick=\'abreFecha("informacoesCupomDesconto")\'><div id=\'informacoesCupomDesconto\' style=\'display:none; position:absolute; border:1px solid #e7e7e7; background-color:#FFFFFF; text-align:left; width:350px\'><div style=\'position:absolute; float:left; left:95%; cursor:pointer\' onclick=\'fecha("informacoesCupomDesconto")\'>&times;</div><h3>Informações do Cupom de Desconto</h3>ID do Cupom: <b>##idCupom##</b><br>Código do Cupom: <b>##codigoCupom##</b><br>Valor do Cupom: <b>##valorCupom##</b><br>Validade do Cupom: <b>##validadeCupom##</b></div>';
                }
                else{
                    var htmlCupomDesconto = "";
                }
                htmlCupomDesconto = htmlCupomDesconto.replace('##idCupom##', data[8]);
                htmlCupomDesconto = htmlCupomDesconto.replace('##codigoCupom##', data[12]);
                htmlCupomDesconto = htmlCupomDesconto.replace('##valorCupom##', data[10]);
                htmlCupomDesconto = htmlCupomDesconto.replace('##validadeCupom##', data[11]);
                $("#cupomDesconto").html(data[3]+" "+htmlCupomDesconto);
                $("#finalizarCompra").html(data[4]);;
                $("#selecionado").val('1');


            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#freteValor").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
            $("#cupomDesconto").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
            $("#totalCompra").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
            $("#finalizarCompra").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
        }
    });
}
function addListaPresentes(url){
    $("#nomeAniversarianteCadastrar").val('');
    $("#dataAniversarioCadastrar").val('');
    $("#nomeMaeCadastrar").val('');
    $("#nomePaiCadastrar").val('');
    $("#idadeCadastrar").val('');
    $("#cepCadastrar").val('');
    $("#logradouroCadastrar").val('');
    $("#numeroCadastrar").val('');
    $("#complementoCadastrar").val('');
    $("#bairroCadastrar").val('');
    $("#cidadeCadastrar").val('');
    $("#estadoCadastrar").val('');
    $('#addListaPresentes').show('slow');
}
function cadastrarLista(url){
    if ($("#nomeAniversarianteCadastrar").val() == ""){
        alert('Informe o nome do aniversariante corretamente!');
    }
    else if ($("#dataAniversarioCadastrar").val() == ""){
        alert("Informe a data do aniversário corretamente!");
    }
    else if ($("#nomeMaeCadastrar").val() == ""){
        alert("Informe o nome da mãe do aniversariante corretamente!");
    }
    else if ($("#nomePaiCadastrar").val() == ""){
        alert("Informe o nome do pai do aniversariante corretamente!");
    }
    else if ($("#idadeCadastrar").val() == ""){
        alert("Informeo a idade que o aniversariante vai completar corretamente!");
    }
    else if (document.getElementById('cepCadastrar').value.length < 9){
        alert('Informe o cep da entrega corretamente!');
    }
    else if ($("#logradouroCadastrar").val() == ""){
        alert("Informeo o logradouro da entrega corretamente!");
    }
    else if ($("#numeroCadastrar").val() == ""){
        alert("Informeo o número da entrega corretamente!");
    }
    else if ($("#bairroCadastrar").val() == ""){
        alert("Informeo o bairro da entrega corretamente!");
    }
    else if ($("#cidadeCadastrar").val() == ""){
        alert("Informeo a cidade da entrega corretamente!");
    }
    else if ($("#estadoCadastrar").val() == ""){
        alert("Informeo o estado da entrega corretamente!");
    }
    else{
        $.ajax({
            url: url+'ajax.php?&acao=cadastraListaPresentes&nomeAniversariante='+$("#nomeAniversarianteCadastrar").val()+"&dataAniversario="+$("#dataAniversarioCadastrar").val()+"&nomeMae="+$("#nomeMaeCadastrar").val()+"&nomePai="+$("#nomePaiCadastrar").val()+"&idade="+$("#idadeCadastrar").val()+"&cep="+$("#cepCadastrar").val()+"&logradouro="+$("#logradouroCadastrar").val()+"&numero="+$("#numeroCadastrar").val()+"&complemento="+$("#complementoCadastrar").val()+"&bairro="+$("#bairroCadastrar").val()+"&cidade="+$("#cidadeCadastrar").val()+"&estado="+$("#estadoCadastrar").val(),
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    $("#addListaPresentes").hide('fast');
                    listarListaPresentes(url);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#nomeAniversarianteCadastrar").val('Aguarde... Cadastrando...');
                $("#dataAniversarioCadastrar").val('');
                $("#nomeMaeCadastrar").val('Aguarde... Cadastrando...');
                $("#nomePaiCadastrar").val('Aguarde... Cadastrando...');
                $("#idadeCadastrar").val('');
                $("#cepCadastrar").val('Aguarde... Cadastrando...');
                $("#logradouroCadastrar").val('Aguarde... Cadastrando...');
                $("#numeroCadastrar").val('Aguarde... Cadastrando...');
                $("#complementoCadastrar").val('Aguarde... Cadastrando...');
                $("#bairroCadastrar").val('Aguarde... Cadastrando...');
                $("#cidadeCadastrar").val('Aguarde... Cadastrando...');
                $("#estadoCadastrar").val('');
            }
        });
    }
}
function edicaoListaPresentes(url){
    if ($("#nomeAniversarianteEdicao").val() == ""){
        alert('Informe o nome do aniversariante corretamente!');
    }
    else if ($("#dataAniversarioEdicao").val() == ""){
        alert("Informe a data do aniversário corretamente!");
    }
    else if ($("#nomeMaeEdicao").val() == ""){
        alert("Informe o nome da mãe do aniversariante corretamente!");
    }
    else if ($("#nomePaiEdicao").val() == ""){
        alert("Informe o nome do pai do aniversariante corretamente!");
    }
    else if ($("#idadeEdicao").val() == ""){
        alert("Informeo a idade que o aniversariante vai completar corretamente!");
    }
    else if (document.getElementById('cepListaEdicao').value.length < 9){
        alert('Informe o cep da entrega corretamente!');
    }
    else if ($("#logradouroListaEdicao").val() == ""){
        alert("Informeo o logradouro da entrega corretamente!");
    }
    else if ($("#numeroListaEdicao").val() == ""){
        alert("Informeo o número da entrega corretamente!");
    }
    else if ($("#bairroListaEdicao").val() == ""){
        alert("Informeo o bairro da entrega corretamente!");
    }
    else if ($("#cidadeListaEdicao").val() == ""){
        alert("Informeo a cidade da entrega corretamente!");
    }
    else if ($("#estadoListaEdicao").val() == ""){
        alert("Informeo o estado da entrega corretamente!");
    }
    else{
        $.ajax({
    url: url+'ajax.php?&acao=atualizaListaPresentes&id='+$("#idListaEdicao").val()+'&nomeAniversariante='+$("#nomeAniversarianteEdicao").val()+"&dataAniversario="+$("#dataAniversarioEdicao").val()+"&nomeMae="+$("#nomeMaeEdicao").val()+"&nomePai="+$("#nomePaiEdicao").val()+"&idade="+$("#idadeEdicao").val()+"&cep="+$("#cepListaEdicao").val()+"&logradouro="+$("#logradouroListaEdicao").val()+"&numero="+$("#numeroListaEdicao").val()+"&complemento="+$("#complementoListaEdicao").val()+"&bairro="+$("#bairroListaEdicao").val()+"&cidade="+$("#cidadeListaEdicao").val()+"&estado="+$("#estadoListaEdicao").val(),
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    $("#addListaPresentes").hide('fast');
                    listarListaPresentes(url);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#nomeAniversarianteEdicao").val('Aguarde... Atualizando...');
                $("#dataAniversarioEdicao").val('');
                $("#nomeMaeEdicao").val('Aguarde... Atualizando...');
                $("#nomePaiEdicao").val('Aguarde... Atualizando...');
                $("#idadeEdicao").val('');
                $("#cepListaEdicao").val('Aguarde... Atualizando...');
                $("#logradouroListaEdicao").val('Aguarde... Atualizando...');
                $("#numeroListaEdicao").val('Aguarde... Atualizando...');
                $("#complementoListaEdicao").val('Aguarde... Atualizando...');
                $("#bairroListaEdicao").val('Aguarde... Atualizando...');
                $("#cidadeListaEdicao").val('Aguarde... Atualizando...');
                $("#estadoListaEdicao").val('');
            }
        });
    }
}
function cadastrarProdutoLista(id, url){
    if ($("#produtoListaProdutos").val() == ""){
        alert('Informe o produto corretamente!');
    }
    else if ($("#itemVendaListaProdutos").val() == ""){
        alert('Informe o item de venda corretamente!');
    }
    else if ($("#quantidadeProdutoLista").val() == ""){
        alert('Informe a quantidade de produtos que deseja ganhar corretamente!');
    }
    else{
        $.ajax({
            url: url+'ajax.php?&acao=cadastrarProdutoLista&id='+id+"&produto="+$("#produtoListaProdutos").val()+"&itemVenda="+$("#itemVendaListaProdutos").val()+"&quantidade="+$("#quantidadeProdutoLista").val(),
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    $("#produtoListaProdutos").val('');
                    selecionaProdutoListaProdutos(id, url);
                    $("#addProdutoListaPresentes").hide('fast');
                    abreListaPresentes(id, url);

                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
            }
        });
    }
}
function atualizarProdutoLista(id, url){
    if ($("#produtoListaEdicao").val() == ""){
        alert('Informe o produto corretamente!');
    }
    else if ($("#itemVendaListaEdicao").val() == ""){
        alert('Informe o item de venda corretamente!');
    }
    else if ($("#quantidadeListaProdutosEdicao").val() == ""){
        alert('Informe a quantidade de produtos que deseja ganhar corretamente!');
    }
    else{
        $.ajax({
            url: url+'ajax.php?&acao=atualizarProdutoLista&id='+id+"&produto="+$("#produtoListaEdicao").val()+"&itemVenda="+$("#itemVendaListaEdicao").val()+"&quantidade="+$("#quantidadeListaProdutosEdicao").val(),
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    $("#produtoListaEdicao").val('');
                    selecionaProdutoListaProdutos(id, url, '');
                    $("#editaProdutoLista").hide('fast');
                    abreListaPresentes(data[1], url);

                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
            }
        });
    }
}
function selecionaItemVendaProdutoLista(id, url, slug = 'qtdeProdutoListaProdutos'){
    if (id != ''){
        $.ajax({
            url: url+'ajax.php?&acao=selecionaItemVendaProdutoLista&id='+id,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    $("#"+slug).html(data[1]);
                    if (data[2] == 0) {
                        $('#salvarProdutoLista').show('slow');
                        $("#editarProdutoLista").show('slow');
                    }
                    else{
                        $("#$salvarProdutoLista").hide('fast');
                        $("#$editarProdutoLista").hide('fast');
                    }
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#"+slug).show('slow');
                $("#"+slug).html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
            }
        });
    }
    else{
        $("#"+slug).show('slow');
        $("#"+slug).html('Selecione o item de venda corretamente acima!');
    }
}
function editaProdutoLista(id, url){
    $.ajax({
        url: url+'ajax.php?&acao=editaProdutoLista&id='+id,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#editaProdutoLista").html(data[1]);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#editaProdutoLista").show('slow');
            $("#editaProdutoLista").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
        }
    });
}
function selecionaProdutoListaProdutos(id, url, slug = 'itensVendaProdutoListaProdutos', slug2 = ''){
    if (id != ''){
        $.ajax({
            url: url+'ajax.php?&acao=selecionaProdutoListaProdutos&id='+id,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    $("#"+slug).html(data[1]);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#"+slug).show('slow');
                $("#"+slug).html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
                $("#salvarProdutoLista").hide('fast');
                $("#editarProdutoLista").hide('fast');
            }
        });
    }
    else{
        $("#"+slug).show('slow');
        $("#"+slug).html('Selecione o produto corretamente acima!');
    }
}
function abreListaPresentes(id, url){
    $.ajax({
        url: url+'ajax.php?&acao=abreListaPresentes&id='+id,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#listaDePresentes").html(data[1]);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#listaDePresentes").show('slow');
            $("#listaDePresentes").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
        }
    });
}
function editaConvidado(id, url){
    $.ajax({
        url: url+'ajax.php?&acao=editaConvidado&id='+id,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#nomeConvidadoEdita").val(data[1]);
                $("#emailConvidadoEdita").val(data[2]);
                $("#celConvidadoEdita").val(data[3]);
                $("#idEdita").val(id);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
                fecha('editConvidado');
            }
        },
        beforeSend: function () {
            abre('editConvidado');
            $("#nomeConvidadoEdita").val('Aguarde... Carregando...');
            $("#emailConvidadoEdita").val('Aguarde... Carregando...');
            $("#celConvidadoEdita").val('Aguarde... Carregando...');
            $("#idEdita").val('Aguarde... Carregando...');
        }
    });
}
function editaPresente(id, url, produto, qual, i, lista){
    $.ajax({
        url: url+'ajax.php?&acao=editaPresente&id='+id,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#itemProdutoEdita"+qual+i).val(data[2]);
                $("#quantidadePresenteEdita"+qual+i).html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
                selecionaItemProdutoEdita(id, produto, qual, url, i, lista, data[3])
                $("#idEdita"+qual+i).val(data[4]);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
                fecha('editConvidado');
            }
        },
        beforeSend: function () {
            abre('editaPresente'+qual+i);
            $("#itemProdutoEdita"+qual+i).val('');
            $("#quantidadePresenteEdita"+qual+i).html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
            $("#idEdita"+qual+i).val(id);
        }
    });
}
function formataCampo(campo, Mascara, evento) {



    var boleanoMascara;







    var Digitato = evento.keyCode;



    exp = /\-|\.|\/|\(|\)| /g



    campoSoNumeros = campo.value.toString().replace( exp, "" );







    var posicaoCampo = 0;



    var NovoValorCampo="";



    var TamanhoMascara = campoSoNumeros.length;;







    if (Digitato != 8) { // backspace



        for(i=0; i<= TamanhoMascara; i++) {



            boleanoMascara  = ((Mascara.charAt(i) == "-") || (Mascara.charAt(i) == ".")



                || (Mascara.charAt(i) == "/"))



            boleanoMascara  = boleanoMascara || ((Mascara.charAt(i) == "(")



                || (Mascara.charAt(i) == ")") || (Mascara.charAt(i) == " "))



            if (boleanoMascara) {



                NovoValorCampo += Mascara.charAt(i);



                TamanhoMascara++;



            }else {



                NovoValorCampo += campoSoNumeros.charAt(posicaoCampo);



                posicaoCampo++;



            }



        }



        campo.value = NovoValorCampo;



        return true;



    }else {



        return true;



    }



}
function cadastrarConvidado(url){
    if ($("#nomeConvidadoAdd").val() == ''){
        alert('Informe o nome do convidado corretamente!');
    }
    else if (!validateEmail($("#emailConvidadoAdd").val())){
        alert("Informeo o email do convidado corretamente!");
    }
    else if ($("#celConvidadoAdd").val() && document.getElementById("celConvidadoAdd").value.length < 14){
        alert('Informe o celular do convidado corretamente!');
    }
    else{
        $.ajax({
            url: url+'ajax.php?&acao=cadastrarConvidado&idLista='+$("#idListAdd").val()+'&nomeConvidado='+$("#nomeConvidadoAdd").val()+"&emailConvidado="+$("#emailConvidadoAdd").val()+"&celConvidado="+$("#celConvidadoAdd").val(),
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    $("#addConvidado").hide('fast');
                    abreListaConvidados($("#idListAdd").val(), url);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                    $("#nomeConvidadoAdd").val('');
                    $("#emailConvidadoAdd").val('');
                    $("#celConvidadoAdd").val('');
                }
            },
            beforeSend: function () {
                $("#nomeConvidadoAdd").val('Aguarde... Cadastrando...');
                $("#emailConvidadoAdd").val('Aguarde... Cadastrando...');
                $("#celConvidadoAdd").val('Aguarde... Cadastrando...');
            }
        });
    }
}
function atualizarConvidado(url){
    if ($("#nomeConvidadoEdita").val() == ''){
        alert('Informe o nome do convidado corretamente!');
    }
    else if (!validateEmail($("#emailConvidadoEdita").val())){
        alert("Informeo o email do convidado corretamente!");
    }
    else if ($("#celConvidadoEdita").val() && document.getElementById("celConvidadoEdita").value.length < 14){
        alert('Informe o celular do convidado corretamente!');
    }
    else{
        $.ajax({
            url: url+'ajax.php?&acao=atualizarConvidado&idLista='+$("#idListEdita").val()+'&nomeConvidado='+$("#nomeConvidadoEdita").val()+"&emailConvidado="+$("#emailConvidadoEdita").val()+"&celConvidado="+$("#celConvidadoEdita").val()+"&id="+$("#idEdita").val(),
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    $("#editConvidado").hide('fast');
                    abreListaConvidados($("#idListEdita").val(), url);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                    $("#nomeConvidadoEdita").val('');
                    $("#emailConvidadoEdita").val('');
                    $("#celConvidadoEdita").val('');
                }
            },
            beforeSend: function () {
                $("#nomeConvidadoEdita").val('Aguarde... Cadastrando...');
                $("#emailConvidadoEdita").val('Aguarde... Cadastrando...');
                $("#celConvidadoEdita").val('Aguarde... Cadastrando...');
            }
        });
    }
}
function abreListaConvidados(id, url){
    $.ajax({
        url: url+'ajax.php?&acao=abreListaConvidados&id='+id,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#listaDeConvidados").html(data[1]);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#listaDeConvidados").show('slow');
            $("#listaDeConvidados").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
        }
    });
}
function visualizaConvidado(id, url){
    $.ajax({
        url: url+'ajax.php?&acao=visualizaConvidado&id='+id,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#visualizaConvidado").html(data[1]);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#visualizaConvidado").show('slow');
            $("#visualizaConvidado").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
        }
    });
}
function addPresente(produto){
    abre('addPresente'+produto);
    $('#itemProduto'+produto).val('');
    $("#quantidadePresente"+produto).html('');
}
function selecionaItemProduto(id, produto, qual, url, i, lista){
    if (id != ''){
        $("#quantidadePresente"+qual+i).html('<label for="quantityAdd'+qual+i+'">Quantidade: </label><input type="number" name="quantityAdd'+qual+i+'" id="quantityAdd'+qual+i+'" value="1" min="1" max="999999" class="form-control"><div style="text-align: right;"><button class="btn btn-primary" onclick=cadastrarPresente("'+produto+'","'+qual+'","'+url+'","'+i+'","'+lista+'")>Cadastrar</button> <button class="btn btn-danger" onclick=fecha("addPresente'+qual+i+'")>Fechar</button></div>');
    }
    else{
        $("#quantidadePresente"+qual+i).html('<button class="btn btn-danger">Selecione o item do produto acima corretamente!</button>');
    }
}
function selecionaItemProdutoEdita(id, produto, qual, url, i, lista, quantidade = ""){
    if (id != ''){
        var quant = (quantidade != '') ? quantidade : "1";
        $("#quantidadePresenteEdita"+qual+i).html('<label for="quantityEdita'+qual+i+'">Quantidade: </label><input type="number" name="quantityEdita'+qual+i+'" id="quantityEdita'+qual+i+'" value="'+quantidade+'" min="1" max="999999" class="form-control"><div style="text-align: right;"><button class="btn btn-primary" onclick=atualizarPresente("'+produto+'","'+qual+'","'+url+'","'+i+'","'+lista+'")>Atualizar</button> <button class="btn btn-danger" onclick=fecha("editaPresente'+qual+i+'")>Fechar</button></div>');
    }
    else{
        $("#quantidadePresenteEdita"+qual+i).html('<button class="btn btn-danger">Selecione o item do produto acima corretamente!</button>');
    }
}
function cadastrarPresente(produto, qual, url, i, lista){
    if ($("#itemProduto"+qual+i).val() == ""){
        alert('Informe o item do produto corretamente!');
        $("#itemProduto"+produto+qual).focus();
    }
    else if ($("#quantityAdd"+qual+i).val() == "" || $("#quantityAdd"+qual+i).val() <= 0 || $("#quantityAdd"+qual+i).val() > 999999){
        alert('Informe a quantidade desejada corretamente!\nMínimo: 1\nMáximo: 9999999');
        $("#quantityAdd"+produto+qual).focus();
    }
    else{
        $.ajax({
            url: url+'ajax.php?&acao=cadastrarPresenteSite&i='+i+'&produto='+produto+"&qual="+qual+"&itemProduto="+$("#itemProduto"+qual+i).val()+"&quantidade="+$("#quantityAdd"+qual+i).val()+"&lista="+$("#listaAdd"+qual+i).val(),
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    $("#itemProduto"+qual+i).val('');
                    $("#quantidadePresente"+qual+i).html('');
                    fecha('addPresente'+qual+i);
                    adicionarListaPresentes(produto, url, i, qual, lista);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#itemProduto"+qual+i).val('');
                $("#quantidadePresente"+qual+i).html('');
            }
        });
    }
}
function atualizarPresente(produto, qual, url, i, lista){
    if ($("#itemProdutoEdita"+qual+i).val() == ""){
        alert('Informe o item do produto corretamente!');
        $("#itemProdutoEdita"+produto+qual).focus();
    }
    else if ($("#quantityEdita"+qual+i).val() == "" || $("#quantityEdita"+qual+i).val() <= 0 || $("#quantityEdita"+qual+i).val() > 999999){
        alert('Informe a quantidade desejada corretamente!\nMínimo: 1\nMáximo: 9999999');
        $("#quantityEdita"+produto+qual).focus();
    }
    else{
        $.ajax({
            url: url+'ajax.php?&acao=atualizarPresenteSite&i='+i+'&produto='+produto+"&qual="+qual+"&itemProduto="+$("#itemProdutoEdita"+qual+i).val()+"&quantidade="+$("#quantityEdita"+qual+i).val()+"&lista="+$("#listaPresentEdita"+qual+i).val()+"&id="+$("#idEdita"+qual+i).val(),
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    $("#itemProdutoEdita"+qual+i).val('');
                    $("#quantidadePresenteEdita"+qual+i).html('');
                    fecha('editaPresente'+qual+i);
                    adicionarListaPresentes(produto, url, i, qual, lista);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#itemProdutoEdita"+qual+i).val('');
                $("#quantidadePresenteEdita"+qual+i).html('');
            }
        });
    }
}
function excluirPresente(id, url, produto, qual, i, lista){
    if (confirm('Tem certeza que deseja excluir esse presente da sua lista?')){
        $.ajax({
            url: url+'ajax.php?&acao=excluirPresenteSite&id='+id+"&qual="+qual+"&i="+i+"&lista="+lista,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    adicionarListaPresentes(produto, url, i, qual, lista);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#listaPresentes"+qual+i).html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
            }
        });
    }
}
function adicionarListaPresentes(produto, url, i, qual, lista){
    $("#listaPresentes"+qual+i).show('slow');
    location.href="#topoListaPresente"+qual+i;
    $.ajax({
        url: url+'ajax.php?&acao=mostraEdicaoListaPooduto&produto='+produto+"&qual="+qual+"&i="+i+"&lista="+lista,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#listaPresentes"+qual+i).html(data[1]);
                location.href="#topoListaPresente"+qual+i;
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#listaPresentes"+qual+i).html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
        }
    });

}
function excluirProdutoLista(id, url){
    if (confirm("Tem certeza que deseja excluir esse produto dessa lista?")){
        $.ajax({
            url: url+'ajax.php?&acao=excluirProdutoLista&id='+id,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    abreListaPresentes(data[1], url);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
            }
        });
    }
}
function enviarTodosNaoEnviados(id, url){
    if (confirm("Tem certeza que deseja enviar email a todos os status não enviados?")){
        $.ajax({
            url: url+'ajax.php?&acao=enviarTodosNaoEnviados&id='+id,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    abreListaConvidados(data[1], url);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
            }
        });
    }
}
function enviarEmailConvidado(id, url){
    if (confirm("Tem certeza que deseja enviar email a esse convidado?")){
        $.ajax({
            url: url+'ajax.php?&acao=enviarEmailConvidado&id='+id,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    abreListaConvidados(data[1], url);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
            }
        });
    }
}
function excluirConvidado(id, url){
    if (confirm("Tem certeza que deseja excluir esse convidado?")){
        $.ajax({
            url: url+'ajax.php?&acao=excluirConvidado&id='+id,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    abreListaConvidados(data[1], url);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
            }
        });
    }
}
function excluirListaPresentes(id, url){
    if (confirm('Tem certeza que deseja excluir essa lista de presentes e todos os registros dela?')){
        $.ajax({
            url: url+'ajax.php?&acao=excluirListaPresentes&id='+id,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    listarListaPresentes(url);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
            }
        });
    }
}
function adicionarProdutosALista(id, url){
    if (confirm('Tem certeza que deseja adicionar produto à essa lista?')){
        $.ajax({
            url: url+'ajax.php?&acao=adicionarProdutosALista&id='+id,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    listarListaPresentes(url);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
            }
        });
    }
}
function visusalizarListaPresentes(id, url){
    $.ajax({
        url: url+'ajax.php?&acao=visusalizarListaPresentes&id='+id,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#visusalizarListaPresentes").html(data[1]);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#visusalizarListaPresentes").show('slow');
            $("#visusalizarListaPresentes").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
        }
    });
}
function editaListaPresentes(id, url){
    $.ajax({
        url: url+'ajax.php?&acao=editaListaPresentes&id='+id,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#editarListaPresentes").html(data[1]);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#editarListaPresentes").show('slow');
            $("#editarListaPresentes").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
        }
    });
}
function removerDaListaPresentes(id, url){
    if (confirm('Tem certeza que deseja remover seleção da lista?')){
        $.ajax({
            url: url+'ajax.php?&acao=removerDaListaPresentes&id='+id,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    listarListaPresentes(url);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
            }
        });
    }
}
function verificaceplista(valor) {
    //Nova variável "cep" somente com dígitos.
    var cep = valor.replace(/\D/g, '');
    //Verifica se campo cep possui valor informado.
    if (cep.length == 8) {
        //Expressão regular para validar o CEP.
        var validacep = /^[0-9]{8}$/;
        //Valida o formato do CEP.
        if(validacep.test(cep)) {
            //Preenche os campos com "..." enquanto consulta webservice.
            $('#logradouroCadastrar').val("Aguarde... Pesquisando...");
            $('#numeroCadastrar').val("Aguarde... Pesquisando...");
            $('#complementoCadastrar').val("Aguarde... Pesquisando...");
            $('#bairroCadastrar').val("Aguarde... Pesquisando...");
            $('#cidadeCadastrar').val("Aguarde... Pesquisando...");
            $('#estadoCadastrar').val("");
            //Cria um elemento javascript.
            var script = document.createElement('script');
            //Sincroniza com o callback.
            script.src = '//viacep.com.br/ws/'+ cep + '/json/?callback=retornoCEPLista';
            //Insere script no documento e carrega o conteúdo.
            document.body.appendChild(script);
        } //end if.
        else {
            //cep é inválido.
            alert("Formato de CEP inválido.");
            $('#logradouroCadastrar').val("");
            $('#numeroCadastrar').val("");
            $('#complementoCadastrar').val("");
            $('#bairroCadastrar').val("");
            $('#cidadeCadastrar').val("");
            $('#estadoCadastrar').val("");
            $('#logradouroCadastrar').focus();
        }
    } //end if.
    else {
        //cep sem valor, limpa formulário.
    }
};
function retornoCEPLista(conteudo) {
    if (!("erro" in conteudo)) {
        //Atualiza os campos com os valores.
        $('#logradouroCadastrar').val(conteudo.logradouro);
        $('#numeroCadastrar').val("");
        $('#complementoCadastrar').val("");
        $('#bairroCadastrar').val(conteudo.bairro);
        $('#cidadeCadastrar').val(conteudo.localidade);
        $('#estadoCadastrar').val(conteudo.uf);
        $('#numeroCadastrar').focus();
    } //end if.
    else {
        //CEP não Encontrado.
        alert("CEP não encontrado. Digeite as informações manualmente!");
        document.getElementById('logradouroCadastrar').value="";
        document.getElementById('bairroCadastrar').value="";
        document.getElementById('numeroCadastrar').value="";
        document.getElementById('complementoCadastrar').value="";
        document.getElementById('cidadeCadastrar').value="";
        document.getElementById('estadoCadastrar').value="";
        document.getElementById('logradouroCadastrar').focus();
    }
}function pesquisacependerecoedicaolista(valor) {
    //Nova variável "cep" somente com dígitos.
    var cep = valor.replace(/\D/g, '');
    //Verifica se campo cep possui valor informado.
    if (cep.length == 8) {
        //Expressão regular para validar o CEP.
        var validacep = /^[0-9]{8}$/;
        //Valida o formato do CEP.
        if(validacep.test(cep)) {
            //Preenche os campos com "..." enquanto consulta webservice.
            $('#logradouroListaEdicao').val("Aguarde... Pesquisando...");
            $('#numeroListaEdicao').val("Aguarde... Pesquisando...");
            $('#complementoListaEdicao').val("Aguarde... Pesquisando...");
            $('#bairroListaEdicao').val("Aguarde... Pesquisando...");
            $('#cidadeListaEdicao').val("Aguarde... Pesquisando...");
            $('#estadoListaEdicao').val("");
            //Cria um elemento javascript.
            var script = document.createElement('script');
            //Sincroniza com o callback.
            script.src = '//viacep.com.br/ws/'+ cep + '/json/?callback=retornoCEPListaEdicao';
            //Insere script no documento e carrega o conteúdo.
            document.body.appendChild(script);
        } //end if.
        else {
            //cep é inválido.
            alert("Formato de CEP inválido.");
            $('#logradouroListaEdicao').val("");
            $('#numeroListaEdicao').val("");
            $('#complementoListaEdicao').val("");
            $('#bairroListaEdicao').val("");
            $('#cidadeListaEdicao').val("");
            $('#estadoListaEdicao').val("");
            $('#logradouroListaEdicao').focus();
        }
    } //end if.
    else {
        //cep sem valor, limpa formulário.
    }
};
function retornoCEPListaEdicao(conteudo) {
    if (!("erro" in conteudo)) {
        //Atualiza os campos com os valores.
        $('#logradouroListaEdicao').val(conteudo.logradouro);
        $('#numeroListaEdicao').val("");
        $('#complementoListaEdicao').val("");
        $('#bairroListaEdicao').val(conteudo.bairro);
        $('#cidadeListaEdicao').val(conteudo.localidade);
        $('#estadoListaEdicao').val(conteudo.uf);
        $('#numeroListaEdicao').focus();
    } //end if.
    else {
        //CEP não Encontrado.
        alert("CEP não encontrado. Digeite as informações manualmente!");
        document.getElementById('logradouroListaEdicao').value="";
        document.getElementById('numeroListaEdicao').value="";
        document.getElementById('complementoEdicao').value="";
        document.getElementById('bairroEdicao').value="";
        document.getElementById('cidadeEdicao').value="";
        document.getElementById('estadoEdicao').value="";
        document.getElementById('logradouroEdicao').focus();
    }
}
function selecionaFormaPagamento(id, url){
    $("#idFormaPagamento").val(id);
    if ($("#totalValor").val() != '') {
        $.ajax({
            url: url + 'ajax.php?&acao=mostraParcelamento&id=' + id + "&valorTotal=" + $("#totalValor").val(),
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    $("#parcelamentos").html(data[1]);
                } else if (data[0] == 0) {
                    alert('Erro: ' + data[1]);
                }
            },
            beforeSend: function () {
                $("#parcelamentos").html('<img src="' + url + 'img/loader.gif" width="20"> Aguarde... Carregando...');
            }
        });
    }
}
function mostraComprovante(request_id, client, url){
    $.ajax({
        url: url + 'ajax.php?&acao=mostra_comprovante&request_id=' + request_id+"&client="+client,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                if (data[1] == 'naoEClienteCompra'){
                    alert('Você não é o cliente dessa compra! Não pode visualizar as compras de outros clientes!');
                    location.href = url;
                }
                else {
                    $("#comprovanteCompra").html(data[1]);
                }
            } else if (data[0] == 0) {
                alert('Erro: ' + data[1]);
            }
        },
        beforeSend: function () {
            $("#comprovanteCompra").html('<h3><img src="' + url + 'img/loader.gif" width="20"> Aguarde... Carregando Comprovante...</h3>');
        }
    });
}
function selecionaParcelamento(id, url){
    $("#parcelamento").val(id);
}
function finalizarOrcamento2(desconto, url){
    $.ajax({
        url: url + 'ajax.php?&acao=finalizarOrcamento&desconto='+desconto,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                location.href=url+"comprovante-de-orcamento/"+data[1];
            } else if (data[0] == 0) {
                alert('Erro: ' + data[1]);
            }
        },
        beforeSend: function () {
            $("#aguardeCarregando").show('slow');
        }
    });
}
function finalizarOrcamento(url){
    if (confirm('Tem certeza que deseja finalizar esse orçamento? Você terá que levá-lo até a loja em nosso endereço físico.')){
	    location.href=url+"finalizar-orcamento";
    }
}
function alteraEnderecoEntrega(id, cep, peso, altura, largura, comprimento, diametro, valorTotal, produtos, vale_presentes, valorDesconto, tipoFrete, valorCarrinho, url){
    $.ajax({
        url: url+'ajax.php?&acao=alteraEnderecoEntrega&id='+id+'&cep=' + cep+'&peso='+peso+'&altura=' + altura+'&largura=' + largura+'&comprimento=' + comprimento+"&diametro="+diametro+"&valorTotal="+valorTotal+"&produtos="+produtos+"&vale_presentes="+vale_presentes+"&valorDesconto="+valorDesconto+"&tipoFrete="+tipoFrete+"&valorCarrinho="+valorCarrinho,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#enderecosEntrega").html(data[1]);
                if (data[5] == 0){
                    $('#freteValor').val('- R$ 0,00');
                }
                else {
                    $("#freteValor").html("+ R$ " + data[5]);
                }
                $("#desconto").html("- R$ "+data[6]);
                $("#totalCompra").html("R$ "+data[7]);
                $("#enderecoEscolhido").val(data[8]);
                $("#valorFrete").val(data[5]);
                $("#cupomDescontoValor").val(data[6]);
                $("#totalValor").val(data[7]);
                $("#fretePrazo").val(data[10]);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#enderecosEntrega").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
            $("#freteValor").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
            $("#desconto").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
            $("#totalCompra").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
        }
    });
}
function calculaFrete(cep, peso, altura, largura, comprimento, diametro, valorTotal, produtos, vale_presentes, valorCarrinho, url){
    if (cep.length == 9) {
        $.ajax({
            url: url+'ajax.php?&acao=calculaFrete&cep=' + cep+'&peso='+peso+'&altura=' + altura+'&largura=' + largura+'&comprimento=' + comprimento+"&diametro="+diametro+"&valorTotal="+valorTotal+"&produtos="+produtos+"&vale_presentes="+vale_presentes+"&valorCarrinho="+valorCarrinho,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    var htmlFrete = '<img src=\''+url+'img/informacao.png\' width=\'20\' style=\'cursor:pointer\' onclick=\'abreFecha("informacoesFrete")\'><div id=\'informacoesFrete\' style=\'display:none; position:absolute; border:1px solid #e7e7e7; background-color:#FFFFFF; text-align:left; width:350px\'><div style=\'position:absolute; float:left; left:95%; cursor:pointer\' onclick=\'fecha("informacoesFrete")\'>&times;</div><h3>Informações do Frete</h3>Tipo de Frete Escolhido: <b>##tipoFrete##</b><br>Prazo do Frete Escolhido: <b>##prazoFrete##</b><br>Valor do Frete: <b>##valorFrete##</b></div>';
                    if(data[4] == 'Frete_Gratis'){
                        data[4] = "Frete Grátis";
                    }
                    htmlFrete = htmlFrete.replace('##tipoFrete##', data[4]);
                    if (data[10] >= 2){
                        var diasUteis = " dias úteis";
                    }
                    else{
                        var diasUteis = " dia útil";
                    }
                    htmlFrete = htmlFrete.replace('##prazoFrete##', data[10]+diasUteis);
                    htmlFrete = htmlFrete.replace('##valorFrete##', "R$"+data[5]);
                    $("#freteCarrinho").html(data[1]);
                    if (data[5] == 0){
                        $('#freteValor').val('- R$ 0,00'+" "+htmlFrete);
                    }
                    else {
                        $("#freteValor").html("+ R$ " + data[5]+" "+htmlFrete);
                    }
                    $("#valorFrete").val(data[5]);
                    if(data[15]) {
                        var htmlCupomDesconto = '<img src=\'' + url + 'img/informacao.png\' width=\'20\' style=\'cursor:pointer\' onclick=\'abreFecha("informacoesValePresente")\'><div id=\'informacoesValePresente\' style=\'display:none; position:absolute; border:1px solid #e7e7e7; background-color:#FFFFFF; text-align:left; width:350px\'><div style=\'position:absolute; float:left; left:95%; cursor:pointer\' onclick=\'fecha("informacoesValePresente")\'>&times;</div><h3>Informações do Vale Presente</h3>ID do Vale: <b>##idCupom##</b><br>Código do Vale: <b>##codigoCupom##</b><br>Valor do Vale: <b>##valorCupom##</b><br>Validade do Vale: <b>##validadeCupom##</b></div>';
                    }
                    else if(data[8]) {
                        var htmlCupomDesconto = '<img src=\'' + url + 'img/informacao.png\' width=\'20\' style=\'cursor:pointer\' onclick=\'abreFecha("informacoesCupomDesconto")\'><div id=\'informacoesCupomDesconto\' style=\'display:none; position:absolute; border:1px solid #e7e7e7; background-color:#FFFFFF; text-align:left; width:350px\'><div style=\'position:absolute; float:left; left:95%; cursor:pointer\' onclick=\'fecha("informacoesCupomDesconto")\'>&times;</div><h3>Informações do Cupom de Desconto</h3>ID do Cupom: <b>##idCupom##</b><br>Código do Cupom: <b>##codigoCupom##</b><br>Valor do Cupom: <b>##valorCupom##</b><br>Validade do Cupom: <b>##validadeCupom##</b></div>';
                    }
                    else{
                        var htmlCupomDesconto = "";
                    }
                    htmlCupomDesconto = htmlCupomDesconto.replace('##idCupom##', data[11]);
                    htmlCupomDesconto = htmlCupomDesconto.replace('##codigoCupom##', data[8]);
                    htmlCupomDesconto = htmlCupomDesconto.replace('##valorCupom##', data[13]);
                    htmlCupomDesconto = htmlCupomDesconto.replace('##validadeCupom##', data[14]);
                    $("#cupomDesconto").html("- R$ "+data[6]+" "+htmlCupomDesconto);
                    $("#cupomDescontoValor").val(data[6]);
                    $("#totalCompra").html("R$ "+data[7]);
                    $("#totalValor").val(data[7]);
                    $("#cupomDescontoCodigo").val(data[8]);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#freteCarrinho").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
            }
        });
    }
}
function aumentaQuantidade(quantidadeAtual, product, product_item, url, maximo, minimo){
    quantidadeAtual = parseInt(quantidadeAtual);
    maximo = parseInt(maximo);
    minimo = parseInt(minimo);
    if (quantidadeAtual < maximo){
        $.ajax({
            url: url+'ajax.php?&acao=aumentaQuantidade&quantidadeAtual=' + quantidadeAtual+'&product=' + product+'&product_item=' + product_item+'&maximo=' + maximo+"&minimo="+minimo,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    $("#valorProduto").html(data[1]);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#valorProduto").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
            }
        });
    }
}
function aumentaQuantidadeCarrinho(idCarrinho, url, estoque){
    quantidadeAtual = $('#quantity'+idCarrinho).val();
    estoque = parseInt(quantidadeAtual) + parseInt(estoque);
    quantidadeQuer = parseInt(quantidadeAtual) + 1;
    if (quantidadeQuer < estoque){
        $.ajax({
            url: url+'ajax.php?&acao=aumentaQuantidadeCarrinho&quantidadeAtual=' + quantidadeAtual+'&id=' + idCarrinho+"&estoque="+estoque,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    alert('Quantidade atualizada com sucesso. Aguarde o refresh da página!');
                    location.href=url+"carrinho";
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#valorProduto").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
            }
        });
    }
}
function diminuiQuantidade(quantidadeAtual, product, product_item, url, minimo, maximo){
    quantidadeAtual = parseInt(quantidadeAtual);
    maximo = parseInt(maximo);
    minimo = parseInt(minimo);
    if (quantidadeAtual > minimo){
        $.ajax({
            url: url+'ajax.php?&acao=diminuiQuantidade&quantidadeAtual=' + quantidadeAtual+'&product=' + product+'&product_item=' + product_item+'&maximo=' + maximo+"&minimo="+minimo,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    $("#valorProduto").html(data[1]);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#valorProduto").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
            }
        });
    }
}
function diminuiQuantidadeCarrinho(idCarrinho, url, estoque){
    quantidadeAtual =  $('#quantity'+idCarrinho).val();
    estoque = parseInt(quantidadeAtual) + parseInt(estoque);
    quantidadeQuer = parseInt(estoque) - 1;
    if (quantidadeAtual > 1){
        $.ajax({
            url: url+'ajax.php?&acao=diminuiQuantidadeCarrinho&quantidadeAtual=' + quantidadeAtual+'&id=' + idCarrinho+"&estoque="+estoque,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    alert('Quantidade atualizada com sucesso. Aguarde o refresh da página!');
                    location.href=url+"carrinho";
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#valorProduto").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
            }
        });
    }
}
function paginacaoComentariosProduto(pag, pags, product, url){
	$.ajax({
		url: url+'ajax.php?&acao=paginacaoComentariosProduto&pag=' + pag+'&pags='+pags+"&product="+product,
		success: function (data) {
			var data = data.split('|-|');
			if (data[0] == 1) {
				$("#pagEstaComentariosProduto").val(data[1]);
				$("#comentarios").html(data[2]);
				$("#numeroComentarios").html(data[3]);
			} else if (data[0] == 0) {
				alert('Erro: '+data[1]);
			}
		},
		beforeSend: function () {
			$("#comentarios").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
			$("#numeroComentarios").html('<img src="'+url+'img/loader.gif" height="20">  Aguarde... Carregando...');
		}
	});
}
function deletarProduto(id, url){
    if (confirm('Tem certeza que deseja excluir esse produto do seu carrinho?')){
        $.ajax({
            url: url+'ajax.php?&acao=deletarProduto&id=' + id,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    alert('Ptoduto excluído com sucesso. Aguarde o refresh da página!');
                    location.href=url+"carrinho";
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#valorProduto").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
            }
        });
    }
}
function pegarProduto(idProduto, url){
    $.ajax({
        url: url+'ajax.php?&acao=pegarProduto&id=' + idProduto,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                location.href=data[1];
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        }
    });
}
function mostraFoto(foto, id, url){
    $("#fotoProduto").html("<img src='"+url+"storage/"+foto+"' style='cursor:pointer' onclick=abreImagemProduto('"+id+"','"+url+"'); data-toggle='modal' data-target='#modal-fotos'>");
}
function marcarNota(nota, url){
    var html = "<b>Nota: </b> ";
    for (i = 1; i <= nota; i++){
        html += "<img src='"+url+"img/star.png' style='cursor:pointer;' title='Nota "+i+"' onclick=marcarNota('"+i+"','"+url+"')> ";
    }
    if (nota < 5){
        j = parseInt(nota) + 1;
        for (i = j; i <= 5; i++){
            html += "<img src='"+url+"img/starApagada.png' style='cursor:pointer;' title='Nota "+i+"' onclick=marcarNota('"+i+"','"+url+"')> ";
        }
    }
    $("#notaComentario").html(html);
    $("#nota").val(nota);
}
function fechaTodos() {
    $("#modalloja-virtual").hide('fast');
    $("#modalsites").hide('fast');
    $("#modalsites-internacionais").hide('fast');
    $("#modalsistema-escolar").hide('fast');
    $("#modalsistema-de-caixa").hide('fast');
    $("#modalcatalogo-virtual").hide('fast');
    $("#modalhospedagem-de-sites").hide('fast');
    $("#modalregistro-de-dominios").hide('fast');
    $("#modalaplicativos-para-celular").hide('fast');
    $("#modalvideos").hide('fast');
}
function pesquisacep(valor, id) {
    //Nova variável "cep" somente com dígitos.
    var cep = valor.replace(/\D/g, '');
    //Verifica se campo cep possui valor informado.
    if (cep.length == 8) {
        //Expressão regular para validar o CEP.
        var validacep = /^[0-9]{8}$/;
        //Valida o formato do CEP.
        if(validacep.test(cep)) {
            //Preenche os campos com "..." enquanto consulta webservice.
            document.getElementById('logradouroEndereco').value="Aguarde... Pesquisando...";
            document.getElementById('numeroEndereco').value="Aguarde... Pesquisando...";
            document.getElementById('complementoEndereco').value="Aguarde... Pesquisando...";
            document.getElementById('bairroEndereco').value="Aguarde... Pesquisando...";
            document.getElementById('cidadeEndereco').value="Aguarde... Pesquisando...";
            document.getElementById('estadoEndereco').value="";
            //Cria um elemento javascript.
            var script = document.createElement('script');
            //Sincroniza com o callback.
            script.src = '//viacep.com.br/ws/'+ cep + '/json/?callback=retornoCEP';
            //Insere script no documento e carrega o conteúdo.
            document.body.appendChild(script);
        } //end if.
        else {
            //cep é inválido.
            alert("Formato de CEP inválido.");
            document.getElementById('logradouroEndereco').value="";
            document.getElementById('bairroEndereco').value="";
            document.getElementById('numeroEndereco').value="";
            document.getElementById('complementoEndereco').value="";
            document.getElementById('cidadeEndereco').value="";
            document.getElementById('estadoEndereco').value="";
            document.getElementById('logradouroEndereco').focus();
        }
    } //end if.
    else {
        //cep sem valor, limpa formulário.
    }
};
function retornoCEP(conteudo) {
    if (!("erro" in conteudo)) {
        //Atualiza os campos com os valores.
        document.getElementById('logradouroEndereco').value=(conteudo.logradouro);
        document.getElementById('bairroEndereco').value=(conteudo.bairro);
        document.getElementById('numeroEndereco').value="";
        document.getElementById('complementoEndereco').value="";
        document.getElementById('cidadeEndereco').value=(conteudo.localidade);
        document.getElementById('estadoEndereco').value=(conteudo.uf);
        document.getElementById('numeroEndereco').focus();
    } //end if.
    else {
        //CEP não Encontrado.
        alert("CEP não encontrado. Digeite as informações manualmente!");
        document.getElementById('logradouroEndereco').value="";
        document.getElementById('bairroEndereco').value="";
        document.getElementById('numeroEndereco').value="";
        document.getElementById('complementoEndereco').value="";
        document.getElementById('cidadeEndereco').value="";
        document.getElementById('estadoEndereco').value="";
        document.getElementById('logradouroEndereco').focus();
    }
}
function pesquisacependerecocadastro(valor, id) {
    //Nova variável "cep" somente com dígitos.
    var cep = valor.replace(/\D/g, '');
    //Verifica se campo cep possui valor informado.
    if (cep.length == 8) {
        //Expressão regular para validar o CEP.
        var validacep = /^[0-9]{8}$/;
        //Valida o formato do CEP.
        if(validacep.test(cep)) {
            //Preenche os campos com "..." enquanto consulta webservice.
            document.getElementById('logradouroCadastro').value="Aguarde... Pesquisando...";
            document.getElementById('numeroCadastro').value="Aguarde... Pesquisando...";
            document.getElementById('complementoCadastro').value="Aguarde... Pesquisando...";
            document.getElementById('bairroCadastro').value="Aguarde... Pesquisando...";
            document.getElementById('cidadeCadastro').value="Aguarde... Pesquisando...";
            document.getElementById('estadoCadastro').value="";
            document.getElementById('paisCadastro').value="";
            //Cria um elemento javascript.
            var script = document.createElement('script');
            //Sincroniza com o callback.
            script.src = '//viacep.com.br/ws/'+ cep + '/json/?callback=retornoCEPEnderecoCadastro';
            //Insere script no documento e carrega o conteúdo.
            document.body.appendChild(script);
        } //end if.
        else {
            //cep é inválido.
            alert("Formato de CEP inválido.");
            document.getElementById('logradouroCadastro').value="";
            document.getElementById('bairroCadastro').value="";
            document.getElementById('numeroCadastro').value="";
            document.getElementById('complementoCadastro').value="";
            document.getElementById('cidadeCadastro').value="";
            document.getElementById('estadoCadastro').value="";
            document.getElementById('paisCadastro').value="";
            document.getElementById('logradouroCadastro').focus();
        }
    } //end if.
    else {
        //cep sem valor, limpa formulário.
    }
};
function pesquisacependerecoedicao(valor, id) {
    //Nova variável "cep" somente com dígitos.
    var cep = valor.replace(/\D/g, '');
    //Verifica se campo cep possui valor informado.
    if (cep.length == 8) {
        //Expressão regular para validar o CEP.
        var validacep = /^[0-9]{8}$/;
        //Valida o formato do CEP.
        if(validacep.test(cep)) {
            //Preenche os campos com "..." enquanto consulta webservice.
            document.getElementById('logradouroEdicao').value="Aguarde... Pesquisando...";
            document.getElementById('numeroEdicao').value="Aguarde... Pesquisando...";
            document.getElementById('complementoEdicao').value="Aguarde... Pesquisando...";
            document.getElementById('bairroEdicao').value="Aguarde... Pesquisando...";
            document.getElementById('cidadeEdicao').value="Aguarde... Pesquisando...";
            document.getElementById('estadoEdicao').value="";
            document.getElementById('paisEdicao').value="";
            //Cria um elemento javascript.
            var script = document.createElement('script');
            //Sincroniza com o callback.
            script.src = '//viacep.com.br/ws/'+ cep + '/json/?callback=retornoCEPEnderecoEdicao';
            //Insere script no documento e carrega o conteúdo.
            document.body.appendChild(script);
        } //end if.
        else {
            //cep é inválido.
            alert("Formato de CEP inválido.");
            document.getElementById('logradouroEdicao').value="";
            document.getElementById('numeroEdicao').value="";
            document.getElementById('numeroEdicao').value="";
            document.getElementById('complementoEdicao').value="";
            document.getElementById('bairroEdicao').value="";
            document.getElementById('cidadeEdicao').value="";
            document.getElementById('estadoEdicao').value="";
            document.getElementById('numeroEdicao').focus();
        }
    } //end if.
    else {
        //cep sem valor, limpa formulário.
    }
};
function retornoCEPEnderecoCadastro(conteudo) {
    if (!("erro" in conteudo)) {
        //Atualiza os campos com os valores.
        document.getElementById('logradouroCadastro').value=(conteudo.logradouro);
        document.getElementById('bairroCadastro').value=(conteudo.bairro);
        document.getElementById('numeroCadastro').value="";
        document.getElementById('complementoCadastro').value="";
        document.getElementById('cidadeCadastro').value=(conteudo.localidade);
        document.getElementById('estadoCadastro').value=(conteudo.uf);
        document.getElementById('paisCadastro').value="1";
        document.getElementById('numeroCadastro').focus();
    } //end if.
    else {
        //CEP não Encontrado.
        alert("CEP não encontrado. Digeite as informações manualmente!");
        document.getElementById('logradouroCadastro').value="";
        document.getElementById('bairroCadastro').value="";
        document.getElementById('numeroCadastro').value="";
        document.getElementById('complementoCadastro').value="";
        document.getElementById('cidadeCadastro').value="";
        document.getElementById('estadoCadastro').value="";
        document.getElementById('paisCadastro').value="";
        document.getElementById('logradouroCadastro').focus();
    }
}
function retornoCEPEnderecoEdicao(conteudo) {
    if (!("erro" in conteudo)) {
        //Atualiza os campos com os valores.
        document.getElementById('logradouroEdicao').value=(conteudo.logradouro);
        document.getElementById('bairroEdicao').value=(conteudo.bairro);
        document.getElementById('numeroEdicao').value="";
        document.getElementById('complementoEdicao').value="";
        document.getElementById('cidadeEdicao').value=(conteudo.localidade);
        document.getElementById('estadoEdicao').value=(conteudo.uf);
        document.getElementById('paisEdicao').value="1";
        document.getElementById('numeroEdicao').focus();
    } //end if.
    else {
        //CEP não Encontrado.
        alert("CEP não encontrado. Digeite as informações manualmente!");
        document.getElementById('logradouroEdicao').value="";
        document.getElementById('bairroEdicao').value="";
        document.getElementById('numeroEdicao').value="";
        document.getElementById('complementoEdicao').value="";
        document.getElementById('cidadeEdicao').value="";
        document.getElementById('estadoEdicao').value="";
        document.getElementById('paisEdicao').value="";
        document.getElementById('logradouroEdicao').focus();
    }
}
function pesquisacepRealizarPedido(valor) {
    //Nova variável "cep" somente com dígitos.
    var cep = valor.replace(/\D/g, '');
    //Verifica se campo cep possui valor informado.
    if (cep.length == 8) {
        //Expressão regular para validar o CEP.
        var validacep = /^[0-9]{8}$/;
        //Valida o formato do CEP.
        if(validacep.test(cep)) {
            //Preenche os campos com "..." enquanto consulta webservice.
            document.getElementById('logadouroRealizarPedido').value="Aguarde... Pesquisando...";
            document.getElementById('numeroRealizarPedido').value="Aguarde... Pesquisando...";
            document.getElementById('complementoRealizarPedido').value="Aguarde... Pesquisando...";
            document.getElementById('bairroRealizarPedido').value="Aguarde... Pesquisando...";
            document.getElementById('cidadeRealizarPedido').value="Aguarde... Pesquisando...";
            document.getElementById('estadoRealizarPedido').value="";
            //Cria um elemento javascript.
            var script = document.createElement('script');
            //Sincroniza com o callback.
            script.src = '//viacep.com.br/ws/'+ cep + '/json/?callback=retornoCEPRealizarPedido';
            //Insere script no documento e carrega o conteúdo.
            document.body.appendChild(script);
        } //end if.
        else {
            //cep é inválido.
            alert("Formato de CEP inválido.");
            document.getElementById('logadouroRealizarPedido').value="";
            document.getElementById('bairroRealizarPedido').value="";
            document.getElementById('numeroRealizarPedido').value="";
            document.getElementById('complementoRealizarPedido').value="";
            document.getElementById('cidadeRealizarPedido').value="";
            document.getElementById('estadoRealizarPedido').value="";
            document.getElementById('logradouroRealizarPedido').focus();
        }
    } //end if.
    else {
        //cep sem valor, limpa formulário.
    }
};
function retornoCEPRealizarPedido(conteudo) {
    if (!("erro" in conteudo)) {
        //Atualiza os campos com os valores.
        document.getElementById('logadouroRealizarPedido').value=(conteudo.logradouro);
        document.getElementById('bairroRealizarPedido').value=(conteudo.bairro);
        document.getElementById('numeroRealizarPedido').value="";
        document.getElementById('complementoRealizarPedido').value="";
        document.getElementById('cidadeRealizarPedido').value=(conteudo.localidade);
        document.getElementById('estadoRealizarPedido').value=(conteudo.uf);
        document.getElementById('numeroRealizarPedido').focus();
    } //end if.
    else {
        //CEP não Encontrado.
        alert("CEP não encontrado. Digeite as informações manualmente!");
        document.getElementById('logadouroRealizarPedido').value="";
        document.getElementById('bairroRealizarPedido').value="";
        document.getElementById('numeroRealizarPedido').value="";
        document.getElementById('complementoRealizarPedido').value="";
        document.getElementById('cidadeRealizarPedido').value="";
        document.getElementById('estadoRealizarPedido').value="";
        document.getElementById('logradouroRealizarPedido').focus();
    }
}
function pesquisacepEscolaRealizarPedido(valor) {
    //Nova variável "cep" somente com dígitos.
    var cep = valor.replace(/\D/g, '');
    //Verifica se campo cep possui valor informado.
    if (cep.length == 8) {
        //Expressão regular para validar o CEP.
        var validacep = /^[0-9]{8}$/;
        //Valida o formato do CEP.
        if(validacep.test(cep)) {
            //Preenche os campos com "..." enquanto consulta webservice.
            document.getElementById('logadouroEscolaRealizarPedido').value="Aguarde... Pesquisando...";
            document.getElementById('numeroEscolaRealizarPedido').value="Aguarde... Pesquisando...";
            document.getElementById('complementoEscolaRealizarPedido').value="Aguarde... Pesquisando...";
            document.getElementById('bairroEscolaRealizarPedido').value="Aguarde... Pesquisando...";
            document.getElementById('cidadeEscolaRealizarPedido').value="Aguarde... Pesquisando...";
            document.getElementById('estadoEscolaRealizarPedido').value="";
            //Cria um elemento javascript.
            var script = document.createElement('script');
            //Sincroniza com o callback.
            script.src = '//viacep.com.br/ws/'+ cep + '/json/?callback=retornoCEPEscolaRealizarPedido';
            //Insere script no documento e carrega o conteúdo.
            document.body.appendChild(script);
        } //end if.
        else {
            //cep é inválido.
            alert("Formato de CEP inválido.");
            document.getElementById('logadouroEscolaRealizarPedido').value="";
            document.getElementById('bairroEscolaRealizarPedido').value="";
            document.getElementById('numeroEscolaRealizarPedido').value="";
            document.getElementById('complementoEscolaRealizarPedido').value="";
            document.getElementById('cidadeEscolaRealizarPedido').value="";
            document.getElementById('estadoEscolaRealizarPedido').value="";
            document.getElementById('logradouroEscolaRealizarPedido').focus();
        }
    } //end if.
    else {
        //cep sem valor, limpa formulário.
    }
};
function retornoCEPEscolaRealizarPedido(conteudo) {
    if (!("erro" in conteudo)) {
        //Atualiza os campos com os valores.
        document.getElementById('logadouroEscolaRealizarPedido').value=(conteudo.logradouro);
        document.getElementById('bairroEscolaRealizarPedido').value=(conteudo.bairro);
        document.getElementById('numeroEscolaRealizarPedido').value="";
        document.getElementById('complementoEscolaRealizarPedido').value="";
        document.getElementById('cidadeEscolaRealizarPedido').value=(conteudo.localidade);
        document.getElementById('estadoEscolaRealizarPedido').value=(conteudo.uf);
        document.getElementById('numeroEscolaRealizarPedido').focus();
    } //end if.
    else {
        //CEP não Encontrado.
        alert("CEP não encontrado. Digeite as informações manualmente!");
        document.getElementById('logadouroEscolaRealizarPedido').value="";
        document.getElementById('bairroEscolaRealizarPedido').value="";
        document.getElementById('numeroEscolaRealizarPedido').value="";
        document.getElementById('complementoEscolaRealizarPedido').value="";
        document.getElementById('cidadeEscolaRealizarPedido').value="";
        document.getElementById('estadoEscolaRealizarPedido').value="";
        document.getElementById('logradouroEscolaRealizarPedido').focus();
    }
}
function selecionaTipoEstabelecimento(id){
    if (id == ''){
        $('#tiposEstabelecimentoRealizarPedido').html('Selecione o tipo do estabelecimento acima...');
    }
    else{
        var html = "";
        if (id == 1){
            html += '<label for="quantidadeRealizarPedido">Quantidade de Mesas do Estabelecimento</label>' +
                '<input type="number" id="quantidadeRealizarPedido" name="quantidadeRealizarPedido" class="form-control" required placeholder="Informe a quantidade de mesas do estabelecimento...">' +
                '<label for="numPessoasRealizarPedido">Número de Pessoas por Mesa do Estabelecimento</label>' +
                '<input type="number" id="numPessoasRealizarPedido" name="numPessoasRealizarPedido" class="form-control" required placeholder="Informe número de pessoas por mesa do estabelecimento...">' +
                '<label for="perGarcomRealizarPedido">Percentual do Garçom do Estabelecimento (em %)</label>' +
                '<input type="number" id="perGarcomRealizarPedido" name="perGarcomRealizarPedido" class="form-control" required placeholder="Percentual do garçom do estabelecimento (em %)...">';
        }
        else{
            html += '<label for="quantidade">Quantidade de Caixas do Estabelecimento</label>' +
                '<input type="number" id="quantidadeRealizarPedido" name="quantidadeRealizarPedido" class="form-control" required placeholder="Informe a quantidade de caixas do estabelecimento...">';
        }
        $('#tiposEstabelecimentoRealizarPedido').html(html);
    }
}
function pesquisacepedit(valor, id) {
    //Nova variável "cep" somente com dígitos.
    var cep = valor.replace(/\D/g, '');
    //Verifica se campo cep possui valor informado.
    if (cep.length == 8) {
        //Expressão regular para validar o CEP.
        var validacep = /^[0-9]{8}$/;
        //Valida o formato do CEP.
        if(validacep.test(cep)) {
            //Preenche os campos com "..." enquanto consulta webservice.
            document.getElementById('logradouroEditaEndereco').value="Aguarde... Pesquisando...";
            document.getElementById('numeroEditaEndereco').value="Aguarde... Pesquisando...";
            document.getElementById('complementoEditaEndereco').value="Aguarde... Pesquisando...";
            document.getElementById('bairroEditaEndereco').value="Aguarde... Pesquisando...";
            document.getElementById('cidadeEditaEndereco').value="Aguarde... Pesquisando...";
            document.getElementById('estadoEditaEndereco').value="";
            //Cria um elemento javascript.
            var script = document.createElement('script');
            //Sincroniza com o callback.
            script.src = '//viacep.com.br/ws/'+ cep + '/json/?callback=retornoCEPEdit';
            //Insere script no documento e carrega o conteúdo.
            document.body.appendChild(script);
        } //end if.
        else {
            //cep é inválido.
            alert("Formato de CEP inválido.");
            document.getElementById('logradouroEditaEndereco').value="";
            document.getElementById('bairroEditaEndereco').value="";
            document.getElementById('numeroEditaEndereco').value="";
            document.getElementById('complementoEditaEndereco').value="";
            document.getElementById('cidadeEditaEndereco').value="";
            document.getElementById('estadoEditaEndereco').value="";
            document.getElementById('logradouroEditaEndereco').focus();
        }
    } //end if.
    else {
        //cep sem valor, limpa formulário.
    }
};
function retornoCEPEdit(conteudo) {
    if (!("erro" in conteudo)) {
        //Atualiza os campos com os valores.
        document.getElementById('logradouroEditaEndereco').value=(conteudo.logradouro);
        document.getElementById('bairroEditaEndereco').value=(conteudo.bairro);
        document.getElementById('numeroEditaEndereco').value="";
        document.getElementById('complementoEditaEndereco').value="";
        document.getElementById('cidadeEditaEndereco').value=(conteudo.localidade);
        document.getElementById('estadoEditaEndereco').value=(conteudo.uf);
        document.getElementById('numeroEditaEndereco').focus();
    } //end if.
    else {
        //CEP não Encontrado.
        alert("CEP não encontrado. Digeite as informações manualmente!");
        document.getElementById('logradouroEditaEndereco').value="";
        document.getElementById('bairroEditaEndereco').value="";
        document.getElementById('numeroEditaEndereco').value="";
        document.getElementById('complementoEditaEndereco').value="";
        document.getElementById('cidadeEditaEndereco').value="";
        document.getElementById('estadoEditaEndereco').value="";
        document.getElementById('logradouroEditaEndereco').focus();
    }
}
function mascara(src, mask, evt){

    var i = src.value.length;

    var saida = mask.substring(i,i+1);

    var ascii = evt.keyCode;

    if(i < mask.length || ascii == 8 || ascii == 9){

        if(document.all){

            var evt = event.keyCode;

        }

        else{

            var evt = evt.which;

        }

        if (saida == "A")

        {

            if ((ascii >=97) && (ascii <= 122))

                evt.keyCode -= 32;

            else

                evt.keyCode = 0;

        }

        else if (saida == "0")

        {

            if ((ascii >= 48) && (ascii <= 57))

                return;

            else

                evt.keyCode = 0;

        }

        else if (saida == "#")

            return;

        else if(ascii != 8)

        {

            src.value += saida;

            i += 1;

            saida = mask.substring(i,i+1);

            if (saida == "A")

            {

                if ((ascii >=97) && (ascii <= 122))

                    evt.keyCode -= 32;

                else

                    evt.keyCode = 0;

            }

            else if (saida == "0")

            {

                if ((ascii >= 48) && (ascii <= 57))

                    return;

                else

                    evt.keyCode = 0;

            }

            else

                return;

        }

    }

    else

        return false;

}
function validaEnderecoCadastro(url){
    if($("#nomeEnderecoCadastro").val() == ""){
        alert('Informe o nome do endereço corretamente!');
        $("#nomeEnderecoCadastro").focus();
    }
    else if (document.getElementById('cepCadastro').value.length != 9){
        alert('Informe o cep corretamente!');
        $("#cepCadastro").focus();
    }
    else if($("#logradouroCadastro").val() == ""){
        alert('Informe o logradouro corretamente!');
        $("#logradouroCadastro").focus();
    }
    else if($("#numeroCadastro").val() == ""){
        alert('Informe o número corretamente!');
        $("#numeroCadastro").focus();
    }
    else if($("#bairroCadastro").val() == ""){
        alert('Informe o bairro corretamente!');
        $("#bairroCadastro").focus();
    }
    else if($("#cidadeCadastro").val() == ""){
        alert('Informe a cidade corretamente!');
        $("#cidadeCadastro").focus();
    }
    else if($("#estadoCadastro").val() == ""){
        alert('Informe o estado corretamente!');
        $("#estadoCadastro").focus();
    }
    else if($("#paisCadastro").val() == ""){
        alert('Informe o país corretamente!');
        $("#paisCadastro").focus();
    }
    else{
        if (confirm('Tem certeza que deseja cadastrar esse endereço?')){
            $.ajax({
                url: url+'ajax.php?&acao=adicionarEndereco&nomeEndereco='+$("#nomeEnderecoCadastro").val()+'&cep='+$("#cepCadastro").val()+'&logradouro='+$("#logradouroCadastro").val()+'&numero='+$("#numeroCadastro").val()+"&complemento="+$("#complementoCadastro").val()+'&bairro='+$("#bairroCadastro").val()+'&cidade='+$("#cidadeCadastro").val()+"&estado="+$('#estadoCadastro').val()+"&pais="+$("#paisCadastro").val(),
                success: function (data) {
                    var data = data.split('|-|');
                    if (data[0] == 1) {
                        $("#adicionarEndereco").hide('fast');
                        listarEnderecos(url);
                    } else if (data[0] == 0) {
                        alert('Erro: '+data[1]);
                    }
                },
                beforeSend: function () {
                }
            });
        }
    }
}
function validaEnderecoEditar(url){
    if($("#nomeEnderecoEdicao").val() == ""){
        alert('Informe o nome do endereço corretamente!');
        $("#nomeEnderecoEdicao").focus();
    }
    else if (document.getElementById('cepEdicao').value.length != 9){
        alert('Informe o cep corretamente!');
        $("#cepEdicao").focus();
    }
    else if($("#logradouroEdicao").val() == ""){
        alert('Informe o logradouro corretamente!');
        $("#logradouroEdicao").focus();
    }
    else if($("#numeroEdicao").val() == ""){
        alert('Informe o número corretamente!');
        $("#numeroEdicao").focus();
    }
    else if($("#bairroEdicao").val() == ""){
        alert('Informe o bairro corretamente!');
        $("#bairroEdicao").focus();
    }
    else if($("#cidadeEdicao").val() == ""){
        alert('Informe a cidade corretamente!');
        $("#cidadeEdicao").focus();
    }
    else if($("#estadoEdicao").val() == ""){
        alert('Informe o estado corretamente!');
        $("#estadoEdicao").focus();
    }
    else if($("#paisEdicao").val() == ""){
        alert('Informe o país corretamente!');
        $("#paisEdicao").focus();
    }
    else{
        if (confirm('Tem certeza que deseja atualizar esse endereço?')){
            $.ajax({
                url: url+'ajax.php?&acao=editaEndereco&nomeEndereco='+$("#nomeEnderecoEdicao").val()+'&cep='+$("#cepEdicao").val()+'&logradouro='+$("#logradouroEdicao").val()+'&numero='+$("#numeroEdicao").val()+"&complemento="+$("#complementoEdicao").val()+'&bairro='+$("#bairroEdicao").val()+'&cidade='+$("#cidadeEdicao").val()+"&estado="+$('#estadoEdicao').val()+'&pais='+$("#paisEdicao").val()+'&id='+$("#idEdicao").val(),
                success: function (data) {
                    var data = data.split('|-|');
                    if (data[0] == 1) {
                        $("#editarEndereco").hide('fast');
                        listarEnderecos(url);
                    } else if (data[0] == 0) {
                        alert('Erro: '+data[1]);
                    }
                },
                beforeSend: function () {
                }
            });
        }
    }
}
function listarEnderecos(url){
    $.ajax({
        url: url+'ajax.php?&acao=visualizarEnderecos',
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#enderecos").html(data[1]);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#enderecos").html('<img src="'+url+'img/loader.gif" style="width:25px"> Aguarde... Carregando...');
        }
    });
}
function listarPedidos(url){
    $.ajax({
        url: url+'ajax.php?&acao=visualizarPedidos',
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#pedidos").html(data[1]);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#pedidos").html('<img src="'+url+'img/loader.gif" style="width:25px"> Aguarde... Carregando...');
        }
    });
}
function visualizarVale(id, url){
    $.ajax({
        url: url+'ajax.php?&acao=visualizarVale&id=' + id,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#vale").html(data[1]);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#vale").show('slow');
            $("#vale").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
        }
    });
}
function listarListaPresentes(url){
    $.ajax({
        url: url+'ajax.php?&acao=visualizarListaPresentes',
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#listasDePresentes").html(data[1]);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#listasDePresentes").html('<img src="'+url+'img/loader.gif" style="width:25px"> Aguarde... Carregando...');
        }
    });
}
function excluirEnderecoCliente(id, url){
    if (confirm('Tem certeza que deseja excluir esse endereço?')){
        $.ajax({
            url: url+'ajax.php?&acao=excluirEnderecos&id='+id,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    listarEnderecos(url);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#enderecos").html('<img src="'+url+'img/loader.gif" style="width:25px"> Aguarde... Carregando...');
            }
        });
    }
}
function editarEnderecoCliente(id, url){
    $("#editarEndereco").show('slow');
    $.ajax({
        url: url+'ajax.php?&acao=editarEnderecos&id='+id,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#nomeEnderecoEdicao").val(data[1]);
                $("#cepEdicao").val(data[2]);
                $("#logradouroEdicao").val(data[3]);
                $("#numeroEdicao").val(data[4]);
                $("#complementoEdicao").val(data[5]);
                $("#bairroEdicao").val(data[6]);
                $("#cidadeEdicao").val(data[7]);
                $("#estadoEdicao").val(data[8]);
                $("#paisEdicao").val(data[9]);
                $("#idEdicao").val(data[10]);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#nomeEnderecoEdicao").val('Aguarde... Carregando...');
            $("#cepEdicao").val('Aguarde... Carregando...');
            $("#logradouroEdicao").val('Aguarde... Carregando...');
            $("#numeroEdicao").val('Aguarde... Carregando...');
            $("#complementoEdicao").val('Aguarde... Carregando...');
            $("#bairroEdicao").val('Aguarde... Carregando...');
            $("#cidadeEdicao").val('Aguarde... Carregando...');
            $("#estadoEdicao").val('Aguarde... Carregando...');
            $("#idEdicao").val('Aguarde... Carregando...');
        }
    });
}
function selecionaAtributo(idAtributo0, idAtributo1, idAtributo2, idAtributo3, idAtributo4, idAtributo5, idAtributo6, idAtributo7, idAtributo8, idAtributo9, idProduto, url, maximo, minimo){
    $.ajax({
        url: url+'ajax.php?&acao=selecionaAtributo&idAtributo0=' + idAtributo0+'&idAtributo1=' + idAtributo1+'&idAtributo2=' + idAtributo2+'&idAtributo3=' + idAtributo3+'&idAtributo4=' + idAtributo4+'&idAtributo5=' + idAtributo5+'&idAtributo6=' + idAtributo6+'&idAtributo7=' + idAtributo7+'&idAtributo8=' + idAtributo8+'&idAtributo9=' + idAtributo9+'&product='+idProduto+'&maximo='+maximo+'&minimo='+minimo,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#fotoProduto").html(data[1]);
                $("#fotos1").html(data[2]);
                $("#codigoProduto").html(data[3]);
                $("#valorProduto").html(data[4]);
                $("#disponibilidadeProduto").html(data[5]);
                $("#product_item").val(data[6]);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#fotoProduto").html('<img src="'+url+'img/loader.gif">');
            $("#fotos1").html('<img src="'+url+'img/loader.gif" height="25"> Aguarde... Carregando...');
            $("#codigoProduto").html('<img src="'+url+'img/loader.gif" height="25"> Aguarde... Carregando...');
            $("#valorProduto").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
            $("#valorProduto").html('<img src="'+url+'img/loader.gif" height="25">  Aguarde... Carregando...');
            $("#disponibilidadeProduto").html('<img src="'+url+'img/loader.gif" height="25"> Aguarde... Carregando...');
            $("#product_item").val('Aguarde... Carregando...');
        }
    });
}
function linkRedeSocial(slug, url){
    $.ajax({
        url: url+'ajax.php?&acao=redirecionaRedeSocial&slug=' + slug,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                location.href=data[1];
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
                window.close();
            }
        }
    });
}
function editaEndereco(id, url){
    $.ajax({
        url: url+'ajax.php?&acao=editarEndereco&id=' + id,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#idEditaEndereco").val(data[1]);
                $("#nomeEdita").val(data[2]);
                $("#cepEditaEndereco").val(data[3]);
                $("#logradouroEditaEndereco").val(data[4]);
                $("#numeroEditaEndereco").val(data[5]);
                $("#complementoEditaEndereco").val(data[6]);
                $("#bairroEditaEndereco").val(data[7]);
                $("#cidadeEditaEndereco").val(data[8]);
                $("#estadoEditaEndereco").val(data[9]);
                $("#paisEndereco").val(data[10]);
                $("#botoesEditaEndereco").val(data[11]);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#nomeEdita").val('Aguarde... Carregando...');
            $("#cepEditaEndereco").val('Aguarde... Carregando...');
            $("#logradouroEditaEndereco").val('Aguarde... Carregando...');
            $("#numeroEditaEndereco").val('Aguarde... Carregando...');
            $("#complementoEditaEndereco").val('Aguarde... Carregando...');
            $("#bairroEditaEndereco").val('Aguarde... Carregando...');
            $("#cidadeEditaEndereco").val('Aguarde... Carregando...');
            $("#estadoEditaEndereco").val('Aguarde... Carregando...');
            $("#botoesEditaEndereco").val('Aguarde... Carregando...');
        }
    });
}
function cadastrarEndereco(id, url){
    if ($("#nome"+id).val() == ''){
        alert('Informe o nome do endereço corretamente. Ex: Casa, Trabalho, etc.');
        $("#nome"+id).focus();
    }
    else if ($("#cepEndereco"+id).val() == ''){
        alert('Informe o cep do endereço corretamente.');
        $("#cepEndereco"+id).focus();
    }
    else if ($("#logradouroEndereco"+id).val() == ''){
        alert('Informe o logradouro do endereço corretamente.');
        $("#logradouroEndereco"+id).focus();
    }
    else if ($("#numeroEndereco"+id).val() == ''){
        alert('Informe o número do endereço corretamente.');
        $("#numeroEndereco"+id).focus();
    }
    else if ($("#bairroEndereco"+id).val() == ''){
        alert('Informe o bairro do endereço corretamente.');
        $("#bairroEndereco"+id).focus();
    }
    else if ($("#cidadeEndereco"+id).val() == ''){
        alert('Informe a cidade do endereço corretamente.');
        $("#cidadeEndereco"+id).focus();
    }
    else if ($("#estadoEndereco"+id).val() == ''){
        alert('Informe o estado do endereço corretamente.');
        $("#estadoEndereco"+id).focus();
    }
    else {
        $.ajax({
            url: url + 'ajax.php?&acao=cadastrarEndereco&url=' + url + '&idCliente=' + $("#idCliente" + id).val() + "&nome=" + $('#nome' + id).val() + "&cepEndereco=" + $("#cepEndereco" + id).val() + "&logradouroEndereco=" + $("#logradouroEndereco" + id).val() + "&numeroEndereco=" + $("#numeroEndereco" + id).val() + "&complementoEndereco=" + $("#complementoEndereco" + id).val() + "&bairroEndereco=" + $("#bairroEndereco" + id).val() + "&cidadeEndereco=" + $("#cidadeEndereco" + id).val() + "&estadoEndereco=" + $("#estadoEndereco" + id).val(),
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    alert('Endereço cadastrado com sucesso!');
                    visualizaEndereco(id, url);
                } else if (data[0] == 2) {
                    alert('Erro: ' + data[1]);
                }
            }
        });
    }
}
function visualizaEndereco(id, url){

}
function salvarEndereco(url){
    if ($("#nome").val() == ''){
        alert('Informe o nome do endereço corretamente. Ex: Casa, Trabalho, etc.');
        $("#nome").focus();
    }
    else if ($("#cepEndereco").val() == ''){
        alert('Informe o cep do endereço corretamente.');
        $("#cepEndereco").focus();
    }
    else if ($("#logradouroEndereco").val() == ''){
        alert('Informe o logradouro do endereço corretamente.');
        $("#logradouroEndereco").focus();
    }
    else if ($("#numeroEndereco").val() == ''){
        alert('Informe o número do endereço corretamente.');
        $("#numeroEndereco").focus();
    }
    else if ($("#bairroEndereco").val() == ''){
        alert('Informe o bairro do endereço corretamente.');
        $("#bairroEndereco").focus();
    }
    else if ($("#cidadeEndereco").val() == ''){
        alert('Informe a cidade do endereço corretamente.');
        $("#cidadeEndereco").focus();
    }
    else if ($("#estadoEndereco").val() == ''){
        alert('Informe o estado do endereço corretamente.');
        $("#estadoEndereco").focus();
    }
    else {
        $.ajax({
            url: url + 'ajax.php?&acao=cadastraEndereco&url=' + url + '&idCliente=' + $("#idClienteEndereco").val() + "&nome=" + $('#nome').val() + "&cepEndereco=" + $("#cepEndereco").val() + "&logradouroEndereco=" + $("#logradouroEndereco").val() + "&numeroEndereco=" + $("#numeroEndereco").val() + "&complementoEndereco=" + $("#complementoEndereco").val() + "&bairroEndereco=" + $("#bairroEndereco").val() + "&cidadeEndereco=" + $("#cidadeEndereco").val() + "&estadoEndereco=" + $("#estadoEndereco").val(),
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    alert('Endereço cadastrado com sucesso!');
                    pegaEnderecos($("#idClienteEndereco").val(), url);
                    fecha('cadastrarEndereco');
                } else if (data[0] == 2) {
                    alert('Erro: ' + data[1]);
                }
            }
        });
    }
}
function atualizarEndereco(id, url, id2){
    if ($("#nome"+id+id2).val() == ''){
        alert('Informe o nome do endereço corretamente. Ex: Casa, Trabalho, etc.');
        $("#nome"+id+id2).focus();
    }
    else if ($("#cepEndereco"+id+id2).val() == ''){
        alert('Informe o cep do endereço corretamente.');
        $("#cepEndereco"+id+id2).focus();
    }
    else if ($("#logradouroEndereco"+id+id2).val() == ''){
        alert('Informe o logradouro do endereço corretamente.');
        $("#logradouroEndereco"+id+id2).focus();
    }
    else if ($("#numeroEndereco"+id+id2).val() == ''){
        alert('Informe o número do endereço corretamente.');
        $("#numeroEndereco"+id+id2).focus();
    }
    else if ($("#bairroEndereco"+id+id2).val() == ''){
        alert('Informe o bairro do endereço corretamente.');
        $("#bairroEndereco"+id+id2).focus();
    }
    else if ($("#cidadeEndereco"+id+id2).val() == ''){
        alert('Informe a cidade do endereço corretamente.');
        $("#cidadeEndereco"+id+id2).focus();
    }
    else if ($("#estadoEndereco"+id+id2).val() == ''){
        alert('Informe o estado do endereço corretamente.');
        $("#estadoEndereco"+id+id2).focus();
    }
    else {
        $.ajax({
            url: url + 'ajax.php?&acao=atualizarEndereco&url=' + url + '&idCliente=' + $("#idCliente" + id+id2).val() + '&idEndereco=' + $("#idEndereco" + id+id2).val() + "&nome=" + $('#nome' + id+id2).val() + "&cepEndereco=" + $("#cepEndereco" + id+id2).val() + "&logradouroEndereco=" + $("#logradouroEndereco" + id+id2).val() + "&numeroEndereco=" + $("#numeroEndereco" + id+id2).val() + "&complementoEndereco=" + $("#complementoEndereco" + id+id2).val() + "&bairroEndereco=" + $("#bairroEndereco" + id+id2).val() + "&cidadeEndereco=" + $("#cidadeEndereco" + id+id2).val() + "&estadoEndereco=" + $("#estadoEndereco" + id+id2).val(),
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    alert('Endereço atualizado com sucesso!');
                    visualizaEndereco(id2, url);
                } else if (data[0] == 2) {
                    alert('Erro: ' + data[1]);
                }
            }
        });
    }
}
function editarEndereco(url){
    var id2 = $("#idClienteEditaEndereco").val();
    if ($("#nomeEdita").val() == ''){
        alert('Informe o nome do endereço corretamente. Ex: Casa, Trabalho, etc.');
        $("#nomeEdita").focus();
    }
    else if ($("#cepEditaEndereco").val() == ''){
        alert('Informe o cep do endereço corretamente.');
        $("#cepEditaEndereco").focus();
    }
    else if ($("#logradouroEditaEndereco").val() == ''){
        alert('Informe o logradouro do endereço corretamente.');
        $("#logradouroEditaEndereco").focus();
    }
    else if ($("#numeroEditaEndereco").val() == ''){
        alert('Informe o número do endereço corretamente.');
        $("#numeroEditaEndereco").focus();
    }
    else if ($("#bairroEditaEndereco").val() == ''){
        alert('Informe o bairro do endereço corretamente.');
        $("#bairroEditaEndereco").focus();
    }
    else if ($("#cidadeEditaEndereco").val() == ''){
        alert('Informe a cidade do endereço corretamente.');
        $("#cidadeEditaEndereco").focus();
    }
    else if ($("#estadoEditaEndereco").val() == ''){
        alert('Informe o estado do endereço corretamente.');
        $("#estadoEditaEndereco").focus();
    }
    else if ($("#paisEditaEndereco").val() == ''){
        alert('Informe o país do endereço corretamente.');
        $("#paisEditaEndereco").focus();
    }
    else {
        $.ajax({
            url: url + 'ajax.php?&acao=atualizarEndereco&url=' + url + '&idCliente=' + $("#idClienteEditaEndereco").val() + '&idEndereco=' + $("#idEditaEndereco").val() + "&nome=" + $('#nomeEdita').val() + "&cepEndereco=" + $("#cepEditaEndereco").val() + "&logradouroEndereco=" + $("#logradouroEditaEndereco").val() + "&numeroEndereco=" + $("#numeroEditaEndereco").val() + "&complementoEndereco=" + $("#complementoEditaEndereco").val() + "&bairroEndereco=" + $("#bairroEditaEndereco").val() + "&cidadeEndereco=" + $("#cidadeEditaEndereco").val() + "&estadoEndereco=" + $("#estadoEditaEndereco").val() + "&paisEndereco=" + $("#paisEditaEndereco").val(),
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    alert('Endereço atualizado com sucesso!');
                    fecha('editaEndereco');
                    pegaEnderecos(id2, url);
                } else if (data[0] == 2) {
                    alert('Erro: ' + data[1]);
                }
            }
        });
    }
}
function mostraCarrinhoDeCompras(idClient, url){
    $("#finalizarPedido").hide('fast');
    $.ajax({
        url: url+'ajax.php?&acao=mostraCarrinhoDeCompras&idClient=' + idClient,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#carrinhoDeCompras").html(data[1]);
                $("#numProdutosCarrinho").val(data[2]);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#carrinhoDeCompras").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
        }
    });
}
function excluirCarrinho(id, url){
    if (confirm('Tem certeza que deseja excluir esse produto do carrinho?')){
        $.ajax({
            url: url+'ajax.php?&acao=excluirCarrinho&id=' + id,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    mostraCarrinhoDeCompras('', url);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#carrinhoDeCompras").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
            }
        });
    }
}
function finalizarPedido(url) {
    if ($("#numProdutosCarrinho").val() == 0){
        alert('Nenhum produto no carrinho de compras!');
    }
    else {
        $("#finalizarPedido").show('slow');
        $.ajax({
            url: url + 'ajax.php?&acao=finalizarPedido',
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    $("#finalizarPedido").html(data[1]);
                } else if (data[0] == 0) {
                    alert('Erro: ' + data[1]);
                }
            },
            beforeSend: function () {
                $("#finalizarPedido").html('<button type="button" class="close" onClick=fecha("finalizarPedido")><span aria-hidden="true">&times;</span></button><img src="' + url + 'img/loader.gif" width="20"> Aguarde... Carregando...');
            }
        });
        location.href = "#finalizarPedido";
    }
}
function comprar(url){
    if ($('#formaPagamentoCompra').val() == ""){
        alert('Informe a forma de pagamento corretamente!');
        $("#formaPagamentoCompra").focus();
    }
    else if ($('#enderecoCompra').val() == ""){
        alert('Informe o endereço da compra corretamente!');
        $("#enderecoCompra").focus();
    }
    else{
        if(confirm('Tem certeza que deseja realizar o pedido?')) {
            $.ajax({
                url: url + 'ajax.php?&acao=comprar&payment_method=' + $('#formaPagamentoCompra').val() + '&address=' + $('#enderecoCompra').val(),
                success: function (data) {
                    var data = data.split('|-|');
                    if (data[0] == 1) {
                        $("#finalizarPedido").html(data[1]);
                        mostraComprovante(data[2], url);
                        //mostraCarrinhoDeCompras('', url);
                    } else if (data[0] == 0) {
                        alert('Erro: ' + data[1]);
                    }
                },
                beforeSend: function () {
                    $("#finalizarPedido").html('<img src="' + url + 'img/loader.gif" width="20"> Aguarde... Carregando Comprovante...');
                }
            });
        }
    }
}
function verInformacoesSistemaEscolar(id) {
    $("#informacoesSistemaEscolar" + id).show('slow');
}
function verInformacoesSistemaCaixa(id){
    $("#informacoesSistemaCaixa"+id).show('slow');
}
function limparCarrinho(url){
    if (confirm('Tem certeza que deseja limpar esse carrinho?')){
        $.ajax({
            url: url+'ajax.php?&acao=limparCarrinho',
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    mostraCarrinhoDeCompras('', url);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#carrinhoDeCompras").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
            }
        });
    }
}
function pegaPedidos(idClient, url){
    $.ajax({
        url: url+'ajax.php?&acao=pegaPedidos&idClient=' + idClient,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#pedidosCliente").html(data[1]);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#pedidosCliente").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
        }
    });
}
function excluirEndereco(id, url, id2) {
    if(confirm("Tem certeza que deseja excluir o endereço "+id+"?")){
        $.ajax({
            url: url+'ajax.php?&acao=excluirEndereco&id=' + id,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    alert('Endereço excluído com sucesso! Aguarde o carregamento dos endereços!');
                    visualizaEndereco(id2, url);
                    pegaEnderecos(id2, url);
                } else if (data[0] == 2) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#htmlVisualizaEnderecos"+id).html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
            }
        });
    }
}
function visualizaEndereco(id, url){
    $.ajax({
        url: url+'ajax.php?&acao=visualizaEnderecos&id=' + id,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#htmlVisualizaEnderecos"+id).html(data[1]);
            } else if (data[0] == 2) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#htmlVisualizaEnderecos"+id).html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
        }
    });
}
function selecionaTipoServicoBugTracking(id){
    if (id == ""){
        $("#tipoVersaoHTML").html('<label class="form-label">\n' +
            '                                Versão\n' +
            '                                <span class="text-danger">*</span>\n' +
            '                            </label>\n' +
            '\n' +
            '                            <select class="form-control" name="typeVersion" id="typeVersion" required\n' +
            '                                    data-msg="Por Favor, informe o tipo de Serviço."\n' +
            '                                    data-error-class="u-has-error"\n' +
            '                                    data-success-class="u-has-success">\n' +
            '                                <option value="">Selecione o tipo de serviço corretamente</option>\n' +
            '                            </select>');
        $("#prioridadeHTML").html('<label class="form-label">\n' +
            '                                Prioridade\n' +
            '                                <span class="text-danger">*</span>\n' +
            '                            </label>\n' +
            '\n' +
            '                            <select class="form-control" name="priority" id="priority" required\n' +
            '                                    data-msg="Por Favor, informe a prioridade."\n' +
            '                                    data-error-class="u-has-error"\n' +
            '                                    data-success-class="u-has-success">\n' +
            '                                <option value="">Selecione o tipo de serviço corretamente</option>\n' +
            '                            </select>');
        $("#categoriaHTML").html('<label class="form-label">\n' +
            '                                Categoria\n' +
            '                                <span class="text-danger">*</span>\n' +
            '                            </label>\n' +
            '\n' +
            '                            <select class="form-control" name="category" id="category" required\n' +
            '                                    data-msg="Por Favor, informe a categoria."\n' +
            '                                    data-error-class="u-has-error"\n' +
            '                                    data-success-class="u-has-success">\n' +
            '                                <option value="">Selecione o tipo de serviço corretamente</option>\n' +
            '                            </select>');
    }
    else {
        $.ajax({
            url: 'ajax.php?&acao=selecionaTipoServiço&id=' + id,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    $("#tipoVersaoHTML").html(data[1]);
                    $("#prioridadeHTML").html(data[2]);
                    $("#categoriaHTML").html(data[3]);
                } else if (data[0] == 2) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#tipoVersaoHTML").html('<img src="img/loader.gif" width="20"> Aguarde... Carregando...');
                $("#prioridadeHTML").html('<img src="img/loader.gif" width="20"> Aguarde... Carregando...');
                $("#categoriaHTML").html('<img src="img/loader.gif" width="20"> Aguarde... Carregando...');
            }
        });
    }
}
function selecionaTipoServicoAdmin(id, url){
    if (id == ""){
        $("#versaoHTML").html('<select name="typeVersion" id="typeVersion" required>\n' +
            '                                <option value="">Selecione o tipo de serviço corretamente</option>\n' +
            '                            </select>');
        $("#prioridadeHTML").html('<select  name="priority" id="priority" required>\n' +
            '                                <option value="">Selecione o tipo de serviço corretamente</option>\n' +
            '                       </select>');
        $("#categoriaHTML").html('<select name="category" id="category" required>\n' +
            '                                <option value="">Selecione o tipo de serviço corretamente</option>\n' +
            '                            </select>');
    }
    else {
        $.ajax({
            url: url+'ajax.php?&acao=selecionaTipoServiçoAdmin&id=' + id,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    $("#versaoHTML").html(data[1]);
                    $("#prioridadeHTML").html(data[2]);
                    $("#categoriaHTML").html(data[3]);
                } else if (data[0] == 2) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#versaoHTML").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
                $("#prioridadeHTML").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
                $("#categoriaHTML").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
            }
        });
    }
}
function pegaEnderecos(idCliente, url){
    $.ajax({
        url: url+'ajax.php?&acao=pegaEnderecos&idCliente=' + idCliente,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
                $("#enderecosCliente").html(data[1]);
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
            $("#enderecosCliente").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
        }
    });
}
function novoEndereco(){
    $("#novoEndereco").show('slow');
}
function abre(id){
    $("#loja-virtual").hide('fast');
    $("#sites").hide('fast');
    $("#sites-internacionais").hide('fast');
    $("#sistema-escolar").hide('fast');
    $("#sistema-de-caixa").hide('fast');
    $("#catalogo-virtual").hide('fast');
    $("#hospedagem-de-sites").hide('fast');
    $("#registro-de-dominios").hide('fast');
    $("#aplicativos-para-celular").hide('fast');
    $("#videos").hide('fast');
    $("#"+id).show('slow');
    location.href='#'+id;
}
function detalhesPedido(id, url){
    $("#detalhesPedido").show('slow');
    if (id == ""){
        $("#detalhesPedido").html('<button type="button" class="close" onClick=fecha("detalhesPedido")><span aria-hidden="true">&times;</span></button>Selecione o pedido corretamente...');
    }else{
        $.ajax({
            url: url+'ajax.php?&acao=detalhesPedido&id=' + id,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    $("#detalhesPedido").html(data[1]);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#detalhesPedido").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
            }
        });
    }
}
function selecionaProduto(id, url){
    $("#productItemsRealizarPedido").show('slow');
    if(id == ""){
        $("#productItemsRealizarPedido").hide('fast');
    }
    else{
        $.ajax({
            url: url+'ajax.php?&acao=selecionaProduto&product=' + id,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    $("#productItemsRealizarPedido").html(data[1]);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#productItemsRealizarPedido").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
            }
        });
    }
}
function selecionaProdutoItem(id, url, id2){
    $("#passo03").show('slow');
    if(id2 == ""){
        alert('Selecione o item do produto corretamente!');
        $("#passo03").hide('fast');
    }
    else{
        $.ajax({
            url: url+'ajax.php?&acao=selecionaPasso03&product=' + id,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    $("#passo03").html(data[1]);
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#passo03").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
            }
        });
    }
}
function mostraMenu(qual, qtosTem){
    for (i = 0; i < qtosTem; i++){
        document.getElementById('menu'+i).className = "nav-item";
    }
    document.getElementById('menu'+qual).className = "nav-item active";
}
function contaAcessoPagina(id){
    $.ajax({
        url: 'ajax.php?&acao=contaAcessoPagina&id='+id,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
    });
}
function contaAcessoSubitem(id){
    $.ajax({
        url: 'ajax.php?&acao=contaAcessoSubitem&id='+id,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
    });
}
function contaAcessoBanner(id){
    $.ajax({
        url: 'ajax.php?&acao=contaAcessoBanner&id='+id,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
    });
}
function sairDoSistema(url){
    if (confirm('Tem certeza que deseja sair da loja?')){
        $.ajax({
            url: url+'ajax.php?&acao=logout',
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {
                    location.href=url;
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
                $("#passo03").html('<img src="'+url+'img/loader.gif" width="20"> Aguarde... Carregando...');
            }
        });
    }
}
function abreServicos(id, url){
    var idE = id.replace('resposta', '');
    if (document.getElementById(id).style.display == 'none'){
        $.ajax({
            url: url+'ajax.php?&acao=contaAcessoSubitem&id='+idE,
            success: function (data) {
                var data = data.split('|-|');
                if (data[0] == 1) {                
                } else if (data[0] == 0) {
                    alert('Erro: '+data[1]);
                }
            },
            beforeSend: function () {
            }
        });
    }
    abreFecha(id);
}
function abreSubitem(id, url){
    $.ajax({
        url: url+'ajax.php?&acao=contaAcessoSubitem&id='+id,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {                
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
        }
    });
    $.ajax({
        url: url+'ajax.php?&acao=insereLogClienteVisualiza&id='+id,
        success: function (data) {
            var data = data.split('|-|');
            if (data[0] == 1) {                
            } else if (data[0] == 0) {
                alert('Erro: '+data[1]);
            }
        },
        beforeSend: function () {
        }
    });
}
var url = document.URL;
var vet = url.split('/');
url = "";
if (vet[2] == 'localhost' && vet.length >= 7) {
    url3 = "https://localhost/lojavirtual/site/";
    url = vet[5].replace('#', '');
    url2 = vet[6].replace('#', '');
}
else if(vet[2] != 'localhost' && vet.length >= 4){
    url3 = "https://lojavirtual.bhcommerce.com.br/site/";
    if (!vet[4]){
        vet[4] = vet[3];
        vet[3] = "pagina";
    }
    url = vet[3].replace('#', '');
    url2 = vet[4].replace('#', '');
}
else{
    url = 'pagina';
    url2 = 'home';
    if (vet[2] == 'localhost'){
        url3 = "http://localhost/lojavirtual/site/";
    }
    else{
        url3 = "https://lojavirtual.bhcommerce.com.br/site/";
    }
}
if (url2 == ""){
    url2 = "home";
}
$.ajax({
    url: url3+'ajax.php?&acao=contaAcesso&url='+url+"&url2="+url2,
    success: function (data) {
        var data = data.split('|-|');
        if (data[0] == 1) {
        } else if (data[0] == 0) {
            alert('Erro: '+data[1]);
        }
    },
});
