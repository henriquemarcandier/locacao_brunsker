<div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-4">
                        <h1>Parâmetros do Site</h1>
                    </div>
                    <div class="col-sm-2">
                        <button class="btn btn-primary" data-toggle="modal" data-target="#modalCadastro" onclick=addParamSite()>Criar Novo</button>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?=URL?>">Home</a></li>
                            <li class="breadcrumb-item">Outros Cadastros</li>
                            <li class="breadcrumb-item active"><a href="<?=URL?>paramSite">Parâmetros do Site</a></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
<div class="my-3 p-3 bg-white rounded shadow-sm">
    <div class="media text-muted pt-3">
        <h6 style="cursor: pointer" onclick="abreFecha('filtro')">Filtro</h6>
    </div>
    <div class="media text-muted pt-3" id="filtro" style="display:none">
        <div style="width:100%">
            <label for="nomeFiltro">Por Nome: </label>
            <input type="text" class="form-control" id="nomeFiltro" name="nomeFiltro">
        </div>
        <button type="button" class="btn btn-primary" onclick='verificaNovamente("paramSite", "<?=URL?>","<?=$_SESSION['user']['id']?>")'>Filtrar</button>
    </div>
    <input type="hidden" name="tipo" id="tipo" value="categorias">
    <input type="hidden" name="pagina" id="pagina" value="1">

    <div class="media text-muted pt-3" id="conteudo">
        <img src="<?=URL?>img/loader.gif" width="20"> Aguarde... Carregando...
    </div>
    <div id="contadorSite"></div>
</div>
<div class="modal fade" id="modalCadastro" tabindex="-1" role="dialog" aria-labelledby="modalCadastro" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Cadastro de Parâmetro do Site</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Fechar" id="fecharCadastro">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="cadastroParametroSite">
                <div class="modal-body">
                    <input type="hidden" name="urlCadastro" id="urlCadastro" value="<?=URL?>">
                    <input type="hidden" name="idUserCadastro" id="idUserCadastro" value="<?=$_SESSION['user']['id']?>">
                    <label for="nomeCadastro">Nome: </label>
                    <input type="text" name="nomeCadastro" id="nomeCadastro" value="" required class="form-control">
                    <label for="tipoCadastro">Tipo do Input: </label>
		    <select name="tipoCadastro" id="tipoCadastro" class='form-control' required onchange=selecionaTipoParamSiteCadastro(this.value,"")>
			<option value="">Selecione o tipo do input abaixo corretamente...</option>
			<option value="textarea">Textarea</option>
			<option value="select">Select</option>
			<option value="text">Text</option>
			<option value="number">Number</option>
			<option value="date">Date</option>
			<option value="time">Time</option>
			<option value="datetime-local">Datetime</option>
		    </select>
		    <div id="valorMostraCadastro">
                    <label for="valorCadastro">Valor: </label>
                    <textarea name="valorCadastro" id="valorCadastro" required class="form-control"></textarea>
		    </div>  
              </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Cadastrar</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="modalEdicao" tabindex="-1" role="dialog" aria-labelledby="modalEdicao" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edição de Parâmetro do Site</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="edicaoParametroSite">
                <div class="modal-body">
                    <input type="hidden" name="urlEdicao" id="urlEdicao" value="<?=URL?>">
                    <input type="hidden" name="idEdicao" id="idEdicao" value="Aguarde... Carregando...">
                    <input type="hidden" name="idUserEdicao" id="idUserEdicao" value="Aguarde... Carregando...">
                    <label for="nomeEdicao">Nome: </label>
                    <input type="text" name="nomeEdicao" id="nomeEdicao" value="Aguarde... Carregando..." required class="form-control">
                    <label for="tipoEdicao">Tipo do Input: </label>
		    <select name="tipoEdicao" id="tipoEdicao" class='form-control' required onchange=selecionaTipoParamSiteEdicao(this.value,"'.$row['value'].'")>
			<option value="">Selecione o tipo do input abaixo corretamente...</option>
			<option value="textarea">Textarea</option>
			<option value="select">Select</option>
			<option value="text">Text</option>
			<option value="number">Number</option>
			<option value="date">Date</option>
			<option value="time">Time</option>
			<option value="datetime-local">Datetime</option>
		    </select>
		    <div id="valorMostraEdicao">
		    <label for="valorEdicao">Valor: </label>
                    <textarea name="valorEdicao" id="valorEdicao" required class="form-control">Aguarde... Carregando...</textarea>
                    </div>
		</div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" id="botaoEditar" style="display:none">Editar</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="modalVisualizacao" tabindex="-1" role="dialog" aria-labelledby="modalVisualizacao" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Visualização de Parâmetro do Site</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="visualizacaoParametroSite">
                <img src="<?=URL?>img/loader.gif" width="20"> Aguarde... Carregando...
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>
</div>
<script>
    window.setInterval('verificaNovamente("paramSite", "<?=URL?>", "<?=$_SESSION['user']['id']?>")', 60000); window.setTimeout('verificaNovamente("paramSite", "<?=URL?>", "<?=$_SESSION['user']['id']?>")', 2000);
</script>