<div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-4">
                        <h1>Imóveis</h1>
                    </div>
                    <div class="col-sm-4">
                        <button class="btn btn-primary" data-toggle="modal" data-target="#modalCadastro" onclick=addImovel()>Criar Novo</button>
                        <button class="btn btn-warning" data-toggle="modal" data-target="#modalImporta" onclick=addImportaImovel()>Importar</button>
                        <button class="btn btn-danger" onclick=exportaImovel('<?=URL?>','<?=$_SESSION['user']['id']?>')>Exportar</button>
                    </div>
                    <div class="col-sm-4">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?=URL?>admin">Home</a></li>
                            <li class="breadcrumb-item">Cadastros</li>
                            <li class="breadcrumb-item active"><a href="<?=URL?>imoveis">Imóveis</a></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>


<div class="my-3 p-3 bg-white rounded shadow-sm">
    <div class="media text-muted pt-3">
        <h6 style="cursor: pointer" onclick="abreFecha('filtro')">Filtro</h6>
    </div>
    <div class="media text-muted pt-3" id="filtro" style="display:none">
        <div style="width:100%">
            <label for="nomeFiltro">Por Nome do Imóvel: </label>
            <input type="text" class="form-control" id="nomeFiltro" name="nomeFiltro">
        </div>
        <button type="button" class="btn btn-primary" onclick='verificaNovamente("imoveis", "<?=URL?>","<?=$_SESSION['user']['id']?>")'>Filtrar</button>
    </div>

    <div class="media text-muted pt-3" id="conteudo">
        <img src="<?=URL?>img/loader.gif" width="20"> Aguarde... Carregando...
    </div>
    <div id="contadorSite"></div>

</div>
        <input type="hidden" name="pagina" id="pagina" value="1">
        <div class="modal fade" id="modalCadastro" tabindex="-1" role="dialog" aria-labelledby="modalCadastro" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Cadastro de Imóvel</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar" id="fecharCadastro">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <button class="btn btn-primary" onclick="mostraImovelCadastro('ImovelCadastro')">Dados do Imóvel</button>
                    <button class="btn btn-success" onclick="mostraImovelCadastro('EnderecoCadastro')">Dados do Endereço</button>
                    <form id="cadastroImoveis">
                        <div class="modal-body" id="dadosImovelCadastro">
                            <h3>Dados do Imóvel</h3>
                            <input type="hidden" name="urlCadastro" id="urlCadastro" value="<?=URL?>">
                            <input type="hidden" name="idCadastro" id="idCadastro" value="">
                            <input type="hidden" name="idUserCadastro" id="idUserCadastro" value="{{$_SESSION['user']['id']}}">
                            <label for="nomeCadastro">Nome: </label>
                            <input type="text" name="nomeCadastro" id="nomeCadastro" value="" required class="form-control">
                            <label for="descricaoCadastro">Descrição: </label>
                            <textarea name="descricaoCadastro" id="descricaoCadastro" class="form-control"></textarea>
                            <label for="metragemCadastro" style="float:left">Metragem: </label>
                            <input type="text" name="metragemCadastro" id="metragemCadastro" value="" required class="form-control" style="width:200px; float:left">
                            <span style="float:left">m2</span><br><br>
                            <label for="quartosCadastro" style="float:left">Número de Quartos: </label>
                            <input type="numeric" name="quartosCadastro" id="quartosCadastro" value="0" min="0" readonly required class="form-control" style="width:200px; float:left">
                            <span style="float:left"><img src="<?=URL?>img/mais.png" width="25" style="cursor:pointer" title="Mais Quartos" onclick="mais('quartosCadastro')"> <img src="<?=URL?>img/menos.png" width="25" style="cursor:pointer" title="Menos Quartos" onclick="menos('quartosCadastro')"></span><br><br>
                            <label for="banheirosCadastro" style="float:left">Número de Banheiros: </label>
                            <input type="numeric" name="banheirosCadastro" id="banheirosCadastro" value="0" min="0" readonly required class="form-control" style="width:200px; float:left">
                            <span style="float:left"><img src="<?=URL?>img/mais.png" width="25" style="cursor:pointer" title="Mais Quartos" onclick="mais('banheirosCadastro')"> <img src="<?=URL?>img/menos.png" width="25" style="cursor:pointer" title="Menos Quartos" onclick="menos('banheirosCadastro')"></span><br><br>
                            <label for="suitesCadastro" style="float:left">Número de Suítes: </label>
                            <input type="numeric" name="suitesCadastro" id="suitesCadastro" value="0" min="0" readonly required class="form-control" style="width:200px; float:left">
                            <span style="float:left"><img src="<?=URL?>img/mais.png" width="25" style="cursor:pointer" title="Mais Quartos" onclick="mais('suitesCadastro')"> <img src="<?=URL?>img/menos.png" width="25" style="cursor:pointer" title="Menos Quartos" onclick="menos('suitesCadastro')"></span><br><br>
                            <label for="vagasCadastro" style="float:left">Vagas na Garagem: </label>
                            <input type="numeric" name="vagasCadastro" id="vagasCadastro" value="0" min="0" readonly required class="form-control" style="width:200px; float:left">
                            <span style="float:left"><img src="<?=URL?>img/mais.png" width="25" style="cursor:pointer" title="Mais Quartos" onclick="mais('vagasCadastro')"> <img src="<?=URL?>img/menos.png" width="25" style="cursor:pointer" title="Menos Quartos" onclick="menos('vagasCadastro')"></span><br><br>
                            <label for="valorCadastro">Valor do Aluguel: </label>R$
                            <input type="value" name="valorCadastro" onkeyup="mascaraValor(this.value, 'valorCadastro')" id="valorCadastro" value="" required class="form-control">
                            <label for="statusCadastro">Status: </label>
                            <select name="statusCadastro" id="statusCadastro" class="form-control">
                                <option value="0">Inativo</option>
                                <option value="1">Ativo</option>
                            </select>
                        </div>
                        <div class="modal-body" id="dadosEnderecoCadastro" style="display:none">
                            <h3>Dados do Endereço</h3>
                            <label for="cepCadastro">CEP: </label>
                            <input type="value" name="cepCadastro" onkeyup="mascara(this, '#####-###', event); verificacepimovelcadastro(this.value)" id="cepCadastro" maxlength="9" value="" required class="form-control">
                            <label for="logradouroCadastro">Logradouro: </label>
                            <input type="text" name="logradouroCadastro" id="logradouroCadastro" value="" required class="form-control">
                            <label for="numeroCadastro">Número: </label>
                            <input type="text" name="numeroCadastro" id="numeroCadastro" value="" required class="form-control">
                            <label for="complementoCadastro">Complemento: </label>
                            <input type="text" name="complementoCadastro" id="complementoCadastro" value="" class="form-control">
                            <label for="bairroCadastro">Bairro: </label>
                            <input type="text" name="bairroCadastro" id="bairroCadastro" value="" required class="form-control">
                            <label for="cidadeCadastro">Cidade: </label>
                            <input type="text" name="cidadeCadastro" id="cidadeCadastro" value="" required class="form-control">
                            <label for="estadoCadastro">Estado: </label>
                            <select name="estadoCadastro" id="estadoCadastro" required class="form-control">
                                <option value="">Selecione o estado abaixo...</option>
                                <?php foreach ($states as $key => $value){?>
                                <option value="<?=$value->sigla?>"><?=$value->nome?></option>
                                <?php }?>
                            </select>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Cadastrar</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="modal fade" id="modalEdicao" tabindex="-1" role="dialog" aria-labelledby="modalEdicao" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Edição de Imóvel</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <button class="btn btn-primary" onclick="mostraImovelEdicao('ImovelEdicao')">Dados do Imóvel</button>
                    <button class="btn btn-success" onclick="mostraImovelEdicao('EnderecoEdicao')">Dados do Endereço</button>
                    <button class="btn btn-warning" onclick="mostraImovelEdicao('ImagemEdicao')">Dados de Imagem</button>
                    <form id="edicaoImoveis">
                        <div class="modal-body" id="dadosImovelEdicao">
                            <h3>Dados do Imóvel</h3>
                            <input type="hidden" name="urlEdicao" id="urlEdicao" value="<?=URL?>">
                            <input type="hidden" name="idEdicao" id="idEdicao" value="Aguarde... Carregando...">
                            <input type="hidden" name="idUserEdicao" id="idUserEdicao" value="Aguarde... Carregando...">
                            <label for="nomeEdicao">Nome: </label>
                            <input type="text" name="nomeEdicao" id="nomeEdicao" value="Aguarde... Carregando..." required class="form-control">
                            <label for="descricaoEdicao">Descrição: </label>
                            <textarea name="descricaoEdicao" id="descricaoEdicao" class="form-control">Aguarde... Carregando...</textarea>
                            <label for="metragemEdicao" style="float:left">Metragem: </label>
                            <input type="text" name="metragemEdicao" id="metragemEdicao" value="Aguarde... Carregando..." required class="form-control" style="width:200px; float:left">
                            <span style="float:left">m2</span><br><br>
                            <label for="quartosEdicao" style="float:left">Número de Quartos: </label>
                            <input type="numeric" name="quartosEdicao" id="quartosEdicao" value="Aguarde... Carregando..." readonly required class="form-control" style="width:200px; float:left">
                            <span style="float:left"><img src="<?=URL?>img/mais.png" width="25" style="cursor:pointer" title="Mais Quartos" onclick="mais('quartosEdicao')"> <img src="<?=URL?>img/menos.png" width="25" style="cursor:pointer" title="Menos Quartos" onclick="menos('quartosEdicao')"></span><br><br>
                            <label for="banheirosEdicao" style="float:left">Número de Banheiros: </label>
                            <input type="integer" name="banheirosEdicao" id="banheirosEdicao" value="Aguarde... Carregando..." readonly required class="form-control" style="width:200px; float:left">
                            <span style="float:left"><img src="<?=URL?>img/mais.png" width="25" style="cursor:pointer" title="Mais Quartos" onclick="mais('banheirosEdicao')"> <img src="<?=URL?>img/menos.png" width="25" style="cursor:pointer" title="Menos Quartos" onclick="menos('banheirosEdicao')"></span><br><br>
                            <label for="suitesEdicao" style="float:left">Número de Suítes: </label>
                            <input type="numeric" name="suitesEdicao" id="suitesEdicao" value="Aguarde... Carregando..." readonly required class="form-control" style="width:200px; float:left">
                            <span style="float:left"><img src="<?=URL?>img/mais.png" width="25" style="cursor:pointer" title="Mais Quartos" onclick="mais('suitesEdicao')"> <img src="<?=URL?>img/menos.png" width="25" style="cursor:pointer" title="Menos Quartos" onclick="menos('suitesEdicao')"></span><br><br>
                            <label for="vagasEdicao" style="float:left">Vagas na Garagem: </label>
                            <input type="numeric" name="vagasEdicao" id="vagasEdicao" value="Aguarde... Carregando..." readonly required class="form-control" style="width:200px; float:left">
                            <span style="float:left"><img src="<?=URL?>img/mais.png" width="25" style="cursor:pointer" title="Mais Quartos" onclick="mais('vagasEdicao')"> <img src="<?=URL?>img/menos.png" width="25" style="cursor:pointer" title="Menos Quartos" onclick="menos('vagasEdicao')"></span><br><br>
                            <label for="valorEdicao">Valor do Aluguel: </label>R$
                            <input type="value" name="valorEdicao" onkeyup="mascaraValor(this.value, 'valorEdicao')" id="valorEdicao" value="Aguarde... Carregando..." required class="form-control">
                            <label for="statusEdicao">Status: </label>
                            <select name="statusEdicao" id="statusEdicao" class="form-control">
                                <option value="0">Inativo</option>
                                <option value="1">Ativo</option>
                            </select>
                        </div>
                        <div class="modal-body" id="dadosEnderecoEdicao" style="display:none">
                            <h3>Dados do Endereço</h3>
                            <label for="cepEdicao">CEP: </label>
                            <input type="value" name="cepEdicao" onkeyup="mascara(this, '#####-###', event); verificacepimoveledicao(this.value)" id="cepEdicao" maxlength="9" value="Aguarde... Carregando..." required class="form-control">
                            <label for="logradouroEdicao">Logradouro: </label>
                            <input type="text" name="logradouroEdicao" id="logradouroEdicao" value="Aguarde... Carregando..." required class="form-control">
                            <label for="numeroEdicao">Número: </label>
                            <input type="text" name="numeroEdicao" id="numeroEdicao" value="Aguarde... Carregando..." required class="form-control">
                            <label for="complementoEdicao">Complemento: </label>
                            <input type="text" name="complementoEdicao" id="complementoEdicao" value="Aguarde... Carregando..." class="form-control">
                            <label for="bairroEdicao">Bairro: </label>
                            <input type="text" name="bairroEdicao" id="bairroEdicao" value="Aguarde... Carregando..." required class="form-control">
                            <label for="cidadeEdicao">Cidade: </label>
                            <input type="text" name="cidadeEdicao" id="cidadeEdicao" value="Aguarde... Carregando..." required class="form-control">
                            <label for="estadoEdicao">Estado: </label>
                            <select name="estadoEdicao" id="estadoEdicao" required class="form-control">
                                <option value="">Selecione o estado abaixo...</option>
                                <?php foreach ($states as $key => $value){?>
                                <option value="<?=$value->sigla?>"><?=$value->nome?></option>
                                <?php }?>
                            </select>
                        </div>
                        <div class="modal-body" id="dadosImagemEdicao" style="display:none">
                            <h3>Dados de Imagem</h3>
                            <iframe id="iframeImagensEdicao" src="<?=URL?>paginas/imagensImovel.php" width="100%" height="300"></iframe>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary" id="botaoEditar" style="display:none">Editar</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="modal fade" id="modalVisualizacao" tabindex="-1" role="dialog" aria-labelledby="modalVisualizacao" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Visualização de Imóvel</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body" id="visualizacaoImoveis">
                        <img src="<?=URL?>img/loader.gif" width="20"> Aguarde... Carregando...
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="modalImporta" tabindex="-1" role="dialog" aria-labelledby="#modalImporta" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Importação de Imóvel</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form name="importacaoImoveis" id="importacaoImoveis">
                        <div class="modal-body" id="importarImoveis">
                            <label for="arquivoImporta">Arquivo (deve ser um *.csv)</label>
                            <input type="file" name="arquivoImporta" id="arquivoImporta" class="form-control" required>
                            <input type="checkbox" name="limparCampos" id="limparCampos">
                            <label for="limparCampos">Limpar campos antes da importação</label>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Importar</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        window.setInterval('verificaNovamente("imoveis", "<?=URL?>", "<?=$_SESSION['user']['id']?>")', 60000); window.setTimeout('verificaNovamente("imoveis", "<?=URL?>", "<?=$_SESSION['user']['id']?>")', 2000);
    </script>