<?php
require_once('../connect.php');
$sql = "SELECT a.* FROM properties a WHERE deleted_at IS NULL ";
if ($_REQUEST['nomeFiltro']){
    $sql .= "AND ";
    $sql .= "a.name LIKE '%".$_REQUEST['nomeFiltro']."%' ";
    $where = "1";
}
$sql .= "ORDER BY a.created_at ASC";
echo "-";
$query = mysqli_query($con, $sql);
$arquivo = utf8_decode('ID;Nome;Descrição;Metragem;Número de Quartos;Número de Banheiros;Número de Suítes;Número de Vagas na Garagem;Valor do Aluguel;Status;CEP;Logradouro;Número;Complemento;Bairro;Cidade;Estado;Imagens;Data / Hora')."\r\n";
if (mysqli_num_rows($query)){
    while($value = mysqli_fetch_object($query)){
        $img = "";
        $sql = "SELECT a.* FROM properties_addresses a WHERE a.property = '".$value->id."' ";
        $sql .= "ORDER BY a.created_at ASC";
        $query2 = mysqli_query($con, $sql);
        $row2 = mysqli_fetch_array($query2);
        $sql = "SELECT a.* FROM properties_photos a WHERE a.property = '".$value->id."' AND a.deleted_at IS NULL ";
        $sql .= "ORDER BY a.created_at ASC";
        $query3 = mysqli_query($con, $sql);
        if (mysqli_num_rows($query2)){
            while ($row3 = mysqli_fetch_array($query3)){
                copy(DIRETORIO."img/upload/".$row3['img'], DIRETORIO."importa/".$row3['img']);
                $img .= $row3['img']."|-|".$row3['name']."|*|";
            }
        }
        $value->status = ($value->status) ? "Ativo" : "Inativo";
        $arquivo .= $value->id.";".$value->name.";".str_replace("\r\n", "<br>", $value->description).";".$value->metragem.";".$value->quartos.";".$value->banheiros.";".$value->suites.";".$value->vagas.";R$ ".number_format($value->value, 2, ',', '.').";".$value->status.";".$row2['zip'].";".$row2['address'].";".$row2['number'].";".$row2['complement'].";".$row2['neighborhood'].";".$row2['city'].";".$row2['state'].";".$img.";".$value->created_at."\r\n";
    }
}
$sql = "INSERT INTO logs (action, user, created_at, updated_at) VALUES ('Exportou os Logs de Acesso', '".$_REQUEST['idUser']."', now(), now())";
mysqli_query($con, $sql);
$fp = fopen(DIRETORIO_SITE."imoveis.csv", "w+");
fwrite($fp, $arquivo);
fclose($fp);


$fp = fopen(DIRETORIO_SITE."imoveis.csv", "r");
header('Content-type: text/csv');
header('Content-Disposition: attachment; filename=imoveis'.date('Y-m-d-H-i-s').'.csv');

while(!feof ($fp)) {

    echo fgets($fp); //LENDO A LINHA
}
fclose($fp);
unlink(DIRETORIO_SITE."imoveis.csv");
?>
