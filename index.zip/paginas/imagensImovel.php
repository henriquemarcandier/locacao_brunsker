<?php
ini_set('display_errors', 'off');
require_once('../connect.php');
?><!doctype html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BH Commerce</title>
    <link rel="stylesheet" href="<?=URL?>dist/css/adminlte.min.css">
    <link rel="stylesheet" href="<?=URL?>img/style.css">
    <link rel="shortcut icon" href="<?=URL?>img/favicon.ico">
</head>
<body>
    <?php if (!$_REQUEST['idImovel']){?>
        <button class="btn btn-danger" style="width:100%">Sem o ID do Imóvel informado!</button>
    <?php } 
    else{?>
<div style="float:left; width:50%; top:0px; position:absolute; left:50%">
    <form class="js-validate" id="formImagens" method="get">
        <h3 style="text-align:center;">Cadastro de Imagens</h3>
        <input type="hidden" value="<?=URL?>" name="url" id="url">
        <input type="hidden" value="<?=$_REQUEST['idImovel']?>" name="property" id="property">
        <input type="hidden" value="" name="id" id="id">
        <label for="name">Nome: </label>
        <input type="text" name="name" id="name" class="form-control" required>
        <label for="imagem">Imagem: </label>
        <input type="file" name="imagem" id="imagem" class="form-control">
        <button type="submit" class="btn btn-primary">Cadastrar</button>
        <button type="button" class="btn btn-secondary" onclick="limparCamposImagens()">Limpar Campos</button>
    </form>
</div>
<div style="float:left; width:50%; top:0px; position:absolute;" id="imagensProduto">
    <?php
    $sql = "SELECT a.*
FROM properties_photos a
WHERE a.property = '".$_REQUEST['idImovel']."'";
    $query = mysqli_query($con, $sql);
    if (mysqli_num_rows($query)) {
        $produtos = 0;
        while ($row = mysqli_fetch_array($query)) {
            if (!isset($imovel)){
                $imovel = $row['property'];
                $imoveis++;
            }
        }
        $query = mysqli_query($con, $sql);
        while ($row = mysqli_fetch_array($query)) {
            ?>
            <div style="width:100%; padding:10px" id="estoque<?=$row['id'] ?>"
                 onmouseover="this.style.backgroundColor='#F7F7F7'"
                 onmouseout="this.style.backgroundColor='#FFFFFF'"><img src="<?=URL?>img/upload/<?=$row['img']?>" width="200"> <?=utf8_encode($row['nomeItem'])." - ".($row['name']) ?> <img
                    src="<?=URL ?>img/editar.png" width="20" style="cursor:pointer"
                    onclick="editaImagem('<?=$row['id'] ?>', '<?=URL ?>', '<?=$_REQUEST['idProduto'] ?>')">
                <img src="<?=URL ?>img/excluir.png" width="20" style="cursor:pointer"
                     onclick="excluirImagem('<?=$row['id'] ?>', '<?=URL ?>', '<?=$_REQUEST['idProduto'] ?>')">
            </div>
            <?php
        }
    }
    else{?>
        <button type="button" class="btn btn-danger">Sem nenhuma imagem encontrado!</button>
                <?php
    }
    ?>
</div>
<?php } ?>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<script src="<?=URL?>img/jquery.min.js"></script>
<script src="<?=URL?>img/bootstrap.min.js"></script>
<script src="<?=URL?>img/moment.min.js"></script>
<script src="<?=URL?>img/daterangepicker.js"></script>
<script src="<?=URL?>img/maskedinput.min.js"></script>
<script src="<?=URL?>img//select2.min.js"></script>
<script src="<?=URL?>img/tags-input.js"></script>
<script src="<?=URL?>img/bhcommerce.js"></script>
<script src="<?=URL?>img/scripts.js"></script>
</body>
</html>
