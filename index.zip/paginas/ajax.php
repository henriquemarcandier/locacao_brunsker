<?php
require_once('../connect.php');
ini_set('display_erros', 'off');
error_reporting(0);
date_default_timezone_set('America/Sao_Paulo');
$sql = "SELECT * FROM param_admins";
$query = mysqli_query($con, $sql);
if (@mysqli_num_rows($query)){
    while ($row = mysqli_fetch_array($query)){
        $parametrosAdmin[$row['name']] = $row['value'];
    }
}
switch ($_REQUEST['acao']) {
	case "paginacaoComentariosProduto":
		$ini = (10 * $_REQUEST['pag']) - 10;
		$fim = 10;
		if ($_REQUEST['pags'] >= 2){
			if ($_REQUEST['pag'] >= 2){
				$anterior = $_REQUEST['pag'] - 1;
			}
			else{
				$anterior = 1;
			}
			if ($_REQUEST['pag'] != $_REQUEST['pags']){
				$proximo = $_REQUEST['pag'] + 1;
			}
			else{
				$proximo = $_REQUEST['pags'];
			}
			$html = '
											<div style="text-align:center">
											<span class="pagina" onclick=\'paginacaoComentariosProduto("1", "'.$_REQUEST['pags'].'", "'.$_REQUEST['product'].'", "'.URL.'")\'>&laquo;</span>
											<span class="pagina" onclick=\'paginacaoComentariosProduto("'.$anterior.'", "'.$_REQUEST['pags'].'", "'.$_REQUEST['product'].'", "'.URL.'")\'><</span>
											';
											for ($i = 1; $i <= $_REQUEST['pags']; $i++){
												$html .= '<span class="';
												if ($i == $_REQUEST['pag']){
													$html .= "pagina_checado";
												}
												else{
													$html .= "pagina";
												}
												$html .= '" onclick=\'paginacaoComentariosProduto("'.$i.'", "'.$_REQUEST['pags'].'", "'.$_REQUEST['product'].'", "'.URL.'")\'>'.$i.'</span>
												';
											}
											$html .= '
											<span class="pagina" onclick=\'paginacaoComentariosProduto("'.$proximo.'", "'.$_REQUEST['pags'].'", "'.$_REQUEST['product'].'", "'.URL.'")\'>></span>
											<span class="pagina" onclick=\'paginacaoComentariosProduto("'.$_REQUEST['pags'].'", "'.$_REQUEST['pags'].'", "'.$_REQUEST['product'].'", "'.URL.'")\'>&raquo;</span>
											</div><br><br>';
		}
		$sql = "SELECT * FROM products_reviews WHERE product = '".$_REQUEST['product']."' AND status = '1' ORDER BY created_at DESC";
		$query = mysqli_query($con, $sql);
		$tot = mysqli_num_rows($query);
		$sql .= " LIMIT ".$ini.", ".$fim;
		$query = mysqli_query($con, $sql);
        $html = "";
		if (mysqli_num_rows($query)){
			while ($value = mysqli_fetch_object($query)){
				$vet = explode(' ', $value->created_at);
				$vet2 = explode('-', $vet[0]);
				$value->hora = $vet[1]."h";
				$value->data = $vet2[2]."/".$vet2[1]."/".$vet2[0];
				$html .= '<ul><li><i class="fa fa-user"></i>'.utf8_encode($value->nome).'</li><li><i class="fa fa-clock-o"></i>'.$value->hora.'</li><li><i class="fa fa-calendar-o"></i>'.$value->data;
				if ($_SESSION['cliente']['email'] == $value->email){
					$html .= ' <img src="'.URL.'img/editar.svg" width="20" style="cursor:pointer" onclick=editarComentarioProduto("'.$value->id.'","'.URL.'")><div id="editarComentarioProduto'.$value->id.'" style="display:none; position:absolute; width:70%; border:1px solid #E7E7E7; background-color:#FFFFFF; padding:5px; border-radius: 25px"></div>';
				}
				$html .= '</li>
												</ul>
												<p>';
												for ($i = 1; $i <= 5; $i++){
													$html .= '<img src="'.URL.'img/star';
													if ($i > $value->avaliacao){
														$html .= "Apagada";
													}
													$html .= '.png" title="Avaliação: '.$value->avaliacao.'"> ';
												}
												$html .= '</p>
												<p>'.(nl2br(utf8_encode($value->mensagem))).'</p>';
			}
		}

		if ($_REQUEST['pags'] >= 2){
			if ($_REQUEST['pag'] >= 2){
				$anterior = $_REQUEST['pag'] - 1;
			}
			else{
				$anterior = 1;
			}
			if ($_REQUEST['pag'] != $_REQUEST['pags']){
				$proximo = $_REQUEST['pag'] + 1;
			}
			else{
				$proximo = $_REQUEST['pags'];
			}
			$html .= '
											<div style="text-align:center">
											<span class="pagina" onclick=\'paginacaoComentariosProduto("1", "'.$_REQUEST['pags'].'", "'.$_REQUEST['product'].'", "'.URL.'")\'>&laquo;</span>
											<span class="pagina" onclick=\'paginacaoComentariosProduto("'.$anterior.'", "'.$_REQUEST['pags'].'", "'.$_REQUEST['product'].'", "'.URL.'")\'><</span>
											';
											for ($i = 1; $i <= $_REQUEST['pags']; $i++){
												$html .= '<span class="';
												if ($i == $_REQUEST['pag']){
													$html .= "pagina_checado";
												}
												else{
													$html .= "pagina";
												}
												$html .= '" onclick=\'paginacaoComentariosProduto("'.$i.'", "'.$_REQUEST['pags'].'", "'.$_REQUEST['product'].'", "'.URL.'")\'>'.$i.'</span>
												';
											}
											$html .= '
											<span class="pagina" onclick=\'paginacaoComentariosProduto("'.$proximo.'", "'.$_REQUEST['pags'].'", "'.$_REQUEST['product'].'", "'.URL.'")\'>></span>
											<span class="pagina" onclick=\'paginacaoComentariosProduto("'.$_REQUEST['pags'].'", "'.$_REQUEST['pags'].'", "'.$_REQUEST['product'].'", "'.URL.'")\'>&raquo;</span>
											</div><br><br>';
		}
		echo "1|-|".$_REQUEST['pag']."|-|".$html."|-|".$tot;
		break;
	case "editarComentarioProduto":
		$sql = "SELECT * FROM products_reviews WHERE id = '".$_REQUEST['id']."'";
		$query = mysqli_query($con, $sql);
		if (mysqli_num_rows($query)){
			$row = mysqli_fetch_array($query);
			$html = "<div style='position:absolute; float:left; left:95%'><img src='".URL."img/close.png' style='cursor: pointer' onclick=fecha('editarComentarioProduto".$_REQUEST['id']."')></div>
			<h3>Solicitação de Edição de Comentário do Produto</h3>
			<label for='estrelasComentarioProduto".$_REQUEST['id']."'>Avaliação</label>
			<div style='width:100%' id='estrelasComentarioProduto".$_REQUEST['id']."'>";
			for ($i = 1; $i <= 5; $i++){
				$html .= "<img src='".URL."img/star";
				if ($i > $row['avaliacao']){
					$html .= "Apagada";
				}
				$html .= ".png' style='cursor:pointer' title='Nota ".$i."' onclick=mudaImgNotasEdicao('".$i."','".$row['id']."','".URL."')> ";
			}
			$html .= '<input type="hidden" name="avaliacaoComentarioProduto'.$row['id'].'" id="avaliacaoComentarioProduto'.$row['id'].'" value="'.$row['avaliacao'].'"></div>
			<label for="mensagemComentarioProduto'.$row['id'].'">Mensagem</label>
			<textarea name="mensagemComentarioProduto'.$row['id'].'" id="mensagemComentarioProduto'.$row['id'].'" style="width:100%; height:250px">'.utf8_encode($row['mensagem']).'</textarea>
			<center><button class="btn btn-primary" onclick=solicitaAlteracaoComentarioProduto("'.$row['id'].'","'.URL.'")>Solicitar Alteração</button> <button class="btn btn-warning" onclick=fecha("editarComentarioProduto'.$row['id'].'")>Fechar</button></center>';
	    }
		else{
			$html .= "Não existe esse comentário do produto!";
		}
		echo "1|-|".$html;
		break;
	case 'solicitarAlteracaoComentarioProduto':
		$sql = "INSERT INTO products_reviews_solicitas (id_product_review, avaliacao, mensagem, created_at, updated_at) VALUES ('".$_REQUEST['id']."', '".$_REQUEST['avaliacao']."', '".$_REQUEST['mensagem']."', now(), now())";
		mysqli_query($con, $sql);
		$assunto = $parametrosSite['title']." - Solicitação de Alteração em Comentário de Produto!";
		$htmlEmail = '<html><head><title>'.$parametrosSite['title'].' - Solicitação de Alteração em Comentário de Produto!</title></head><body><table border="0" width="100%" cellpadding="0" cellspacing="0"><tr><td width="200" valign="top"><img src="'.URL.'img/logo.png" width="100%"></td><td valign="top">Olá <b>'.$parametrosSite['title'].'</b>,<br><br>Esse email é para informar que foi realizada agora uma alteração em um comentário de um produto no site.<br><br>Para ver essa solicitação, <a href="'.URL.'admin/solicitacaoComentario">clique aqui</a>.<br><br>Atenciosamente,<br><br>Equipe '.$parametrosSite['title'].'</td></tr></table><hr noshade><center>Email Desenvolvido Pela <a href="https://www.bhcommerce.com.br/">BH Commerce</a></center><hr noshade></body></html>';
        $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
        $cabecalhoEmail .= "From: ".$parametrosSite['title']."<".$parametrosSite['email'].">\nReply-To: ".$parametrosSite['title']."<".$parametrosSite['email'].">";    
        //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $parametrosSite['email'], $parametrosSite['title'], utf8_decode($assunto), utf8_decode($htmlEmail));
		mail($parametrosSite['title']."<".$parametrosSite['email'].">", utf8_decode($assunto), utf8_decode($htmlEmail), $cabecalhoEmail);
        echo "1";
		break;
    case "contabilizaExibicoesBanner":
        $sql = "SELECT * FROM banners WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $row = mysqli_fetch_array($query);
            $exibitions = $row['exibitions'] + 1;
            $sql = "UPDATE banners SET exibitions = '".$exibitions."' WHERE id = '".$_REQUEST['id']."'";
            mysqli_query($con, $sql);
            echo "1|-|".$row['link'];
        }
        else{
            echo "0|-|Não foi encontrado banner com o id informado!";
        }
        break;
    case "marcarBannerVisitadoEPegarUrl":
        $sql = "SELECT * FROM banners WHERE slug = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $row = mysqli_fetch_array($query);
        }
        $sql = "SELECT * FROM counters_banners WHERE data = '".date('Y-m-d')."' AND banner = '".$row['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row2 = mysqli_fetch_array($query);
            $acessos = $row2['acessos'] + 1;
            $sql = "UPDATE counters_banners SET acessos = '".$acessos."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$row2['id']."'";
            mysqli_query($con, $sql);
        }
        else{
            $sql = "INSERT INTO counters_banners (banner, data, acessos, created_at, updated_at) VALUES ('".$row['id']."', '".date('Y-m-d')."', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql);
        }
        $clicks = $row['clicks'] + 1;
        $sql = "UPDATE banners SET clicks = '".$clicks."' WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo "1|-|".$row['link'];
        break;
    case "editaPresente":
        $sql = "SELECT * FROM presents_lists_products WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        echo "1|-|".$row['product']."|-|".$row['product_item']."|-|".$row['quantity']."|-|".$row['id'];
        break;
    case "excluirPresenteSite":
        $sql = "DELETE FROM presents_lists_products WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo '1';
        break;
    case "cadastrarPresenteSite":
        $sql = "SELECT * FROM presents_lists_products WHERE product = '".$_REQUEST['produto']."' AND product_item = '".$_REQUEST['itemProduto']."' AND lista = '".$_REQUEST['lista']."'";
        $query = mysqli_query($con, $sql);
        if (!mysqli_num_rows($query)){
            $sql = "INSERT INTO presents_lists_products (product, product_item, quantity, ganhou, lista, created_at, updated_at) VALUES ('".$_REQUEST['produto']."', '".$_REQUEST['itemProduto']."', '".$_REQUEST['quantidade']."', '0', '".$_REQUEST['lista']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        }
        else{
            $row = mysqli_fetch_array($query);
            $quantidade = $_REQUEST['quantidade'] + $row['quantity'];
            $sql = "UPDATE presents_lists_products SET quantity = '".$quantidade."' WHERE id = '".$row['id']."'";
        }
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1";
        break;
    case "atualizarPresenteSite":
        $sql = "UPDATE presents_lists_products SET product_item = '".$_REQUEST['itemProduto']."', quantity = '".$_REQUEST['quantidade']."' WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "mostraEdicaoListaPooduto":
        $html = '<div style="display:none; position:absolute; border:1px solid #000000; border-radius:15px; background-color:#FFFFFF; width:100%; z-index:99999999; padding:5px; background-color:#FFFFFF;" id="addPresente'.$_REQUEST['qual'].$_REQUEST['i'].'"><div style="position:absolute; float:left; left:95%; cursor:pointer" onclick=fecha("addPresente'.$_REQUEST['qual'].$_REQUEST['i'].'")>&times;</div><input type="hidden" id="listaAdd'.$_REQUEST['qual'].$_REQUEST['i'].'" name="listaAdd'.$_REQUEST['qual'].$_REQUEST['i'].'" value="'.$_REQUEST['lista'].'"><h3 style="text-align:center">Adicionar Produto de Presente</h3><label for="itemProduto'.$_REQUEST['qual'].$_REQUEST['i'].'">Item do Produto:</label><select name="itemProduto'.$_REQUEST['qual'].$_REQUEST['i'].'" id="itemProduto'.$_REQUEST['qual'].$_REQUEST['i'].'" class="form-control" onchange=selecionaItemProduto(this.value,"'.$_REQUEST['produto'].'","'.$_REQUEST['qual'].'","'.URL.'","'.$_REQUEST['i'].'","'.$_REQUEST['lista'].'")><option value="">Selecione o item do produto abaixo...</option>';
        $sql = "SELECT a.*, b.name AS nomeProduto FROM products_items a INNER JOIN products b ON (a.product = b.id) WHERE a.product = '".$_REQUEST['produto']."'";
        $query = mysqli_query($con, $sql);
        while ($row = mysqli_fetch_array($query)){
            $html .= "<option value='".$row['id']."'>".utf8_encode($row['nomeProduto']." - ".$row['name'])."</option>";
        }
        $html .= '</select><div id="quantidadePresente'.$_REQUEST['qual'].$_REQUEST['i'].'"></div></div><div style="display:none; position:absolute; border:1px solid #000000; border-radius:15px; background-color:#FFFFFF; width:100%; z-index:99999999; padding:5px; background-color:#FFFFFF;" id="editaPresente'.$_REQUEST['qual'].$_REQUEST['i'].'"><div style="position:absolute; float:left; left:95%; cursor:pointer" onclick=fecha("editaPresente'.$_REQUEST['qual'].$_REQUEST['i'].'")>&times;</div><input type="hidden" id="listaEdita'.$_REQUEST['qual'].$_REQUEST['i'].'" name="listaEdita'.$_REQUEST['qual'].$_REQUEST['i'].'" value="'.$_REQUEST['lista'].'"><h3 style="text-align:center">Atualizar Produto de Presente</h3><label for="itemProdutoEdita'.$_REQUEST['qual'].$_REQUEST['i'].'">Item do Produto:</label><select name="itemProdutoEdita'.$_REQUEST['qual'].$_REQUEST['i'].'" id="itemProdutoEdita'.$_REQUEST['qual'].$_REQUEST['i'].'" class="form-control" onchange=selecionaItemProdutoEdita(this.value,"'.$_REQUEST['produto'].'","'.$_REQUEST['qual'].'","'.URL.'","'.$_REQUEST['i'].'","'.$_REQUEST['lista'].'")><option value="">Selecione o item do produto abaixo...</option>';
        $sql = "SELECT a.*, b.name AS nomeProduto FROM products_items a INNER JOIN products b ON (a.product = b.id) WHERE a.product = '".$_REQUEST['produto']."'";
        $query = mysqli_query($con, $sql);
        while ($row = mysqli_fetch_array($query)){
            $html .= "<option value='".$row['id']."'>".utf8_encode($row['nomeProduto']." - ".$row['name'])."</option>";
        }
        $html .= '</select><div id="quantidadePresenteEdita'.$_REQUEST['qual'].$_REQUEST['i'].'"></div></div><input type="hidden" name="listaPresentEdita'.$_REQUEST['qual'].$_REQUEST['i'].'" id="listaPresentEdita'.$_REQUEST['qual'].$_REQUEST['i'].'" value="'.$_REQUEST['lista'].'"><input type="hidden" name="idEdita'.$_REQUEST['qual'].$_REQUEST['i'].'" id="idEdita'.$_REQUEST['qual'].$_REQUEST['i'].'" value=""><div style="position:absolute; float:left; left:95%; cursor:pointer" onclick=fecha("listaPresentes'.$_REQUEST['qual'].$_REQUEST['i'].'")>&times;</div><a id="topoListaPresente'.$_REQUEST['qual'].$_REQUEST['i'].'"></a><h3>Produtos Adicionados à Lista</h3><div style="text-align:right"><button class="btn btn-primary" onclick=addPresente("'.$_REQUEST['qual'].$_REQUEST['i'].'")>Adicionar</button></div>';
        $sql = "SELECT a.*, b.name AS nomeProduto, c.name AS nomeItem FROM presents_lists_products a INNER JOIN products b ON (a.product = b.id) INNER JOIN products_items c ON (a.product_item = c.id) WHERE a.product = '".$_REQUEST['produto']."' AND a.lista = '".$_SESSION['idLista']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $html .= '<table border="0" width="100%" cellpadding="0" cellspacing="0"><tr><th>Nome do Produto</th><th>Pediu</th><th>Ganhou</th><th>Ações</th></tr>';
            while ($row = mysqli_fetch_array($query)){
                $html .= "<tr><td style='text-align:center'>".utf8_encode($row['nomeProduto']." - ".$row['nomeItem'])."</td><td valign='top' style='text-align:center'>".$row['quantity']."</td><td valign='top' style='text-align:center'>".$row['ganhou']."</td><td valign='top' style='text-align:center'><img src='".URL."img/editar.png' width='20' style='cursor:pointer' onclick=editaPresente('".$row['id']."','".URL."','".$row['product']."','".$_REQUEST['qual']."','".$_REQUEST['i']."','".$_REQUEST['lista']."')><img src='".URL."img/excluir.png' width='20' style='cursor:pointer' onclick=excluirPresente('".$row['id']."','".URL."','".$row['product']."','".$_REQUEST['qual']."','".$_REQUEST['i']."','".$_REQUEST['lista']."')></td></tr>";
            }
            $html .= "</table>";
        }
        else{
            $html .= "<div class='btn btn-danger'>Sem nenhum desse produto adicionado à lista!</div>";
        }
        echo "1|-|".$html;
        break;
    case "atualizarPresente":
        $sql = "UPDATE presents_lists_products SET product = '".$_REQUEST['product']."', product_item = '".$_REQUEST['product_item']."', quantity = '".$_REQUEST['quantidade']."' WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "adicionarPresente":
        $sql = "SELECT * FROM presents_lists_products WHERE lista = '".$_REQUEST['lista']."' AND product = '".$_REQUEST['product']."' AND product_item = '".$_REQUEST['product_item']."'";
        $query = mysqli_query($con, $sql);
        if(!mysqli_num_rows($query)){
            $sql = "INSERT INTO presents_lists_products (lista, product, product_item, quantity, ganhou, created_at, updated_at) VALUES ('".$_REQUEST['lista']."', '".$_REQUEST['product']."', '".$_REQUEST['product_item']."', '".$_REQUEST['quantidade']."', '0', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        }
        else{
            $row = mysqli_fetch_array($query);
            $quantidade = $row['quantity'] + $_REQUEST['quantidade'];
            $sql = "UPDATE presents_lists_products SET quantity = '".$quantidade."' WHERE id = '".$row['id']."'";
        }
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "selecionaProdutoPresente":
        $sql = "SELECT * FROM products_items WHERE product = '".$_REQUEST['produto']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $html = '<label for="itemProdutoPresenteAdd">Item do Produto</label><select name="itemProdutoPresenteAdd" id="itemProdutoPresenteAdd" class="form-control" onclick=selecionaItemProdutoPresente(this.value,"'.URL.'")><option value="">Selecione o item abaixo corretamente...</option>';
            while ($row = mysqli_fetch_array($query)){
                $html .= '<option value="'.$row['id'].'">'.utf8_encode($row['name']).'</option>';
            }
            $html .= '</select><div id="qtdeAdd"></div>';
        }
        else{
            $html = '<div class="btn btn-danger">Nenhum item encontrado!</div>';
        }
        echo "1|-|".$html;
        break;
    case "selecionaProdutoPresenteEdita":
        $sql = "SELECT * FROM products_items WHERE product = '".$_REQUEST['produto']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $html = '<label for="itemProdutoPresenteEdita">Item do Produto</label><select name="itemProdutoPresenteEdita" id="itemProdutoPresenteEdita" class="form-control" onclick=selecionaItemProdutoPresenteEdita(this.value,"'.URL.'","'.$_REQUEST['qualEQuant'].'")><option value="">Selecione o item abaixo corretamente...</option>';
            while ($row = mysqli_fetch_array($query)){
                $html .= '<option value="'.$row['id'].'"';
                if ($_REQUEST['qualE'] == $row['id']){
                    $html .= " selected";
                }
                $html .= '>'.utf8_encode($row['name']).'</option>';
            }
            $html .= '</select><div id="qtdeEdita"></div>';
        }
        else{
            $html = '<div class="btn btn-danger">Nenhum item encontrado!</div>';
        }
        echo "1|-|".$html."|-|".$_REQUEST['qualEQuant'];
        break;
    case "adicionarConvidado":
        $sql = "SELECT * FROM presents_lists_guests WHERE lista = '".$_REQUEST['lista']."' AND email = '".$_REQUEST['email']."'";
        $query = mysqli_query($con, $sql);
        $rows = mysqli_num_rows($query);
        $sql = "SELECT a.* FROM presents_lists a INNER JOIN clients b ON (a.client = b.id) WHERE a.id = '".$_REQUEST['lista']."' AND b.email = '".$_REQUEST['email']."'";
        $query2 = mysqli_query($con, $sql);
        $rows2 = mysqli_num_rows($query2);
        if ($rows){
            echo "0|-|Já existe um convidado com o email informado! Tente outro!";
        }
        elseif ($rows2) {
            echo "0|-|Não é possível cadastrar o mesmo email do cliente da lista! Tente outro!";
        }
        else {
            $sql = "INSERT INTO presents_lists_guests (lista, name, email, cel, created_at, updated_at) VALUES ('".$_REQUEST['lista']."', '".$_REQUEST['nome']."', '".$_REQUEST['email']."', '".$_REQUEST['cel']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql);
            echo "1";
        }
        break;
    case "atualizaConvidado":
        $sql = "SELECT * FROM presents_lists_guests WHERE lista = '".$_REQUEST['lista']."' AND email = '".$_REQUEST['email']."' AND id != '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $rows = mysqli_num_rows($query);
        $sql = "SELECT a.* FROM presents_lists a INNER JOIN clients b ON (a.client = b.id) WHERE a.id = '".$_REQUEST['lista']."' AND b.email = '".$_REQUEST['email']."'";
        $query2 = mysqli_query($con, $sql);
        $rows2 = mysqli_num_rows($query2);
        if ($rows){
            echo "0|-|Já existe um convidado com o email informado! Tente outro!";
        }
        elseif ($rows2) {
            echo "0|-|Não é possível cadastrar o mesmo email do cliente da lista! Tente outro!";
        }
        else {
            $sql = "UPDATE presents_lists_guests SET name = '".$_REQUEST['nome']."', email = '".$_REQUEST['email']."', cel = '".$_REQUEST['cel']."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['id']."'";
            mysqli_query($con, $sql);
            echo "1";
        }
        $sql = utf8_decode("INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', 'Editou o convidado ".$_REQUEST['id']." da lista de presentes ".$_REQUEST['lista']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
        mysqli_query($con, $sql);
        break;
    case "enviarEmailConvidado":
        $sql = "SELECT a.*, b.nomeAniversariante, b.dataAniversario, b.nomeMae, b.nomePai, b.idade, b.cep, b.address, b.number, b.complement, b.neighborhood, b.city, b.state, b.slug, d.name AS nomeCliente, e.nomeFantasia, e.contato FROM presents_lists_guests a INNER JOIN presents_lists b ON (a.lista = b.id) INNER JOIN clients c ON (b.client = c.id) LEFT JOIN pessoa_fisicas d ON (c.id = d.client) LEFT JOIN pessoa_juridicas e ON (c.id = e.client) WHERE a.id = '" . $_REQUEST['id'] . "'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $idLista = $row['lista'];
        $id = $row['id'];
        $nomeCliente = ($row['nomeCliente']) ? $row['nomeCliente'] : $row['nomeFantasia']." - ".$row['contato'];
        $vet = explode('-', $row['dataAniversario']);
        $row['dataAniversario'] = $vet[2]."/".$vet[1]."/".$vet[0];
        $htmlEmail = utf8_decode("<html><head><title>Email de Lista de presentes</title></head><body><table width='100%' border='0' cellpadding='0' cellspacing='0'><tr><td width='150' valign='top'><img src='".URL."img/logo.png'></td><td valign='top'>Olá <b>".($row['name'])."</b>,<br>O cliente ".utf8_encode($nomeCliente)." te adicionou a uma lista de presentes em nosso site.<h3>Dados da Lista</h3>Nome do Aniversariante: <b>".utf8_encode($row['nomeAniversariante'])."</b><br>Data do aniversário: <b>".$row['dataAniversario']."</b><br>Nome da mãe: <b>".utf8_encode($row['nomeMae'])."</b><br>Nome do pai: <b>".utf8_encode($row['nomePai'])."</b><br>Idade que vai completar: <b>".utf8_encode($row['idade'])."</b><br>Endereço: <b>".utf8_encode($row['address'].", ".$row['number']));
        if ($row['complement']){
            $htmlEmail .= ', '.$row['complement'];
        }
        $htmlEmail .= utf8_decode(" - B. ".utf8_encode($row['neighborhood']." - ".$row['city']." - ".$row['state'])." - CEP: ".$row['cep']."</b><br><a href='".URL."lista-de-presentes/".$row['slug']."'>Ver a Lista de Presentes</a><h3>Produtos da Lista</h3>");
        $sql = "SELECT a.*, b.name AS nomeProduto, b.slug, c.id AS idItemProduto, c.name AS nomeItemProduto, c.value, c.promotion, c.validity_promotion FROM presents_lists_products a INNER JOIN products b ON (a.product = b.id) INNER JOIN products_items c ON (a.product_item = c.id) WHERE a.lista = '".$row['lista']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $i = 0;
            $htmlEmail .= "<table width='100%' cellpadding='0' cellspacing='0' border='0'><tr><th>Produto</th><th>Valor do Produto</th><th>Qtde</th><th>Ganhou</th><th>Comprar</th></tr>";
            while ($row2 = mysqli_fetch_array($query)){
                $valorProduto = ($row2['promotion'] && $row2['valiidity_promotion'] <= date('Y-m-d')) ? $row2['promotion'] : $row2['value'];
                $sql = "SELECT * FROM products_images WHERE product_item = '".$row2['idItemProduto']."' LIMIT 1";
                $query3 = mysqli_query($con, $sql);
                $row3 = mysqli_fetch_array($query3);
                $htmlEmail .= "<tr><td";
                if ($i % 2 == 0){
                    $htmlEmail .= " style='background-color:#E7E7E7'";
                }
                $htmlEmail .= "><a href='".URL_SITE."produto/".$row2['slug']."'>";
                $htmlEmail .= "<img src='".URL."img/upload/".$row3['img']."' width='100'>";

                $htmlEmail .= "<br>".$row2['nomeProduto']." - ".$row2['nomeItemProduto']."</a></td><td";
                if ($i % 2 == 0){
                    $htmlEmail .= " style='background-color:#E7E7E7'";
                }
                $htmlEmail .= ">R$ ".number_format($valorProduto, 2, ',','.')."</td><td";
                if ($i % 2 == 0){
                    $htmlEmail .= " style='background-color:#E7E7E7'";
                }
                $htmlEmail .= ">".$row2['quantity']."</td><td";
                if ($i % 2 == 0){
                    $htmlEmail .= " style='background-color:#E7E7E7'";
                }
                $htmlEmail .= ">".$row2['ganhou']."</td><td style='text-align:center; ";
                if ($i % 2 == 0){
                    $htmlEmail .= "background-color:#E7E7E7";
                }
                $htmlEmail .= "'>";
                if ($row2['quantity'] > $row2['ganhou']) {
                    $htmlEmail .= "<a href='" . URL_SITE . "addCart.php?idList=" . base64_encode($row2['lista']) . "&product=" . base64_encode($row2['product']) . "&product_item=" . base64_encode($row2['product_item']) . "&idGuest=" . base64_encode($row2['id']) . "'><img src='" . URL . "img/addCart.png' width='50'></a>";
                }
                $htmlEmail .= "</td></tr>";
                $i++;
            }
            $htmlEmail .= "</table>";
        }
        $htmlEmail .= "</td></td></tr></table>Atenciosamente,<br><br>Equipe ".$parametrosSite['title']."<hr noshade><center>Email Desenvolvido Pela <a href='https://www.bhcommerce.com.br/'>BH Commerce</a></center><hr noshade></body></html>";
        $assunto = $parametrosSite['title']." - Lista de Presentes";
        $paraNome = $nomeCliente;
        $paraEmail = $row['email'];
        $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
        $cabecalhoEmail .= "From: ".$parametrosSite['title']."<".$parametrosSite['email'].">\nReply-To: ".$parametrosSite['title']."<".$parametrosSite['email'].">";
        mail($paraNome."<".$paraEmail.">", $assunto, $htmlEmail, $cabecalhoEmail);
        //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $paraEmail, $paraNome, $assunto, $htmlEmail);
        $sql = "UPDATE presents_lists_guests SET send_email_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$id."'";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1|-|".$row['lista']."|-|".$htmlEmail;
        break;
    case "enviarFaleConosco":
        $sql = "INSERT INTO messages (name, email, subject, phone, text, status, created_at, updated_at) VALUES ('".$_REQUEST['nome']."', '".$_REQUEST['email']."', '".$_REQUEST['assunto']."', '".$_REQUEST['phone']."', '".$_REQUEST['message']."', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql);
        $htmlEmail = utf8_decode("<html><head><title>Email Enviado pelo formulário de contato do ".$parametrosSite['title']."</title></head><body><table width='100%' border='0' cellpadding='0' cellspacing='0'><tr><td width='150' valign='top'><img src='".URL."img/logo.png'></td><td valign='top'>Olá <b>Equipe ".$parametrosSite['title']."</b>,<br>Foi enviado um email pelo formulário de fale conosco da ".$parametrosSite['title']."<br><br>Dados da Mensagem:<br><br>Nome: <b>".$_REQUEST['nome']."</b><br>Email: <b>".$_REQUEST['email']."</b><br>Assunto: <b>".$_REQUEST['assunto']."</b><br>Telefone: <b>".$_REQUEST['phone']."</b><br>Mensagem: <b>".$_REQUEST['message']."</b><br>Data/Hora de Envio: <b>".date('d/m/Y H:i:s')."</b>");
        $htmlEmail .= "<br><br>Para ver essa mensagem no admin, <a href='".URL."admin/faleConosco'>clique aqui.</a><br><br></br>Atenciosamente,<br><br>Equipe ".$parametrosSite['title']."<hr noshade><center>Email Desenvolvido Pela <a href='https://www.bhcommerce.com.br/'>BH Commerce</a></center><hr noshade></body></html>";
        $assunto = $parametrosSite['title'].utf8_decode(" - Email enviado pelo formulário de Fale Conosco do Site");
        $paraNome = $_REQUEST['nome'];
        $paraEmail = $_REQUEST['email'];
        $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
        $cabecalhoEmail .= "From: ".$parametrosSite['title']."<".$parametrosSite['email'].">\nReply-To: ".$parametrosSite['title']."<".$parametrosSite['email'].">";
        //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $parametrosSite['email'], $parametrosSite['title'], $assunto, $htmlEmail);
        mail($parametrosSite['title']."<".$parametrosSite['email'].">", $assunto, $htmlEmail, $cabecalhoEmail);
        echo "1|-|".$_SESSION['cliente']['name']."|-|".$_SESSION['cliente']['email'];
        break;
    case "enviarAnuncieAqui":
        $sql = "INSERT INTO anuncie_aqui (name, email, subject, phone, text, status, nome_banner, link_banner, target_banner, posicao_banner, tipo_banner, created_at, updated_at) VALUES ('".$_REQUEST['nome']."', '".$_REQUEST['email']."', '".$_REQUEST['assunto']."', '".$_REQUEST['phone']."', '".$_REQUEST['message']."', '1', '".$_REQUEST['nome_banner']."', '".$_REQUEST['link_banner']."', '".$_REQUEST['target_banner']."', '".$_REQUEST['posicao_banner']."', '".$_REQUEST['tipo_banner']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        $query = mysqli_query($con, $sql);
        $idAnuncieAqui = mysqli_insert_id($con);
        if (preg_match("/jpg/", $_FILES['banner']['name']) || preg_match("/jpeg/", $_FILES['banner']['name'])){
            $img = "anuncieAqui".$idAnuncieAqui.".jpg";
        }
        elseif (preg_match("/gif/", $_FILES['banner']['name'])){
            $img = "anuncieAqui".$idAnuncieAqui.".gif";
        }
        elseif (preg_match("/png/", $_FILES['banner']['name'])){
            $img = "anuncieAqui".$idAnuncieAqui.".png";
        }
        elseif (preg_match("/bmp/", $_FILES['banner']['name'])){
            $img = "anuncieAqui".$idAnuncieAqui.".bmp";
        }
        elseif (preg_match("/webp/", $_FILES['banner']['name'])){
            $img = "anuncieAqui".$idAnuncieAqui.".webp";
        }
        if ($img){
            copy($_FILES['banner']['tmp_name'], DIRETORIO."img/upload/".$img);
        }
        $sql = "UPDATE anuncie_aqui SET img = '".$img."' WHERE id = '".$idAnuncieAqui."'";
        $query = mysqli_query($con, $sql);
		$htmlEmail = utf8_decode("<html><head><title>Email Enviado pelo formulário do anuncie aqui do ".$parametrosSite['title']."</title></head><body><table width='100%' border='0' cellpadding='0' cellspacing='0'><tr><td width='150' valign='top'><img src='".URL."img/logo.png'></td><td valign='top'>Olá <b>Equipe ".$parametrosSite['title']."</b>,<br>Foi enviado um email pelo formulário de anuncie aqui do ".$parametrosSite['title']."<br><br>Dados da Mensagem:<br><br>Nome: <b>".$_REQUEST['nome']."</b><br>Email: <b>".$_REQUEST['email']."</b><br>Assunto: <b>".$_REQUEST['assunto']."</b><br>Telefone: <b>".$_REQUEST['phone']."</b><br>Mensagem: <b>".$_REQUEST['message']."</b><br>Data/Hora de Envio: <b>".date('d/m/Y H:i:s')."</b>");
        $htmlEmail .= "<br><br>Para ver essa mensagem no admin, <a href='".URL."admin/faleConosco'>clique aqui.</a><br><br></br>Atenciosamente,<br><br>Equipe ".$parametrosSite['title']."<hr noshade><center>Email Desenvolvido Pela <a href='https://www.bhcommerce.com.br/'>BH Commerce</a></center><hr noshade></body></html>";
        $assunto = $parametrosSite['title'].utf8_decode(" - Email enviado pelo formulário de Anuncie Aqui do Site");
        $paraNome = $row['nome'];
        $paraEmail = $row['email'];
        $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
        $cabecalhoEmail .= "From: ".$parametrosSite['title']."<".$parametrosSite['email'].">\nReply-To: ".$parametrosSite['title']."<".$parametrosSite['email'].">";
        //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $parametrosSite['email'], $parametrosSite['title'], $assunto, $htmlEmail);
        mail($parametrosSite['title']."<".$parametrosSite['email'].">", $assunto, $htmlEmail, $cabecalhoEmail);
        echo "1|-|".$_SESSION['cliente']['name']."|-|".$_SESSION['cliente']['email'];
        break;
    case "enviarTodosNaoEnviados":
        $sql = "SELECT a.*, b.nomeAniversariante, b.dataAniversario, b.nomeMae, b.nomePai, b.idade, b.cep, b.address, b.number, b.complement, b.neighborhood, b.city, b.state, b.slug, d.name AS nomeCliente, e.nomeFantasia, e.contato FROM presents_lists_guests a INNER JOIN presents_lists b ON (a.lista = b.id) INNER JOIN clients c ON (b.client = c.id) LEFT JOIN pessoa_fisicas d ON (c.id = d.client) LEFT JOIN pessoa_juridicas e ON (c.id = e.client) WHERE a.lista= '" . $_REQUEST['id'] . "' AND (a.send_email_at = '0000-00-00 00:00:00' OR a.send_email_at IS NULL)";
        //echo $sql;
        $query = mysqli_query($con, $sql);
        while($row = mysqli_fetch_array($query)) {
            $idLista = $row['lista'];
            $id = $row['id'];
            $nomeCliente = ($row['nomeCliente']) ? $row['nomeCliente'] : $row['nomeFantasia'] . " - " . $row['contato'];
            $vet = explode('-', $row['dataAniversario']);
            $row['dataAniversario'] = $vet[2] . "/" . $vet[1] . "/" . $vet[0];
            $htmlEmail = utf8_decode("<html><head><title>Email de Lista de presentes</title></head><body><table width='100%' border='0' cellpadding='0' cellspacing='0'><tr><td width='150' valign='top'><img src='" . URL . "img/logo.png'></td><td valign='top'>Olá <b>" . ($row['name']) . "</b>,<br>O cliente " . utf8_encode($nomeCliente) . " te adicionou a uma lista de presentes em nosso site.<h3>Dados da Lista</h3>Nome do Aniversariante: <b>" . utf8_encode($row['nomeAniversariante']) . "</b><br>Data do aniversário: <b>" . $row['dataAniversario'] . "</b><br>Nome da mãe: <b>" . utf8_encode($row['nomeMae']) . "</b><br>Nome do pai: <b>" . utf8_encode($row['nomePai']) . "</b><br>Idade que vai completar: <b>" . utf8_encode($row['idade']) . "</b><br>Endereço: <b>" . utf8_encode($row['address'] . ", " . $row['number']));
            if ($row['complement']) {
                $htmlEmail .= ', ' . $row['complement'];
            }
            $htmlEmail .= utf8_decode(" - B. " . utf8_encode($row['neighborhood'] . " - " . $row['city'] . " - " . $row['state']) . " - CEP: " . $row['cep'] . "</b><br><a href='".URL."lista-de-presentes/".$row['slug']."'>Ver a Lista de Presentes</a><h3>Produtos da Lista</h3>");
            $sql = "SELECT a.*, b.name AS nomeProduto, b.slug, c.id AS idItemProduto, c.name AS nomeItemProduto, c.value, c.promotion, c.validity_promotion FROM presents_lists_products a INNER JOIN products b ON (a.product = b.id) INNER JOIN products_items c ON (a.product_item = c.id) WHERE a.lista = '" . $row['lista'] . "'";
            $query2 = mysqli_query($con, $sql);
            if (mysqli_num_rows($query2)) {
                $i = 0;
                $htmlEmail .= "<table width='100%' cellpadding='0' cellspacing='0' border='0'><tr><th>Produto</th><th>Valor do Produto</th><th>Qtde</th><th>Ganhou</th><th>Comprar</th></tr>";
                while ($row2 = mysqli_fetch_array($query2)) {
                    $valorProduto = ($row2['promotion'] && $row2['valiidity_promotion'] <= date('Y-m-d')) ? $row2['promotion'] : $row2['value'];
                    $sql = "SELECT * FROM products_images WHERE product_item = '" . $row2['idItemProduto'] . "' LIMIT 1";
                    $query3 = mysqli_query($con, $sql);
                    $row3 = mysqli_fetch_array($query3);
                    $htmlEmail .= "<tr><td";
                    if ($i % 2 == 0) {
                        $htmlEmail .= " style='background-color:#E7E7E7'";
                    }
                    $htmlEmail .= "><a href='" . URL . "produto/" . $row2['slug'] . "'>";
                    $htmlEmail .= "<img src='" . URL . "img/upload/" . $row3['img'] . "' width='100'>";
                    $htmlEmail .= "<br>" . $row2['nomeProduto'] . " - " . $row2['nomeItemProduto'] . "</a></td><td";
                    if ($i % 2 == 0) {
                        $htmlEmail .= " style='background-color:#E7E7E7'";
                    }
                    $htmlEmail .= ">R$ " . number_format($valorProduto, 2, ',', '.') . "</td><td";
                    if ($i % 2 == 0) {
                        $htmlEmail .= " style='background-color:#E7E7E7'";
                    }
                    $htmlEmail .= ">" . $row2['quantity'] . "</td><td";
                    if ($i % 2 == 0) {
                        $htmlEmail .= " style='background-color:#E7E7E7'";
                    }
                    $htmlEmail .= ">" . $row2['ganhou'] . "</td><td style='text-align:center; ";
                    if ($i % 2 == 0) {
                        $htmlEmail .= "background-color:#E7E7E7";
                    }
                    $htmlEmail .= "'>";
                    if ($row2['quantity'] > $row2['ganhou']) {
                        $htmlEmail .= "<a href='" . URL . "addCart.php?idList=" . base64_encode($row2['lista']) . "&product=" . base64_encode($row2['product']) . "&product_item=" . base64_encode($row2['product_item']) . "&idGuest=" . base64_encode($row2['id']) . "'><img src='" . URL . "img/addCart.png' width='50'></a>";
                    }
                    $htmlEmail .= "</td></tr>";
                    $i++;
                }
                $htmlEmail .= "</table>";
            }
            $htmlEmail .= "</td></td></tr></table>Atenciosamente,<br><br>Equipe " . $parametrosSite['title'] . "<hr noshade><center>Email Desenvolvido Pela <a href='https://www.bhcommerce.com.br/'>BH Commerce</a></center><hr noshade></body></html>";
            $assunto = $parametrosSite['title'] . " - Lista de Presentes";
            $paraNome = $nomeCliente;
            $paraEmail = $row['email'];
            $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
            $cabecalhoEmail .= "From: " . $parametrosSite['title'] . "<" . $parametrosSite['email'] . ">\nReply-To: " . $parametrosSite['title'] . "<" . $parametrosSite['email'] . ">";
            //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $paraEmail, $paraNome, $assunto, $htmlEmail);
			mail($paraNome."<".$paraEmail.">", $assunto, $htmlEmail, $cabecalhoEmail);
            $sql = "UPDATE presents_lists_guests SET send_email_at = '".date('Y-m-d H:i:s')."' WHERE id = '" . $id . "'";
            mysqli_query($con, $sql) or die(mysqli_error($con));
        }
        echo "1|-|".$_REQUEST['id']."|-|".$htmlEmail;
        break;
    case "excluirConvidado":
        $sql = "SELECT * FROM presents_lists_guests WHERE id = '" . $_REQUEST['id'] . "'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $sql = "DELETE FROM presents_lists_guests WHERE id = '" . $_REQUEST['id'] . "'";
            $query = mysqli_query($con, $sql);
            $sql = utf8_decode("INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', 'Excluiu o convidado ".$_REQUEST['id']." da lista de presentes ".$row['lista']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
            mysqli_query($con, $sql);
            echo "1|-|".$row['lista'];
        }
        break;
    case "visualizaConvidado":
        $sql = "SELECT * FROM presents_lists_guests WHERE id = '" . $_REQUEST['id'] . "'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        if ($row['send_email_at'] != '0000-00-00 00:00:00'){
            $vet = explode(' ', $row['send_email_at']);
            $vet2 = explode('-', $vet[0]);
            $row['send_email_at'] = $vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h";
        }
        else{
            $row['send_email_at'] = "Não Enviado";
        }
        $vet = explode(' ', $row['created_at']);
        $vet2 = explode('-', $vet[0]);
        $row['created_at'] = $vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h";
        $vet = explode(' ', $row['updated_at']);
        $vet2 = explode('-', $vet[0]);
        $row['updated_at'] = $vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h";
        echo "1|-|<div style='position:absolute; float:left; left:95%; cursor:pointer' onclick=fecha('visualizaConvidado')>&times;</div><h3 style='text-align:center'>Visualizar Convidado</h3><hr style='color:#f7f7f7'>Nome do convidado: <b>".$row['name']."</b><br>Email do convidado: <b>".$row['email']."</b><br>Celular do convidado: <b>".$row['cel']."</b><br>Email enviado em: <b>".$row['send_email_at']."</b><br>Cadastrado em: <b>".$row['created_at']."</b><br>Atualizado em: <b>".$row['updated_at']."</b>";
        break;
    case "atualizarConvidado":
        if ($_REQUEST['emailConvidado'] != $_SESSION['cliente']['email']) {
            $sql = "SELECT * FROM presents_lists_guests WHERE id = '".$_REQUEST['id']."'";
            $query = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($query);
            $sql = "UPDATE presents_lists_guests SET name = '".$_REQUEST['nomeConvidado']."', email = '".$_REQUEST['emailConvidado']."', cel = '".$_REQUEST['celConvidado']."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['id']."'";
            mysqli_query($con, $sql) or die(mysqli_error($con));
            $sql = utf8_decode("INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', 'Editou o convidado ".$_REQUEST['id']." da lista de presentes ".$row['lista']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
            mysqli_query($con, $sql);
            echo "1";
        }
        else{
            echo "0|-|Não é possível cadastrar o seu email em suas listas!";
        }
        break;
    case "editaConvidado":
        $sql = "SELECT * FROM presents_lists_guests WHERE id = '" . $_REQUEST['id'] . "'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        echo "1|-|".$row['name']."|-|".$row['email']."|-|".$row['cel'];
        break;
    case 'cadastrarConvidado':
        if ($_REQUEST['emailConvidado'] != $_SESSION['cliente']['email']) {
            $sql = "SELECT * FROM presents_lists_guests WHERE lista = '" . $_REQUEST['idLista'] . "' AND email = '" . $_REQUEST['emailConvidado'] . "'";
            $query = mysqli_query($con, $sql);
            if (!mysqli_num_rows($query)) {
                $sql = "INSERT INTO presents_lists_guests (lista, name, email, cel, send_email_at, created_at, updated_at) VALUES ('" . $_REQUEST['idLista'] . "', '" . $_REQUEST['nomeConvidado'] . "', '" . $_REQUEST['emailConvidado'] . "', '" . $_REQUEST['celConvidado'] . "', '0000-00-00 00:00:00', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                mysqli_query($con, $sql) or die(mysqli_error($con));
                $sql = utf8_decode("INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', 'Cadastrou um convidado à lista de presentes ".$_REQUEST['idLista']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                mysqli_query($con, $sql);
            }
            echo "1";
        }
        else{
            echo "0|-|Não é possível cadastrar o seu email em suas listas!";
        }
        break;
    case "abreListaConvidados":
        echo "1|-|<div style='position:absolute; float:left; left:95%; cursor:pointer' onclick=fecha('listaDeConvidados')>&times;</div><h3 style='text-align:center'>Lista de Convidados</h3><hr style='color:#E7E7E7'><div id='visualizaConvidado' style='display:none; position:absolute; width:100%; padding:5px; background-color:#FFFFFF; border-color:#e7e7e7; border-radius:15px'><div style='position:absolute; float:left; left:95%; cursor:pointer' onclick=fecha('visualizaConvidado')>&times;</div></div><div id='editConvidado' style='display:none; position:absolute; width:100%; padding:5px; background-color:#FFFFFF; border-color:#e7e7e7; border-radius:15px'><div style='position:absolute; float:left; left:95%; cursor:pointer' onclick=fecha('editConvidado')>&times;</div><h3 style='text-align:center'>Atualizar Convidado</h3><hr style='color:#e7e7e7'><input type='hidden' value='".$_REQUEST['id']."' name='idListEdita' id='idListEdita'><label for='nomeConvidadoEdita'>Nome do Convidado: </label><input type='text' class='form-control' name='nomeConvidadoEdita' id='nomeConvidadoEdita' required placeholder='Informe o nome do convidado aqui...'><label for='emailConvidadoEdita'>Email do Convidado: </label><input type='email' class='form-control' name='emailConvidadoEdita' id='emailConvidadoEdita' required placeholder='Informe o email do convidado aqui...'><label for='celConvidadoEdita'>Celular do Convidado: </label><input type='text' class='form-control' name='celConvidadoEdita' id='celConvidadoEdita' maxlength='14' onkeyup=formataCampo(this,'(##)#####-####',event) required placeholder='Informe o celular com o DDD do convidado aqui...'><input type='hidden' id='idEdita' name='idEdita' value=''><div style='text-align:right'><button type='button' class='btn btn-primary' onclick=atualizarConvidado('".URL."')>Atualizar</button> <button type='button' class='btn btn-secondary' onclick=fecha('editConvidado')>Fechar</button></div></div><div id='addConvidado' style='display:none; position:absolute; width:100%; padding:5px; background-color:#FFFFFF; border-color:#e7e7e7; border-radius:15px'><div style='position:absolute; float:left; left:95%; cursor:pointer' onclick=fecha('addConvidado')>&times;</div><h3 style='text-align:center'>Adicionar Convidado</h3><hr style='color:#e7e7e7'><input type='hidden' value='".$_REQUEST['id']."' name='idListAdd' id='idListAdd'><label for='nomeConvidadoAdd'>Nome do Convidado: </label><input type='text' class='form-control' name='nomeConvidadoAdd' id='nomeConvidadoAdd' required placeholder='Informe o nome do convidado aqui...'><label for='emailConvidadoAdd'>Email do Convidado: </label><input type='email' class='form-control' name='emailConvidadoAdd' id='emailConvidadoAdd' required placeholder='Informe o email do convidado aqui...'><label for='celConvidadoAdd'>Celular do Convidado: </label><input type='text' class='form-control' name='celConvidadoAdd' id='celConvidadoAdd' maxlength='14' onkeyup=formataCampo(this,'(##)#####-####',event) required placeholder='Informe o celular com o DDD do convidado aqui...'><div style='text-align:right'><button type='button' class='btn btn-primary' onclick=cadastrarConvidado('".URL."')>Cadastrar</button> <button type='button' class='btn btn-secondary' onclick=fecha('addConvidado')>Fechar</button></div></div>";
		$sql = "SELECT * FROM presents_lists WHERE id = '".$_REQUEST['id']."' AND status = '1'";
		$query = mysqli_query($con, $sql);
		$totLista = mysqli_num_rows($query);
		if ($totLista){
			echo "<div style='text-align:right; float:left'><button type='button' class='btn btn-primary' onclick=abreFecha('addConvidado')>Adicionar Convidado</button> <div style='float:left; padding-top:15px'><button type='button' class='btn btn-info' onclick=enviarTodosNaoEnviados('".$_REQUEST['id']."','".URL."')>Enviar a Todos não enviados</button></div>";
		}
		echo "</div>";
        $sql = "SELECT * FROM presents_lists_guests WHERE lista = '".$_REQUEST['id']."' ORDER BY created_at DESC";
        //echo $sql;
        $query = mysqli_query($con, $sql);
        $i = 0;
        if (mysqli_num_rows($query)){
            echo "<table border='0' width='100%' cellpadding='0' cellspacing='0' style='border-radius:15px'><tr><th style='text-align:center'>Nome do Convidado</th><th style='text-align:center'>Email do Convidado</th><th style='text-align:center'>Celular do Convidado</th><th style='text-align:center'>Data de Envio</th><th style='text-align:center'>Ações</th></tr>";
            while ($row = mysqli_fetch_array($query)){
                echo "<tr><td style='padding:5px;";
                if ($i % 2 == 0){
                    echo " background-color:#e7e7e7";
                }
                echo "'>".$row['name']."</td><td style='padding:5px;";
                if ($i % 2 == 0){
                    echo " background-color:#e7e7e7";
                }
                echo "'>".$row['email']."</td><td style='padding:5px;";
                if ($i % 2 == 0){
                    echo " background-color:#e7e7e7";
                }
                echo "'>".$row['cel']."</td>";
                if ($row['send_email_at'] != '0000-00-00 00:00:00'){
                    $vet = explode(' ', $row['send_email_at']);
                    $vet2 = explode('-', $vet[0]);
                    $row['send_email_at'] = $vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h";
                }
                else{
                    $row['send_email_at'] = "Não enviado";
                }
                echo "<td style='padding:5px;";
                if ($i % 2 == 0){
                    echo " background-color:#e7e7e7";
                }
                echo "'>".$row['send_email_at']."</td><td style='padding:5px;";
                if ($i % 2 == 0){
                    echo " background-color:#e7e7e7";
                }
                echo "'>";
				if ($totLista){
					echo "<img src='".URL."img/enviarEmail.png' width='20' style='cursor:pointer' onclick=enviarEmailConvidado('".$row['id']."','".URL."')> ";
				}
				echo "<img src='".URL."img/visualizar.svg' width='20' style='cursor:pointer' onclick=visualizaConvidado('".$row['id']."','".URL."')> ";
				if ($totLista){
					echo "<img src='".URL."img/editar.png' width='20' style='cursor:pointer' onclick=editaConvidado('".$row['id']."','".URL."')> <img src='".URL."img/excluir.png' width='20' style='cursor:pointer' onclick=excluirConvidado('".$row['id']."','".URL."')>";
				}
				echo "</td></tr>";
                $i++;
            }
            echo "</table>";
        }
        else{
            echo "<button type='button' class='btn btn-danger'>Nenhum convidado encontrado!</button>";
        }
        echo "<div style='text-align:right'><button type='button' class='btn btn-secondary' onclick=fecha('listaDeConvidados')>Fechar</button></div>";
        $sql = utf8_decode("INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', 'Visualizou os convidados da lista de presentes ".$_REQUEST['id']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
        mysqli_query($con, $sql);
        break;
    case "atualizarProdutoLista":
        $sql = "SELECT * FROM presents_lists_products WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $sql = "UPDATE presents_lists_products SET product = '".$_REQUEST['produto']."', product_item = '".$_REQUEST['itemVenda']."', quantity = '".$_REQUEST['quantidade']."' WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo "1|-|".$row['lista'];
        break;
    case "excluirProdutoLista":
        $sql = "SELECT * FROM presents_lists_products WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $sql = "DELETE FROM presents_lists_products WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        $sql = utf8_decode("INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', 'Excluiu o produto ".$row['product']." da lista de presentes ".$row['lista']."!', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1|-|".$row['lista'];
        break;
    case "editaProdutoLista":
        $sql = "SELECT * FROM presents_lists_products WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $html = "<div style='position:absolute; float:left; left:95%; cursor:pointer' onclick=fecha('editaProdutoLista')>&times;</div><h3 style='text-align:center'>Editar Produto da Lista</h3><hr style='color:#e7e7e7'><label for='produtoListaEdicao'>Produto:</label><select name='produtoListaEdicao' id='produtoListaEdicao' onchange=selecionaProdutoListaProdutos(this.value,'".URL."','itemVendaEdicao') class='form-control'><option value=''>Selecione um produto corretamente...</option>";
        $sql = "SELECT * FROM products WHERE status = '1'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row2 = mysqli_fetch_array($query)){
                $html .= "<option value='".$row2['id']."' ";
                if ($row2['id'] == $row['product']){
                    $html .= "selected";
                }
                $html .= ">".$row2['name']."</option>";
            }
        }
        $html .= "</select><div id='itemVendaEdicao'><label for='itemVendaListaEdicao'>Item de Venda:</label><select name='itemVendaListaEdicao' id='itemVendaListaEdicao' onchange=selecionaItemVendaProdutoLista(this.value,'".URL."','quantidadeEdicao') class='form-control'><option value=''>Selecione um item de venda corretamente...</option>";
        $sql = "SELECT a.*, b.name AS nomeProduto FROM products_items a INNER JOIN products b ON (a.product = b.id) WHERE a.status = '1' AND a.product = '".$row['product']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row3 = mysqli_fetch_array($query)){
                $html .= "<option value='".$row3['id']."' ";
                if ($row3['id'] == $row['product_item']){
                    $html .= "selected";
                }
                $html .= ">".$row3['nomeProduto']." - ".$row3['name']."</option>";
            }
        }
        $html .= "</select><div id='quantidadeEdicao'><label for='quantidadeListaProdutosEdicao'>Quantidade:</label><input type='number' id='quantidadeListaProdutosEdicao' name='quantidadeListaProdutosEdicao' class='form-control' value='".$row['quantity']."' min='1' max='".$row['estoque']."'></div></div><span id='editarProdutoLista'><button class='btn btn-primary' onclick=atualizarProdutoLista('".$_REQUEST['id']."','".URL."')>Atualizar</button></span><button class='btn btn-secondary' onclick=fecha('editaProdutoLista')>Fechar</button>";
        $sql = utf8_decode("INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', 'Atualizou o produto ".$row['product']." da lista de presentes ".$row['lista']."!', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1|-|".utf8_encode($html);
        break;
    case "cadastrarProdutoLista":
        $sql = "SELECT * FROM presents_lists_products WHERE lista = '".$_REQUEST['id']."' AND product = '".$_REQUEST['produto']."' AND product_item = '".$_REQUEST['itemVenda']."'";
        $query = mysqli_query($con, $sql);
        if (!mysqli_num_rows($query)) {
            $sql = "INSERT INTO presents_lists_products (lista, product, product_item, quantity, ganhou, created_at, updated_at) VALUES ('" . $_REQUEST['id'] . "', '" . $_REQUEST['produto'] . "', '" . $_REQUEST['itemVenda'] . "', '" . $_REQUEST['quantidade'] . "', '0', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql);
        }
        else{
            $row = mysqli_fetch_array($query);
            $quantidade = $row['quantity'] + $_REQUEST['quantidade'];
            $sql = "UPDATE presents_lists_products SET quantity = '".$quantidade."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$row['id']."'";
            mysqli_query($con, $sql);
        }        
        $sql = utf8_decode("INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', 'Inseriu um produto a lista de presentes ".$_REQUEST['id']."!', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1";
        break;
    case "selecionaItemVendaProdutoLista":
        $sql = "SELECT * FROM products_items WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $html = "<label for='quantidadeProdutoLista'>Quantidade: </label>";
            $row = mysqli_fetch_array($query);
            if ($row['estoque']){
                $html .= "<input type='number' name='quantidadeProdutoLista' id='quantidadeProdutoLista' class='form-control' min='1' max='".$row['estoque']."' value='1'>";
                $semEstoque = 0;
            }
            else{
                $html = "<button class='btn btn-danger'>Este item de venda se encontra sem estoque!!</button>";
                $semEstoque = 1;
            }
        }
        else{
            $html = "<button class='btn btn-danger'>Este item de venda não existe!</button>";
        }
        echo "1|-|".$html."|-|".$semEstoque;
        break;
    case "selecionaProdutoListaProdutos":
        $html = "<label for='itemVendaListaProdutos'>Item de Venda: </label><select name='itemVendaListaProdutos' id='itemVendaListaProdutos' class='form-control' onchange=selecionaItemVendaProdutoLista(this.value,'".URL."')><option value=''>Selecione o item de venda corretamente...</option>";
        $sql =  "SELECT a.*, b.name AS nomeProduto FROM products_items a INNER JOIN products b ON (a.product = b.id) WHERE a.product = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                $valor = ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')) ? $row['promotion'] : $row['value'];
                $html .= "<option value='".$row['id']."'>".utf8_encode($row['nomeProduto']." - ".$row['name'])." - R$ ".number_format($valor, 2, ',', '.')."</option>";
            }
        }
        $html .= "</select><div id='qtdeProdutoListaProdutos' style='display:none'></div>";
        echo "1|-|".$html;
       break;
    case 'abreListaPresentes':
        $html = "<div style='position:absolute; float:left; left:95%; cursor:pointer' onclick=fecha('listaDePresentes')>&times;</div><div id='editaProdutoLista' style='display:none; position:absolute; background-color:#FFFFFF; border:1px solid #e7e7e7; width:100%; border-radius:15px; padding:5px'></div><div id='addProdutoListaPresentes' style='position:absolute; width:100%; background-color:#FFFFFF; border:1px solid #e7e7e7; border-radius:15px; padding:5px; display:none'><div style='position:absolute;float:left; left:95%; cursor:pointer' onclick=fecha('addProdutoListaPresentes')>&times;</div><h3 style='text-align:center'>Adicionar Produto à Lista</h3><hr style='color:#e7e7e7'><input type='hidden' id='idListaProdutosCadastro' name='idListaProdutosCadastro' value='".$_REQUEST['id']."'><label for='produtoListaProdutos'>Produto: </label><select name='produtoListaProdutos' id='produtoListaProdutos' class='form-control' required onchange=selecionaProdutoListaProdutos(this.value,'".URL."')><option value=''>Selecione o produto abaixo corretamente...</option>";
        $sql = "SELECT * FROM products WHERE status = '1'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                $html .= "<option value='".$row['id']."'>".utf8_encode($row['name'])."</option>";
            }
        }
		$sql = "SELECT * FROM presents_lists WHERE id = '".$_REQUEST['id']."' AND status = '1'";
		$query = mysqli_query($con, $sql);
		$totLista = mysqli_num_rows($query);
        $html .= "</select><div id='itensVendaProdutoListaProdutos' style='display:none'></div><div style='text-align:right'><span id='salvarProdutoLista' style='display:none'><button class='btn btn-primary' onclick=cadastrarProdutoLista('".$_REQUEST['id']."','".URL."')>Cadastrar</button></span><button class='btn btn-secondary' onclick=fecha('addProdutoListaPresentes')>Fechar</button></div></div><h3 style='text-align:center'>Lista de Presentes</h3><hr style='color: #e7e7e7'>";
		if ($totLista){
			$html .= "<button type='button' class='btn btn-primary' onclick=abreFecha('addProdutoListaPresentes')>Cadastrar Novo</button>";
        }
		$sql = "SELECT a.*, b.name AS nomeProduto, b.slug, c.name AS nomeItemVenda, c.value, c.promotion, c.validity_promotion FROM presents_lists_products a INNER JOIN products b ON (a.product = b.id) INNER JOIN products_items c ON (a.product_item = c.id) WHERE a.lista = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $html .= "<table width='100%' border='0' cellpadding='0' cellspacing='0'><tr><th>Produto</th><th>Valor</th><th>Quantidade</th><th>Ganhou</th><th>Ações</th></tr>";
            while ($row = mysqli_fetch_array($query)){
                $sql = "SELECT * FROM products_images WHERE product_item = '".$row['product_item']."' LIMIT 1";
                $query2 = mysqli_query($con, $sql);
                $row2 = mysqli_fetch_array($query2);
                $valor = ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')) ? $row['promotion'] : $row['value'];
                $html .= utf8_encode("<tr><td style='text-align:center'><a href='".URL."produto/".$row['slug']."'>");
                if ($row2['img']){
                    $html .= "<img src='".URL."img/upload/".$row2['img']."' width='100'>";
                }
                else{
                    $html .= "<img src='".URL."img/upload/sem_imagem.png' width='100'>";
                }
                $html .= utf8_encode("<br>".$row['nomeProduto']." - ".$row['nomeItemVenda']."</a></td><td style='text-align:center'>R$ ".number_format($valor, 2,',','.')."</td><td style='text-align:center'>".$row['quantity']."</td><td style='text-align:center'>".$row['ganhou']."</td><td style='text-align:center'>");
                if ($totLista && $row['quantity'] > $row['ganhou']) {
                    $html .= "<img src='" . URL . "img/editar.png' width='20' style='cursor:pointer' onclick=editaProdutoLista('" . $row['id'] . "','" . URL . "')> <img src='" . URL . "img/excluir.png' width='20' style='cursor:pointer' onclick=excluirProdutoLista('" . $row['id'] . "','" . URL . "')>";
                }
                $html .= "</td></tr>";
            }
            $html .= "</table>";
        }
        else{
            $html .= "<center><button class='btn btn-danger'>Não foi encontrado nenhum produto para esta lista!</button></center>";
        }
        echo "1|-|".$html;
        break;
    case "visusalizarListaPresentes":
        $sql = "SELECT * FROM presents_lists WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $lista = mysqli_fetch_array($query);
            $vet = explode('-', $lista['dataAniversario']);
            $lista['dataAniversario'] = $vet[2]."/".$vet[1]."/".$vet[0];
            $vet = explode(' ', $lista['created_at']);
            $vet2 = explode('-', $vet[0]);
            $lista['created_at'] = $vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h";
        }
        $html = "<div style='position:absolute; float:left; left:95%; cursor:pointer' onclick='fecha(\"visusalizarListaPresentes\")'>&times;</div><h3 style='text-align:center'>Visualização de Lista de Presentes</h3><hr style='color:#E7E7E7'>URL da Lista: <a href='".URL."lista-de-presentes/".$lista['slug']."'>".URL."lista-de-presentes/".$lista['slug']."</a><br>Nome do Aniversariante: <b>".utf8_encode($lista['nomeAniversariante'])."</b><br>Data do Aniversário: <b>".$lista['dataAniversario']."</b><br>Nome da Mãe: <b>".utf8_encode($lista['nomeMae'])."</b><br>Nome do Pai: <b>".utf8_encode($lista['nomePai'])."</b><br>Idade do Aniversariante: <b>".$lista['idade']." ano";
        if ($lista['idade'] > 1){
            $html .= "s";
        }
        $html .= "</b><br>CEP: <b>".$lista['cep']."</b><br>Logradouro: <b>".utf8_encode($lista['address'])."</b><br>Número: <b>".utf8_encode($lista['number'])."</b>";
        if ($lista['complement']) {
            $html .= "<br>Complemento: <b>" . utf8_encode($lista['complement']) . "</b>";
        }
        $html .= "<br>Bairro: <b>".utf8_encode($lista['neighborhood'])."</b><br>Cidade: <b>".utf8_encode($lista['city'])."</b><br>Estado: <b>".utf8_encode($lista['state'])."</b><br>Data do Cadastro: <b>".$lista['created_at']."</b>";
        echo "1|-|".$html;
        break;
    case "editaListaPresentes":
        $sql = "SELECT * FROM presents_lists WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $lista = mysqli_fetch_array($query);
        }
        $html = "<input type='hidden' value='".$lista['id']."' name='idListaEdicao' id='idListaEdicao'><div style='position:absolute; float:left; left:95%; cursor:pointer' onclick='fecha(\"editarListaPresentes\")'>&times;</div><h3 style='text-align:center'>Atualização de Lista de Presentes</h3><hr style='color:#E7E7E7'><label for='nomeAniversarianteEdicao'>Nome do(a) Aniversariante: </label><input type='text' value='".utf8_encode($lista['nomeAniversariante'])."' name='nomeAniversarianteEdicao' id='nomeAniversarianteEdicao' required class='form-control'><label for='dataAniversarioEdicao'>Data do Aniversário: </label><input type='date' value='".$lista['dataAniversario']."' name='dataAniversarioEdicao' id='dataAniversarioEdicao' required class='form-control'><label for='nomeMaeEdicao'>Nome da Mãe do(a) Aniversariante: </label><input type='text' value='".utf8_encode($lista['nomeMae'])."' class='form-control' name='nomeMaeEdicao' id='nomeMaeEdicao' required><label for='nomePaiEdicao'>Nome do Pai do(a) Aniversariante: </label><input type='text' value='".utf8_encode($lista['nomePai'])."' class='form-control' name='nomePaiEdicao' id='nomePaiEdicao' required><label for='idadeEdicao'>Idade que o(a) aniversariante vai fazer: </label><input type='number' value='".$lista['idade']."' name='idadeEdicao' id='idadeEdicao' class='form-control' required><label for='cepListaEdicao'>CEP: </label><input type=\"text\" name=\"cepListaEdicao\" id=\"cepListaEdicao\" class=\"form-control\" onkeyup=\"mascara(this, '#####-###', event); pesquisacependerecoedicaolista(this.value)\" maxlength=\"9\" value='".$lista['cep']."'><label for='logradouroListaEdicao'>Logradouro: </label><input type='text' value='".utf8_encode($lista['address'])."' class='form-control' name='logradouroListaEdicao' id='logradouroListaEdicao' required><label for='numeroListaEdicao'>Número: </label><input type='text' value='".utf8_encode($lista['number'])."' class='form-control' name='numeroListaEdicao' id='numeroListaEdicao' required>";
        $html .= "<label for='complementoListaEdicao'>Complemento: </label><input type='text' value='".utf8_encode($lista['complement'])."' class='form-control' name='complementoListaEdicao' id='complementoListaEdicao'>";
        $html .= "<label for='bairroListaEdicao'>Bairro: </label><input type='text' value='".utf8_encode($lista['neighborhood'])."' class='form-control' name='bairroListaEdicao' id='bairroListaEdicao' required><label for='cidadeListaEdicao'>Cidade: </label><input type='text' value='".utf8_encode($lista['city'])."' class='form-control' name='cidadeListaEdicao' id='cidadeListaEdicao' required><label for='estadoListaEdicao'>Estado: </label><select class='form-control' name='estadoListaEdicao' id='estadoListaEdicao' required><option value=''>UF</option>";
        $sql = "SELECT * FROM states ORDER BY sigla ASC";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                $html .= "<option value='".$row['sigla']."'";
                if ($row['sigla'] == $lista['state']){
                    $html .= " selected";
                }
                $html .= ">".$row['sigla']."</option>";
            }
        }
        $html .= "</select><div style='float:left; padding-top:0px; margin:0px'><button type='button' class='btn btn-primary' onclick=edicaoListaPresentes('".URL."')>Editar</button></div><div style='float:left; padding-top:15px; margin:0px'><button type='button' class='btn btn-info' onclick=fecha('editarListaPresentes')>Fechar</button></div>";
        echo "1|-|".$html;
        break;
    case "removerDaListaPresentes":
        $_SESSION['idLista'] = '';
        echo "1";
        break;
    case "adicionarProdutosALista":
        $_SESSION['idLista'] = $_REQUEST['id'];
        echo "1";
        break;
    case "excluirListaPresentes":
        $sql = utf8_decode("DELETE FROM presents_lists WHERE id = '".$_REQUEST['id']."'");
        mysqli_query($con, $sql) or die(mysqli_error($con));
        $_SESSION['idLista'] = mysqli_insert_id($con);
        $sql = utf8_decode("INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', 'Excluiu a lista de presentes ".$_REQUEST['id']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
        mysqli_query($con, $sql);
        echo "1|-|";
        break;
    case "cadastraListaPresentes":
        $slug = RetirarAcentos(utf8_decode($_REQUEST['nomeAniversariante']."_".$_REQUEST['dataAniversario']));
        $sql = "SELECT * FROM presents_lists WHERE slug = '".$slug."'";
        $query = mysqli_query($con, $sql);
        $qualEsta = 2;
        while (mysqli_num_rows($query)){
            $slug = RetirarAcentos(utf8_decode($_REQUEST['nomeAniversariante']."_".$qualEsta."_".$_REQUEST['dataAniversario']));
            $sql = "SELECT * FROM presents_lists WHERE slug = '".$slug."'";
            $query = mysqli_query($con, $sql);
            $qualEsta++;
        }
        $sql = utf8_decode("INSERT INTO presents_lists (client, nomeAniversariante, dataAniversario, slug, nomeMae, nomePai, idade, cep, address, number, complement, neighborhood, city, state, status, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', '".$_REQUEST['nomeAniversariante']."', '".$_REQUEST['dataAniversario']."', '".$slug."', '".$_REQUEST['nomeMae']."', '".$_REQUEST['nomePai']."', '".$_REQUEST['idade']."', '".$_REQUEST['cep']."', '".$_REQUEST['logradouro']."', '".$_REQUEST['numero']."', '".$_REQUEST['complemento']."', '".$_REQUEST['bairro']."', '".$_REQUEST['cidade']."', '".$_REQUEST['estado']."', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
        mysqli_query($con, $sql) or die(mysqli_error($con));
        $_SESSION['idLista'] = mysqli_insert_id($con);
        $sql = utf8_decode("INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', 'Cadastrou uma nova lista de presentes!', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1|-|".$sql;
        break;
    case "atualizaListaPresentes":
	$slug = RetirarAcentos(utf8_decode($_REQUEST['nomeAniversariante']."_".$_REQUEST['dataAniversario']));
        $sql = "SELECT * FROM presents_lists WHERE slug = '".$slug."' AND id != '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $qualEsta = 2;
        while (mysqli_num_rows($query)){
            $slug = RetirarAcentos(utf8_decode($_REQUEST['nomeAniversariante']."_".$qualEsta."_".$_REQUEST['dataAniversario']));
            $sql = "SELECT * FROM presents_lists WHERE slug = '".$slug."' AND id != '".$_REQUEST['id']."'";
            $query = mysqli_query($con, $sql);
            $qualEsta++;
        }
        $sql = "SELECT * FROM presents_lists WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        if (date('Y-m-d') > $_REQUEST['dataAniversario']){
            $status = 0;
        }
        else{
            $status = 1;
        }
        $sql = utf8_decode("UPDATE presents_lists SET nomeAniversariante = '".$_REQUEST['nomeAniversariante']."', dataAniversario = '".$_REQUEST['dataAniversario']."', slug = '".$slug."', nomeMae = '".$_REQUEST['nomeMae']."', nomePai = '".$_REQUEST['nomePai']."', idade = '".$_REQUEST['idade']."', cep = '".$_REQUEST['cep']."', address = '".$_REQUEST['logradouro']."', number = '".$_REQUEST['numero']."', complement = '".$_REQUEST['complemento']."', neighborhood = '".$_REQUEST['bairro']."', city = '".$_REQUEST['cidade']."', state = '".$_REQUEST['estado']."', status = '".$status."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['id']."'");
        mysqli_query($con, $sql) or die(mysqli_error($con));
        if ($status) {
            $_SESSION['idLista'] = $_REQUEST['id'];
        }
		elseif ($_SESSION['idLista'] == $_REQUEST['id']){
			$_SESSION['idLista'] = "";
		}
        $sql = utf8_decode("INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', 'Atualizou a lista de presentes ".$_REQUEST['id']."!', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1|-|".$sql;
        break;
    case "cadastraProdutoPedido":
        $sql = "SELECT * FROM products_items WHERE id = '".$_REQUEST['idItem']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $sql = "SELECT * FROM products WHERE id = '".$_REQUEST['idProduto']."'";
        $query = mysqli_query($con, $sql);
        $row2 = mysqli_fetch_array($query);
        $sql = "SELECT a.*, b.cep FROM requests a INNER JOIN addresses b ON (a.address = b.id) WHERE a.id = '".$_REQUEST['idPedido']."'";
        $query = mysqli_query($con, $sql);
        $row3 = mysqli_fetch_array($query);
        $estoque = $row['estoque'] - $_REQUEST['quantidade'];
        $valor = ($row['promotion'] != '0.00' && $row['validity_promotion'] >= date('Y-m-d')) ? $row['promotion'] : $row['value'];
        $sql = "UPDATE products_items SET estoque = '".$estoque."' WHERE id = '".$_REQUEST['idItem']."'";
        mysqli_query($con, $sql);
        $sql = "INSERT INTO requests_items (request, product, product_item, name, value, quantity, created_at, updated_at) VALUES ('".$_REQUEST['idPedido']."', '".$_REQUEST['idProduto']."', '".$_REQUEST['idItem']."', '".$row2['name']." - ".$row['name']."', '".$valor."', '".$_REQUEST['quantidade']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql);
        $sql = "SELECT a.*, b.peso, b.comprimento, b.largura, b.altura, b.diametro FROM requests_items a INNER JOIN products_items b ON (a.product_item = b.id) WHERE a.request = '".$_REQUEST['idPedido']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while($row = mysqli_fetch_array($query)){
                if (!preg_match('/Vale Presente/', $row['name'])) {
                    $valorSubtotal += $row['value'] * $row['quantity'];
                    $peso += $row['peso'] * $row['quantity'];
                    $diametro += $row['diametro'] * $row['quantity'];
                    $comprimento += $row['comprimento'] * $row['quantity'];
                    $largura += $row['largura'] * $row['quantity'];
                    $altura += $row['altura'] * $row['quantity'];
                }
            }
        }
        if ($row3['tipoFrete'] != 'Frete_Gratis') {
            if ($row3['tipoFrete'] == 'SEDEX'){
                $tipoFrete = 40010;
            }
            elseif ($row3['tipoFrete'] == 'PAC'){
                $tipoFrete = 41106;
            }
            elseif ($row3['tipoFrete'] == 'SEDEX_10'){
                $tipoFrete = 40215;
            }
            elseif ($row3['tipoFrete'] == 'SEDEX_Hoje'){
                $tipoFrete = 40290;
            }
            unset($data);
            $data['nCdEmpresa'] = '';
            $data['sDsSenha'] = '';
            $data['sCepOrigem'] = $parametrosSite['cepLoja'];
            $data['sCepDestino'] = str_replace('-', '', $row3['cep']);
            $data['nVlPeso'] = $peso;
            $data['nCdFormato'] = '1';
            $data['nVlComprimento'] = $comprimento;
            $data['nVlAltura'] = $altura;
            $data['nVlLargura'] = $largura;
            $data['nVlDiametro'] = $diametro;
            $data['sCdMaoPropria'] = 's';
            $data['nVlValorDeclarado'] = $valorSubtotal;
            $data['sCdAvisoRecebimento'] = 'n';
            $data['StrRetorno'] = 'xml';
            $data = http_build_query($data);
            $url = 'http://ws.correios.com.br/calculador/CalcPrecoPrazo.aspx';
            $curl = curl_init($url . '?' . $data."&nCdServico=".$tipoFrete);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

            $result = curl_exec($curl);

            $result = simplexml_load_string($result);

            foreach ($result->cServico as $row) {

                //Os dados de cada serviço estará aqui

                $retorno[$k] = $row;

            }
            foreach ($retorno as $key => $value) {
                $valorFrete = str_replace(".", "", $value->Valor);
                $valorFrete = str_replace(",", ".", $valorFrete);
            }
        }
        else{
            $valorFrete = 0;
        }
        $valorTotal = $valorSubtotal + $valorFrete - $row3['valurDiscount'];
        $sql = "UPDATE requests SET valueSubtotal = '".$valorSubtotal."', valueFrete = '".$valorFrete."', valueTotal = '".$valorTotal."' WHERE id = '".$_REQUEST['idPedido']."'";
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "listarMensagemPedido":
        $sql = "SELECT a.*, b.email, c.name, d.nomeFantasia FROM requests a INNER JOIN clients b ON (a.client = b.id) LEFT JOIN pessoa_fisicas c ON (a.id = c.client) LEFT JOIN pessoa_juridicas d ON (a.id = d.client) WHERE a.id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $html = "<h5>Mensagens Internas (vista só no admin)</h5>".nl2br($row['msInterna'])."<h5>Mensagens Externas (vista também pelo cliente)</h5>".nl2br($row['msExterna'])."<h5>Mensagens de Email</h5>".nl2br($row['msEmail']);
        echo "1|-|".$html;
        break;
    case "cadastraMensagemPedido":
        $msgMensagem = "em <b>".date('d/m/Y')."</b> às <b>".date('H:i:s')."</b>h\r\nPor: <b>".$_SESSION['user']['name']."<".$_SESSION['user']['email']."></b>\r\nReferente ao pedido: <b>".sprintf("%06s\n", $_REQUEST['idPedido'])."</b>\r\nMensagem: <b>".$_REQUEST['mensagem']."</b>";
        $sql = "SELECT a.*, b.email, c.name, d.nomeFantasia FROM requests a INNER JOIN clients b ON (a.client = b.id) LEFT JOIN pessoa_fisicas c ON (a.id = c.client) LEFT JOIN pessoa_juridicas d ON (a.id = d.client) WHERE a.id = '".$_REQUEST['idPedido']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        if ($_REQUEST['msInterna']){
            if ($row['msInterna']){
                $msInterna = $msgMensagem."<hr noshade>".$row['msInterna'];
            }
            else{
                $msInterna = $msgMensagem;
            }
        }
        if ($_REQUEST['msExterna']){
            if ($row['msExterna']){
                $msExterna = $msgMensagem."<hr noshade>".$row['msExterna'];
            }
            else{
                $msExterna = $msgMensagem;
            }
        }
        if ($_REQUEST['msEmail']){
            if ($row['msEmail']){
                $msEmail = $msgMensagem."<hr noshade>".$row['msEmail'];
            }
            else{
                $msEmail = $msgMensagem;
            }
            $msgEmail = "<html><head><title>".$parametrosSite['title']." - Mensagem referente ao pedido ".sprintf("%06s\n", $_REQUEST['idPedido'])."</title></head><body><table border='0' width='100%'><tr><td width='30%' style='text-align:center'><img src='".URL."img/logo.png' width='100'></td><td>".nl2br($msgMensagem)."<br><br>Atenciosamente,<br><br>Equipe <b>".$parametrosSite['title']."</b><hr noshade><center>Email Desenvolvido Pela <a href='https://www.bhcommerce.com.br/'>BH Commerce</a></center><hr noshade></td></tr></table></body></html>";
            if ($row['name']) {
                $paraNome = $row['name'];
            }
			else{
				$paraNome = $row['nomeFantasia'];
			}
            $paraEmail = $row['email'];
            $assunto = $parametrosSite['title']." - Mensagem referente ao pedido ".sprintf("%06s\n", $_REQUEST['idPedido']);
            $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
            $cabecalhoEmail .= "From: ".$parametrosSite['title']."<".$parametrosSite['email'].">\nReply-To: ".$parametrosSite['title']."<".$parametrosSite['email'].">";
            mail($paraNome."<".$paraEmail.">", $assunto, $msEmail, $cabecalhoEmail);
			//enviarEmail($parametrosSite['email'], $parametrosSite['title'], $paraEmail, $paraNome, $assunto, $msgEmail);

        }
        $sql = "UPDATE requests SET ";
        if ($msInterna){
            $sql .= "msInterna = '".$msInterna."'";
            $entrou = 1;
        }
        if ($msExterna){
            if ($entrou == 1){
                $sql .= ', ';
            }
            $sql .= "msExterna = '".$msExterna."'";
            $entrou = 1;
        }
        if ($msEmail){
            if ($entrou == 1){
                $sql .= ', ';
            }
            $sql .= "msEmail = '".$msEmail."'";
            $entrou = 1;
        }
        $sql .= " WHERE id = '".$_REQUEST['idPedido']."'";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1";
        break;
    case "visualizarPedidos":
        echo "1|-|";
        $sql = "SELECT a.*, b.name, c.nomeFantasia, d.sigla AS siglaStatus, d.name AS nomeStatus, d.color, d.background FROM requests a LEFT JOIN pessoa_fisicas b ON (a.client = b.client) LEFT JOIN pessoa_juridicas c ON (a.client = c.client) INNER JOIN requests_statuses d ON (a.status = d.id) WHERE a.client = '".$_SESSION['cliente']['id']."' ORDER BY a.created_at DESC";
        $query = mysqli_query($con, $sql) or die(mysqli_error($con));
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                echo '<div class="col-2" style="width:33%; float:left; padding:5px; cursor:pointer; color:'.$row['color'].'; background-color: '.$row['background'].'" onclick=abrePedido("'.$row['id'].'","'.URL.'")><h3>Orç. '.sprintf("%06s", $row['id']).'</h3>';
                if ($row['name']){
                    echo "Nome do cliente: <b>".($row['name'])."</b>";
                }
                else{
                    echo "Nome da empresa: <b>".($row['nomeFantasia'])."</b>";
                }
                echo '<br>Status do Orçamento: <b title="'.utf8_encode($row['nomeStatus']).'">'.$row['siglaStatus'].'</b></div>';
            }
        }
        else{
            echo '<div class="btn btn-danger" data-dismiss="modal">Nenhum orçamento encontrado até o momento!</div>';
        }
        break;
    case "visualizarListaPresentes":
        $sql = "SELECT * FROM presents_lists WHERE dataAniversario <= '".date('Y-m-d')."' AND status = '1'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
			while ($row = mysqli_fetch_array($query)){
				$sql = "UPDATE presents_lists SET status = '0' WHERE id = '".$row['id']."'";
				mysqli_query($con, $sql);
			}
		}
        echo "1|-|<div style='position:absolute; display:none; border:1px solid #e7e7e7; background-color:#FFFFFF; border-radius:15px; width:100%; padding:5px;' id='listaDeConvidados'></div><div style='position:absolute; display:none; border:1px solid #e7e7e7; background-color:#FFFFFF; border-radius:15px; width:100%; padding:5px;' id='listaDePresentes'><div style='position:absolute; float:left; left:95%; cursor:pointer' onclick='fecha(\"listaDePresentes\")'>&times;</div><h3>Lista de Presentes</h3></div><div style='position:absolute; display:none; border:1px solid #e7e7e7; background-color:#FFFFFF; border-radius:15px; width:100%' id='addListaPresentes'><div style='position:absolute; float:left; left:95%; cursor:pointer' onclick='fecha(\"addListaPresentes\")'>&times;</div><input type='hidden' name='urlAddListasPresentes' id='urlAddListasPresentes' value='".URL."'><h3 style='text-align:center;'>Adicionar Lista de Presentes</h3><hr style='color:#E7E7E7'><label for='nomeAniversarianteCadastrar'>Nome do(a) aniversariante:</label><input type='text' name='nomeAniversarianteCadastrar' id='nomeAniversarianteCadastrar' class='form-control' placeholder='Informe o nome do(a) aniversariante aqui...' required><label for='dataAniversarioCadastrar'>Data do aniversário:</label><input type='date' name='dataAniversarioCadastrar' id='dataAniversarioCadastrar' class='form-control' required><label for='nomeMaeCadastrar'>Nome da mãe do(a) aniversariante:</label><input type='text' name='nomeMaeCadastrar' id='nomeMaeCadastrar' class='form-control' placeholder='Informe o nome da mãe do(a) aniversariante aqui...' required><label for='nomePaiCadastrar'>Nome do pai do(a) aniversariante:</label><input type='text' name='nomePaiCadastrar' id='nomePaiCadastrar' class='form-control' placeholder='Informe o nome do pai do(a) aniversariante aqui...' required><label for='idadeCadastrar'>Idade que o(a) aniversariante vai fazer:</label><input type='number' name='idadeCadastrar' id='idadeCadastrar' class='form-control' placeholder='Informe a idade que o(a) aniversariante vai completar aqui...' required><label for='cepCadastrar'>CEP: </label><input type=\"text\" name=\"cepCadastrar\" id=\"cepCadastrar\" value=\"\" placeholder=\"Informe o seu cep\" class='form-control' onkeyup=\"mascara(this, '#####-###', event); verificaceplista(this.value)\" maxlength=\"9\"><label for='logradouroCadastrar'>Logradouro: </label><input type='text' name='logradouroCadastrar' id='logradouroCadastrar' class='form-control' placeholder='Informe o logradouro aqui...' required><label for='numeroCadastrar'>Número: </label><input type='text' name='numeroCadastrar' id='numeroCadastrar' class='form-control' placeholder='Informe o número aqui...' required><label for='complementoCadastrar'>Complemento: </label><input type='text' name='complementoCadastrar' id='complementoCadastrar' class='form-control' placeholder='Informe o complemento aqui...'><label for='bairroCadastrar'>Bairro: </label><input type='text' name='bairroCadastrar' id='bairroCadastrar' class='form-control' placeholder='Informe o bairro aqui...' required><label for='cidadeCadastrar'>Cidade: </label><input type='text' name='cidadeCadastrar' id='cidadeCadastrar' class='form-control' placeholder='Informe a cidade aqui...' required><label for='estadoCadastrar'>Estado: </label><select name='estadoCadastrar' id='estadoCadastrar' class='form-control' required><option value=''>UF</option>";
        $sql = "SELECT * FROM states ORDER BY sigla ASC";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                echo "<option value='".$row['sigla']."'>".$row['sigla']."</option>";
            }
        }
        echo "</select><div style='width:100%; text-align:right; padding-right: 5px'><button type='button'  onclick='cadastrarLista(\"".URL."\")' class='btn btn-primary' style='border-radius:5px; margin:none'>Cadastrar</button> <button type='button' class='btn btn-secondary' onclick='fecha(\"addListaPresentes\")'>Fechar</button></div></div><div id='visusalizarListaPresentes' style='position:absolute; background-color:#FFFFFF; border: 1px solid #e7e7e7; padding:5px; width:100%; border-radius:15px; display:none'><h3 style='text-align:center'>Visualizar Lista de Presentes</h3></div><div id='editarListaPresentes' style='position:absolute; background-color:#FFFFFF; border: 1px solid #e7e7e7; padding:5px; width:100%; border-radius:15px; display:none'><h3 style='text-align:center'>Editar Lista de Presentes</h3></div><div style='left:70%'><div class='btn btn-primary' style='cursor:pointer' onclick='addListaPresentes(\"".URL."\")'>Adicionar Lista</div>";
        $sql = "SELECT a.* FROM presents_lists a WHERE a.client = '".$_SESSION['cliente']['id']."' ORDER BY a.status DESC, a.created_at DESC";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                echo '<div class="col-3" style="padding:10px;';
                if ($_SESSION['idLista'] == $row['id']){
                    echo 'background-color:#00b6ff';
                }
                echo '"><h3>Lista '.sprintf("%06s", $row['id']).'</h3>';
                echo "Nome do aniversariante: <b>".utf8_encode($row['nomeAniversariante'])."</b><br>Idade: <b>".utf8_encode($row['idade'])." ano";
                if ($row['idade'] > 1){
                    echo "s";
                }
                echo "</b><br>Data do Aniversário: <b>";
                $vet = explode('-', $row['dataAniversario']);
                echo $vet[2]."/".$vet[1]."/".$vet[0];
                echo '</b><br>Status da Lista: <b>';
                if ($row['status'] == 1){
                    echo "<span style='color: #000033;'>Há ocorrer</span>";
                }
                else{
                    echo "<span style='color:#FF0000'>Ocorrido</span>";
                }
                echo '</b><br><img src="'.URL.'img/presentes.png" style="cursor:pointer" onclick="abreListaPresentes(\''.$row['id'].'\',\''.URL.'\')" height="25" title="Lista de Presentes"> <img src="'.URL.'img/convidados.png" style="cursor:pointer" onclick="abreListaConvidados(\''.$row['id'].'\',\''.URL.'\')" height="25" title="Lista de Convidados"> <img src="'.URL.'img/visualizar.svg" style="cursor:pointer" onclick="visusalizarListaPresentes(\''.$row['id'].'\',\''.URL.'\')" height="18" title="Visualizar Lista"> <img src="'.URL.'img/editar.png" style="cursor:pointer" onclick="editaListaPresentes(\''.$row['id'].'\',\''.URL.'\')" height="25" title="Editar Lista"> <img src="'.URL.'img/excluir.png" style="cursor:pointer" onclick="excluirListaPresentes(\''.$row['id'].'\',\''.URL.'\')" height="25" title="Excluir Lista"> ';
                if ($row['status']) {
                    if ($_SESSION['idLista'] != $row['id']) {
                        echo '<img src="' . URL . 'img/mais.png" style="cursor:pointer" onclick="adicionarProdutosALista(\'' . $row['id'] . '\',\'' . URL . '\')" height="25" title="Adicionar Produtos à Lista">';
                    } else {
                        echo '<img src="' . URL . 'img/menos.png" style="cursor:pointer" onclick="removerDaListaPresentes(\'' . $row['id'] . '\',\'' . URL . '\')" height="25" title="Remover da Lista de Presentes">';
                    }
                }
                echo '</div>';
            }
        }
        else{
            echo '<div class="btn btn-danger" onclick=\'addListaPresentes("'.URL.'")\'>Nenhuma lista encontrada até o momento! Adicione uma agora!</div>';
        }
        break;
    case "editarEnderecos":
        $sql = "SELECT * FROM addresses WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            echo utf8_encode("1|-|".$row['name']."|-|".$row['cep']."|-|".$row['address']."|-|".$row['number']."|-|".$row['complement']."|-|".$row['neighborhood']."|-|".$row['city']."|-|".$row['state']."|-|".$row['country']."|-|".$row['id']);
        }
    break;
    case "visualizarEnderecos":
        $sql = "SELECT a.*, b.name AS nomePais FROM addresses a INNER JOIN countries b ON (a.country = b.id) WHERE a.idClient = '".$_SESSION['cliente']['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                $sql = "SELECT * FROM requests WHERE address = '".$row['id']."'";
                $query2 = mysqli_query($con, $sql);
                $html .= '<div style="background-color: #e7e7e7; margin:5px; padding:5px; border-radius:15px"><div style="position: absolute; float:left; left:80%"><br><br><img src="'.URL.'img/editar.png" width="20" style="cursor:pointer" onclick="editarEnderecoCliente(\''.$row['id'].'\', \''.URL.'\')">';
                if (!mysqli_num_rows($query2)){
                    $html .= ' <img src="'.URL.'img/excluir.png" width="20" style="cursor:pointer" onclick="excluirEnderecoCliente(\''.$row['id'].'\', \''.URL.'\')">';
                }
                $html .= '</div><h4>'.$row['name'].'</h4>'.$row['address'].', '.$row['number'];
                if ($row['complement']) {
                    $html .= ', '.$row['complement'];
                }
                $html .= '<br>Bairro: '.$row['neighborhood'].' - '.$row['city'].' - '.$row['state'].' - '.utf8_decode($row['nomePais']).'<br>CEP: '.$row['cep'].'</div>';
            }
            $html = utf8_encode($html);
        }
		else{
			$html = "<div class='btn btn-danger'  onclick='adicionarEnderecoCliente()'>Nenhum endereço encontrado! Adicione um agora!</div>";
		}
        echo "1|-|".$html;
        break;
    case "adicionarEndereco":
        $sql = utf8_decode("INSERT INTO addresses (idClient, name, cep, address, number, complement, neighborhood, city, state, country) VALUES ('".$_SESSION['cliente']['id']."', '".$_REQUEST['nomeEndereco']."', '".$_REQUEST['cep']."', '".$_REQUEST['logradouro']."', '".$_REQUEST['numero']."', '".$_REQUEST['complemento']."', '".$_REQUEST['bairro']."', '".$_REQUEST['cidade']."', '".$_REQUEST['estado']."', '".$_REQUEST['pais']."')");
        mysqli_query($con, $sql) or die(mysqli_error($con));
        $sql = utf8_decode("INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', 'Adicionou um endereço ao cliente', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1";
        break;
    case "editaEndereco":
        $sql = utf8_decode("UPDATE addresses SET idClient = '".$_SESSION['cliente']['id']."', name = '".$_REQUEST['nomeEndereco']."', cep = '".$_REQUEST['cep']."', address = '".$_REQUEST['logradouro']."', number = '".$_REQUEST['numero']."', complement = '".$_REQUEST['complemento']."', neighborhood = '".$_REQUEST['bairro']."', city = '".$_REQUEST['cidade']."', state = '".$_REQUEST['estado']."', country = '".$_REQUEST['pais']."' WHERE id = '".$_REQUEST['id']."'");
        mysqli_query($con, $sql) or die(mysqli_error($con));
        ;$sql = utf8_decode("INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', 'Atualizou o endereço do cliente ".$_REQUEST['id']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1";
        break;
    case 'excluirEnderecos':
        $sql = "DELETE FROM addresses WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        ;$sql = utf8_decode("INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', 'Excluiu o endereço do cliente ".$_REQUEST['id']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo '1';
        break;
    case "paginacao":
        if ($_REQUEST['vet0'] == 'sugestao'){
            $sql = "SELECT * FROM suggestions WHERE slug = '".$_REQUEST['vet1']."'";
            $query = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($query);
            $id = $row['id'];
        }
        $sql = "SELECT DISTINCT a.id, a.*, b.value, b.promotion, b.validity_promotion, c.img FROM products a INNER JOIN products_items b ON (a.id = b.product) LEFT JOIN products_images c ON (a.id = c.product)";
        if ($_REQUEST['vet0'] == 'busca'){
            $sql .= " WHERE a.name LIKE '%".$_REQUEST['vet1']."%'";
        }
        elseif ($_REQUEST['vet0'] == 'sugestao'){
            $sql .= " INNER JOIN products_suggestions d ON (a.id = d.product) WHERE d.suggestion = '".$id."'";
        }
        $sql .= " GROUP BY a.id";
        $query = mysqli_query($con, $sql);
        $total = mysqli_num_rows($query);
        $paginas = ceil($total / 9);
        $offSet = $_REQUEST['pagina'] <= 1 ? 0 : ((9 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 9) : 9 * ($_REQUEST['pagina'] - 1));
        $sql .= " LIMIT ".$offSet.", 9";
        $query = mysqli_query($con, $sql);
        $htmlPaginacao = "";
        if ($total){
            while ($row = mysqli_fetch_array($query)){
                $htmlPaginacao .= '<div class="col-sm-4">
                                            <div class="product-image-wrapper">
                                                <div class="single-products">
                                                    <div class="productinfo text-center">
                                                        ';
                $sql = "SELECT a.*, b.img FROM products_stamps a INNER JOIN stamps b ON (a.stamp = b.id) WHERE a.product = '".$row['id']."'";
                $query2 = mysqli_query($con, $sql);
                if (mysqli_num_rows($query2)){
                    $htmlPaginacao .= '<div style="position:absolute">';
                    while ($row2 = mysqli_fetch_array($query2)){
                        $htmlPaginacao .= '<div style="width:50px; height:50px; float:left; background-image: url(\''.URL_SITE.'img/upload/'.$row2['img'].'\'); background-size: contain; background-repeat: no-repeat">&nbsp;</div>';
                    }
                    $htmlPaginacao .= '</div>';
                }
                if ($row['img'] && file_exists(DIRETORIO."img/upload/".$row['img'])){
                    $htmlPaginacao .= '<img src="'.URL.'img/upload/'.$row['img'].'" alt="" style="width:200px; height:200px" />';
                }
                else{
                    $htmlPaginacao .= '<img src="'.URL.'img/upload/sem_imagem.png" alt="" style="width:200px; height:200px" />';
                }
                $htmlPaginacao .= '
                                                        <h2>R$';
                                                            if ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')){
                                                                $htmlPaginacao .= number_format($row['promotion'], 2, ',', '.');
                                                            }
                                                            else{
                                                                $htmlPaginacao .= number_format($row['value'], 2, ',', '.');
                                                            }
                                                        $htmlPaginacao .= '</h2>
                                                        <p>'.utf8_encode(substr($row['name'], 0, 25));
                                                            if (utf8_encode(strlen($row['name'])) > 25){ $htmlPaginacao .= '...'; }
                                                            $htmlPaginacao .= '</p>
                                                        <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-crosshairs"></i>Maiores Informações</a>
                                                    </div>
                                                    <div class="product-overlay">
                                                        <div class="overlay-content">
                                                            <h2>R$';
                if ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')){
                    $htmlPaginacao .= number_format($row['promotion'], 2, ',', '.');
                }
                else{
                    $htmlPaginacao .= number_format($row['value'], 2, ',', '.');
                }
                $htmlPaginacao .= '
                                                            </h2>
                                                            <p>'.utf8_encode($row['name']).'</p>
                                                            <a href="'.URL.'produto/'.$row['slug'].'" class="btn btn-default add-to-cart"><i class="fa fa-crosshairs"></i>Maiores Informações</a>
                                                        </div>
                                                    </div>
                                                </div>
                                                ';
                $htmlPaginacao .= '
                                            </div>
                                        </div>';
            }
        }
        $htmlPaginas = '<ul class="pagination" id="paginacao">';
        $paginaAnterior = $_REQUEST['pagina'] - 1;
        $paginaProxima = $_REQUEST['pagina'] + 1;
        if ($_REQUEST['pagina'] > 1){
            $htmlPaginas .= '<li><a onclick="paginacao(\''.$_REQUEST['vet0'].'\', \''.$_REQUEST['vet1'].'\', \''.$paginaAnterior.'\', \''.URL.'\')" style="cursor:pointer">&laquo;</a></li>';
        }
        for ($i = 1; $i <= $paginas; $i++){
            $htmlPaginas .= '<li ';
            if ($i == $_REQUEST['pagina']){
                $htmlPaginas .= 'class="active"';
            }
            $htmlPaginas .= '><a onclick="paginacao(\''.$_REQUEST['vet0'].'\', \''.$_REQUEST['vet1'].'\', \''.$i.'\', \''.URL.'\')" style="cursor:pointer">'.$i.'</a></li>';
        }
        if ($_REQUEST['pagina'] < $paginas){
            $htmlPaginas .= '<li><a onclick="paginacao(\''.$_REQUEST['vet0'].'\', \''.$_REQUEST['vet1'].'\', \''.$paginaProxima.'\', \''.URL.'\')" style="cursor:pointer">&raquo;</a></li>';
        }
        $htmlPaginas .= '</ul>';
        echo "1|-|".$htmlPaginacao."|-|".$htmlPaginas;
        break;
    case "mostraParcelamento":
        $_REQUEST['valorTotal'] = str_replace('.', '', $_REQUEST['valorTotal']);
        $_REQUEST['valorTotal'] = str_replace(',', '.', $_REQUEST['valorTotal']);
        $sql = "SELECT * FROM payment_methods WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $html = '
        <div class="step-one">
            <h2 class="heading">Parcelamento</h2>
        </div>';
        if ($row['parcelas'] >= 2){
            $k = 1;
            for ($i = $row['parcelas']; $i >= 2; $i--){
                $valorParcela = $_REQUEST['valorTotal'] / $i;
                if ($valorParcela >= $row['vlParcelaMinima']){
                    if ($i == $row['parcelas']){
                        $checked = 1;
                        $qual = $i;
                    }
                    else{
                        $checked = 0;
                    }
                    $html .= '<span>
            <input type="radio" name="parcelas" id="parcelas'.$i.'" value="'.$i.'" onclick="selecionaParcelamento(\''.$i.'\', \''.URL.'\')" ';
                    if ($checked == 1) {
                        $html .= 'checked';
                    }
                    $html .= '> <label for="parcelas'.$i.'">em '.$i.'X de R$ '.number_format($valorParcela, 2, ',', '.').'</label>
        </span>';
                    if($k % 6 == 0){
                        $html .= "<br>";
                    }
                    $k++;
                }
            }
        }
        if (!$qual){
            $checked = 1;
            $qual = 1;
        }
        else{
            $checked = 0;
        }
        $html .= '
        <span>
            <input type="radio" name="parcelas" id="parcelas1" value="1" onclick="selecionaParcelamento(\'1\', \''.URL.'\')" ';
        if ($checked == 1) {
            $html .= 'checked';
        }
        $html .= '> <label for="parcelas1">em 1X de R$ '.number_format($_REQUEST['valorTotal'], 2, ',', '.').'</label>
        </span>
        <input type="hidden" name="parcelamento" id="parcelamento" value="'.$qual.'">';
        echo "1|-|".$html;
        break;
    case "finalizarOrcamento":
        $cupomDesconto['id'] = 0;
        $vale['id'] = 0;
        $sql = "SELECT * FROM carts WHERE session_id = '".session_id()."'";
        $query = mysqli_query($con, $sql);
        $total_carrinho = 0;
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                $carrinho[] = $row;
                $total_carrinho += $row['value'] * $row['quantity'];
            }
        }
        $total = $total_carrinho - $_SESSION['desconto'];
        $sql = "INSERT INTO requests (client, status, discount, vale, valueSubtotal, valueDiscount, valueTotal, msInterna, msExterna, msEmail, created_at, updated_at) VALUES('".$_SESSION['cliente']['id']."', '3', '".$_SESSION['cupomDesconto']."', '".$vale['id']."', '".$total_carrinho."', '".$_SESSION['desconto']."', '".$total."', '', '', '', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        $query = mysqli_query($con, $sql) or die(mysqli_error($con));
        $idRequest = mysqli_insert_id($con);
        foreach ($carrinho as $key => $value){
            $sql = "INSERT INTO requests_items (request, product, product_item, lista, name, quantity, value, its_already_gone, created_at, updated_at) VALUES ('".$idRequest."', '".$value['product']."', '".$value['product_item']."', '".$value['lista']."', '".$value['name']."', '".$value['quantity']."', '".$value['value']."', '".$value['its_already_gone']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql);
        }
        $sql = "DELETE FROM carts WHERE session_id = '".session_id()."'";
        mysqli_query($con, $sql);
        $sql = "SELECT a.*, b.name, c.nomeFantasia FROM clients a LEFT JOIN pessoa_fisicas b ON (a.id = b.client) LEFT JOIN pessoa_juridicas c ON (a.id = c.client) WHERE a.id = '".$_SESSION['cliente']['id']."'";
		$query2 = mysqli_query($con, $sql);
        $rowCliente = mysqli_fetch_array($query2);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, URL."comprovante.php?id=".$idRequest."&client=".$_SESSION['cliente']['id']."&semHtml=1");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$comprovanteEmail = curl_exec($ch);
        //$comprovanteEmail = "<html><head><title>Comprovante de Compras número ".sprintf("%06s\n", $idRequest)." - BH Commerce</title></head><body>".curl_exec($ch)."</body></html>";
        curl_close($ch);
		$comprovanteEmail .= '<hr noshade><center>Email Desenvolvido Pela <a href="https://www.bhcommerce.com.br/">BH Commerce</a></center><hr noshade>';
        $assuntoEmail = "Comprovante de Compras número ".sprintf("%06s\n", $idRequest)." - ".$parametrosSite['title'];
        $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
        $cabecalhoEmail .= "From: Contato - BH Commerce<contato@bhcommerce.com.br>\nReply-To: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>";
        $nome = ($rowCliente['type_person'] == 'F') ? $rowCliente['name'] : $rowCliente['nomeFantasia'];
        $email = $rowCliente['email'];
        @mail($parametrosSite['title']."<".$parametrosSite['email'].">", utf8_decode($assuntoEmail), utf8_decode($comprovanteEmail), utf8_decode($cabecalhoEmail));
        @mail(utf8_decode($nome."<".$email).">", utf8_decode($assuntoEmail), utf8_decode($comprovanteEmail), utf8_decode($cabecalhoEmail));
        //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $parametrosSite['email'], $parametrosSite['title'], utf8_decode($assuntoEmail), utf8_decode($comprovanteEmail));
        //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $email, utf8_decode($nome), utf8_decode($assuntoEmail), utf8_decode($comprovanteEmail));
        $_SESSION['frete']['valor'] = "0";
        $_SESSION['frete']['cep'] = "";
        $_SESSION['frete']['prazo'] = "";
        $_SESSION['frete']['tipo'] = "";
        $_SESSION['frete']['qual'] = "";
        $_SESSION['valePresente'] = "0";
        $_SESSION['desconto'] = "0";
        $_SESSION['codigo'] = "";
        $_SESSION['cupomDesconto'] = "";
        echo "1|-|".$idRequest;
        break;
    case "calculaCupomDesconto":
        $sql = "SELECT * FROM coupon_discounts WHERE codigo = '".$_REQUEST['codigo']."' AND validade >= '".date('Y-m-d H:i:s')."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);

            $sql = "SELECT a.* FROM coupon_requests a INNER JOIN requests b ON (a.request = b.id) WHERE a.codigo = '".$row['codigo']."' AND b.client = '".$_SESSION['idCliente']."'";
            $query2 = mysqli_query($con, $sql);
            if (!mysqli_num_rows($query) || $row['utilizavel'] == 2){
                if ($row['tipo'] == 1) {
                    $valorDesconto = $row["valor"];
                }
                else{
                    $desconto = $row['valor'] / 100;
                    $valorDesconto = $_REQUEST['valorTotal'] * $desconto;
                }
                if ($valorDesconto > $_REQUEST['valorTotal']){
                    $valorDesconto = $_REQUEST['valorTotal'];
                }
                $vet = explode('-', $row['validade']);
                $row['validade'] = $vet[2]."/".$vet[1]."/".$vet[0];
                $totalCompra = $_REQUEST['valorTotal'] - $valorDesconto + $_REQUEST['freteValor'];
                if ($row['tipo'] == 1){
                    $row['valor'] = "R$ ".number_format($row['valor'], 2, ',', '.');
                }
                else{
                    $row['valor'] = $row['valor']."%";
                }
                $_SESSION['cupomDesconto'] = $row['id'];
                $_SESSION['codigo'] = $row['codigo'];
                $_SESSION['desconto'] = $valorDesconto;
                $_SESSION['valePresente'] = 0;
                $_SESSION['desc'] = $row;
                echo "1|-|R$ " . number_format($valorDesconto, 2, ',', '.')."|-|R$ ".number_format($_REQUEST['freteValor'], 2, ',', '.')."|-|R$ ".number_format($totalCompra, 2, ',', '.');
            }
        }
        else {
            $sql = "SELECT * FROM vales WHERE code = '" . $_REQUEST['codigo'] . "' AND validade >= '".date('Y-m-d H:i:s')."'";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)) {
                $row = mysqli_fetch_array($query);
                $sql = "SELECT * FROM requests WHERE vale = '".$row['id']."' AND status != '7'";
                $query2 = mysqli_query($con, $sql);
                if (!mysqli_num_rows($query2)){
                    if ($row['value'] > $_REQUEST['valorTotal']){
                        $desconto = $_REQUEST['valorTotal'];
                    }
                    else{
                        $desconto = $row['value'];
                    }
                    $vet = explode('-', $row['validade']);
                    $row['validade'] = $vet[2]."/".$vet[1]."/".$vet[0];
                    $row['valor'] = "R$ ".number_format($row['value'], 2,',', '.');
                    $_SESSION['cupomDesconto'] = 0;
                    $_SESSION['codigo'] = $row['code'];
                    $_SESSION['desconto'] = $desconto;
                    $_SESSION['valePresente'] = $row['id'];
                    $_SESSION['desc'] = $row;
                    echo "1|-|R$ " . number_format($desconto, 2, ',', '.')."|-|R$ ".number_format($_REQUEST['freteValor'], 2, ',', '.')."|-|R$ ".number_format($totalCompra, 2, ',', '.');
                }
                else{
                    $_SESSION['cupomDesconto'] = 0;
                    $_SESSION['codigo'] = "";
                    $_SESSION['desconto'] = 0;
                    $_SESSION['valePresente'] = 0;
                    $totalCompra = $_REQUEST['valorTotal'] - $valorDesconto + $_REQUEST['freteValor'];
                    echo "0|-|R$ " . number_format($valorDesconto, 2, ',', '.') . "|-|R$ " . $_SESSION[''] . "|-|R$ " . number_format($totalCompra, 2, ',', '.');
                }
            } else {
                $_SESSION['cupomDesconto'] = 0;
                $_SESSION['codigo'] = "";
                $_SESSION['desconto'] = 0;
                $_SESSION['valePresente'] = 0;
                $totalCompra = $_REQUEST['valorTotal'] - $valorDesconto + $_REQUEST['freteValor'];
                echo "0|-|R$ " . number_format($valorDesconto, 2, ',', '.') . "|-|R$ " . $_SESSION[''] . "|-|R$ " . number_format($totalCompra, 2, ',', '.');
            }
        }
        break;
    case "selecionaFormaFrete":
        $_SESSION['frete']['qual'] = $_REQUEST['codigoFrete'];
        $valorFrete = str_replace('.', '', $_REQUEST['valorFrete']);
        $valorFrete = str_replace(',', '.', $valorFrete);
        $total = $_REQUEST['valorTotal'] + $valorFrete - $_SESSION['desconto'];
        if (!$_SESSION['desc']['codigo']){
            $_SESSION['desc']['codigo'] = $_SESSION['desc']['code'];
        }
        $_SESSION['frete']['valor'] = $valorFrete;
        $_SESSION['frete']['tipo'] = $_REQUEST['tipo'];
        $_SESSION['frete']['prazo'] = $_REQUEST['prazoFrete'];
        $_SESSION['frete']['cep'] = $_REQUEST['cep'];
        $botao = '<a class="btn btn-default check_out" onclick="';
		if($_SESSION['cliente']['id'] != ''){
			$botao .= 'finalizarCompra(\''.$_SESSION['frete']['qual'].'\', \''.URL.'\')';
		}
		else{
			$botao .= 'alert(\'Faça o seu login na loja para continuar!\');$(\'#modal-login\').modal(\'show\')';
		}
		$botao .= '" style="cursor:pointer">Finalização de Compra</a>';
        echo "1|-|R$".$_REQUEST['valorFrete']."|-|R$".number_format($total, 2, ',', '.')."|-|R$".number_format($_SESSION['desconto'], 2, ',', '.')."|-|".$botao."|-|".$_SESSION['frete']['tipo']."|-|".$_SESSION['frete']['prazo']."|-|".$_SESSION['cupomDesconto']."|-|".$_SESSION['desc']['id']."|-|".$_SESSION['desc']['tipo']."|-|".$_SESSION['desc']['valor']."|-|".$_SESSION['desc']['validade']."|-|".$_SESSION['desc']['codigo']."|-|".$_SESSION['valePresente'];
        break;
    case "selecionaFormaFreteAdminPedido":
        $sql = "SELECT * FROM requests WHERE id = '".$_REQUEST['idPedido']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $_REQUEST['valorFrete'] = str_replace('.', '', $_REQUEST['valorFrete']);
        $_REQUEST['valorFrete'] = str_replace(',', '.', $_REQUEST['valorFrete']);
        $total = $row['valueSubtotal'] - $row['valueDiscount'] + $_REQUEST['valorFrete'];
        $sql = "UPDATE requests SET valueFrete = '".$_REQUEST['valorFrete']."', valueTotal = '".$total."', tipoFrete = '".$_REQUEST['tipo']."', prazoFrete = '".$_REQUEST['prazoFrete']."' WHERE id = '".$_REQUEST['idPedido']."'";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1|-|R$".$_REQUEST['valorFrete']."|-|R$".number_format($total, 2, ',', '.')."|-|R$".number_format($_SESSION['desconto'], 2, ',', '.')."|-|".$botao."|-|".$_SESSION['frete']['tipo']."|-|".$_SESSION['frete']['prazo'];
        break;
    case "calculaFrete":
        if ($_SESSION['valePresente']){
            $sql = "SELECT * FROM requests WHERE vale = '".$_SESSION['valePresente']."' AND client = '".$_SESSION['cliente']['id']."' AND status != '7'";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                $_SESSION['cupomDesconto'] = 0;
                $_SESSION['codigo'] = "";
                $_SESSION['desconto'] = 0;
                $_SESSION['valePresente'] = 0;
            }
        }
        if ($_REQUEST['vale_presentes'] && !$_REQUEST['produtos']){
            $html .= "<input type='radio' name='frete' id='frete999999' ";
            if ($_SESSION['frete']){
                if (999999 == $_SESSION['frete']['qual']){
                    $html .= " checked";
                    $_SESSION['frete']['tipo'] = "Frete_Gratis";
                    $tipoQual = $_SESSION['frete']['tipo'];
                    $_SESSION['frete']['Valor'] = '0';
                    $valorFrete = $_SESSION['frete']['Valor'];
                    $_SESSION['frete']['PrazoEntrega'] = $maiorPrazoEntrega;
                    $prazoEntrega = $_SESSION['frete']['PrazoEntrega'];
                    $_SESSION['frete']['codigo'] = 999999;
                    $_SESSION['frete']['qual'] = 999999;
                    $_SESSION['frete']['endereco'] = $result->id;
                }
            }
            $html .= " onChange=selecionaFormaFrete('999999','".$_REQUEST['cep']."','".$_REQUEST['peso']."','".$_REQUEST['comprimento']."','".$_REQUEST['altura']."','".$_REQUEST['largura']."','".$_REQUEST['diametro']."','".$_REQUEST['valorTotal']."','".$desconto."','".$tela."','0,00','".$maiorPrazoEntrega."','999999','Frete_Gratis','1','0','" . URL . "')>";
            $html .= " <label for='frete999999'>Frete Grátis - Vale Presente";
            $html .= " - R$ 0,00</label>";
            $html .= '<br><br>';
        }
        else {
            $k = 0;
			$sql = "SELECT * FROM shipping_methods WHERE status = '1'";
			$query = mysqli_query($con, $sql);
			while ($row = mysqli_fetch_array($query)){
                unset($data);
                $data['nCdEmpresa'] = '';
                $data['sDsSenha'] = '';
                $data['sCepOrigem'] = $parametrosSite['cepLoja'];
                $data['sCepDestino'] = str_replace('-', '', $_REQUEST['cep']);
                $data['nVlPeso'] = $_REQUEST['peso'];
                $data['nCdFormato'] = '1';
                $data['nVlComprimento'] = $_REQUEST['comprimento'];
                $data['nVlAltura'] = $_REQUEST['altura'];
                $data['nVlLargura'] = $_REQUEST['largura'];
                $data['nVlDiametro'] = $_REQUEST['diametro'];
                $data['sCdMaoPropria'] = 's';
                $data['nVlValorDeclarado'] = $_REQUEST['valorCarrinho'];
                $data['sCdAvisoRecebimento'] = 'n';
                $data['StrRetorno'] = 'xml';
                $data = http_build_query($data);
                $url = 'http://ws.correios.com.br/calculador/CalcPrecoPrazo.aspx';
                $curl = curl_init($url . '?' . $data."&nCdServico=".$row['code']);
				//echo $url . '?' . $data."&nCdServico=".$row['code'];
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

                $result = curl_exec($curl);

                $result = simplexml_load_string($result);

                foreach ($result->cServico as $row) {

                    //Os dados de cada serviço estará aqui

                    $retorno[$k] = $row;

                }
                $k++;
            }
            $checado = 0;
            $html = "<table border='0' width='100%' cellpadding='0' cellspacing='0'>";
            if (count($retorno)) {
                $maiorPrazoEntrega = 0;
                $totalFretes = 0;
                $semFrete = 0;
                $selecionado = 0;
                foreach ($retorno as $key => $value) {
                    $chave = $key + 1;
                    $totalFretes++;
                    if ($value->Erro == 0) {
						$sql = "SELECT * FROM shipping_methods WHERE code = '".$value->Codigo."'";
						$query2 = mysqli_query($con, $sql);
						$row = mysqli_fetch_array($query2);
						$value->Valor = str_replace(".", "", $value->Valor);
						$value->Valor = str_replace(",", ".", $value->Valor);
						$value->Valor = number_format($value->Valor + $row['value'], 2, ',', '.');
                        $html .= "<tr><td width='10%' align='center'>";
                        $html .= "<input type='radio' name='frete' ";
                        $html .= " id='frete" . $chave . "' title='" . $row['name'] . "' ";
                        if ($_SESSION['frete']['qual'] == $value->Codigo) {
                            $_SESSION['frete']['tipo'] = $row['name'];
                            $tipoQual = $_SESSION['frete']['tipo'];
                            $_SESSION['frete']['valor'] = $value->Valor;
                            $valorFrete = $_SESSION['frete']['valor'];
                            $_SESSION['frete']['prazo'] = $value->PrazoEntrega;
                            $prazoEntrega = $_SESSION['frete']['prazo'];
                            $_SESSION['frete']['codigo'] = $value->Codigo;
                            $_SESSION['frete']['qual'] = $value->Codigo;
                            $checado = "1";
                        }
                        $codigoFrete = $value->Codigo;
                        $valorFrete = $value->Valor;
                        $prazoFrete = $value->PrazoEntrega;
                        $html .= " onChange=selecionaFormaFrete('" . $chave . "','" . $_REQUEST['cep'] . "','" . $_REQUEST['peso'] . "','" . $_REQUEST['comprimento'] . "','" . $_REQUEST['altura'] . "','" . $_REQUEST['largura'] . "','" . $_REQUEST['diametro'] . "','" . $_REQUEST['valorTotal'] . "','" . $_REQUEST['desconto'] . "','" . $tela . "','" . $valorFrete . "','" . $prazoFrete . "','" . $codigoFrete . "','" . str_replace(' ', '_', $row['name']) . "','" . $_REQUEST['produtos'] . "','" . $_REQUEST['vale_presentes'] . "','" . URL . "','".$_SESSION['frete']['qual']."')>";
                        $html .= "</td><td align='left'>";
                        $html .= " <label for='frete" . $chave . "' title='" . $row['name'] . "'>" . $row['name'] . " - " . $value->PrazoEntrega;
                        if ($value->PrazoEntrega > 1) {
                            $html .= " dias úteis";
                        } else {
                            $html .= " dia útil";
                        }
                        $html .= " - R$ " . $value->Valor. "</label>";
                        $html .= "</td></tr>";
                        $maiorPrazoEntrega = (int)$maiorPrazoEntrega;
                        $value->PrazoEntrega = (integer)$value->PrazoEntrega;
                        if ($prazoFrete >= $maiorPrazoEntrega) {
                            $maiorPrazoEntrega = $prazoFrete;
                        }
                    } else {
                        $semFrete++;
                    }
                }
                if ($maiorPrazoEntrega && $_REQUEST['valorCarrinho'] >= $parametrosSite['freteGratis']){
                    $html .= "<tr><td align='center' valign='top'><input type='radio' name='frete' id='frete999998' ";
                    if ($_SESSION['frete']){
                        if (999998 == $_SESSION['frete']['qual']){
                            $html .= " checked";
                            $_SESSION['frete']['tipo'] = "Frete_Gratis";
                            $tipoQual = $_SESSION['frete']['tipo'];
                            $_SESSION['frete']['Valor'] = '0';
                            $valorFrete = $_SESSION['frete']['Valor'];
                            $_SESSION['frete']['PrazoEntrega'] = $maiorPrazoEntrega;
                            $prazoEntrega = $_SESSION['frete']['PrazoEntrega'];
                            $_SESSION['frete']['codigo'] = 999998;
                            $_SESSION['frete']['qual'] = 999998;
                            $_SESSION['frete']['endereco'] = $result->id;
                        }
                    }
                    $html .= " onChange=selecionaFormaFrete('999998','".$_REQUEST['cep']."','".$_REQUEST['peso']."','".$_REQUEST['comprimento']."','".$_REQUEST['altura']."','".$_REQUEST['largura']."','".$_REQUEST['diametro']."','".$_REQUEST['valorTotal']."','".$desconto."','".$tela."','0,00','".$maiorPrazoEntrega."','999998','Frete_Gratis','1','0','" . URL . "')>";
                    $html .= " </td><td><label for='frete999998'>Frete Grátis - ".$maiorPrazoEntrega;
                    if ($maiorPrazoEntrega == 1){
                        $html .= " dia útil";
                    }
                    else{
                        $html .= ' dias úteis';
                    }
                    $html .= " - R$ 0,00</label>";
                    $html .= '<br><br></td></tr>';
                }
            }
        }
        if (!$checado){
            $_SESSION['frete']['qual'] = 0;
            $_SESSION['frete']['valor'] = '0.00';
            $_SESSION['frete']['tipo'] = "";
            $_SESSION['frete']['prazo'] = "";
            $_SESSION['frete']['cep'] = "";
        }
        if ($_SESSION['frete']['valor']) {
            $valorFrete2 = str_replace('.', '', $_SESSION['frete']['valor']);
            $valorFrete2 = str_replace(',', '.', $valorFrete2);
        }
        else{
            $valorFrete2 = 0;
        }
        $html .= "<input type='hidden' value='".$selecionado."' id='selecionado' name='selecionado'>";
        $totalCompra = $_REQUEST['valorTotal'] - $_SESSION['desconto'] + $valorFrete2;
        $_SESSION['frete']['valor'] = number_format($valorFrete2, 2, ',', '.');
        if (!$_SESSION['frete']['tipo']){
            $_SESSION['frete']['tipo'] = "Frete_Gratis";
        }
        echo "1|-|".$html."|-|0|-|".$_SESSION['frete']['qual']."|-|".$_SESSION['frete']['tipo']."|-|".$_SESSION['frete']['valor']."|-|".number_format($_SESSION['desconto'], 2, ',', '.0')."|-|".number_format($totalCompra, 2, ',', '.')."|-|".$_SESSION['codigo']."|-|".$_SESSION['frete']['qual']."|-|".$_SESSION['frete']['prazo']."|-|".$_SESSION['desc']['id']."|-|".$_SESSION['desc']['tipo']."|-|".$_SESSION['desc']['valor']."|-|".$_SESSION['desc']['validade']."|-|".$_SESSION['valePresente'];
        break;
    case "calculaFreteAdminPedido":
        if ($_REQUEST['vale_presentes'] && !$_REQUEST['produtos']){
            $html = "<div style='position:absolute; float:left; left:95%; cursor:pointer' onclick='fecha(\"freteAdminPedido\")'>&times;</div><h3>Frete do Pedido</h3>";
            $html .= "<input type='radio' name='frete' id='frete999999' ";
            if ($_REQUEST['freteSelecionado'] == 'Frete_Gratis'){
                $html .= "checked ";
            }
            $html .= " onChange=selecionaFormaFreteAdminPedido('999999','".$_REQUEST['cep']."','".$_REQUEST['peso']."','".$_REQUEST['comprimento']."','".$_REQUEST['altura']."','".$_REQUEST['largura']."','".$_REQUEST['diametro']."','".$_REQUEST['valorTotal']."','".$desconto."','".$tela."','0,00','".$maiorPrazoEntrega."','999999','Frete_Gratis','1','0','" . URL . "', '', '".$_REQUEST['idPedido']."','".$_SESSION['user']['id']."')>";
            $html .= " <label for='frete999999'>Frete Grátis - Vale Presente";
            $html .= " - R$ 0,00</label>";
            $html .= '<br><br>';
        }
        else {
            $k = 0;
            $vet = explode(",", $parametrosSite['freteCalculo']);
            for ($i = 0; $i < count($vet); $i++) {
                unset($data);
                $data['nCdEmpresa'] = '';
                $data['sDsSenha'] = '';
                $data['sCepOrigem'] = $parametrosSite['cepLoja'];
                $data['sCepDestino'] = str_replace('-', '', $_REQUEST['cep']);
                $data['nVlPeso'] = $_REQUEST['peso'];
                $data['nCdFormato'] = '1';
                $data['nVlComprimento'] = $_REQUEST['comprimento'];
                $data['nVlAltura'] = $_REQUEST['altura'];
                $data['nVlLargura'] = $_REQUEST['largura'];
                $data['nVlDiametro'] = $_REQUEST['diametro'];
                $data['sCdMaoPropria'] = 's';
                $data['nVlValorDeclarado'] = $_REQUEST['valorCarrinho'];
                $data['sCdAvisoRecebimento'] = 'n';
                $data['StrRetorno'] = 'xml';
                $data = http_build_query($data);
                $url = 'http://ws.correios.com.br/calculador/CalcPrecoPrazo.aspx';
                $curl = curl_init($url . '?' . $data."&nCdServico=".$vet[$i]);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

                $result = curl_exec($curl);

                $result = simplexml_load_string($result);

                foreach ($result->cServico as $row) {

                    //Os dados de cada serviço estará aqui

                    $retorno[$k] = $row;

                }
                $k++;
            }
            $checado = 0;
            $html = "<div style='position:absolute; float:left; left:95%; cursor:pointer' onclick='fecha(\"freteAdminPedido\")'>&times;</div><h3>Frete do Pedido</h3><table border='0' width='100%' cellpadding='0' cellspacing='0'>";
            if (count($retorno)) {
                $maiorPrazoEntrega = 0;
                $totalFretes = 0;
                $semFrete = 0;
                $selecionado = 0;
                foreach ($retorno as $key => $value) {
                    $chave = $key + 1;
                    $totalFretes++;
                    if ($value->Erro == 0) {
                        switch ($value->Codigo) {
                            case 40010:
                                $tipo = "SEDEX";
                                break;
                            case 40045:
                                $tipo = "SEDEX À COBRAR";
                                break;
                            case 40215:
                                $tipo = "SEDEX 10";
                                break;
                            case 40290:
                                $tipo = "SEDEX HOJE";
                                break;
                            case 41106:
                                $tipo = "PAC";
                                break;
                        }
                        $html .= "<tr><td width='10%' align='center'>";
                        $html .= "<input type='radio' name='frete' ";
                        $html .= " id='frete" . $chave . "' title='" . $tipo . "' ";
                        if ($_REQUEST['freteSelecionado'] == $tipo){
                            $html .= 'checked ';
                        }
                        $codigoFrete = $value->Codigo;
                        $valorFrete = $value->Valor;
                        $prazoFrete = $value->PrazoEntrega;
                        $html .= " onChange=selecionaFormaFreteAdminPedido('" . $chave . "','" . $_REQUEST['cep'] . "','" . $_REQUEST['peso'] . "','" . $_REQUEST['comprimento'] . "','" . $_REQUEST['altura'] . "','" . $_REQUEST['largura'] . "','" . $_REQUEST['diametro'] . "','" . $_REQUEST['valorTotal'] . "','" . $_REQUEST['desconto'] . "','" . $tela . "','" . $valorFrete . "','" . $prazoFrete . "','" . $codigoFrete . "','" . str_replace(' ', '_', $tipo) . "','" . $_REQUEST['produtos'] . "','" . $_REQUEST['vale_presentes'] . "','" . URL . "','".$_SESSION['frete']['qual']."','".$_REQUEST['idPedido']."','".$_SESSION['user']['id']."')>";
                        $html .= "</td><td align='left'>";
                        $html .= " <label for='frete" . $chave . "' title='" . $tipo . "'>" . $tipo . " - " . $value->PrazoEntrega;
                        if ($value->PrazoEntrega > 1) {
                            $html .= " dias úteis";
                        } else {
                            $html .= " dia útil";
                        }
                        $html .= " - R$ " . $value->Valor . "</label>";
                        $html .= "</td></tr>";
                        $maiorPrazoEntrega = (int)$maiorPrazoEntrega;
                        $value->PrazoEntrega = (integer)$value->PrazoEntrega;
                        if ($prazoFrete >= $maiorPrazoEntrega) {
                            $maiorPrazoEntrega = $prazoFrete;
                        }
                    } else {
                        $semFrete++;
                    }
                }
                if ($maiorPrazoEntrega && $_REQUEST['valorCarrinho'] >= $parametrosSite['freteGratis']){
                    $html .= "<tr><td align='center' valign='top'><input type='radio' name='frete' id='frete999998' ";
                    if ($_REQUEST['freteSelecionado'] == 'Frete_Gratis'){
                        $html .= 'checked ';
                    }
                    $html .= " onChange=selecionaFormaFreteAdminPedido('999998','".$_REQUEST['cep']."','".$_REQUEST['peso']."','".$_REQUEST['comprimento']."','".$_REQUEST['altura']."','".$_REQUEST['largura']."','".$_REQUEST['diametro']."','".$_REQUEST['valorTotal']."','".$desconto."','".$tela."','0,00','".$maiorPrazoEntrega."','999998','Frete_Gratis','1','0','" . URL . "','','".$_REQUEST['idPedido']."','".$_SESSION['user']['id']."')>";
                    $html .= " </td><td align='left'><label for='frete999998'>Frete Grátis - ".$maiorPrazoEntrega;
                    if ($maiorPrazoEntrega == 1){
                        $html .= " dia útil";
                    }
                    else{
                        $html .= ' dias úteis';
                    }
                    $html .= " - R$ 0,00</label>";
                    $html .= '<br><br></td></tr>';
                }
            }
        }
        $html .= "<input type='hidden' value='".$selecionado."' id='selecionado' name='selecionado'>";
        $totalCompra = $_REQUEST['valorTotal'] - $_REQUEST['desconto'] + $valorFrete2;
        $_SESSION['frete']['valor'] = number_format($valorFrete2, 2, ',', '.');
        if (!$_SESSION['frete']['tipo']){
            $_SESSION['frete']['tipo'] = "Frete_Gratis";
        }
        echo "1|-|".$html;
        break;
    case "alteraEnderecoEntrega":
        $sql = "SELECT * FROM addresses WHERE idClient = '".$_SESSION['cliente']['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($value = mysqli_fetch_object($query)){
                $html .= '<div style="';
                if ($_REQUEST['id'] == $value->id){
                    $html .= 'background-color:#e7e7e7;';
                }
                $html .= 'padding:2px; cursor:pointer" onClick="alteraEnderecoEntrega(\''.$value->id.'\', \''.$value->cep.'\', \''.$_REQUEST['peso'].'\', \''.$_REQUEST['altura'].'\', \''.$_REQUEST['largura'].'\', \''.$_REQUEST['comprimento'].'\', \''.$_REQUEST['diametro'].'\', \''.$_REQUEST['valorTotal'].'\', \''.$_REQUEST['produtos'].'\', \''.$_REQUEST['vale_presentes'].'\', \''.$_REQUEST['valorDesconto'].'\', \''.$_REQUEST['tipoFrete'].'\', \''.$_REQUEST['valorCarrinho'].'\', \''.URL.'\')">
                                                        <h3>'.$value->name.'</h3>
                                                        <p>'.$value->address.', '.$value->number;
                if ($value->complement)
                    $html .= ', '.$value->complement;
                $html .= '<br>Bairro: '.$value->neighborhood.' - '.$value->city.' - '.$value->state.'<br>CEP: '.$value->cep.'</p>
                                                    </div>';
            }
        }
        $k = 0;
        $sql = "SELECT * FROM shipping_methods WHERE status = '1'";
        $query = mysqli_query($con, $sql);
		while ($row = mysqli_fetch_array($query)){
			unset($data);
            $data['nCdEmpresa'] = '';
            $data['sDsSenha'] = '';
            $data['sCepOrigem'] = $parametrosSite['cepLoja'];
            $data['sCepDestino'] = str_replace('-', '', $_REQUEST['cep']);
            $data['nVlPeso'] = $_REQUEST['peso'];
            $data['nCdFormato'] = '1';
            $data['nVlComprimento'] = $_REQUEST['comprimento'];
            $data['nVlAltura'] = $_REQUEST['altura'];
            $data['nVlLargura'] = $_REQUEST['largura'];
            $data['nVlDiametro'] = $_REQUEST['diametro'];
            $data['sCdMaoPropria'] = 's';
            $data['nVlValorDeclarado'] = $_REQUEST['valorCarrinho'];
            $data['sCdAvisoRecebimento'] = 'n';
            $data['StrRetorno'] = 'xml';
            $data = http_build_query($data);
            $url = 'http://ws.correios.com.br/calculador/CalcPrecoPrazo.aspx';
            $curl = curl_init($url . '?' . $data."&nCdServico=".$row['code']);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

            $result = curl_exec($curl);

            $result = simplexml_load_string($result);

            foreach ($result->cServico as $row) {

                //Os dados de cada serviço estará aqui

                $retorno[$k] = $row;

            }
            $k++;
        }
        $checado = 0;
        if (count($retorno)) {
            $maiorPrazoEntrega = 0;
            $totalFretes = 0;
            $semFrete = 0;
            $selecionado = 0;
            foreach ($retorno as $key => $value) {
                $chave = $key + 1;
                $totalFretes++;
                if ($value->Erro == 0) {
					$sql = "SELECT * FROM shipping_methods WHERE code = '".$value->Codigo."'";
					$query = mysqli_query($con, $sql);
					$row = mysqli_fetch_array($query);
					$value->Valor = str_replace(".", "", $value->Valor);
					$value->Valor = str_replace(",", ".", $value->Valor);
					$value->Valor = number_format($value->Valor + $row['value'], 2, ',', '.');
                    if ($row['name'] == $_REQUEST['tipoFrete']){
                        $_SESSION['frete']['tipo'] = $row['name'];
                        $tipoQual = $_SESSION['frete']['tipo'];
                        $_SESSION['frete']['valor'] = $value->Valor;
                        $valorFrete = $_SESSION['frete']['valor'];
                        $_SESSION['frete']['prazo'] = $value->PrazoEntrega;
                        $prazoEntrega = $_SESSION['frete']['prazo'];
                        $_SESSION['frete']['codigo'] = $value->Codigo;
                        $_SESSION['frete']['qual'] = $value->Codigo;
                        $checado = "1";
                    }
                } else {
                    $semFrete++;
                }
            }
        }
        $_SESSION['frete']['cep'] = $_REQUEST['cep'];
        $freteValor =  str_replace('.', '', $_SESSION['frete']['valor']);
        $freteValor =  str_replace(',', '.', $freteValor);
        $valorTotal = $_REQUEST['valorTotal'] - $_REQUEST['valorDesconto'] + $_SESSION['frete']['valor'];
        $valorTotal =  str_replace('.', '', $valorTotal);
        $valorTotal =  str_replace(',', '.', $valorTotal);
        echo "1|-|".utf8_encode($html)."|-|". $freteValor."|-|".$_REQUEST['valorDesconto']."|-|".$valorTotal."|-|".number_format($freteValor, 2, ',', '.')."|-|".number_format($_REQUEST['valorDesconto'], 2, ',', '.')."|-|".number_format($valorTotal, 2, ',', '.')."|-|".$_REQUEST['id']."|-|".$_SESSION['codigo']."|-|".$_SESSION['frete']['prazo'];
        break;
    case "deletarProduto":
        $sql = "";
        $sql = "SELECT * FROM carts WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $sql = "SELECT * FROM products_items WHERE id = '".$row['product_item']."'";
        $query = mysqli_query($con, $sql);
        $rowItem = mysqli_fetch_array($query);
        $estoque = $rowItem['estoque'] + $row['quantity'];
        $sql = "UPDATE products_items SET estoque = '".$estoque."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$row['product_item']."'";
        mysqli_query($con, $sql);
        $sql = "DELETE FROM carts WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "aprovarAnuncie":
        $sql = "SELECT a.*, b.days FROM anuncie_aqui a INNER JOIN banners_type b ON (a.tipo_banner = b.id) WHERE a.id = '".$_REQUEST['id']."' AND a.aprovado = '0'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $slug = retirarAcentos($row['nome_banner']);
            $dias_adiciona = $row['days'];
            if ($dias_adiciona != 'eterno'){
                $date = date('Y-m-d H:i:s');
                $celke_data_inicio = strtotime($date);
                $celke_data_fim = '+'.$dias_adiciona.' day';
                $validade = date('Y-m-d', strtotime($celke_data_fim));
            }
            else{
                $validade = "9999-12-31";
            }
            $i = 1;
            $sql = "SELECT * FROM banners WHERE slug = '".$slug."'";
            $query = mysqli_query($con, $sql);
            while (mysqli_num_rows($query)){
                $slug .= $i;
                $sql = "SELECT * FROM banners WHERE slug = '".$slug."'";
                $query = mysqli_query($con, $sql);  
                $i++;              
            }
            $sql = "INSERT INTO banners (name, slug, link, target, status, position, validade, created_at, updated_at) VALUES ('".$row['nome_banner']."', '".$slug."', '".$row['link_banner']."', '".$row['target_banner']."', '1', '".$row['posicao_banner']."', '".$validade."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            $query = mysqli_query($con, $sql) or die(mysqli_error($con));
            $idBanner = mysqli_insert_id($con);
            if (preg_match("/jpg/", $row['img'])){
                $tipo = ".jpg";
            }
            elseif (preg_match("/gif/", $row['img'])){
                $tipo = ".gif";
            }
            elseif (preg_match("/png/", $row['img'])){
                $tipo = ".png";
            }
            elseif (preg_match("/bmp/", $row['img'])){
                $tipo = ".bmp";
            }
            elseif (preg_match("/webp/", $row['img'])){
                $tipo = ".webp";
            }
            copy(DIRETORIO."img/upload/".$row['img'], DIRETORIO."img/upload/banner".$idBanner.$tipo);
            $sql = "UPDATE banners SET img = 'banner".$idBanner.$tipo."' WHERE id = '".$idBanner."'";
            mysqli_query($con, $sql);
            $sql = "UPDATE anuncie_aqui SET aprovado = '1' WHERE id = '".$row['id']."'";
            mysqli_query($con, $sql);
            echo "1";
        }
        break;
    case "comprarProduto":
        $sql = "SELECT * FROM products_items WHERE id = '".$_REQUEST['product_item']."'";
        $query = mysqli_query($con, $sql);
        $rowItem = mysqli_fetch_array($query);
        $estoque = $rowItem['estoque'] - $_REQUEST['quantidade'];
        $sql = "UPDATE products_items SET estoque = '".$estoque."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['product_item']."'";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        $sql = "SELECT * FROM products WHERE id = '".$_REQUEST['product']."'";
        $query = mysqli_query($con, $sql);
        $rowProduto = mysqli_fetch_array($query);
        $nomeProduto = $rowProduto['name']." - ".$rowItem['name'];
        $valorProduto = ($rowItem['promotion'] && $rowItem['validity_promotion'] >= date('Y-m-d')) ? $rowItem['promotion'] : $rowItem['value'];
        $sql = "SELECT * FROM carts WHERE product = '".$_REQUEST['product']."' AND product_item = '".$_REQUEST['product_item']."' AND session_id = '".session_id()."'";
        $query = mysqli_query($con, $sql);
        if (!mysqli_num_rows($query)){
            $sql = "INSERT INTO carts (product, product_item, session_id, name, quantity, value, created_at, updated_at) VALUES ('".$_REQUEST['product']."', '".$_REQUEST['product_item']."', '".session_id()."', '".$nomeProduto."', '".$_REQUEST['quantidade']."', '".$valorProduto."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        }
        else{
            $row = mysqli_fetch_array($query);
            $quantidade = $row['quantity'] + $_REQUEST['quantidade'];
            $sql = "UPDATE carts SET quantity = '".$quantidade."', value = '".$valorProduto."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$row['id']."'";
        }
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1";
        break;
    case "aumentaQuantidade":
        $quantidade = $_REQUEST['quantidadeAtual'] + 1;
        $sql = "SELECT * FROM products_items WHERE id = '".$_REQUEST['product_item']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        if ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')) {
            $htmlValor = '<span style="text-decoration: line-through; font-size:18px; color:#999999">R$ '.number_format($row['value'] * $quantidade, 2, ',', '.').'</span><span>R$ '.number_format($row['promotion'] * $quantidade, 2, ',', '.').'</span>';
        }
        else {
            $htmlValor = '<span>R$ '.number_format($row['value'] * $quantidade, 2, ',', '.').'</span>';
        }
        $htmlValor .= '             <label style="float:left">Quantidade:</label>
                                        <input type="text" value="'.$quantidade.'" id="quantidade" name="quantidade" readonly style="float:left" />
                                    <div style="float:left">
                                        <a style="cursor:pointer">
                                            <i class="fa fa-angle-up" onclick="aumentaQuantidade($(\'#quantidade\').val(), \''.$_REQUEST['product'].'\', \''.$row['id'].'\', \''.URL.'\', \''.$_REQUEST['maximo'].'\', \''.$_REQUEST['minimo'].'\')"></i>
                                        </a>
                                        <a style="cursor: pointer;">
                                            <i class="fa fa-angle-down" onclick="diminuiQuantidade($(\'#quantidade\').val(), \''.$_REQUEST['product'].'\', \''.$row['id'].'\', \''.URL.'\', \''.$_REQUEST['minimo'].'\', \''.$_REQUEST['maximo'].'\')"></i>
                                        </a>
                                    </div>
                                        <button type="submit" class="btn btn-fefault ';
        if ($row['estoque'] > $quantidade)
            $htmlValor .= 'cart';
        $htmlValor .= '">
                                            <i class="fa fa-shopping-cart"></i>
                                            Adicionar ao Carrinho
                                        </button>';
        echo "1|-|".$htmlValor;
        break;
    case "aumentaQuantidadeCarrinho":
        $quantidade = $_REQUEST['quantidadeAtual'] + 1;
        $sql = "SELECT * FROM carts WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $novoEstoque = $_REQUEST['estoque'] - $quantidade;
        $sql = "UPDATE products_items SET  estoque = '".$novoEstoque."' WHERE id = '".$row['product_item']."'";
        $query = mysqli_query($con, $sql);
        $sql = "UPDATE carts SET quantity = '".$quantidade."' WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        echo "1";
        break;
    case "diminuiQuantidade":
        $quantidade = $_REQUEST['quantidadeAtual'] - 1;
        $sql = "SELECT * FROM products_items WHERE id = '".$_REQUEST['product_item']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        if ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')) {
            $htmlValor = '<span style="text-decoration: line-through; font-size:18px; color:#999999">R$ '.number_format($row['value'] * $quantidade, 2, ',', '.').'</span><span>R$ '.number_format($row['promotion'] * $quantidade, 2, ',', '.').'</span>';
        }
        else {
            $htmlValor = '<span>R$ '.number_format($row['value'] * $quantidade, 2, ',', '.').'</span>';
        }
        $htmlValor .= '             <label style="float:left">Quantidade:</label>
                                        <input type="text" value="'.$quantidade.'" id="quantidade" name="quantidade" readonly style="float:left" />
                                    <div style="float:left">
                                        <a style="cursor:pointer">
                                            <i class="fa fa-angle-up" onclick="aumentaQuantidade($(\'#quantidade\').val(), \''.$_REQUEST['product'].'\', \''.$row['id'].'\', \''.URL.'\', \''.$_REQUEST['maximo'].'\', \''.$_REQUEST['minimo'].'\')"></i>
                                        </a>
                                        <a style="cursor: pointer;">
                                            <i class="fa fa-angle-down" onclick="diminuiQuantidade($(\'#quantidade\').val(), \''.$_REQUEST['product'].'\', \''.$row['id'].'\', \''.URL.'\', \''.$_REQUEST['minimo'].'\', \''.$_REQUEST['maximo'].'\')"></i>
                                        </a>
                                    </div>
                                        <button type="submit" class="btn btn-fefault ';
        if ($row['estoque'] > $quantidade)
            $htmlValor .= 'cart';
        $htmlValor .= '">
                                            <i class="fa fa-shopping-cart"></i>
                                            Adicionar ao Carrinho
                                        </button>';
        echo "1|-|".$htmlValor;
        break;
    case "diminuiQuantidadeCarrinho":
        $quantidade = $_REQUEST['quantidadeAtual'] - 1;
        $sql = "SELECT * FROM carts WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $novoEstoque = $_REQUEST['estoque'] - $quantidade;
        $sql = "UPDATE products_items SET  estoque = '".$novoEstoque."' WHERE id = '".$row['product_item']."'";
        $query = mysqli_query($con, $sql);
        $sql = "UPDATE carts SET quantity = '".$quantidade."' WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        echo "1";
        break;
    case "selecionaAtributo":
        $sql = "SELECT * FROM products_items WHERE product = '".$_REQUEST['product']."'";
        for ($i = 0; $i < 10; $i++) {
            $chave = $i+1;
            $sql .= " AND attribute".$chave." = '" . $_REQUEST['idAtributo'.$i] . "'";
        }
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $sql = "SELECT * FROM products_images WHERE product = '".$_REQUEST['product']."' AND product_item = '".$row['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row2 = mysqli_fetch_array($query)){
                $products_images[] = $row2;
            }
        }
        foreach ($products_images as $key => $value){
            $htmlFotos .= "<a onclick=\"mostraFoto('".$value['img']."', '".$value['id']."', '".URL."')\" style=\"cursor: pointer\">
                                            <img src=\"".URL."img/upload/".$value['img']."\" alt=\"\" width=\"50\" /></a>";
        }
        if ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')) {
            $htmlValor = '<span style="text-decoration: line-through; font-size:18px; color:#999999">R$ '.number_format($row['value'], 2, ',', '.').'</span><span>R$ '.number_format($row['promotion'], 2, ',', '.').'</span>';
        }
        else {
            $htmlValor = '<span>R$ '.number_format($row['value'], 2, ',', '.').'</span>';
        }
        $htmlValor .= '             <label style="float:left">Quantidade:</label>
                                        <input type="text" value="'.$_REQUEST['minimo'].'" id="quantidade" name="quantidade" readonly style="float:left" />
                                    <div style="float:left">
                                        <a style="cursor:pointer">
                                            <i class="fa fa-angle-up" onclick="aumentaQuantidade($(\'#quantidade\').val(), \''.$_REQUEST['product'].'\', \''.$row['id'].'\', \''.URL.'\', \''.$_REQUEST['maximo'].'\', \''.$_REQUEST['minimo'].'\')"></i>
                                        </a>
                                        <a style="cursor: pointer;">
                                            <i class="fa fa-angle-down" onclick="diminuiQuantidade($(\'#quantidade\').val(), \''.$_REQUEST['product'].'\', \''.$row['id'].'\', \''.URL.'\', \''.$_REQUEST['minimo'].'\', \''.$_REQUEST['maximo'].'\')"></i>
                                        </a>
                                    </div>
                                        <button type="submit" class="btn btn-fefault ';
        if ($row['estoque'])
            $htmlValor .= 'cart';
        $htmlValor .= '">
                                            <i class="fa fa-shopping-cart"></i>
                                            Adicionar ao Carrinho
                                        </button>';
        if ($row['estoque']){
            $htmlDisponibilidade = "Em estoque";
        }
        else{
            $htmlDisponibilidade = "Indisponível";
        }
        echo "1|-|<img src='".URL."img/upload/".$products_images[0]['img']."' style='cursor:pointer' onclick=abreImagemProduto('".$products_images[0]['id']."','".URL."'); data-toggle='modal' data-target='#modal-fotos'>|-|".$htmlFotos."|-|Código: ".$row['code']."|-|'.$htmlValor.'|-|".$htmlDisponibilidade."|-|".$row['id'];
        break;
    case "salvarComentario":
		$sql = "SELECT name FROM products WHERE id = '".$_REQUEST['product']."'";
		$query = mysqli_query($con, $sql);
		$row = mysqli_fetch_array($query);
        $sql = "INSERT INTO products_reviews (product, nome, email, avaliacao, mensagem, created_at, updated_at) VALUES ('".$_REQUEST['product']."', '".$_REQUEST['nomeComentario']."', '".$_REQUEST['emailComentario']."', '".$_REQUEST['nota']."', '".$_REQUEST['comentario']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql) or die(mysqli_error($con));
		$assuntoEnvia = "Comentário Cadastrado em um produto - ".$parametrosSite['title'];
		$htmlEnvia = '<html><head><title>Comentário Cadastrado em um produto!</title></head><body><table width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td valign="top" width="200" style="text-align: center"><img src="'.URL.'img/logo.png" width="180"></td><td>Olá Equipe '.$parametrosSite['title'].',<br><br>Viemos informar que foi feito um novo comentário de produto no site.<br><br>Nome do Produto: '.utf8_encode($row['name']).'<br>Nome: '.$_REQUEST['nomeComentario'].'<br>Email: '.$_REQUEST['emailComentario'].'<br>Mensagem: '.str_replace("\r\n", "<br>", $_REQUEST['comentario']).'<br><br>Para visualizar os comentários no admin, <a href="'.URL.'admin/comentariosProduto">clique aqui</a>.<br><br>Atenciosamente,<br><br>Equipe <a href="'.URL.'">'.$parametrosSite['title'].'</a><hr noshade><center>Email Desenvolvido pela <a href="https://www.bhcommerce.com.br">BH Commerce</a><hr noshade></td></tr></table></body></html>';
        $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
        $cabecalhoEmail .= "From:".$parametrosSite['title']."<".$parametrosSite['email'].">\nReply-To: ".$parametrosSite['title']."<".$parametrosSite['email'];
        //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $parametrosSite['email'], $parametrosSite['title'], utf8_decode($assuntoEnvia), utf8_decode($htmlEnvia));
        @mail($parametrosSite['title']."<".$parametrosSite['email'].">", utf8_decode($assuntoEnvia), utf8_decode($htmlEnvia), utf8_decode($cabecalhoEmail));
        echo "1|-|".$_SESSION['cliente']['name']."|-|".$_SESSION['cliente']['email'];
        break;
    case "formCadastro":
        $sql = "SELECT * FROM users WHERE email = '".$_REQUEST['email']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            echo "0|-|Já existe um usuáio cadastrado com esse email! Clique em 'Esqueci a minha senha' caso tenha se esquecido da sua senha ou em 'Login' para se logar no sistema!";
        }
        else{
            $sql = "SELECT * FROM users_pre WHERE email = '".$_REQUEST['email']."'";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)) {
                echo "0|-|Já existe um usuáio pre-cadastrado com esse email! Aguarde ele ser checado que você vai receber um email nosso informando isso!";
            }
            else{
                if ($_REQUEST['password'] != $_REQUEST['password2']){
                    echo "0|-|As senhas digitadas não conferem. Confira!";
                }
                else {
                    $sql = "INSERT INTO user_pres (name, email, password, created_at, updated_at) VALUES ('".$_REQUEST['nome']."', '".$_REQUEST['email']."', '".md5($_REQUEST['password'])."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                    mysqli_query($con, $sql);
                    $htmlEnvia = '<html><head><title>Pré cadastro efetuado com sucesso!</title></head><body><table width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td valign="top" width="200" style="text-align: center"><img src="'.URL.'img/logo.png" width="180"></td><td>Olá,<br><br>Viemos informar que foi feito um novo pré-cadastro no admin do site.<br><br>Nome: '.$_REQUEST['nome'].'<br>Email: '.$_REQUEST['email'].'<br><br>Para visualizar os pré-cadastros no admin, <a href="'.URL.'admin/usuarios-pre">clique aqui</a>.<br><br>Atenciosamente,<br><br>Equipe <a href="'.URL.'">'.$parametrosSite['title'].'</a><hr noshade><center>Email desenvolvido pela <a href="https://www.bhcommerce.com.br">BH Commerce</a></center><hr noshade></td></tr></table></body></html>';
                    $nomeEnvia = "Henrique - BH Commerce";
                    $emailEnvia = "henrique@bhcommerce.com.br";
                    $assuntoEnvia = $parametrosSite['title']." - Pré-cadastro efetuado com sucesso";
                    $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
                    $cabecalhoEmail .= "From: Contato - BH Commerce<contato@bhcommerce.com.br>\nReply-To: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>";
                    //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $parametrosSite['email'], $parametrosSite['title'], $assuntoEnvia, $htmlEnvia);
					mail($nomeEnvia."<".$emailEnvia.">", utf8_decode($assuntoEnvia), utf8_decode($htmlEnvia), $cabecalhoEmail);
                    echo "1";
                }
            }
        }
        break;
    case "formLogin":
        $sql = "SELECT * FROM users WHERE email = '".$_REQUEST['email']."' AND password = '".md5($_REQUEST['password'])."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $_SESSION['user'] = $row;
            $action = "Se logou no sistema";
            $idUser = $_SESSION['user']['id'];
            $sql = "INSERT INTO logs (user, action, created_at, updated_at) VALUES ('".$idUser."', '".$action."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql);
            echo "1";
        }
        else{
            echo "0|-|Login e/ou senha inválidos! Confira!";
        }
        break;
    case "formAlterarSenha":
        print_r($_REQUEST);
        if ($_REQUEST['password'] != $_REQUEST['password2']){
            echo "0|-|Informe senhhas iguais!";
        }
        else {
            $sql = "UPDATE users SET password = '".md5($_REQUEST['password'])."', remember_token = '', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idUsuario']."'";
            mysqli_query($con, $sql);
            echo "1";
        }
        break;
    case "formEsqueceuSuaSenha":
        $sql = "SELECT * FROM users WHERE email = '".$_REQUEST['email']."'";
        $query = mysqli_query ($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $digitos = rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9);
            $sql = "UPDATE users SET remember_token = '".$digitos."' WHERE id = '".$row['id']."'";
            mysqli_query($con,  $sql);
            $html = "<html>
                    <head>
                        <title>".$parametrosSite['title']." - Esqueceu sua senha</title>
<                   </head>
                    <body>
                        <table width='100%' cellspacing='0' cellpadding='0' border='0'>
                            <tr>
                                <td width='100' style='text-align:center' valign='top'><img src='".URL."img/logo.png' width='90'></td>
                                <td>Olá <b>".$row['name']."</b>,<br><br>
                                Este email é porque você solicitou em nosso site um lembrete da sua senha!<br><br>
                                Para alterar a sua senha, <a href='".URL."alterar-senha.php?codigo=".$digitos."'>clique aqui</a>.<br><br>
                                Atenciosamente,<br><br>
                                Equipe <a href='".URL."'>".$parametrosSite['title']."</a></td>
<                           </tr>
                        </table><hr noshade><center>Email desenvolvido pela <a href='https://www.bhcommerce.com.br'>BH Commerce</a></center><hr noshade>
                   </body>
                   </html>";
				   $assunto = $parametrosSite['title']." - Esqueceu Sua Senha?";
            $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
            $cabecalhoEmail .= "From: Contato - BH Commerce<contato@bhcommerce.com.br>\nReply-To: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>";
            //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $parametrosSite['email'], $parametrosSite['title'], utf8_decode($assunto), $html);
			mail($row['name']."<".$row['email'].">", $parametrosSite['title']." - Esqueceu sua senha?", $html, $cabecalhoEmail);
            echo "1|-|".$html;
        }
        else{
            echo "0|-|Esse email não está cadastrado em nossa base de dados!";
        }
        break;
    case 'aprovarUsuario':
        $sql = "SELECT * FROM user_pres WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $sql = "DELETE FROM user_pres WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        $sql = "INSERT INTO users (name, email, password, created_at, updated_at) VALUES ('".$row['name']."', '".$row['email']."', '".$row['password']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql);
        $html = "<html>
                    <head>
                        <title>".$parametrosSite['title']." - Cadastro Liberado no Admin com Sucesso!</title>
<                   </head>
                    <body>
                        <table width='100%' cellspacing='0' cellpadding='0' border='0'>
                            <tr>
                                <td width='100' style='text-align:center' valign='top'><img src='".URL."img/logo.png' width='90'></td>
                                <td>Olá <b>".$row['name']."</b>,<br><br>
                                Este email é para informar que o seu cadastro foi liberado com sucesso no admin de nosso site!<br><br>
                                Para acessar nosso admin, <a href='".URL."admin'>clique aqui</a>.<br><br>
                                Seu email: ".$row['email']."<br><br>
                                Atenciosamente,<br><br>
                                Equipe <a href='".URL."'>".$parametrosSite['title']."</a></td>
<                           </tr>
                        </table><hr noshade><center>Email desenvolvido pela <a href='https://www.bhcommerce.com.br'>BH Commerce</a></center><hr noshade>
                   </body>
                   </html>";
        $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
        $cabecalhoEmail .= "From: Contato - BH Commerce<contato@bhcommerce.com.br>\nReply-To: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>";
        //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $row['email'], $row['name'], $parametrosSite['title']." - Cadastro Liberado no Admin com Sucesso!", $html);
        mail($row['name']."<".$row['email'].">", $parametrosSite['title']." - Cadastro Liberado no Admin com Sucesso!", $html, $cabecalhoEmail);
        echo "1";
        break;
    case "editar":
        $qualE = 0;
        $filesImg = "";
        $img = "";
        switch ($_REQUEST['table']){
            case "pedido":
                $sql = "SELECT a.*, b.email AS emailCliente, c.send_email, c.email, d.name AS nomeCliente, e.nomeFantasia FROM requests a INNER JOIN clients b ON (a.client = b.id) INNER JOIN requests_statuses c ON (a.status = c.id) LEFT JOIN pessoa_fisicas d ON (b.id = d.client) LEFT JOIN pessoa_juridicas e ON (b.id = e.client) WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $sql = "SELECT * FROM requests_statuses WHERE id = '".$_REQUEST['statusEditar']."'";
                $query2 = mysqli_query($con, $sql);
                $row2 = mysqli_fetch_array($query2);
                $sql = "SELECT a.* FROM requests_items a WHERE a.request = '".$_REQUEST['id']."' LIMIT 1";
                $query3 = mysqli_query($con, $sql);
                $row3 = mysqli_fetch_array($query3);
                $lista = $row3['lista'];
                $vet = explode(' ', $row['created_at']);
                $vet1 = explode('-', $vet[0]);
                if ($row['status'] != $_REQUEST['statusEditar'] && $row2['send_email'] == 1){
                    $paraNome3 = ($row['nomeCliente']) ? $row['nomeCliente'] : $row['nomeFantasia'];
                    $paraEmail = $row['emailCliente'];
                    $assunto = $parametrosSite['title'].utf8_decode(" - Alteração de status do pedido ").sprintf("%06s", $row['id'])." - ".$row2['name'];
                    $htmlEmail = "<html><head><title>Email de alteração de status</title></head><body><table border='0' width='100%'><tr><td valign='top' width='150'><img src='".URL."img/logo.png' width='150'></td><td>".nl2br(str_replace("##nomeCliente##", utf8_decode($paraNome), str_replace("##numPedido##", sprintf("%06s", $row['id']), str_replace("##dataHora##", utf8_decode(date('d/m/Y')." às ".date('H:i:s')."h"), str_replace('##linkAcompanha##', 'https://www2.correios.com.br/sistemas/rastreamento/ctrl/ctrlRastreamento.cfm?objetos='.$_REQUEST['codRastreamento'], $row2['email'])))))."<hr noshade><center>Email desenvolvido pela <a href='https://www.bhcommerce.com.br'>BH Commerce</a></center><hr noshade></td></td></tr></table></body></html>";
                    $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
                    $cabecalhoEmail .= "From: ".$parametrosSite['title']."<".$parametrosSite['email'].">\nReply-To: ".$parametrosSite['title']."<".$parametrosSite['email'].">";
                    //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $paraEmail, $paraNome3, ($assunto), $htmlEmail);
					mail($paraNome."<".$paraEmail.">", $assunto, $htmlEmail, $cabecalhoEmail);
                    if ($lista && $_REQUEST['statusEditar'] == 6){
                        $sql = "SELECT a.*, b.email, c.name, d.nomeFantasia, d.contato FROM presents_lists a INNER JOIN clients b ON (a.client = b.id) LEFT JOIN pessoa_fisicas c ON (b.id = c.client) LEFT JOIN pessoa_juridicas d ON (b.id = d.client) WHERE a.id = '".$lista."'";
						$query4 = mysqli_query($con, $sql);
                        $row4 = mysqli_fetch_array($query4);
                        $sql = "SELECT a.*, b.name AS nomeProduto, c.name AS nomeItem FROM requests_items a INNER JOIN products b ON (a.product = b.id) INNER JOIN products_items c ON (a.product_item = c.id) WHERE a.request = '".$_REQUEST['id']."'";
                        $query5 = mysqli_query($con, $sql);
                        if (mysqli_num_rows($query5)){
                            while ($row5 = mysqli_fetch_array($query5)){
                                $sql = "SELECT * FROM presents_lists_products WHERE lista = '".$row5['lista']."' AND product = '".$row5['product']."' AND product_item = '".$row5['product_item']."'";
                                $query6 = mysqli_query($con, $sql);
                                $row6 = mysqli_fetch_array($query6);
                                $ganhou = $row6['ganhou'] + $row5['quantity'];
								$nomeProduto = $row5['nomeProduto']." - ".$row5['nomeItem'];
                                $sql = "UPDATE presents_lists_products SET ganhou = '".$ganhou."' WHERE lista = '".$row5['lista']."' AND product = '".$row5['product']."' AND product_item = '".$row5['product_item']."'";
                                mysqli_query($con, $sql);
								$paraNome = ($row4['name']) ? $row4['name'] : $row4['nomeFantasia']." - ".$row4['contato'];
								$paraEmail = $row4['email'];
								$assunto = $parametrosSite['title']." - Recebimento de Presente";
								$htmlEmail = "<html><head><title>Recebimento de Presente</title></head><body><table border='0' width='100%'><tr><td valign='top' width='150'><img src='".URL."img/logo.png' width='150'></td><td>Olá ".$paraNome.",<br><br>Este email é para te informar do recebimento do seguinte presente: ".utf8_encode($nomeProduto).".<br><br>Este presente foi dado por: ".$paraNome3."<br><br>A ".$parametrosSite['title']." te parabeniza pelo seu dia!<br><br>Atenciosamente,<br><br>Equipe ".$parametrosSite['title']."<hr noshade><center>Email desenvolvido pela <a href='https://www.bhcommerce.com.br'>BH Commerce</a></center><hr noshade></td></td></tr></table></body></html>";
								$cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
								$cabecalhoEmail .= "From: ".$parametrosSite['title']."<".$parametrosSite['email'].">\nReply-To: ".$parametrosSite['title']."<".$parametrosSite['email'].">";
								mail($paraNome."<".$paraEmail.">", $assunto, $htmlEmail, $cabecalhoEmail);
								//enviarEmail($parametrosSite['email'], $parametrosSite['title'], $paraEmail, $paraNome, utf8_decode($assunto), utf8_decode($htmlEmail));
                            }
                        }
                    }
                    if ($_REQUEST['statusEditar'] == 6){
                        $sql = "SELECT * FROM requests_items WHERE request = '".$row['id']."' AND name LIKE 'Vale Presente%'";
                        $query = mysqli_query($con, $sql);
                        $i = 0;
                        if (mysqli_num_rows($query)){
                            while ($row2 = mysqli_fetch_array($query)){
                                $codigo = rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9)."-".$parametrosSite['nomeValePresente']."-".rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9);
                                $sql = "INSERT INTO vales (request_item, code, value, validade, created_at, updated_at) VALUES('".$row2['id']."', '".$codigo."', '".$row2['value']."', '9999-12-31', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                                mysqli_query($con, $sql);
                                $idVale = mysqli_insert_id($con);
                                $sql = "UPDATE requests_items SET vale = '".$idVale."' WHERE id = '".$row2['id']."'";
                                mysqli_query($con, $sql);
                                $paraNome = ($row['nomeCliente']) ? $row['nomeCliente'] : $row['nomeFantasia'];
                                $paraEmail = $row['emailCliente'];
                                $assunto = $parametrosSite['title']." - Vale Presente de R$".number_format($row2['value'], 2, ',', '.');
                                $htmlEmail = "<html><head><title>".$parametrosSite['title']." - Vale Presente de R$".number_format($row2['value'], 2, ',', '.')."</title></head><body><table border='0' style=background-image:url('".URL."img/valePresente.png');background-repeat:no-repeat;width:456px;height:314px><tr><td height='100' colspan='2'>&nbsp;</td></tr><tr><td width='40%'>&nbsp;</td><td style='color:#999999'><h3>".$parametrosSite['title']."</h3><p style='left:50%'><img src='".URL."img/logo.png' width='75'><b>R$".number_format($row2['value'], 2, ',', '.')."</b><br>Válido até: <b>31/12/9999</b></p><h3 style='text-align:center; padding:5px; margin:none'>".$codigo."</h3></td></tr></table><sub>* válido para utilização no site <a href='".URL."' target='_blank'>".URL."</a>. Caso seja utilizado em compra de menor valor, o desconto será do valor total da compra. Só é possível a utilização uma vez no nosso site.</sub>Atenciosamente,<br><br>Equipe <a href='".URL."'>".$parametrosSite['title']."</a><hr noshade><center>Email desenvolvido pela <a href='https://www.bhcommerce.com.br'>BH Commerce</a></center><hr noshade></body></html>";
                                $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
                                $cabecalhoEmail .= "From: ".$parametrosSite['title']."<".$parametrosSite['email'].">\nReply-To: ".$parametrosSite['title']."<".$parametrosSite['email'].">";
                                mail($paraNome."<".$paraEmail.">", $assunto, $htmlEmail, $cabecalhoEmail);
								//enviarEmail($parametrosSite['email'], $parametrosSite['title'], $paraEmail, $paraNome, $assunto, $htmlEmail);
                                $vales[$i] = $row2;
                                $i++;
                            }
                        }
					}
                    if ($_REQUEST['statusEditar'] == 7){
                        $sql = "SELECT * FROM requests_items WHERE request = '".$row['id']."'";
                        $query = mysqli_query($con, $sql);
                        if (mysqli_num_rows($query)){
                            while ($row = mysqli_fetch_array($query)){
                                $estoque[$row['product_item']] = $row['quantity'];
                            }
                        }
                        if (count($estoque)){
                            foreach ($estoque as $key => $value){
                                $sql = "SELECT * FROM products_items WHERE id = '".$key."'";
                                $query = mysqli_query($con, $sql);
                                $row = mysqli_fetch_array($query);
                                if ($row['estoque']){
                                    $estoque = $row['estoque'] + $value;
                                }
                                $sql = "UPDATE products_items SET estoque = '".$estoque."' WHERE id = '".$key."'";
                                mysqli_query($con, $sql);
                            }
                        }
                    }
                }
                $sql = "UPDATE requests SET status = '".utf8_decode($_REQUEST['statusEditar'])."', codRastreamento = '".$_REQUEST['codRastreamento']."', paymentMethod = '".utf8_decode($_REQUEST['formaPagamentoEditar'])."', client = '".utf8_decode($_REQUEST['clienteEditar'])."', address = '".utf8_decode($_REQUEST['enderecoEditar'])."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['id']."'";
                $artigo = "o";
                break;
            case "newsletter":
                $sql = "UPDATE newsletters SET name = '".utf8_decode($_REQUEST['nomeEdicao'])."', email = '".utf8_decode($_REQUEST['emailEdicao'])."', status = '".utf8_decode($_REQUEST['statusEdicao'])."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "a";
                break;
            case "imoveis":
                $sql = "UPDATE properties_addresses SET zip = '".$_REQUEST['cepEdicao']."', address = '".$_REQUEST['logradouroEdicao']."', number = '".$_REQUEST['numeroEdicao']."', complement = '".$_REQUEST['complementoEdicao']."', neighborhood = '".$_REQUEST['bairroEdicao']."' WHERE property = '".$_REQUEST['idEdicao']."'";
                mysqli_query($con, $sql);
                $sql = "UPDATE properties SET name = '".($_REQUEST['nomeEdicao'])."', description = '".($_REQUEST['descricaoEdicao'])."', metragem = '".$_REQUEST['metragemEdicao']."', quartos = '".$_REQUEST['quartosEdicao']."', suites = '".$_REQUEST['suitesEdicao']."', vagas = '".$_REQUEST['vagasEdicao']."', status = '".($_REQUEST['statusEdicao'])."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "a";
                break;
            case "cupomDesconto":
                $_REQUEST['valorEdicao'] = str_replace('.', '', $_REQUEST['valorEdicao']);
                $_REQUEST['valorEdicao'] = str_replace(',', '.', $_REQUEST['valorEdicao']);
                $sql = "UPDATE coupon_discounts SET codigo = '".utf8_decode($_REQUEST['codigoEdicao'])."', tipo = '".utf8_decode($_REQUEST['tipoEdicao'])."', valor = '".utf8_decode($_REQUEST['valorEdicao'])."', validade = '".utf8_decode($_REQUEST['validadeEdicao'])."', utilizavel = '".utf8_decode($_REQUEST['utilizavelEdicao'])."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "valePresente":
                $_REQUEST['valorEdicao'] = str_replace('.', '', $_REQUEST['valorEdicao']);
                $_REQUEST['valorEdicao'] = str_replace(',', '.', $_REQUEST['valorEdicao']);
                $sql = "UPDATE vales SET code = '".utf8_decode($_REQUEST['codigoEdicao'])."', value = '".utf8_decode($_REQUEST['valorEdicao'])."', validade = '".utf8_decode($_REQUEST['validadeEdicao'])."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "bugTracking":
                $sql = "SELECT a.*, b.name AS nomeTipoServico , c.name AS nomeTipoVersao , d.name AS nomePrioridade, e.name AS nomeCategoria FROM bug_trackings a INNER JOIN types_services b ON (a.typeService = b.id) INNER JOIN type_versions c ON (a.typeVersion = c.id) INNER JOIN priorities d ON (a.priority = d.id) INNER JOIN categories e ON (a.category = e.id) WHERE a.id = '".$_REQUEST['idEdicao']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = $vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h";
                if($row['status'] != $_REQUEST['statusEdicao'] && $_REQUEST['statusEdicao'] == 2){
                    $nomelQuem = utf8_decode($_REQUEST['nomeEdicao']);
                    $emailQuem = utf8_decode($_REQUEST['emailEdicao']);
                    $assunto = $parametrosSite['title']." - Resposta ao bug tracking enviado em nosso site";
                    $corpoEmail = utf8_decode("<html><head><title>Resposta ao bug tracking enviado em nosso site</title><body><table width='100%' border='0' cellpadding='0' cellspacing='0'><tr><td width='30%' style='text-align:center' valign='top'><img src='".URL."img/logo.png' width='100'></td><td>Olá <b>".$_REQUEST['nomeEdicao']."</b>,<br><br>Este email é pra informar da resposta ao bug tracking enviado em <b>".$row['created_at']."</b>.<br><br><b>Dados do Bug Tracking</b><br><br>Título: <b>".utf8_encode($row['title'])."</b><br>Tipo de Serviço: <b>".utf8_encode($row['nomeTipoServico'])."</b><br>Versão: <b>".utf8_encode($row['nomeTipoVersao'])."</b><br>Prioridade: <b>".utf8_encode($row['nomePrioridade'])."</b><br>Categoria: <b>".utf8_encode($row['nomeCategoria'])."</b><br>Mensagem: <b>".utf8_encode(nl2br($row['message']))."</b><br>Resposta: <b>".(nl2br($_REQUEST['respostaEdicao']))."</b><br><br>Atenciosamente<br><br>Equipe <a href='".URL."'>".$parametrosSite['title']."</a><hr noshade><center>Email desenvolvido pela <a href='https://www.bhcommerce.com.br'>BH Commerce</a></center><hr noshade></td></tr></table></body></head></html>");
                    $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
                    $cabecalhoEmail .= "From: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>\nReply-To: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>";
                    mail($nomelQuem."<".$emailQuem.">", $assunto, $corpoEmail, $cabecalhoEmail);
					//enviarEmail($parametrosSite['email'], $parametrosSite['title'], $emailQuem, $nomelQuem, $assunto, $corpoEmail);
                }
                $sql = "UPDATE bug_trackings SET name = '".utf8_decode($_REQUEST['nomeEdicao'])."', email = '".utf8_decode($_REQUEST['emailEdicao'])."', title = '".utf8_decode($_REQUEST['tituloEdicao'])."', typeService = '".$_REQUEST['tipoServicoEdicao']."', typeVersion = '".$_REQUEST['typeVersion']."', priority = '".$_REQUEST['priority']."', category = '".$_REQUEST['category']."', status = '".utf8_decode($_REQUEST['statusEdicao'])."', answer = '".utf8_decode($_REQUEST['respostaEdicao'])."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "faleConosco":
                $sql = "SELECT a.* FROM messages a WHERE a.id = '".$_REQUEST['idEdicao']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                if($row['status'] != $_REQUEST['statusEdicao'] && $_REQUEST['statusEdicao'] == 2){
                    $nomelQuem = utf8_decode($_REQUEST['nomeEdicao']);
                    $emailQuem = utf8_decode($_REQUEST['emailEdicao']);
                    $vet = explode(' ', $row['created_at']);
                    $vet2 = explode('-', $vet[0]);
                    $row['created_at'] = $vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h";
                    $assunto = $parametrosSite['title']." - Resposta ao fale Conosco enviado em nosso site";
                    $corpoEmail = utf8_decode("<html><head><title>Resposta ao FALE CONOSCO enviado em nosso site</title><body><table width='100%' border='0' cellpadding='0' cellspacing='0'><tr><td width='30%' style='text-align:center' valign='top'><img src='".URL."img/logo.png' width='100'></td><td>Olá <b>".$_REQUEST['nomeEdicao']."</b>,<br><br>Este email é pra informar da resposta ao fale conosco enviado em <b>".$row['created_at']."</b>.<br><br><b>Dados do Fale Conosco</b><br><br>Assunto: <b>".utf8_encode($row['subject'])."</b><br>Telefone: <b>".utf8_encode($row['phone'])."</b><br></b><br>Mensagem: <b>".utf8_encode(nl2br($row['text']))."</b><br>Resposta: <b>".(nl2br($_REQUEST['respostaEdicao']))."</b><br><br>Atenciosamente<br><br>Equipe <a href='".URL."'>".$parametrosSite['title']."</a><hr noshade><center>Email desenvolvido pela <a href='https://www.bhcommerce.com.br'>BH Commerce</a></center><hr noshade></td></tr></table></body></head></html>");
                    $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
                    $cabecalhoEmail .= "From: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>\nReply-To: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>";
                    mail($nomelQuem."<".$emailQuem.">", $assunto, $corpoEmail, $cabecalhoEmail);
                    //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $emailQuem, $nomelQuem, $assunto, $corpoEmail);
                }
                $sql = "UPDATE messages SET name = '".utf8_decode($_REQUEST['nomeEdicao'])."', email = '".utf8_decode($_REQUEST['emailEdicao'])."', subject = '".utf8_decode($_REQUEST['assuntoEdicao'])."', phone = '".$_REQUEST['telefoneEdicao']."', status = '".utf8_decode($_REQUEST['statusEdicao'])."', answer = '".utf8_decode($_REQUEST['respostaEdicao'])."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "anuncie":
                $sql = "SELECT a.* FROM anuncie_aqui a WHERE a.id = '".$_REQUEST['idEdicao']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                if($row['status'] != $_REQUEST['statusEdicao'] && $_REQUEST['statusEdicao'] == 2){
                    $nomelQuem = utf8_decode($_REQUEST['nomeEdicao']);
                    $emailQuem = utf8_decode($_REQUEST['emailEdicao']);
					$vet = explode(' ', $row['created_at']);
					$vet2 = explode('-', $vet[0]);
					$row['created_at'] = $vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h";
                    $assunto = $parametrosSite['title']." - Resposta ao anuncie aqui enviado em nosso site";
                    $corpoEmail = utf8_decode("<html><head><title>Resposta ao ANUNCIE AQUI enviado em nosso site</title><body><table width='100%' border='0' cellpadding='0' cellspacing='0'><tr><td width='30%' style='text-align:center' valign='top'><img src='".URL."img/logo.png' width='100'></td><td>Olá <b>".$_REQUEST['nomeEdicao']."</b>,<br><br>Este email é pra informar da resposta ao Anuncie Aqui enviado em <b>".$row['created_at']."</b>.<br><br><b>Dados do Fale Conosco</b><br><br>Assunto: <b>".utf8_encode($row['subject'])."</b><br>Telefone: <b>".utf8_encode($row['phone'])."</b><br></b><br>Mensagem: <b>".utf8_encode(nl2br($row['text']))."</b><br>Resposta: <b>".(nl2br($_REQUEST['respostaEdicao']))."</b><br><br>Atenciosamente<br><br>Equipe <a href='".URL."'>".$parametrosSite['title']."</a><hr noshade><center>Email desenvolvido pela <a href='https://www.bhcommerce.com.br'>BH Commerce</a></center><hr noshade></td></tr></table></body></head></html>");
                    $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
                    $cabecalhoEmail .= "From: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>\nReply-To: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>";
                    mail($nomelQuem."<".$emailQuem.">", $assunto, $corpoEmail, $cabecalhoEmail);
					//enviarEmail($parametrosSite['email'], $parametrosSite['title'], $emailQuem, $nomelQuem, $assunto, $corpoEmail);
                }
                $sql = "UPDATE anuncie_aqui SET name = '".utf8_decode($_REQUEST['nomeEdicao'])."', email = '".utf8_decode($_REQUEST['emailEdicao'])."', subject = '".utf8_decode($_REQUEST['assuntoEdicao'])."', phone = '".$_REQUEST['telefoneEdicao']."', status = '".utf8_decode($_REQUEST['statusEdicao'])."', answer = '".utf8_decode($_REQUEST['respostaEdicao'])."', nome_banner = '".$_REQUEST['nomeBannerEdicao']."', link_banner = '".$_REQUEST['linkBannerEdicao']."', target_banner = '".$_REQUEST['targetBannerEdicao']."', posicao_banner = '".$_REQUEST['posicaoBannerEdicao']."', tipo_banner = '".$_REQUEST['tipoBannerEdicao']."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "statusPedido":
                $sql = utf8_decode("UPDATE requests_statuses SET name = '".($_REQUEST['nomeEdicao'])."', sigla = '".($_REQUEST['siglaEdicao'])."', color = '".$_REQUEST['colorEdicao']."', background = '".$_REQUEST['backgroundEdicao']."', send_email = '".$_REQUEST['enviarEmailEdicao']."', email = '".$_REQUEST['emailEdicao']."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'");
                $artigo = "o";
                break;
            case "tiposDocumento":
                $sql = "UPDATE type_documents SET name = '".utf8_decode($_REQUEST['nomeEdicao'])."', status = '".utf8_decode($_REQUEST['statusEdicao'])."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "clientes":
                $sql = "UPDATE clients SET email = '".utf8_decode($_REQUEST['emailEdicao'])."', type_person = '".$_REQUEST['tipoEdicao']."'";
                if ($_REQUEST['senhaEdicao']){
                    $sql .= ", password = '".md5($_REQUEST['senhaEdicao'])."'";
                }
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                $sql2 = "DELETE FROM pessoa_fisicas WHERE client = '".$_REQUEST['idEdicao']."'";
                mysqli_query($con, $sql2);
                $sql2 = "DELETE FROM pessoa_juridicas WHERE client = '".$_REQUEST['idEdicao']."'";
                mysqli_query($con, $sql2);
                if ($_REQUEST['tipoEdicao'] == 'F'){
                    $sql2 = utf8_decode("INSERT INTO pessoa_fisicas (client, name, cpf, rg, nationality, dtNasc, cel, created_at, updated_at) VALUES ('".$_REQUEST['idEdicao']."', '".utf8_encode($_REQUEST['nomeEdicao'])."', '".$_REQUEST['cpfEdicao']."', '".$_REQUEST['rgEdicao']."', '".$_REQUEST['nacionalidadeEdicao']."', '".$_REQUEST['dtNascEdicao']."', '".$_REQUEST['celEdicao']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                    mysqli_query($con, $sql2) or die(mysqli_error($con));
                }
                else{
                    $sql2 = utf8_decode("INSERT INTO pessoa_juridicas (client, razaoSocial, nomeFantasia, contato, cnpj, ie, im, nationality, dataAbertura, telefone, cel, created_at, updated_at) VALUES ('".$_REQUEST['idEdicao']."', '".utf8_encode($_REQUEST['razaoSocialEdicao']."', '".$_REQUEST['nomeFantasiaEdicao']."', '".$_REQUEST['contatoEdicao'])."', '".$_REQUEST['cnpjEdicao']."', '".$_REQUEST['ieEdicao']."', '".$_REQUEST['imEdicao']."', '".$_REQUEST['nacionalidadeEmpresaEdicao']."', '".$_REQUEST['dataAberturaEdicao']."', '".$_REQUEST['telefoneEdicao']."', '".$_REQUEST['celEdicao']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                    mysqli_query($con, $sql2) or die(mysqli_error($con));
                }
                break;
            case "tiposProduto":
                $sql = "UPDATE types_products SET name = '".utf8_decode($_REQUEST['nomeEdicao'])."', status = '".utf8_decode($_REQUEST['statusEdicao'])."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "relacionamentosProduto":
                $sql = "DELETE FROM products_attributes WHERE product = '".$_REQUEST['idProdutoRelacionamento']."'";
                mysqli_query($con, $sql);
                for ($i = 1; $i <= 999; $i++) {
                    if ($_REQUEST['atributosEditar'.$i]) {
                        $sql = "INSERT INTO products_attributes (product, attribute, created_at, updated_at) VALUES ('".$_REQUEST['idProdutoRelacionamento']."', '".$i."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                        mysqli_query($con, $sql) or die(mysqli_error($con));
                    }
                }
                $sql = "DELETE FROM products_brands WHERE product = '".$_REQUEST['idProdutoRelacionamento']."'";
                mysqli_query($con, $sql);
                if ($_REQUEST['marcaEdicao']){
                    $sql = "INSERT INTO products_brands (product, brand, created_at, updated_at) VALUES ('".$_REQUEST['idProdutoRelacionamento']."', '".$_REQUEST['marcaEdicao']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                    mysqli_query($con, $sql);
                }
                $sql = "DELETE FROM products_departaments WHERE product = '".$_REQUEST['idProdutoRelacionamento']."'";
                mysqli_query($con, $sql) or die(mysqli_error($con));
                for ($i = 1; $i <= 999; $i++) {
                    if ($_REQUEST['deptoEditar'.$i]) {
                        $sql = "INSERT INTO products_departaments (product, departament, created_at, updated_at) VALUES ('".$_REQUEST['idProdutoRelacionamento']."', '".$i."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                        mysqli_query($con, $sql) or die(mysqli_error($con));
                    }
                    if ($_REQUEST['subdeptoEditar'.$i]) {
                        $sql = "INSERT INTO products_departaments (product, departament, created_at, updated_at) VALUES ('".$_REQUEST['idProdutoRelacionamento']."', '".$i."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                        mysqli_query($con, $sql) or die(mysqli_error($con));
                    }
                }
                $sql = "DELETE FROM products_suggestions WHERE product = '".$_REQUEST['idProdutoRelacionamento']."'";
                mysqli_query($con, $sql) or die(mysqli_error($con));
                for ($i = 1; $i <= 999; $i++) {
                    if ($_REQUEST['sugestaoEditar'.$i]) {
                        $sql = "INSERT INTO products_suggestions (product, suggestion, created_at, updated_at) VALUES ('" . $_REQUEST['idProdutoRelacionamento'] . "', '" . $i . "', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                        mysqli_query($con, $sql) or die(mysqli_error($con));
                    }
                }
                $sql = "DELETE FROM products_stamps WHERE product = '".$_REQUEST['idProdutoRelacionamento']."'";
                mysqli_query($con, $sql) or die(mysqli_error($con));
                for ($i = 1; $i <= 999; $i++) {
                    if ($_REQUEST['selosEditar'.$i]) {
                        $sql = "INSERT INTO products_stamps (product, stamp, created_at, updated_at) VALUES ('" . $_REQUEST['idProdutoRelacionamento'] . "', '" . $i . "', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                        mysqli_query($con, $sql) or die(mysqli_error($con));
                    }
                }
                $sql = "DELETE FROM products_relationships WHERE product = '".$_REQUEST['idProdutoRelacionamento']."'";
                mysqli_query($con, $sql) or die(mysqli_error($con));
                for ($i = 1; $i <= 999; $i++) {
                    if ($_REQUEST['relacionamentosEditar'.$i]) {
                        $sql = "INSERT INTO products_relationships (product, relationship, created_at, updated_at) VALUES ('" . $_REQUEST['idProdutoRelacionamento'] . "', '" . $i . "', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                        mysqli_query($con, $sql) or die(mysqli_error($con));
                    }
                }
                echo "1";
                break;
            case "produto":
                $sql = "UPDATE products SET name = '".utf8_decode($_REQUEST['nomeEdicao'])."', description = '".utf8_decode($_REQUEST['descricaoEdicao'])."', status = '".utf8_decode($_REQUEST['statusEdicao'])."', apareceVitrine = '".$_REQUEST['apareceVitrineEdicao']."', destaque = '".$_REQUEST['destaqueEdicao']."', compreAgora = '".$_REQUEST['compreAgoraEdicao']."', freteGratis = '".$_REQUEST['freteGratisEdicao']."', mostraCarrinho = '".$_REQUEST['mostraCarrinhoEdicao']."', promocao = '".$_REQUEST['promocaoEdicao']."', itemRecomendado = '".$_REQUEST['itemRecomendadoEdicao']."', valorContaParaOFrete = '".$_REQUEST['valorContaParaOFreteEdicao']."'";
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
				for ($i = 1; $i <= $_REQUEST['qtasTemEdicao']; $i++){
					if ($_REQUEST['description'.$i."Edicao"]){
						$sql2 = "SELECT * FROM products_descriptions WHERE product = '".$_REQUEST['idEdicao']."' AND num = '".$i."'";
						$query = mysqli_query($con, $sql2);
						if (mysqli_num_rows($query)){
							$sql3 = utf8_decode("UPDATE products_descriptions SET text = '".$_REQUEST['description'.$i."Edicao"]."', type = '".$_REQUEST['tipo'.$i."Edicao"]."', updated_at = '".date('Y-m-d H:i:s')."' WHERE product = '".$_REQUEST['idEdicao']."' AND num = '".$i."'");
						}
						else{
							$sql3 = utf8_decode("INSERT INTO products_descriptions (product, num, text, type, created_at, updated_at) VALUES ('".$_REQUEST['idEdicao']."', '".$i."', '".$_REQUEST['description'.$i."Edicao"]."', '".$_REQUEST['tipo'.$i."Edicao"]."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
						}
						mysqli_query($con, $sql3) or die(mysqli_error($con));
					}
				}
				$i = 1;
				$sql4 = "SELECT * FROM products_descriptions WHERE product = '".$_REQUEST['idEdicao']."' ORDER BY num ASC";
				$query4 = mysqli_query($con, $sql4);
				if (mysqli_num_rows($query4)){
					while ($row4 = mysqli_fetch_array($query4)){
						$sql5 = "UPDATE products_descriptions SET num = '".$i."' WHERE id = '".$row4['id']."'";
						$i++;
						mysqli_query($con, $sql5);
					}
				}
                $artigo = "o";
                $qualE = "products";
                break;
            case "listaPresente":
                if ($_REQUEST['dataAniversarioEdicao'] >= date('Y-m-d')){
                    $status = 1;
                }
                else{
                    $status = 0;
                }
                $sql = "UPDATE presents_lists SET client = '".utf8_decode($_REQUEST['clienteEdicao'])."', nomeAniversariante = '".utf8_decode($_REQUEST['nomeEdicao'])."', dataAniversario = '".$_REQUEST['dataAniversarioEdicao']."', nomeMae = '".utf8_decode($_REQUEST['nomeMaeEdicao'])."', nomePai = '".utf8_decode($_REQUEST['nomePaiEdicao'])."', idade = '".$_REQUEST['idadeEdicao']."', status = '".$status."', cep = '".$_REQUEST['cepEdicao']."', address = '".utf8_decode($_REQUEST['logradouroEdicao']."', number = '".$_REQUEST['numeroEdicao']."', complement = '".$_REQUEST['complementoEdicao']."', neighborhood = '".$_REQUEST['bairroEdicao']."', city = '".$_REQUEST['cidadeEdicao'])."', state = '".$_REQUEST['estadoEdicao']."'";
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "a";
                $qualE = "presents_lists";
                break;
            case "comentarioProduto":
				$sql = "SELECT a.status, a.nome, a.email, b.name AS nomeProduto, b.slug AS urlProduto, a.created_at FROM products_reviews a INNER JOIN products b ON (a.product = b.id) WHERE a.id = '".$_REQUEST['idEdicao']."'";
				$query = mysqli_query($con, $sql) or die(mysqli_error($con));
				$row = mysqli_fetch_array($query);
				if ($row['status'] != $_REQUEST['statusEdicao'] && $_REQUEST['statusEdicao'] == 1){
					$vet = explode(' ', $row['created_at']);
					$vet2 = explode('-', $vet[0]);
					$row['created_at'] = $vet2[2]."/".$vet2[1]."/".$vet2[0]." âs ".$vet[1]."h";
					$assuntoEmail = "Comentário aprovado e aparecendo em nosso site - ".$parametrosSite['title'];
					$htmlEmail = "<html><head><title>Comentário aprovado e aparecendo em nosso site - ".$parametrosSite['title']."</title></head><body><table width='100%' border='0' cellpadding='0' cellspacing='0'><tr><td width='250' valign='top' align='center'><img src='".URL."img/logo.png' width='230'></td><td>Olá ".utf8_encode($row['nome']).",<br><br>Informamos que o seu comentário, enviado dia ".$row['created_at'].", acaba de ser aprovado para aparecer no site.<br><br>Para ver o produto ".utf8_encode($row['nomeProduto']).", <a href='".URL."produto/".$row['urlProduto']."'>clique aqui</a>. Aí é só rolar um pouco a página até a parte dos comentários que o seu deve ser o primeiro a aparecer lá. Caso isso não esteja acontecendo favor nos informar.<br><br>Atenciosamente,<br><br>Equipe ".$parametrosSite['title']."<hr noshade><center>Email Desenvolvido Pela <a href='https://www.bhcommerce.com.br/'>BH Commerce</a></center><hr noshade></td></tr></table></body></html>";
                    $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
                    $cabecalhoEmail .= "From: BH Commerce<contato@bhcommerce.com.br>\nReply-To: BH Commerce<contato@bhcommerce.com.br>";
                    mail($row['nome']."<".$row['email'].">", $assuntoEmail, $htmlEmail, $cabecalhoEmail);
                    //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $row['email'], $row['nome'], utf8_decode($assuntoEmail), utf8_decode($htmlEmail));
				}
                $sql = "UPDATE products_reviews SET nome = '".($_REQUEST['nomeEdicao'])."', email = '".($_REQUEST['emailEdicao'])."', avaliacao = '".($_REQUEST['avaliacaoEditar'])."',  mensagem = '".$_REQUEST['mensagemEdicao']."', status = '".($_REQUEST['statusEdicao'])."'";
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "solicitacaoComentario":
				$sql = "SELECT a.*, a.created_at FROM products_reviews_solicitas a WHERE a.id = '".$_REQUEST['idEdicao']."'";
				$query = mysqli_query($con, $sql) or die(mysqli_error($con));
				$row = mysqli_fetch_array($query);
                $sql = "UPDATE products_reviews_solicitas SET avaliacao = '".($_REQUEST['avaliacaoEditar'])."',  mensagem = '".$_REQUEST['mensagemEdicao']."'";
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "a";
                break;
            case "formaPagamento":
                $_REQUEST['vlParcelaMinimaEdicao'] = str_replace(".", "", $_REQUEST['vlParcelaMinimaEdicao']);
                $_REQUEST['vlParcelaMinimaEdicao'] = str_replace(",", ".", $_REQUEST['vlParcelaMinimaEdicao']);
                $sql = "UPDATE payment_methods SET name = '".utf8_decode($_REQUEST['nomeEdicao'])."', vlParcelaMinima = '".$_REQUEST['vlParcelaMinimaEdicao']."', parcelas = '".$_REQUEST['parcelasEdicao']."'";
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                    $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                    $nameImg = $_FILES['imagemEdicao']['name'];
                    $qualEdicao = "formaPagamento";
                    $tableEditar = "payment_methods";
                }
                break;
            case "formaFrete":
                $_REQUEST['valorEdicao'] = str_replace(".", "", $_REQUEST['valorEdicao']);
                $_REQUEST['valorEdicao'] = str_replace(",", ".", $_REQUEST['valorEdicao']);
                $sql = "UPDATE shipping_methods SET name = '".utf8_decode($_REQUEST['nomeEdicao'])."', value = '".$_REQUEST['valorEdicao']."', code = '".$_REQUEST['codigoEdicao']."', status = '".$_REQUEST['statusEdicao']."'";
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "a";
                break;
            case "banner":
                $sql = "UPDATE banners SET name = '".utf8_decode($_REQUEST['nomeEdicao']."', description = '".$_REQUEST['descricaoEdicao']."', position = '".$_REQUEST['posicaoEdicao']."', link = '".$_REQUEST['linkEdicao']."', target = '".$_REQUEST['targetEdicao']."', status = '".$_REQUEST['statusEdicao']."', position = '".$_REQUEST['posicaoEdicao']."', validade = '".$_REQUEST['validadeEdicao']."'");
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                $qualE = "banners";
                if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                    $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                    $nameImg = $_FILES['imagemEdicao']['name'];
                    $qualEdicao = "banner";
                    $tableEditar = "banners";
                }
                break;
            case "feriados":
                $sql = "UPDATE holidays SET name = '".utf8_decode($_REQUEST['nomeEdicao']."', date = '".$_REQUEST['dataEdicao']."', status = '".$_REQUEST['statusEdicao']."'");
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "parceiros":
                $sql = "UPDATE partners SET name = '".utf8_decode($_REQUEST['nomeEdicao']."', description = '".$_REQUEST['descricaoEdicao']."', link = '".$_REQUEST['linkEdicao']."', status = '".$_REQUEST['statusEdicao']."'");
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "nacionalidade":
                $sql = "UPDATE nationalities SET name = '".($_REQUEST['nomeEdicao']."', padrao = '".$_REQUEST['padraoEdicao']."', status = '".$_REQUEST['statusEdicao']."'");
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "a";
                break;
            case "pais":
                $sql = "UPDATE countries SET name = '".($_REQUEST['nomeEdicao']."', padrao = '".$_REQUEST['padraoEdicao']."', status = '".$_REQUEST['statusEdicao']."'");
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "redesSociais":
                $sql = "UPDATE social_networks SET name = '".utf8_decode($_REQUEST['nomeEdicao']."', description = '".$_REQUEST['descricaoEdicao']."', status = '".$_REQUEST['statusEdicao']."', link = '".$_REQUEST['linkEdicao']."'");
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "a";
                $qualE = "social_networks";
                if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                    $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                    $nameImg = $_FILES['imagemEdicao']['name'];
                    $qualEdicao = "social_network";
                    $tableEditar = "social_networks";
                }
                break;
            case "marcas":
                $sql = "UPDATE brands SET name = '".utf8_decode($_REQUEST['nomeEdicao']."', description = '".$_REQUEST['descricaoEdicao']."', status = '".$_REQUEST['statusEdicao']."'");
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "a";
                $qualE = "brands";
                if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                    $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                    $nameImg = $_FILES['imagemEdicao']['name'];
                    $qualEdicao = "marca";
                    $tableEditar = "brands";
                }
                break;
            case "selos":
                $sql = "UPDATE stamps SET name = '".utf8_decode($_REQUEST['nomeEdicao']."', description = '".$_REQUEST['descricaoEdicao']."', status = '".$_REQUEST['statusEdicao']."'");
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                $qualE = "selos";
                if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                    $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                    $nameImg = $_FILES['imagemEdicao']['name'];
                    $qualEdicao = "selo";
                    $tableEditar = "stamps";
                }
                break;
            case "sugestoes":
                $sql = "UPDATE suggestions SET name = '".utf8_decode($_REQUEST['nomeEdicao']."', description = '".$_REQUEST['descricaoEdicao']."', status = '".$_REQUEST['statusEdicao']."'");
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                $qualE = "suggestions";
                if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                    $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                    $nameImg = $_FILES['imagemEdicao']['name'];
                    $qualEdicao = "sugestao";
                    $tableEditar = "suggestions";
                }
                break;
            case "pagina":
                $sql = "UPDATE pages SET name = '".utf8_decode($_REQUEST['nomeEdicao']."', subname = '".$_REQUEST['subtituloEdicao']."', appearsMenu = '".$_REQUEST['apareceMenuEdicao']."', appearsSite = '".$_REQUEST['apareceSiteEdicao']."', status = '".$_REQUEST['statusEdicao']."'");
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
				for ($i = 1; $i <= $_REQUEST['qtasTemEdicao']; $i++){
					if ($_REQUEST['description'.$i."Edicao"]){
						$sql2 = "SELECT * FROM pages_descriptions WHERE page = '".$_REQUEST['idEdicao']."' AND num = '".$i."'";
						$query = mysqli_query($con, $sql2);
						if (mysqli_num_rows($query)){
							$sql3 = utf8_decode("UPDATE pages_descriptions SET text = '".$_REQUEST['description'.$i."Edicao"]."', type = '".$_REQUEST['tipo'.$i."Edicao"]."', updated_at = '".date('Y-m-d H:i:s')."' WHERE page = '".$_REQUEST['idEdicao']."' AND num = '".$i."'");
						}
						else{
							$sql3 = utf8_decode("INSERT INTO pages_descriptions (page, num, text, type, created_at, updated_at) VALUES ('".$_REQUEST['idEdicao']."', '".$i."', '".$_REQUEST['description'.$i."Edicao"]."', '".$_REQUEST['tipo'.$i."Edicao"]."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
						}
						mysqli_query($con, $sql3) or die(mysqli_error($con));
					}
				}
				$i = 1;
				$sql4 = "SELECT * FROM pages_descriptions WHERE page = '".$_REQUEST['idEdicao']."' ORDER BY num ASC";
				$query4 = mysqli_query($con, $sql4);
				if (mysqli_num_rows($query4)){
					while ($row4 = mysqli_fetch_array($query4)){
						$sql = "UPDATE pages_descriptions SET num = '".$i."' WHERE id = '".$row4['id']."'";
						$i++;
						mysqli_query($con, $sql);
					}
				}
                $artigo = "a";
                $qualE = "pages";
                if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                    $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                    $nameImg = $_FILES['imagemEdicao']['name'];
                    $qualEdicao = "pagina";
                    $tableEditar = "pages";
                }
                break;
            case "subitem":
                $sql = "UPDATE subitems SET name = '".utf8_decode($_REQUEST['nomeEdicao']."', description = '".$_REQUEST['descricaoEdicao']."', subname = '".$_REQUEST['subtituloEdicao']."', appearsImg = '".$_REQUEST['mostraImagemEdicao']."', page = '".$_REQUEST['paginaEdicao']."', status = '".$_REQUEST['statusEdicao']."'");
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                $qualE = "subitems";
                if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                    $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                    $nameImg = $_FILES['imagemEdicao']['name'];
                    $qualEdicao = "subitem";
                    $tableEditar = "subitems";
                }
                break;
            case "tipoServico":
                $sql = "UPDATE types_services SET name = '".utf8_decode($_REQUEST['nomeEdicao'])."', status = '".utf8_decode($_REQUEST['statusEdicao'])."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "tipoModulo":
                $sql = "UPDATE type_modules SET name = '".($_REQUEST['nomeEdicao'])."', status = '".($_REQUEST['statusEdicao'])."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "modulo":
                $sql = "UPDATE modules SET name = '".($_REQUEST['nomeEdicao'])."', status = '".($_REQUEST['statusEdicao'])."', typeModule = '".$_REQUEST['tipoModuloEdicao']."', slug = '".$_REQUEST['urlAmigavelEdicao']."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "prioridade":
                $sql = "UPDATE priorities SET name = '".utf8_decode($_REQUEST['nomeEdicao'])."', status = '".utf8_decode($_REQUEST['statusEdicao'])."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "a";
                break;
            case "tipoVersao":
                $sql = "UPDATE type_versions SET name = '".utf8_decode($_REQUEST['nomeEdicao'])."', typeService = '".utf8_decode($_REQUEST['tipoServicoEdicao'])."', status = '".utf8_decode($_REQUEST['statusEdicao'])."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "departamento":
                $sql = "UPDATE departaments SET name = '".utf8_decode($_REQUEST['nomeEdicao'])."', idPai = '".utf8_decode($_REQUEST['departamentoEdicao'])."', status = '".utf8_decode($_REQUEST['statusEdicao'])."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "relacionamento":
                $sql = "UPDATE relationships SET name = '".utf8_decode($_REQUEST['nomeEdicao'])."', status = '".utf8_decode($_REQUEST['statusEdicao'])."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                $qualE = "relationships";
                break;
            case "atributo":
                $sql = "UPDATE attributes SET name = '".utf8_decode($_REQUEST['nomeEdicao'])."', idPai = '".utf8_decode($_REQUEST['atributoEdicao'])."', status = '".utf8_decode($_REQUEST['statusEdicao'])."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "parametroSite":
                $sql = "UPDATE  param_sites SET name = '".utf8_decode($_REQUEST['nomeEdicao'])."', value = '".utf8_decode($_REQUEST['valorEdicao'])."', type = '".$_REQUEST['tipoEdicao']."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "parametroAdmin":
                $sql = "UPDATE  param_admins SET name = '".($_REQUEST['nomeEdicao'])."', value = '".($_REQUEST['valorEdicao'])."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "versao":
                $sql = "UPDATE versions SET name = '".($_REQUEST['nomeEdicao'])."', description = '".($_REQUEST['descricaoEdicao'])."', date = '".($_REQUEST['dataEdicao'])."'";
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "a";
                if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                    $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                    $nameImg = $_FILES['imagemEdicao']['name'];
                    $qualEdicao = "versao";
                    $tableEditar = "versions";
                }
                break;
            case "usuario":
                $sql = "UPDATE users SET name = '".($_REQUEST['nomeEdicao'])."', email = '".($_REQUEST['emailEdicao'])."'";
                if ($_REQUEST['senhaEdicao']){
                    $sql .= ", password = '".md5($_REQUEST['senhaEdicao'])."'";
                }
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                    $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                    $nameImg = $_FILES['imagemEdicao']['name'];
                    $qualEdicao = "usuarios";
                    $tableEditar = "users";
                }
                break;
            case "usuarioPre":
                $sql = "UPDATE user_pres SET name = '".($_REQUEST['nomeEdicao'])."', email = '".($_REQUEST['emailEdicao'])."'";
                if ($_REQUEST['senhaEdicao']){
                    $sql .= ", password = '".md5($_REQUEST['senhaEdicao'])."'";
                }
                $sql .= ", updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
        }
        mysqli_query($con, $sql) or die(mysqli_error($con));
        if ($qualE){
            $sql = "SELECT * FROM ".$qualE." WHERE id = '".$_REQUEST['idEdicao']."'";
            $query = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($query);
            if ($row['name']) {
                $slug = retirarAcentos($row['name']);
            }
            else{
                $slug = retirarAcentos($row['nomeAniversariante']."_".$row['dataAniversario']);
            }
            $sql = "UPDATE ".$qualE." SET slug = '". $slug."' WHERE id = '".$_REQUEST['idEdicao']."'";
            mysqli_query($con, $sql);

        }
        if ($filesImg && $qualEdicao){
            if (preg_match('/.jpg/', $nameImg) || preg_match('/.jpeg/', $nameImg)){
                $arquivo = $qualEdicao.$_REQUEST['idEdicao'].".jpg";
            }
            elseif (preg_match('/.gif/', $nameImg)){
                $arquivo = $qualEdicao.$_REQUEST['idEdicao'].".gif";
            }
            elseif (preg_match('/.png/', $nameImg)){
                $arquivo = $qualEdicao.$_REQUEST['idEdicao'].".png";
            }
            elseif (preg_match('/.bmp/', $nameImg)){
                $arquivo = $qualEdicao.$_REQUEST['idEdicao'].".bmp";
            }
            elseif (preg_match('/.svg/', $nameImg)){
                $arquivo = $qualEdicao.$_REQUEST['idEdicao'].".svg";
            }
            if ($arquivo){
                copy($filesImg, DIRETORIO."img/upload/".$arquivo);
                $sql = "UPDATE ".$tableEditar." SET img = '".$arquivo."' WHERE id = '".$_REQUEST['idEdicao']."'";
                mysqli_query($con, $sql);
                $img = URL."img/upload/".$arquivo;
            }
        }
        $action = "Atualizou ".$artigo." ".$_REQUEST['table']." ".$_REQUEST['idEdicao'];
        $sql = "INSERT INTO logs (action, user, created_at, updated_at) VALUES ('".$action."', '".$_REQUEST['idUserEdicao']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql);
        echo "1|-|".$_REQUEST['idUserEdicao']."|-|".$img;
        break;
    case "cadastrar":
        $qualE = 0;
        $filesImg = 0;
        switch ($_REQUEST['table']){
            case "statusPedido":
                $sql = utf8_decode("INSERT INTO requests_statuses (name, sigla, color, background, send_email, email, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['siglaCadastro']."', '".$_REQUEST['colorCadastro']."', '".$_REQUEST['backgroundCadastro']."', '".$_REQUEST['enviarEmailCadastro']."', '".$_REQUEST['emailCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                break;
            case "tiposDocumento":
                $sql = utf8_decode("INSERT INTO type_documents (name, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['statusCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                break;
            case "tiposProduto":
                $sql = utf8_decode("INSERT INTO types_products (name, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['statusCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                break;
            case "produto":
                $sql = utf8_decode("INSERT INTO products (name, description, status, apareceVitrine, destaque, compreAgora, freteGratis, mostraCarrinho, promocao, itemRecomendado, valorContaParaOFrete, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['descricaoCadastro']."', '".$_REQUEST['statusCadastro']."','".$_REQUEST['apareceVitrineCadastro']."', '".$_REQUEST['destaqueCadastro']."', '".$_REQUEST['compreAgoraCadastro']."', '".$_REQUEST['freteGratisCadastro']."', '".$_REQUEST['mostraCarrinhoCadastro']."', '".$_REQUEST['promocaoCadastro']."', '".$_REQUEST['itemRecomendadoCadastro']."', '".$_REQUEST['valorContaParaOFreteCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                $qualE = "products";
                break;
            case "nacionalidade":
                $sql = ("INSERT INTO nationalities (name, status, padrao, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['statusCadastro']."', '".$_REQUEST['padraoCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "a";
                break;
            case "pais":
                $sql = ("INSERT INTO countries (name, status, padrao, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['statusCadastro']."', '".$_REQUEST['padraoCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                break;
            case "imoveis":
                $sql = ("INSERT INTO properties (name, description, metragem, quartos, suites, vagas, value, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['descricaoCadastro']."', '".$_REQUEST['metragemCadastro']."', '".$_REQUEST['quartosCadastro']."', '".$_REQUEST['suitesCadastro']."', '".$_REQUEST['vagasCadastro']."', '".$_REQUEST['valorCadastro']."', '".$_REQUEST['statusCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                break;
            case "formaPagamento":
                $_REQUEST['vlParcelaMinimaCadastro'] = str_replace(".", "", $_REQUEST['vlParcelaMinimaCadastro']);
                $_REQUEST['vlParcelaMinimaCadastro'] = str_replace(",", ".", $_REQUEST['vlParcelaMinimaCadastro']);
                $sql = utf8_decode("INSERT INTO payment_methods (name, vlParcelaMinima, parcelas, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['vlParcelaMinimaCadastro']."', '".$_REQUEST['parcelasCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                if ($_FILES['imagemCadastro'] && $_FILES['imagemCadastro']['error'] == 0){
                    $filesImg = $_FILES['imagemCadastro']['tmp_name'];
                    $nameImg = $_FILES['imagemCadastro']['name'];
                    $qualEdicao = "formaPagamento";
                    $tableEditar = "payment_methods";
                }
                break;
            case "formaFrete":
                $_REQUEST['valor'] = str_replace(".", "", $_REQUEST['valor']);
                $_REQUEST['valor'] = str_replace(",", ".", $_REQUEST['valor']);
                $sql = utf8_decode("INSERT INTO shipping_methods (name, code, value, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['codigoCadastro']."', '".$_REQUEST['valorCadastro']."', '".$_REQUEST['statusCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "a";
                break;
            case "banner":
                $sql = utf8_decode("INSERT INTO banners (name, description, position, link, target, status, validade, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['descricaoCadastro']."', '".$_REQUEST['posicaoCadastro']."', '".$_REQUEST['linkCadastro']."', '".$_REQUEST['targetCadastro']."', '".$_REQUEST['statusCadastro']."', '".$_REQUEST['validadeCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                $qualE = "banners";
                if ($_FILES['imagemCadastro'] && $_FILES['imagemCadastro']['error'] == 0){
                    $filesImg = $_FILES['imagemCadastro']['tmp_name'];
                    $nameImg = $_FILES['imagemCadastro']['name'];
                    $qualEdicao = "banner";
                    $tableEditar = "banners";
                }
                break;
            case "feriados":
                $sql = utf8_decode("INSERT INTO holidays (name, date, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['dataCadastro']."', '".$_REQUEST['statusCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                break;
            case "parceiros":
                $sql = utf8_decode("INSERT INTO partners (name, description, link, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['descricaoCadastro']."', '".$_REQUEST['linkCadastro']."', '".$_REQUEST['statusCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                break;
            case "listaPresente":
                if ($_REQUEST['dataAniversarioCadastro'] >= date('Y-m-d')){
                    $_REQUEST['statusCadastro'] = 1;
                }
                else{
                    $_REQUEST['statusCadastro'] = 0;
                }
                $sql = utf8_decode("INSERT INTO presents_lists (client, nomeAniversariante, dataAniversario, nomeMae, nomePai, idade, status, cep, address, number, complement, neighborhood, city, state, created_at, updated_at) VALUES ('".$_REQUEST['clienteCadastro']."', '".$_REQUEST['nomeCadastro']."', '".$_REQUEST['dataAniversarioCadastro']."', '".$_REQUEST['nomeMaeCadastro']."', '".$_REQUEST['nomePaiCadastro']."', '".$_REQUEST['idadeCadastro']."', '".$_REQUEST['statusCadastro']."', '".$_REQUEST['cepCadastro']."', '".$_REQUEST['logradouroCadastro']."', '".$_REQUEST['numeroCadastro']."', '".$_REQUEST['complementoCadastro']."', '".$_REQUEST['bairroCadastro']."', '".$_REQUEST['cidadeCadastro']."', '".$_REQUEST['estadoCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "a";
                $qualE = "presents_lists";
                break;
            case "redesSociais":
                $sql = utf8_decode("INSERT INTO social_networks (name, description, link, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['descricaoCadastro']."', '".$_REQUEST['linkCadastro']."', '".$_REQUEST['statusCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "a";
                $qualE = "social_networks";
                if ($_FILES['imagemCadastro'] && $_FILES['imagemCadastro']['error'] == 0){
                    $filesImg = $_FILES['imagemCadastro']['tmp_name'];
                    $nameImg = $_FILES['imagemCadastro']['name'];
                    $qualEdicao = "social_network";
                    $tableEditar = "social_networks";
                }
                break;
            case "pagina":
                $sql = utf8_decode("INSERT INTO pages (name, subname, appearsMenu, appearsSite, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['subtituloCadastro']."', '".$_REQUEST['apareceMenuCadastro']."', '".$_REQUEST['apareceSiteCadastro']."', '".$_REQUEST['statusCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "a";
                $qualE = "pages";
                if ($_FILES['imagemCadastro'] && $_FILES['imagemCadastro']['error'] == 0){
                    $filesImg = $_FILES['imagemCadastro']['tmp_name'];
                    $nameImg = $_FILES['imagemCadastro']['name'];
                    $qualEdicao = "pagina";
                    $tableEditar = "pages";
                }
                break;
            case "subitem":
                $sql = utf8_decode("INSERT INTO subitems (page, name, description, subname, appearsImg, status, created_at, updated_at) VALUES ('".$_REQUEST['paginaCadastro']."', '".$_REQUEST['nomeCadastro']."', '".$_REQUEST['descricaoCadastro']."', '".$_REQUEST['subtituloCadastro']."', '".$_REQUEST['mostraImagemCadastro']."', '".$_REQUEST['statusCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "a";
                $qualE = "subitems";
                if ($_FILES['imagemCadastro'] && $_FILES['imagemCadastro']['error'] == 0){
                    $filesImg = $_FILES['imagemCadastro']['tmp_name'];
                    $nameImg = $_FILES['imagemCadastro']['name'];
                    $qualEdicao = "subitem";
                    $tableEditar = "subitems";
                }
                break;
            case "tipoServico":
                $sql = utf8_decode("INSERT INTO types_services (name, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['statusCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                break;
            case "prioridade":
                $sql = utf8_decode("INSERT INTO priorities (name, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['statusCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "a";
                break;
            case "tipoVersao":
                $sql = utf8_decode("INSERT INTO type_versions (name, typeService, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['tipoServicoCadastro']."', '".$_REQUEST['statusCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                break;
            case "departamento":
                $sql = utf8_decode("INSERT INTO departaments (name, idPai, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['departamentoCadastro']."', '".$_REQUEST['statusCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                $qualE = DB_PREFIX."departaments";
                $idCadastro = mysqli_insert_id($con);
                break;
            case "atributos":
                $sql = utf8_decode("INSERT INTO attributes (name, idPai, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['atributoCadastro']."', '".$_REQUEST['statusCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                $idCadastro = mysqli_insert_id($con);
                break;
            case "marcas":
                $sql = utf8_decode("INSERT INTO brands (name, description, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['descricaoCadastro']."', '".$_REQUEST['statusCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "a";
                $qualE = "brands";
                if ($_FILES['imagemCadastro'] && $_FILES['imagemCadastro']['error'] == 0){
                    $filesImg = $_FILES['imagemCadastro']['tmp_name'];
                    $nameImg = $_FILES['imagemCadastro']['name'];
                    $qualEdicao = "marca";
                    $tableEditar = "brands";
                }
                break;
            case "selos":
                $sql = utf8_decode("INSERT INTO stamps (name, description, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['descricaoCadastro']."', '".$_REQUEST['statusCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                $qualE = "selos";
                if ($_FILES['imagemCadastro'] && $_FILES['imagemCadastro']['error'] == 0){
                    $filesImg = $_FILES['imagemCadastro']['tmp_name'];
                    $nameImg = $_FILES['imagemCadastro']['name'];
                    $qualEdicao = "selo";
                    $tableEditar = "stamps";
                }
                break;
            case "sugestoes":
                $sql = utf8_decode("INSERT INTO suggestions (name, description, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['descricaoCadastro']."', '".$_REQUEST['statusCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "a";
                $qualE = "suggestions";
                if ($_FILES['imagemCadastro'] && $_FILES['imagemCadastro']['error'] == 0){
                    $filesImg = $_FILES['imagemCadastro']['tmp_name'];
                    $nameImg = $_FILES['imagemCadastro']['name'];
                    $qualEdicao = "sugestao";
                    $tableEditar = "suggestions";
                }
                break;
            case "relacionamentos":
                $sql = utf8_decode("INSERT INTO relationships (name, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['statusCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                $qualE = "relationships";
                $idCadastro = mysqli_insert_id($con);
                break;
            case "cupomDesconto":
                $_REQUEST['valorCadastro'] = str_replace('.', '', $_REQUEST['valorCadastro']);
                $_REQUEST['valorCadastro'] = str_replace(',', '.', $_REQUEST['valorCadastro']);
                $sql = utf8_decode("INSERT INTO coupon_discounts (codigo, valor, tipo,  validade, utilizavel, created_at, updated_at) VALUES ('".$_REQUEST['codigoCadastro']."', '".$_REQUEST['valorCadastro']."', '".$_REQUEST['tipoCadastro']."', '".$_REQUEST['validadeCadastro']."', '".$_REQUEST['utilizavelCadastro']."',  '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                break;
            case "parametroSite":
                $sql = utf8_decode("INSERT INTO param_sites (name, value, type, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['valorCadastro']."', '".$_REQUEST['tipoCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                break;
            case "parametroAdmin":
                $sql = ("INSERT INTO  param_admins (name, value, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['valorCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                break;
            case "versao":
                $sql = utf8_decode("INSERT INTO versions (name, description, date, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['descricaoCadastro']."', '".($_REQUEST['dataCadastro'])."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "a";
                if ($_FILES['imagemCadastro'] && $_FILES['imagemCadastro']['error'] == 0){
                    $filesImg = $_FILES['imagemCadastro']['tmp_name'];
                    $nameImg = $_FILES['imagemCadastro']['name'];
                    $qualEdicao = "versao";
                    $tableEditar = "versions";
                }
                break;
            case "usuarios":
                $sql = ("INSERT INTO users (name, email, password, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['emailCadastro']."', '".md5($_REQUEST['senhaCadastro'])."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                if ($_FILES['imagemCadastro'] && $_FILES['imagemCadastro']['error'] == 0){
                    $filesImg = $_FILES['imagemCadastro']['tmp_name'];
                    $nameImg = $_FILES['imagemCadastro']['name'];
                    $qualEdicao = "usuario";
                    $tableEditar = "users";
                }
                break;
            case "tipoModulo":
                $sql = ("INSERT INTO type_modules (name, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['statusCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                break;
            case "modulo":
                $sql = ("INSERT INTO modules (typeModule, name, slug, status, created_at, updated_at) VALUES ('".$_REQUEST['tipoModuloCadastro']."', '".$_REQUEST['nomeCadastro']."', '".$_REQUEST['urlAmigavelCadastro']."', '".$_REQUEST['statusCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $artigo = "o";
                break;
        }
        mysqli_query($con, $sql) or die(mysqli_error($con));
        $_REQUEST['idCadastro'] = mysqli_insert_id($con);
        if ($qualE){
            $sql = "SELECT * FROM ".$qualE." WHERE id = '".$_REQUEST['idCadastro']."'";
            $query = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($query);
            if ($row['name']) {
                $slug = retirarAcentos($row['name']);
            }
            else{
                $slug = retirarAcentos($row['nomeAniversariante']."_".$row['dataAniversario']);
            }
            $sql = "UPDATE ".$qualE." SET slug = '". $slug."' WHERE id = '".$_REQUEST['idCadastro']."'";
            mysqli_query($con, $sql);
        }
        if ($filesImg && $qualEdicao){
            if (preg_match('/.jpg/', $nameImg) || preg_match('/.jpeg/', $nameImg)){
                $arquivo = $qualEdicao.$_REQUEST['idCadastro'].".jpg";
            }
            elseif (preg_match('/.gif/', $nameImg)){
                $arquivo = $qualEdicao.$_REQUEST['idCadastro'].".gif";
            }
            elseif (preg_match('/.png/', $nameImg)){
                $arquivo = $qualEdicao.$_REQUEST['idCadastro'].".png";
            }
            elseif (preg_match('/.bmp/', $nameImg)){
                $arquivo = $qualEdicao.$_REQUEST['idCadastro'].".bmp";
            }
            elseif (preg_match('/.svg/', $nameImg)){
                $arquivo = $quaclEdicao.$_REQUEST['idCadastro'].".svg";
            }
            if ($arquivo){
                copy($filesImg, DIRETORIO."img/upload/".$arquivo);
                $sql = "UPDATE ".$tableEditar." SET img = '".$arquivo."' WHERE id = '".$_REQUEST['idCadastro']."'";
                mysqli_query($con, $sql);
            }
        }
        $action = "Cadastrou ".$artigo." ".$_REQUEST['table']." ".$_REQUEST['idCadastro'];
        $sql = "INSERT INTO logs (action, user, created_at, updated_at) VALUES ('".$action."', '".$_REQUEST['idUserCadastro']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "visualizar":
        switch ($_REQUEST['table']){
            case "pedido":
                $sql = "SELECT a.*, c.name AS nomeStatus, c.id AS idStatus, d.type_person, d.email, e.name, e.cpf, e.rg, e.cel, e.dtNasc, g.razaoSocial, g.nomeFantasia, g.contato, g.cnpj, g.ie, g.im, g.dataAbertura, g.cel AS cel2, g.telefone, i.codigo, i.tipo, i.valor, i.validade, j.code, j.value AS valorVale, j.validade AS validade2, k.name AS nacionalidade, l.name AS nacionalidadeEmpresa
                FROM requests a
                INNER JOIN requests_statuses c ON (a.status = c.id)
                INNER JOIN clients d ON (a.client = d.id)
                LEFT JOIN pessoa_fisicas e ON (d.id = e.client)
                LEFT JOIN pessoa_juridicas g ON (d.id = g.client)
                LEFT JOIN coupon_discounts i ON (a.discount = i.id)
                LEFT JOIN vales j ON (a.vale = j.id)
                LEFT JOIN nationalities k ON (e.nationality = k.id)
                LEFT JOIN nationalities l ON (g.nationality = l.id)
                WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode('-', $row['dtNasc']);
                $row['dtNasc'] = $vet[2]."/".$vet[1]."/".$vet[0];
                $vet = explode('-', $row['dataAbertura']);
                $row['dataAbertura'] = $vet[2]."/".$vet[1]."/".$vet[0];
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|<h5>".utf8_decode("Dados do Orçamento")." ".sprintf("%06s\n", $row[0])."</h5>".utf8_decode("Número do Orçamento:")." <b>".sprintf("%06s\n", $row[0])."</b><br>".utf8_decode("Data do Orçamento").": <b>".$row['created_at']."</b><br>".utf8_decode("Status do Orçamento").": <b>".$row['nomeStatus']."</b><br>");
                $sql = "SELECT * FROM requests_items WHERE request = '".$row[0]."'";
                $query = mysqli_query($con, $sql);
                $totalItens = mysqli_num_rows($query);
                echo "<h5>Dados do";
                if ($totalItens > 1){
                    echo 's';
                }
                echo " Produto";
                if ($totalItens > 1){
                    echo 's';
                }
                echo "</h5>
                     <table width='100%' cellpadding='0' cellspacing='0' border='0'>
                        <tr>
                            <th width='23%'>Nome do Produto</th>
                            <th width='23%'>Valor do Produto</th>
                            <th width='23%'>Quant.</th>
                            <th width='23%'>Valor Total</th>
                            <th width='8%'>&nbsp;</th>
                        </tr>
                        ";
                while ($rowItens = mysqli_fetch_array($query)){
                    $lista = $rowItens['lista'];
                    echo "<tr";
                if ($i % 2 == 0){
                    echo " style='background-color:#F7F7F7'";
                }
                echo ">
                            <td>".utf8_encode($rowItens['name']);
                    echo "</td>
                            <td>R$ ".number_format($rowItens['value'], 2, ',', '.')."</td>
                            <td>".$rowItens['quantity']."</td>
                            <td>R$ ".number_format($rowItens['value'] * $rowItens['quantity'], 2, ',', '.')."</td>
                            <td>";
                    if ($rowItens['vale']){
                        echo "<img src='" . URL . "img/visualizar.svg' width='20' title='Visualizar Vale' style='cursor:pointer' onclick=visualizarVale('" . $rowItens['vale'] . "','" . URL . "')><div id='vale' style='position:absolute; display:none; width:495px; height:390px; background-color:#FFFFFF; border:1px solid #E7E7E7; border-radius:15px;'>Oi</div>";
                    }
                    echo "</td>
                         </tr>";
                    $i++;
                    $total += $rowItens['value'] * $rowItens['quantity'];
                }
                echo "<tr>
                            <td colspan='4' style='text-align:right'>Total Carrinho: <b>R$ ".number_format($total, 2, ',','.')."</b></td>
                      </tr>
                      <tr>
                            <td colspan='4' style='text-align:right'>Cupom de Desconto: <b style='#003300'>- R$ ".number_format($row['valueDiscount'], 2, ',','.')."</b> ";
                if ($row['discount']) {
                    echo "<img src='" . URL . "img/informacao.png' width='20' style='cursor:pointer' onclick='abreFecha(\"informacoesCupomDesconto\")'><div id='informacoesCupomDesconto' style='display:none; position:absolute; border:1px solid #e7e7e7; background-color:#FFFFFF; text-align:left; width:100%; border-radius:15px'><div style='position:absolute; float:left; left:95%; cursor:pointer' onclick='fecha(\"informacoesCupomDesconto\")'>&times;</div><h3>Informações do Cupom de Desconto</h3>ID do Cupom: <b>".$row['discount'];
                    echo "</b><br>Código do Cupom: <b>" . $row['codigo'];
                    if ($row['tipo'] == 1){
                        $valorCupom = "R$ ".number_format($row['valor'], 2,',','.');
                    }
                    else{
                        $valorCupom = $row['valor']."%";
                    }
                    $vet = explode('-', $row['validade']);
                    $row['validade'] = $vet[2]."/".$vet[1]."/".$vet[0];
                    echo "</b><br>Valor do Cupom: <b>" . $valorCupom . "</b><br>Validade do Cupom: <b>".$row['validade']."</b></div>";
                    $total += $row['valor'];
                }
                if ($row['vale']) {
                    echo "<img src='" . URL . "img/informacao.png' width='20' style='cursor:pointer' onclick='abreFecha(\"informacoesValePresente\")'><div id='informacoesValePresente' style='display:none; position:absolute; border:1px solid #e7e7e7; background-color:#FFFFFF; text-align:left; width:100%; border-radius:15px'><div style='position:absolute; float:left; left:95%; cursor:pointer' onclick='fecha(\"informacoesValePresente\")'>&times;</div><h3>Informações do Vale Presente</h3>ID do Vale: <b>".$row['vale'];
                    echo "</b><br>Código do Vale: <b>" . $row['code'];
                    $valorCupom = "R$ ".number_format($row['valorVale'], 2,',','.');
                    $vet = explode('-', $row['validade2']);
                    $row['validade'] = $vet[2]."/".$vet[1]."/".$vet[0];
                    echo "</b><br>Valor do Vale: <b>" . $valorCupom . "</b><br>Validade do Vale: <b>".$row['validade']."</b></div>";
                    $total += $row['valorVale'];
                }
                      echo "</td>
                      </tr>
                      <tr>
                            <td colspan='4' style='text-align:right'>Total: <b style='#000033'>R$ ".number_format($total, 2, ',','.')."</b></td>
                      </tr>
                     </table>
                     <h5>Dados do Cliente</h5>
                     Email: <b>".$row['email']."</b><br>";
                if ($row['type_person'] == 'F') {
                    echo "Nome do Cliente: <b>" . ($row['name']) . "</b><br>
                    Email do Cliente: <b>" . ($row['email']) . "</b><br>
                    Telefone do Cliente: <b>" . ($row['cel']) . "</b><br>
                    CPF do Cliente: <b>" . ($row['cpf']) . "</b><br>
                    RG do Cliente: <b>" . ($row['rg']) . "</b><br>
                    Data de Nascimento do Cliente: <b>" . ($row['dtNasc']) . "</b>";
                }
                else{
                    echo "Razão Social: <b>".$row['razaoSocial']."</b><br>
                    Nome Fantasia: <b>".$row['nomeFantasia']."</b><br>
                    Nome do Contato: <b>".$row['contato']."</b><br>
                    CNPJ: <b>".$row['cnpj']."</b><br>
                    Inscrição Estadual: <b>".$row['ie']."</b><br>
                    Inscrição Municipal: <b>".$row['im']."</b><br>
                    Data de Abertura da Empresa: <b>".$row['dataAbertura']."</b><br>
                    Telefone da Empresa: <b>".$row['telefone']."</b><br>
                    Celular da Empresa: <b>".$row['cel2']."</b>";
                }
                echo "<h5>Dados do Endereço à Retirar o Orçamento</h5>
                <p>Imprima e leve este comprovante até a nossa loja, no endereço abaixo, para retirar os seus produtos.</p>";
                echo utf8_encode("<b>".$parametrosSite['endereco1']."<br>".$parametrosSite['endereco2']."<br>".$parametrosSite['endereco3']."</b>
                <hr noshade><center><a href='".URL."imprimirComprovante/".base64_encode($row['id'])."' target='_blank'><img src='".URL."img/imprimir.png' height='35'> Imprimir Comprovante</a></center><hr noshade>");
                $artigo = "o";
                break;
            case "listaPresente":
                $sql = "SELECT a.*, b.name, c.nomeFantasia, c.contato FROM presents_lists a LEFT JOIN pessoa_fisicas b ON (a.client = b.client) LEFT JOIN pessoa_juridicas c ON (a.client = c.client) WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode('-', $row['validade']);
                $row['validade'] = utf8_decode($vet[2]."/".$vet[1]."/".$vet[0]);
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode('-', $row['dataAniversario']);
                $row['dataAniversario'] = $vet[2]."/".$vet[1]."/".$vet[0];
                $nomeCliente = ($row['name']) ? $row['name'] : $row['nomeFantasia']." - ".$row['contato'];
                echo "1|-|Nome do Cliente: <b>".utf8_encode($nomeCliente."</b><br>Nome do(a) Aniversariante: <b>".$row['nomeAniversariante']."</b><br>".utf8_decode("Data do Aniversário").": <b>".$row['dataAniversario']."</b><br>".utf8_decode("Nome da Mãe").": <b>".$row['nomeMae']."</b><br>".utf8_decode("Nome do Pai").": <b>".$row['nomePai']."</b><br>".utf8_decode("Idade que vai completar").": <b>".$row['idade']."</b><br>".utf8_decode("CEP").": <b>".$row['cep']."</b><br>".utf8_decode("Endereço").": <b>".$row['address'].", ".$row['number']);
                if ($row['complement']){
                    echo utf8_encode(', '.$row['complement']);
                }
                echo utf8_encode("</b><br>Bairro: <b>".$row['neighborhood']."</b><br>Cidade: <b>".$row['city']."</b><br>Estado: <b>".$row['state']."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "presentes":
                echo "1|-|<div id='registroExcluidoComSucessoListasPresentes' style='position:absolute; display:none; background-color:#FF0000; color:#FFFFFF; text-align:center; border-radius:15px; z-index:9999999'><h3>Registro Excluído Com Sucesso</h3></div><div id='visualizacaoPresente' style='display:none; position:absolute; width:100%; border:1px solid #e7e7e7; background-color:#FFFFFF; border-radius:15px;'><div style='position:absolute; float:left; left:95%; cursor:pointer;' onclick=fecha('visualizacaoPresente')>&times;</div></div><div id='addPresente' style='display:none; position:absolute; width:100%; border:1px solid #e7e7e7; background-color:#FFFFFF; border-radius:15px;'><div style='position:absolute; float:left; left:95%; cursor:pointer;' onclick=fecha('addPresente')>&times;</div><h3 style='text-align:center'>Adicionar Presente</h3><label for='produtoPresenteAdd'>Produto: </label><select name='produtoPresenteAdd' id='produtoPresenteAdd' class='form-control' onchange=selecionaProdutoPresente(this.value,'".URL."')>
                        <option value=''>Selecione o produto corretamente...</option>
                        ";
                $sql = "SELECT * FROM products WHERE status = '1'";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)){
                    while ($row = mysqli_fetch_array($query)){
                        echo "<option value='".$row['id']."'>".utf8_encode($row['name'])."</option>";
                    }
                }
                echo "</select><div id='itensProduto'></div><input type='hidden' name='listaPresenteAdd' id='listaPresenteAdd' value='".$_REQUEST['id']."'><div style='text-align: right'><button class='btn btn-primary' onclick=adicionarPresente('".URL."','".$_SESSION['user']['id']."')>Adicionar</button> <button class='btn btn-secondary' onclick=fecha('addPresente')>Fechar</button></div></div><div id='editaPresente' style='display:none; position:absolute; width:100%; border:1px solid #e7e7e7; background-color:#FFFFFF; border-radius:15px;'><div style='position:absolute; float:left; left:95%; cursor:pointer;' onclick=fecha('editaPresente')>&times;</div><h3 style='text-align:center'>Editar Presente</h3><label for='produtoPresenteEdita'>Produto: </label><select name='produtoPresenteEdita' id='produtoPresenteEdita' class='form-control' onchange=selecionaProdutoPresenteEdita(this.value,'".URL."')>
                        <option value=''>Selecione o produto corretamente...</option>
                        ";
                $sql = "SELECT * FROM products WHERE status = '1'";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)){
                    while ($row = mysqli_fetch_array($query)){
                        echo "<option value='".$row['id']."'>".utf8_encode($row['name'])."</option>";
                    }
                }
				$sql = "SELECT * FROM presents_lists WHERE id = '".$_REQUEST['id']."' AND status = '1'";
				$query = mysqli_query($con, $sql);
				$totLista = mysqli_num_rows($query);
                echo "</select><div id='itensProdutoEdita'></div><input type='hidden' name='listaPresenteEdita' id='listaPresenteEdita' value='".$_REQUEST['id']."'><div style='text-align: right'><button class='btn btn-primary' onclick=atualizarPresente('".URL."','".$_SESSION['user']['id']."')>Atualizar</button> <button class='btn btn-secondary' onclick=fecha('editaPresente')>Fechar</button><input type='hidden' name='idPresenteEdita' id='idPresenteEdita' value=''></div></div>";
				if ($totLista){
					echo "<div style='text-align:right'><button class='btn btn-primary' onclick='addPresente()'>Adicionar Novo</button></div>";
                }
				$sql = "SELECT a.*, b.name as nomeProduto, c.name as nomeItem, c.value, c.promotion, c.validity_promotion FROM presents_lists_products a INNER JOIN products b ON (a.product = b.id) INNER JOIN products_items c ON (a.product_item = c.id) WHERE a.lista = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                if(mysqli_num_rows($query)){
                    echo "<table width='100%' border='0' cellpadding='0' cellspacing='0'><tr><th style='padding:5px; text-align:center'>Nome do Produto</th><th style='padding:5px; text-align:center'>Valor do Produto</th><th style='padding:5px; text-align:center'>Pediu</th><th style='padding:5px; text-align:center'>Ganhou</th><th style='padding:5px; text-align:center'>Ações</th></tr>";
                    $i = 0;
                    while ($row = mysqli_fetch_array($query)){
                        $valor = ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')) ? $row['promotion'] : $row['value'];
                        echo "<tr><td style='padding:5px; text-align:center;";
                        if ($i % 2 == 0){
                            echo " background-color:#e7e7e7";
                        }
                        echo "'>".utf8_encode($row['nomeProduto']." - ".$row['nomeItem'])."</td><td style='padding:5px;; text-align:center;";
                        if ($i % 2 == 0){
                            echo " background-color:#e7e7e7";
                        }
                        echo "'>R$ ".number_format($valor, 2, ',', '.')."</td><td style='padding:5px;; text-align:center;";
                        if ($i % 2 == 0){
                            echo " background-color:#e7e7e7";
                        }
                        echo "'>".$row['quantity']."</td><td style='padding:5px;; text-align:center;";
                        if ($i % 2 == 0){
                            echo " background-color:#e7e7e7";
                        }
                        echo "'>".$row['ganhou']."</td><td style='padding:5px; text-align:center;";
                        if ($i % 2 == 0){
                            echo " background-color:#e7e7e7";
                        }
                        echo "'>";
						if ($totLista){
							echo "<img src='".URL."img/editar.png' width='20' style='cursor:pointer' onclick=editaPresente('".$row['id']."','".URL."','".$_SESSION['user']['id']."')> <img src='".URL."img/excluir.png' width='20' style='cursor:pointer' onclick=excluirPresente('".$row['id']."','".URL."','".$_SESSION['user']['id']."','o','presente','".$row['lista']."')>";
                        }
						echo "</td></tr>";
						$i++;
                    }
                    echo "</table>";
                }
                else{
                    echo "<div style='text-align:center'><button class='btn btn-danger'>Nenhum presente encontrado até o momento!</button></div>";
                }
                $artigo = "o";
                break;
            case "convidados":
				$sql = "SELECT * FROM presents_lists WHERE id = '".$_REQUEST['id']."' AND status = '1'";
				$query = mysqli_query($con, $sql);
				$totLista = mysqli_num_rows($query);
                echo "1|-|<div id='registroExcluidoComSucessoListasPresentes' style='position:absolute; display:none; background-color:#FF0000; color:#FFFFFF; text-align:center; border-radius:15px; z-index:9999999'><h3>Registro Excluído Com Sucesso</h3></div><div id='visualizacaoConvidado' style='display:none; position:absolute; width:100%; border:1px solid #e7e7e7; background-color:#FFFFFF; border-radius:15px;'><div style='position:absolute; float:left; left:95%; cursor:pointer;' onclick=fecha('addConvidado')>&times;</div></div><div id='addConvidado' style='display:none; position:absolute; width:100%; border:1px solid #e7e7e7; background-color:#FFFFFF; border-radius:15px;'><div style='position:absolute; float:left; left:95%; cursor:pointer;' onclick=fecha('addConvidado')>&times;</div><h3 style='text-align:center'>Adicionar Convidado</h3><label for='nomeConvidadoAdd'>Nome: </label><input type='text' name='nomeConvidadoAdd' id='nomeConvidadoAdd' class='form-control' value=''><label for='emailConvidadoAdd'>Email: </label><input type='email' name='emailConvidadoAdd' id='emailConvidadoAdd' class='form-control' value=''><label for='celConvidadoAdd'>Celular: </label><input type='text' name='celConvidadoAdd' id='celConvidadoAdd' maxlength='14' onkeyup=formataCampo(this,'(##)#####-####',event) class='form-control' value=''><input type='hidden' name='listaConvidadoAdd' id='listaConvidadoAdd' value='".$_REQUEST['id']."'><div style='text-align: right'><button class='btn btn-primary' onclick=adicionarConvidado('".URL."','".$_SESSION['user']['id']."')>Adicionar</button> <button class='btn btn-secondary' onclick=fecha('addConvidado')>Fechar</button></div></div><div id='editaConvidado' style='display:none; position:absolute; width:100%; border:1px solid #e7e7e7; background-color:#FFFFFF; border-radius:15px;'><div style='position:absolute; float:left; left:95%; cursor:pointer;' onclick=fecha('editaConvidado')>&times;</div><h3 style='text-align:center'>Editar Convidado</h3><label for='nomeConvidadoEdita'>Nome: </label><input type='text' name='nomeConvidadoEdita' id='nomeConvidadoEdita' class='form-control' value=''><label for='emailConvidadoEdita'>Email: </label><input type='email' name='emailConvidadoEdita' id='emailConvidadoEdita' class='form-control' value=''><label for='celConvidadoEdita'>Celular: </label><input type='text' name='celConvidadoEdita' id='celConvidadoEdita' maxlength='14' onkeyup=formataCampo(this,'(##)#####-####',event) class='form-control' value=''><input type='hidden' name='listaConvidadoEdita' id='listaConvidadoEdita' value='".$_REQUEST['id']."'><input type='hidden' name='idConvidadoEdita' id='idConvidadoEdita' value=''><div style='text-align: right'><button class='btn btn-primary' onclick=atualizarConvidado('".URL."','".$_SESSION['user']['id']."')>Editar</button> <button class='btn btn-secondary' onclick=fecha('editaConvidado')>Fechar</button></div></div>";
				if ($totLista){
					echo "<div style='text-align:right'><button class='btn btn-primary' onclick=addConvidado()>Adicionar Novo</button><button class='btn btn-warning' onclick=enviarTodosNaoEnviados('".$_REQUEST['id']."','".URL."','".$_SESSION['user']['id']."')>Enviar a Todos Não Enviados</button></div>";
                }
				$sql = "SELECT a.* FROM presents_lists_guests a WHERE a.lista = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                if(mysqli_num_rows($query)){
                    echo "<table width='100%' border='0' cellpadding='0' cellspacing='0'><tr><th style='padding:5px; text-align:center'>Nome</th><th style='padding:5px; text-align:center'>Email</th><th style='padding:5px; text-align:center'>Celular</th><th style='padding:5px; text-align:center'>Ações</th></tr>";
                    $i = 0;
                    while ($row = mysqli_fetch_array($query)){
                        echo "<tr><td style='padding:5px; text-align:center; font-size:14px;";
                        if ($i % 2 == 0){
                            echo " background-color:#e7e7e7";
                        }
                        echo "'>".($row['name'])."</td><td style='padding:5px;; text-align:center; font-size:14px;";
                        if ($i % 2 == 0){
                            echo " background-color:#e7e7e7";
                        }
                        echo "'>".utf8_encode($row['email'])."</td><td style='padding:5px;; text-align:center; font-size:14px;";
                        if ($i % 2 == 0){
                            echo " background-color:#e7e7e7";
                        }
                        echo "'>".$row['cel']."</td><td style='padding:5px; text-align:center;";
                        if ($i % 2 == 0){
                            echo " background-color:#e7e7e7";
                        }
                        echo "'>";
						if ($totLista){
							echo "<img src='".URL."img/enviarEmail.png' width='20' style='cursor:pointer' onclick=enviarEmailConvidado('".$row['id']."','".URL."','".$_SESSION['user']['id']."','".$_REQUEST['id']."')>";
						}
						echo "<img src='".URL."img/visualizar.svg' width='20' style='cursor:pointer' onclick=visualizarConvidado('".$row['id']."','".URL."','".$_SESSION['user']['id']."')>";
						if ($totLista){
							echo "<img src='".URL."img/editar.png' width='20' style='cursor:pointer' onclick=editaConvidado('".$row['id']."','".URL."','".$_SESSION['user']['id']."')><img src='".URL."img/excluir.png' width='20' style='cursor:pointer' onclick=excluirConvidado('".$row['id']."','".URL."','".$_SESSION['user']['id']."','o','convidado','".$_REQUEST['id']."')>";
						}
						echo "</td></tr>";
                        $i++;
                    }
                    echo "</table>";
                }
                else{
                    echo "<div style='text-align:center'><button class='btn btn-danger'>Nenhum convidado encontrado até o momento!</button></div>";
                }
                $artigo = "o";
                break;
            case "cupomDesconto":
                $sql = "SELECT * FROM coupon_discounts WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode('-', $row['validade']);
                $row['validade'] = utf8_decode($vet[2]."/".$vet[1]."/".$vet[0]);
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if ($row['tipo'] == 1){
                    $tipo = "Valor";
                    $valor = "R$".number_format($row['valor'], 2, ',', '.');
                }
                elseif ($row['tipo'] == 2){
                    $tipo = "Percentual";
                    $valor = $row['valor']."%";
                }
                if ($row['utilizavel'] == 1){
                    $utilizavel = "Uma vez por cliente";
                }
                elseif ($row['utilizavel'] == 2){
                    $utilizavel = utf8_decode("Várias vezes por cliente");
                }
                echo "1|-|Código: <b>".utf8_encode($row['codigo']."</b><br>Tipo: <b>".$tipo."</b><br>Valor: <b>".$valor."</b><br>Validade: <b>".$row['validade']."</b><br>".utf8_decode("Utilização: ")."<b>".$utilizavel."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "valePresente":
                $sql = "SELECT * FROM vales WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode('-', $row['validade']);
                $row['validade'] = utf8_decode($vet[2]."/".$vet[1]."/".$vet[0]);
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $valor = "R$".number_format($row['value'], 2, ',', '.');
                echo "1|-|Código: <b>".utf8_encode($row['code']."</b><br>Valor: <b>".$valor."</b><br>Validade: <b>".$row['validade']."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "newsletter":
                $sql = "SELECT * FROM newsletters WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>Email: <b>".$row['email']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "a";
                break;
            case "bugTracking":
                $sql = "SELECT a.*, b.name AS nomeTipoServico , c.name AS nomeTipoVersao , d.name AS nomePrioridade, e.name AS nomeCategoria FROM bug_trackings a INNER JOIN types_services b ON (a.typeService = b.id) INNER JOIN type_versions c ON (a.typeVersion = c.id) INNER JOIN priorities d ON (a.priority = d.id) INNER JOIN categories e ON (a.category = e.id) WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#FFFF00'>Enviado</span>" : "<span style='color:#000033'>Respondido</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>Email: <b>".$row['email']."</b><br>".utf8_decode("Título").": <b>".$row['title']."</b><br>".utf8_decode("Tipo de Serviço").": <b>".$row['nomeTipoServico']."</b><br>".utf8_decode("Versão").": <b>".$row['nomeTipoVersao']."</b><br>".utf8_decode("Prioridade").": <b>".$row['nomePrioridade']."</b><br>".utf8_decode("Categoria").": <b>".$row['nomeCategoria']."</b><br>".utf8_decode("Mensagem").": <b>".nl2br($row['message'])."</b><br>Status: <b>".$status."</b>");
                if ($row['status'] == 2){
                    echo utf8_encode('<br>Resposta: <b>'.nl2br($row['answer']).'</b>');
                }
                echo utf8_encode("<br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "faleConosco":
                $sql = "SELECT a.* FROM messages a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#FFFF00'>Enviado</span>" : "<span style='color:#000033'>Respondido</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>Email: <b>".$row['email']."</b><br>".utf8_decode("Assunto").": <b>".$row['subject']."</b><br>".utf8_decode("Telefone").": <b>".$row['phone']."</b><br>".utf8_decode("Mensagem").": <b>".nl2br($row['text'])."</b><br>Status: <b>".$status."</b>");
                if ($row['status'] == 2){
                    echo utf8_encode('<br>Resposta: <b>'.nl2br($row['answer']).'</b>');
                }
                echo utf8_encode("<br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "anuncie":
                $sql = "SELECT a.*, b.name AS nomeTempo FROM anuncie_aqui a INNER JOIN banners_type b ON (a.tipo_banner = b.id) WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                if (file_exists(DIRETORIO."img/upload/anuncieAqui".$row['id'].".jpg")){
                    $img = URL."img/upload/anuncieAqui".$row['id'].".jpg";
                }
                elseif (file_exists(DIRETORIO."img/upload/anuncieAqui".$row['id'].".gif")){
                    $img = URL."img/upload/anuncieAqui".$row['id'].".gif";
                }
                elseif (file_exists(DIRETORIO."img/upload/anuncieAqui".$row['id'].".png")){
                    $img = URL."img/upload/anuncieAqui".$row['id'].".png";
                }
                elseif (file_exists(DIRETORIO."img/upload/anuncieAqui".$row['id'].".bmp")){
                    $img = URL."img/upload/anuncieAqui".$row['id'].".bmp";
                }
                elseif (file_exists(DIRETORIO."img/upload/anuncieAqui".$row['id'].".webp")){
                    $img = URL."img/upload/anuncieAqui".$row['id'].".webp";
                }
                $status = ($row['status'] == 1) ? "<span style='color:#FFFF00'>Enviado</span>" : "<span style='color:#000033'>Respondido</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>Email: <b>".$row['email']."</b><br>".utf8_decode("Assunto").": <b>".$row['subject']."</b><br>".utf8_decode("Telefone").": <b>".$row['phone']."</b><br>".utf8_decode("Mensagem").": <b>".nl2br($row['text'])."</b><br>Status: <b>".$status."</b>");
                if ($row['status'] == 2){
                    echo utf8_encode('<br>Resposta: <b>'.nl2br($row['answer']).'</b>');
                }
                if ($img){
                    echo "<br>Banner: <img src='".$img."' width='100%'>";
                }
                echo utf8_encode("<br>Nome do Banner: <b>".$row['nome_banner']."</b><br>Link do Banner: <b>".$row['link_banner']."</b><br>Target do Banner: <b>");
                if ($row['target_banner'] == "_parent"){
                    echo "Na mesma página";
                }
                else{
                    echo "Em nova Página";
                }
                echo "</b><br>Posição do Banner: <b>";
                if ($row['posicao_banner'] == "1"){
                    echo "Banner Lateral";
                }
                else{
                    echo "Banner Meio Página";
                }
                echo "</b><br>Tempo do Banner: <b>";
                echo utf8_encode($row['nomeTempo']."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "statusPedido":
                $sql = "SELECT a.* FROM requests_statuses a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $enviarEmail = ($row['send_email'] == 1) ? "<span style='color:#000033'>Sim</span>" : "<span style='color:#FF0000'>Não</span>";
                $displayEmail = ($row['send_email'] == 1) ? "" : "none";
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>Sigla: <b>".$row['sigla']."</b><br>Cor da Fonte: <b><span style='width:50px; height:20px; background-color:".$row['color']."; border:1px solid #000000;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></b><br>Cor do Background: <b><span style='width:50px; height:20px; background-color:".$row['background']."; border:1px solid #000000;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></b><br>Enviar Email: <b>".utf8_decode($enviarEmail)."</b><br><div style='display:".$displayEmail."'>Email: ".nl2br($row['email'])."</div>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "tiposDocumento":
                $sql = "SELECT a.* FROM type_documents a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "clientes":
                $sql = "SELECT a.*, b.name, b.cpf, b.rg, b.dtNasc, b.cel, c.razaoSocial, c.nomeFantasia, c.contato, c.cnpj, c.ie, c.im, c.dataAbertura, c.cel AS celular, c.telefone, d.name AS nacionalidade, e.name AS nacionalidadeEmpresa FROM clients a LEFT JOIN pessoa_fisicas b ON (a.id = b.client) LEFT JOIN pessoa_juridicas c ON (a.id = c.client) LEFT JOIN nationalities d ON (b.nationality = d.id) LEFT JOIN nationalities e ON (c.nationality = e.id) WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet2 = explode('-', $row['dtNasc']);
                $row['dtNasc'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]);
                $vet2 = explode('-', $row['dataAbertura']);
                $row['dataAbertura'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]);
                if ($row['type_person'] == 'F') {
                    echo utf8_encode("1|-|Tipo de Pessoa: <b>".utf8_decode("Física")."</b><br>Nome: <b>" . utf8_decode(($row['name'])) . "</b><br>CPF: <b>" . $row['cpf'] . "</b><br>RG: <b>" . $row['rg'] . "</b><br>Nacionalidade: <b>" . utf8_decode($row['nacionalidade']) . "</b><br>Data de Nascimento: <b>" . $row['dtNasc'] . "</b><br>Celular: <b>" . $row['cel'] . "</b><br>Email: <b>" . $row['email'] . "</b><br>Data de Cadastro: <b>" . $row['created_at'] . "</b><br>" . utf8_decode("Data de Atualização") . ": <b>" . $row['updated_at'] . "</b>");
                }
                else{
                    echo utf8_encode("1|-|Tipo de Pessoa: <b>".utf8_decode("Jurídica")."</b><br>".utf8_decode("Razão Social").": <b>" . utf8_decode($row['razaoSocial']) . "</b><br>Nome Fantasia: <b>" . utf8_decode($row['nomeFantasia']) . "</b><br>Nome do Contato: <b>" . utf8_decode($row['contato']) . "</b><br>CNPJ: <b>" . $row['cnpj'] . "</b><br>".utf8_decode("Inscrição Estadual").": <b>" . $row['ie'] . "</b><br>".utf8_decode("Inscrição Municipal").": <b>" . $row['im'] . "</b><br>Nacionalidade da Empresa: <b>".utf8_decode($row['nacionalidadeEmpresa'])."</b><br>Data de Abertura: <b>" . $row['dataAbertura'] . "</b><br>Telefone: <b>" . $row['telefone'] . "</b><br>Celular: <b>" . $row['celular'] . "</b><br>Email: <b>" . $row['email'] . "</b><br>Data de Cadastro: <b>" . $row['created_at'] . "</b><br>" . utf8_decode("Data de Atualização") . ": <b>" . $row['updated_at'] . "</b>");
                }
                $artigo = "o";
                break;
            case "tiposProduto":
                $sql = "SELECT a.* FROM types_products a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "produto":
                $sql = "SELECT a.* FROM products a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if (!file_exists(DIRETORIO."img/upload/".$row['img']) || !$row['img']){
                    $row['img'] = URL."img/noFoto1.gif";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>".utf8_decode("Descrição").": <b>".$row['description']."</b><br>");
                if ($excluirImg) {
                    echo "Imagem: <img src='" . $row['img'] . "' width='150'><input type='button' value='Excluir Imagem' class='btn btn-danger' onclick=excluirImg('produto','" . $row['id'] . "','" . URL . "','" . $_REQUEST['idUser'] . "','o')><br>";
                }
                echo utf8_encode("Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "comentarioProduto":
                $sql = "SELECT a.*, b.name AS nomeProduto FROM products_reviews a INNER JOIN products b ON (a.product = b.id) WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Aprovado</span>" : "<span style='color:#FF0000'>Não Aprovado</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: do Comentarista <b>".utf8_encode($row['nome'])."</b><br>Email: <b>".$row['email']."</b><br>".("Avaliação").": <b>");
                for ($i = 1; $i <= $row['avaliacao']; $i++){
                    echo "<img src='".URL."img/star.png' title='Avaliação: ".$row['avaliacao']."'>";
                }
                if ($row['avaliacao'] < 5){
                    for ($i = $row['avaliacao'] + 1; $i <= 5; $i++){
                        echo "<img src='".URL."img/starApagada.png' title='Avaliação: ".$row['avaliacao']."'>";
                    }
                }
                echo ("</b><br>".("Comentário").": <b>".str_replace("\r\n", "<br>", utf8_encode($row['mensagem']))."</b><br>");
                echo ("Status: <b>".($status)."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "formaPagamento":
                $sql = "SELECT a.* FROM payment_methods a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if (!file_exists(DIRETORIO."img/upload/".$row['img']) || !$row['img']){
                    $row['img'] = URL."img/noFoto1.gif";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>".utf8_decode("Valor da Parcela Mínima").": <b>R$ ".number_format($row['vlParcelaMinima'], 2, ',', '.')."</b><br>Parcelas: <b>".$row['parcelas']."</b><br>");
                if ($excluirImg) {
                    echo "Imagem: <img src='" . $row['img'] . "' width='150'><input type='button' value='Excluir Imagem' class='btn btn-danger' onclick=excluirImg('formaPagamento','" . $row['id'] . "','" . URL . "','" . $_REQUEST['idUser'] . "','a')><br>";
                }
                echo utf8_encode("Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "a";
                break;
            case "formaFrete":
                $sql = "SELECT a.* FROM shipping_methods a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativa</span>" : "<span style='color:#FF0000'>Inativa</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>".utf8_decode("Valor Adicional").": <b>R$ ".number_format($row['value'], 2, ',', '.')."</b><br>".utf8_decode("Código").": <b>".$row['code']."</b><br>Status: <b>".$status."</b><br>");
                echo utf8_encode("Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "a";
                break;
            case "banner":
                $sql = "SELECT a.* FROM banners a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if (!file_exists(DIRETORIO."img/upload/".$row['img']) || !$row['img']){
                    $row['img'] = URL."img/noFoto1.gif";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                if ($row['position'] == 1){
                    $row['position'] = "Banner Lateral";
                }
                elseif ($row['position'] == 2){
                    $row['position'] = "Banner Meio da Página";
                }
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>".utf8_decode("Descrição").": <b>".$row['description']."</b><br>".utf8_decode('Posição: '."<b>".$row['position'])."</b><br>");
                if ($excluirImg) {
                    echo "Imagem: <img src='" . $row['img'] . "' width='150'><input type='button' value='Excluir Imagem' class='btn btn-danger' onclick=excluirImg('banner','" . $row['id'] . "','" . URL . "','" . $_REQUEST['idUser'] . "','o')><br>";
                }
                if ($row['link']){
                    echo "Link: <b><a href='".$row['link']."' target='_blank'>".$row['link']."</a></b><br>";
                }
                if ($row['target']){
                    if ($row['target'] == "_blank"){
                        $row['target'] = "Em uma nova aba";
                    }
                    else{
                        $row['target'] = "Na mesma janela";
                    }
                    echo "Abertura do Link: <b>".$row['target']."</b><br>";
                }
                $vet1 = explode('-', $row['validade']);
                $row['validade'] = $vet1[2]."/".$vet1[1]."/".$vet1[0];
                echo "Validade do Banner: <b>".$row['validade']."</b><br>";
                echo "Exibições".utf8_encode(": <b>".$row['exibitions']."</b><br>Cliques: <b>".$row['clicks']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "feriados":
                $sql = "SELECT a.* FROM holidays a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode('-', $row['date']);
                $row['date'] = utf8_decode($vet[2]."/".$vet[1]."/".$vet[0]);
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>".utf8_decode("Data").": <b>".$row['date']."</b><br>");
                echo utf8_encode("Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "parceiros":
                $sql = "SELECT a.* FROM partners a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>".utf8_decode("Descrição").": <b>".$row['description']."</b><br>".utf8_decode("Link").": <b>".$row['link']."</b><br>".utf8_decode("Cliques").": <b>".$row['cliques']."</b><br>");
                echo utf8_encode("Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "nacionalidade":
                $sql = "SELECT a.* FROM nationalities a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".$row['name']."</b><br>");
                echo utf8_encode("Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "a";
                break;
            case "pais":
                $sql = "SELECT a.* FROM countries a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".$row['name']."</b><br>");
                echo utf8_encode("Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "redesSociais":
                $sql = "SELECT a.* FROM social_networks a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if (!file_exists(DIRETORIO."img/upload/".$row['img']) || !$row['img']){
                    $row['img'] = URL."img/noFoto1.gif";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                if ($row['position'] == 1){
                    $row['position'] = "Banner Topo";
                }
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>".utf8_decode("Descrição").": <b>".$row['description']."</b><br>".utf8_decode('Link: ')."<b>".$row['link']."</b><br>");
                if ($excluirImg) {
                    echo "Imagem: <img src='" . $row['img'] . "' width='150'><input type='button' value='Excluir Imagem' class='btn btn-danger' onclick=excluirImg('social_network','" . $row['id'] . "','" . URL . "','" . $_REQUEST['idUser'] . "','a')><br>";
                }
                echo utf8_encode("Cliques: <b>".$row['cliques']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "marcas":
                $sql = "SELECT a.* FROM brands a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if (!file_exists(DIRETORIO."img/upload/".$row['img']) || !$row['img']){
                    $row['img'] = URL."img/noFoto1.gif";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                if ($row['position'] == 1){
                    $row['position'] = "Banner Topo";
                }
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>".utf8_decode("Descrição").": <b>".$row['description']."</b><br>");
                if ($excluirImg) {
                    echo "Imagem: <img src='" . $row['img'] . "' width='150'><input type='button' value='Excluir Imagem' class='btn btn-danger' onclick=excluirImg('banner','" . $row['id'] . "','" . URL . "','" . $_REQUEST['idUser'] . "','o')><br>";
                }
                echo utf8_encode("Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "a";
                break;
            case "selos":
                $sql = "SELECT a.* FROM stamps a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if (!file_exists(DIRETORIO."img/upload/".$row['img']) || !$row['img']){
                    $row['img'] = URL."img/noFoto1.gif";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>".utf8_decode("Descrição").": <b>".$row['description']."</b><br>");
                if ($excluirImg) {
                    echo "Imagem: <img src='" . $row['img'] . "' width='150'><input type='button' value='Excluir Imagem' class='btn btn-danger' onclick=excluirImg('selo','" . $row['id'] . "','" . URL . "','" . $_REQUEST['idUser'] . "','o')><br>";
                }
                echo utf8_encode("Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "sugestoes":
                $sql = "SELECT a.* FROM suggestions a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if (!file_exists(DIRETORIO."img/upload/".$row['img']) || !$row['img']){
                    $row['img'] = URL."img/noFoto1.gif";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>".utf8_decode("Descrição").": <b>".$row['description']."</b><br>");
                if ($excluirImg) {
                    echo "Imagem: <img src='" . $row['img'] . "' width='150'><input type='button' value='Excluir Imagem' class='btn btn-danger' onclick=excluirImg('selo','" . $row['id'] . "','" . URL . "','" . $_REQUEST['idUser'] . "','o')><br>";
                }
                echo utf8_encode("Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "a";
                break;
            case "pagina":
                $sql = "SELECT a.* FROM pages a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
				$sql = "SELECT * FROM pages_descriptions WHERE page = '".$_REQUEST['id']."' ORDER BY num ASC";
				$query2 = mysqli_query($con, $sql);
				if (mysqli_num_rows($query2)){
					while ($row2 = mysqli_fetch_array($query2)){
						$descricao[$row2['num']] = $row2['text'];
					}
				}
                $apareceMenu = ($row['appearsMenu'] == 1) ? "<span style='color:#000033'>Sim</span>" : "<span style='color:#FF0000'>Não</span>" ;
                $apareceSite = ($row['appearsSite'] == 1) ? "<span style='color:#000033'>Sim</span>" : "<span style='color:#FF0000'>Não</span>" ;
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if (!file_exists(DIRETORIO."img/upload/".$row['img']) || !$row['img']){
                    $row['img'] = URL."img/noFoto1.gif";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                if ($row['position'] == 1){
                    $row['position'] = "Banner Topo";
                }
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>".utf8_decode("Subtítulo").": <b>".$row['subname']."</b><br>");
                if ($excluirImg) {
                    echo "Imagem: <img src='" . $row['img'] . "' width='150'><input type='button' value='Excluir Imagem' class='btn btn-danger' onclick=excluirImg('pagina','" . $row['id'] . "','" . URL . "','" . $_REQUEST['idUser'] . "','a')><br>";
                }
                echo utf8_encode("Aparece no Menu: <b>".utf8_decode($apareceMenu)."</b><br>Aparece no Site: <b>".utf8_decode($apareceSite)."</b><br>Status: <b>".$status."</b><br>");
				$i = 1;
				if (count($descricao)){
					foreach ($descricao as $key => $value){
						echo "Descrição ".$i.": <b>".utf8_encode($value)."</b><br>";
						$i++;
					}
				}
				echo utf8_encode("Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "a";
                break;
            case "convidado":
                $sql = "SELECT a.* FROM presents_lists_guests a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if ($row['send_email_at']) {
                    $vet = explode(' ', $row['send_email_at']);
                    $vet2 = explode('-', $vet[0]);
                    $row['send_email_at'] = ($vet2[2] . "/" . $vet2[1] . "/" . $vet2[0] . " às " . $vet[1] . "h");
                }
                else{
                    $row['send_email_at'] = "Não enviado";
                }
                echo "1|-|<div style='position:absolute; float:left; left:95%; cursor:pointer;' onclick=$('#visualizacaoConvidado').hide('fast')>&times</div><h3>Visualização de Convidado</h3>Nome: <b>".$row['name']."</b><br>".("Email").": <b>".$row['email']."</b><br>".("Celular").": <b>".$row['cel']."</b><br>";
                echo "Email enviado em: <b>".$row['send_email_at']."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b><div style='text-align:right'><button class='btn btn-secondary' onclick=fecha('visualizacaoConvidado')>Fechar</div>";
                $artigo = "o";
                break;
            case "subitem":
                $sql = "SELECT a.*, b.name AS nomePagina FROM subitems a INNER JOIN pages b ON (a.page = b.id) WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $apareceImagem = ($row['appearsImg'] == 1) ? "<span style='color:#000033'>Sim</span>" : "<span style='color:#FF0000'>Não</span>";
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if (!file_exists(DIRETORIO."img/upload/".$row['img']) || !$row['img']){
                    $row['img'] = URL."img/noFoto1.gif";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                if ($row['position'] == 1){
                    $row['position'] = "Banner Topo";
                }
                echo utf8_encode("1|-|".utf8_decode("Página").": <b>".$row['nomePagina']."</b><br>Nome: <b>".$row['name']."</b><br>".utf8_decode("Subtítulo").": <b>".$row['subname']."</b><br>".utf8_decode("Descrição").": <b>".$row['description']."</b><br>");
                if ($excluirImg) {
                    echo "Imagem: <img src='" . $row['img'] . "' width='150'><input type='button' value='Excluir Imagem' class='btn btn-danger' onclick=excluirImg('subitem','" . $row['id'] . "','" . URL . "','" . $_REQUEST['idUser'] . "','o')><br>";
                }
                echo utf8_encode("Aparece Imagem no ".utf8_decode("Subítem").": <b>".utf8_decode($apareceImagem)."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "tipoServico":
                $sql = "SELECT a.* FROM types_services a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "tipoModulo":
                $sql = "SELECT a.* FROM type_modules a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "modulo":
                $sql = "SELECT a.*, b.name AS nomeTipoModulo FROM modules a INNER JOIN type_modules b ON (a.typeModule = b.id) WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|".utf8_decode("Nome do Tipo Módulo").": <b>".$row['nomeTipoModulo']."</b><br>Nome: <b>".$row['name']."</b><br>".utf8_decode("Url Amigável").": <b>".$row['slug']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "prioridade":
                $sql = "SELECT a.* FROM priorities a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "a";
                break;
            case "tipoVersao":
                $sql = "SELECT a.*, b.name AS nomeTipoServico FROM type_versions a INNER JOIN types_services b ON (a.typeService = b.id) WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|".utf8_decode("Nome do Tipo de Serviço").": <b>".$row['nomeTipoServico']."</b><br>Nome: <b>".$row['name']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "departamentos":
                $sql = "SELECT a.* FROM departaments a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                if ($row['idPai']){
                    $sql = "SELECT a.* FROM departaments a WHERE a.id = '".$row['idPai']."'";
                    $query = mysqli_query($con, $sql);
                    $row2 = mysqli_fetch_array($query);
                }
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|Nome: <b>");
                if ($row2['name']){
                    echo utf8_encode($row2['name']." - ");
                }
                echo utf8_encode($row['name']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "parametroSite":
                $sql = "SELECT a.* FROM param_sites a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>Valor: <b>".$row['value']."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "departamentos":
                $sql = "SELECT a.* FROM departaments a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                if ($row['idPai']){
                    $sql = "SELECT a.* FROM departaments a WHERE a.id = '".$row['idPai']."'";
                    $query = mysqli_query($con, $sql);
                    $row2 = mysqli_fetch_array($query);
                }
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|Nome: <b>");
                if ($row2['name']){
                    echo utf8_encode($row2['name']." - ");
                }
                echo utf8_encode($row['name']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "atributos":
                $sql = "SELECT a.* FROM attributes a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                if ($row['idPai']){
                    $sql = "SELECT a.* FROM attributes a WHERE a.id = '".$row['idPai']."'";
                    $query = mysqli_query($con, $sql);
                    $row2 = mysqli_fetch_array($query);
                }
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|Nome: <b>");
                if ($row2['name']){
                    echo utf8_encode($row2['name']." - ");
                }
                echo utf8_encode($row['name']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "relacionamentos":
                $sql = "SELECT a.* FROM relationships a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                if ($row['idPai']){
                    $sql = "SELECT a.* FROM departaments a WHERE a.id = '".$row['idPai']."'";
                    $query = mysqli_query($con, $sql);
                    $row2 = mysqli_fetch_array($query);
                }
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|Nome: <b>");
                if ($row2['name']){
                    echo utf8_encode($row2['name']." - ");
                }
                echo utf8_encode($row['name']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "parametroSite":
                $sql = "SELECT a.* FROM param_sites a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>Valor: <b>".$row['value']."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "parametroAdmin":
                $sql = "SELECT a.* FROM  param_admins a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Valor: <b>".$row['value']."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "versao":
                $sql = "SELECT a.* FROM versions a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                if (!file_exists(DIRETORIO."img/upload/".$row['img'])){
                    $row['img'] = URL."img/noFotoUsuario.png";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode('-', $row['date']);
                $row['data'] = $vet[2]."/".$vet[1]."/".$vet[0];
                echo utf8_encode("1|-|Nome: <b>".$row['name']."</b><br>".utf8_decode("Descrição")." <b>".$row['description']."</b><br>Data: <b>".$row['data']."</b><br>");
                if ($excluirImg) {
                    echo "Imagem: <img src='" . $row['img'] . "' width='150'><input type='button' value='Excluir Imagem' class='btn btn-danger' onclick=excluirImg('versao','" . $row['id'] . "','" . URL . "','" . $_REQUEST['idUser'] . "','a')><br>";
                }
                echo utf8_encode("Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "usuarios":
                $sql = "SELECT a.* FROM users a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if (!$row['img'] || !file_exists(DIRETORIO."img/upload/".$row['img'])){
                    $row['img'] = URL."img/user-avatar.svg";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Email: <b>".$row['email']."</b><br>Foto: <img src='");
                if ($excluirImg){
                    echo $row['img'];
                    echo "' width='100'> <a class='btn btn-primary' style='color:#FFFFFF' onclick=excluirImg('usuarios','".$row['id']."','".URL."','".$_SESSION['user']['id']."','a');>Excluir Foto</a><br>";
                }
                else{
                    echo URL."img/noFotoUsuario.png' width='100'><br>";
                }
                echo utf8_encode("Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "usuariosPre":
                $sql = "SELECT a.* FROM user_pres a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Email: <b>".$row['email']."</b><br>");
                echo utf8_encode("Data de Cadastro: <b>".$row['created_at']."</b><br>".utf8_decode("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
        }
        $action = "Visualizou ".$artigo." ".$_REQUEST['table']." ".$_REQUEST['id'];
        $sql = "INSERT INTO logs (action, user, created_at, updated_at) VALUES ('".$action."', '".$_REQUEST['idUser']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql);
        break;
     case 'excluirImg':
        unlink(DIRETORIO."img/upload/".$_REQUEST['table'].$_REQUEST['id'].".jpg");
        unlink(DIRETORIO."img/upload/".$_REQUEST['table'].$_REQUEST['id'].".gif");
        unlink(DIRETORIO."img/upload/".$_REQUEST['table'].$_REQUEST['id'].".png");
        unlink(DIRETORIO."img/upload/".$_REQUEST['table'].$_REQUEST['id'].".bmp");
        unlink(DIRETORIO."img/upload/".$_REQUEST['table'].$_REQUEST['id'].".svg");
        if ($_REQUEST['table'] == 'usuarios'){
            $table = "usuario";
        }
        elseif ($_REQUEST['table'] == 'produto'){
            $table = "produto";
        }
        elseif ($_REQUEST['table'] == 'formaPagamento'){
            $table = "forma de pagamento";
        }
        elseif ($_REQUEST['table'] == 'banner'){
            $table = "banner";
        }
        elseif ($_REQUEST['table'] == 'pagina'){
            $table = "página";
        }
        elseif ($_REQUEST['table'] == 'subitem'){
            $table = "subitem";
        }
        elseif ($_REQUEST['table'] == 'versao'){
            $table = "versao";
        }
        elseif ($_REQUEST['table'] == 'usuario'){
            $table = "usuario";
        }
        elseif ($_REQUEST['table'] == 'selo'){
            $table = "selo";
        }
        elseif ($_REQUEST['table'] == 'social_network'){
            $table = "rede social";
        }
        $action = "Excluiu a imagem d".$_REQUEST['artigo']." ".$table." ".$_REQUEST['id'];
        $sql = "INSERT INTO logs (action, user, created_at, updated_at) VALUES ('".$action."', '".$_REQUEST['idUser']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql);
        echo "1|-|".$_SESSION['user']['id']."|-|".URL."img/user-avatar.svg";
        break;
    case "selecionaCliente":
        $sql = "SELECT a.*, b.name AS nomeCliente, b.cel, b.cpf, b.rg, b.dtNasc, c.razaoSocial, c.nomeFantasia, c.contato, c.cnpj, c.ie, c.im, c.dataAbertura, c.telefone, c.cel AS cel2, d.name AS nacionalidade, e.name AS nacionalidadeEmpresa FROM clients a LEFT JOIN pessoa_fisicas b ON (a.id = b.client) LEFT JOIN pessoa_juridicas c ON (a.id = c.client) LEFT JOIN nationalities d ON (b.nationality = d.id) LEFT JOIN nationalities e ON (c.nationality = e.id) WHERE a.id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $vet = explode('-', $row['dtNasc']);
        $row['dtNasc'] = $vet[2]."/".$vet[1]."/".$vet[0];
        $vet = explode('-', $row['dataAbertura']);
        $row['dataAbertura'] = $vet[2]."/".$vet[1]."/".$vet[0];
        if ($row['type_person'] == 'F') {
            $html = "Nome do Cliente: <b>" . ($row['nomeCliente']) . "</b><br>
                Email do Cliente: <b>" . ($row['email']) . "</b><br>
                Telefone do Cliente: <b>" . ($row['cel']) . "</b><br>
                CPF do Cliente: <b>" . ($row['cpf']) . "</b><br>
                RG do Cliente: <b>" . ($row['rg']) . "</b><br>
                Nacionalidade do Cliente: <b>" . ($row['nacionalidade']) . "</b><br>
                Data de Nascimento do Cliente: <b>" . ($row['dtNasc']) . "</b>";
        }
        else{
            $html = "Razão Social: <b>".$row['razaoSocial']."</b><br>
                Nome Fantasia: <b>" . ($row['nomeFantasia']) . "</b><br>
                Nome do Contato: <b>" . ($row['contato']) . "</b><br>
                Email: <b>" . ($row['email']) . "</b><br>
                CNPJ: <b>" . ($row['cnpj']) . "</b><br>
                Inscrição Estadual: <b>" . ($row['ie']) . "</b><br>
                Inscrição Municipal: <b>" . ($row['im']) . "</b><br>
                Nacionalidade da Empresa: <b>" . ($row['nacionalidadeEmpresa']) . "</b><br>
                Data de Abertura da Empresa: <b>" . ($row['dataAbertura']) . "</b><br>
                Telefone: <b>" . ($row['telefone']) . "</b><br>
                Celular: <b>" . ($row['cel2']) . "</b><br>";
        }
        $sql = "SELECT * FROM addresses WHERE idClient = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $html2 = "<select name='enderecoEditar' id='enderecoEditar' class='form-control' onchange='selecionaEndereco(this.value,\"".URL."\")'><option value=''>Selecione o endereço abaixo corretamente...</option>";
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                $html2 .= "<option value='".$row['id']."'>".utf8_encode($row['name'])."</option>";
            }
        }
        $html2 .= "</select><span id='dadosEndereco'>Selecione o endereco acima corretamente!</span>";
        echo "1|-|".($html)."|-|".$html2;
        break;
    case "selecionaEndereco":
        $sql = "SELECT a.*, b.name AS pais FROM addresses a LEFT JOIN countries b ON (a.country = b.id) WHERE a.id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $html = "Nome do Endereço: <b>".utf8_encode($row['name'])."</b><br>
                CEP do Endereço: <b>".utf8_encode($row['cep'])."</b><br>
                Logradouro do Endereço: <b>".utf8_encode($row['address'])."</b><br>
                Número do Endereço: <b>".utf8_encode($row['number'])."</b><br>
                Complemento do Endereço: <b>".utf8_encode($row['complement'])."</b><br>
                Bairro do Endereço: <b>".utf8_encode($row['neighborhood'])."</b><br>
                Cidade do Endereço: <b>".utf8_encode($row['city'])."</b><br>
                Estado do Endereço: <b>".utf8_encode($row['state'])."</b><br>
                País do Endereço: <b>".($row['pais'])."</b>";
        echo "1|-|".($html);
        break;
    case "visualizarVale":
        $sql = "SELECT * FROM vales WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $vet = explode('-', $row['validade']);
        $row['validade'] = $vet[2]."/".$vet[1]."/".$vet[0];
        $html = "<table border='0' style=background-image:url('".URL."img/valePresente.png');background-repeat:no-repeat;width:456px;height:314px><tr><td height='100' colspan='2'>&nbsp;</td></tr><tr><td width='40%'>&nbsp;</td><td style='color:#999999'><h5>".$parametrosSite['title']."</h5><p style='left:50%'><img src='".URL."img/logo.png' width='75'><b>R$".number_format($row['value'], 2, ',', '.')."</b><br>Válido até: <b>".$row['validade']."</b></p><h5 style='text-align:center; padding:5px; margin:none'>".$row['code']."</h5></td></tr></table><sub>* válido para utilização no site <a href='".URL."' target='_blank'>".URL."</a>. Caso seja utilizado em compra de menor valor, o desconto será do valor total da compra. Só é possível a utilização uma vez no nosso site.</sub>";
        echo "1|-|<div style='position:absolute; float:left; left:92%; cursor:pointer' onclick='fecha(\"vale\")'><img src='".URL."img/close.png' width='25'></div>".$html;
        break;
    case "pegaDados":
        switch ($_REQUEST['table']){
            case 'pedido':
                $sql = "SELECT a.*, c.name AS nomeStatus, c.id AS idStatus, d.type_person, d.email, e.name, e.cpf, e.rg, e.cel, e.dtNasc, g.razaoSocial, g.nomeFantasia, g.contato, g.cnpj, g.ie, g.im, g.dataAbertura, g.cel AS cel2, g.telefone, i.codigo, i.tipo, i.valor, i.validade, j.code, j.value AS valorVale, j.validade AS validade2, k.name AS nacionalidade, l.name AS nacionalidadeEmpresa
FROM requests a
INNER JOIN requests_statuses c ON (a.status = c.id)
INNER JOIN clients d ON (a.client = d.id)
LEFT JOIN pessoa_fisicas e ON (d.id = e.client)
LEFT JOIN pessoa_juridicas g ON (d.id = g.client)
LEFT JOIN coupon_discounts i ON (a.discount = i.id)
LEFT JOIN vales j ON (a.vale = j.id)
LEFT JOIN nationalities k ON (e.nationality = k.id)
LEFT JOIN nationalities l ON (g.nationality = l.id)
WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode('-', $row['dtNasc']);
                $row['dtNasc'] = $vet[2]."/".$vet[1]."/".$vet[0];
                $vet = explode('-', $row['dataAbertura']);
                $row['dataAbertura'] = $vet[2]."/".$vet[1]."/".$vet[0];
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = utf8_decode($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo utf8_encode("1|-|<input type='hidden' name='idEdicao' id='idEdicao' value='".$row['id']."'><input type='hidden' name='idUserEdicao' id='idUserEdicao' value='".$_REQUEST['idUser']."'><h5>Dados do ".utf8_decode("Orçamento")." ".sprintf("%06s\n", $row[0])."</h5>".utf8_decode("Número do Orçamento:")." <b>".sprintf("%06s\n", $row[0])."</b><br>Data do ".utf8_decode("Orçamento").": <b>".$row['created_at']."</b><br>Status do ".utf8_decode("Orçamento").": <b><select name='statusEditar' id='statusEditar' class='form-control' onchange='selecionaStatusPedido(this.value)' ");
                if ($row['status'] == 6 || $row['status'] == 7){
                    echo " disabled";
                }
                echo utf8_encode("><option value=''>Selecione o status do orçamento corretamente...</option>");
                $sql = "SELECT * FROM requests_statuses";
                $query2 = mysqli_query($con, $sql);
                if (mysqli_num_rows($query2)){
                    while ($row2 = mysqli_fetch_array($query2)){
                        echo "<option value='".$row2['id']."'";
                        if ($row2['id'] == $row['status']){
                            echo " selected";
                        }
                        echo ">".utf8_encode($row2['name'])."</option>";
                    }
                }
                echo "</select></b>";
                $sql = "SELECT a.*, b.peso, b.altura, b.largura, b.comprimento, b.diametro FROM requests_items a INNER JOIN products_items b ON (a.product_item = b.id) WHERE a.request = '".$row[0]."'";
                $query = mysqli_query($con, $sql);
                $totalItens = mysqli_num_rows($query);
                echo "<h5>Dados do";
                if ($totalItens > 1){
                    echo 's';
                }
                echo " Produto";
                if ($totalItens > 1){
                    echo 's';
                }
                if ($row['status'] <= 3){
                echo " <img src='".URL."img/mais.png' width='25' style='cursor:pointer' onclick=addProdutoPedido('".$row['id']."','".URL."','".$_REQUEST['idUser']."')>";
                }
                echo "<div style='border:1px solid #CCCCCC; width:100%; display:none; position:absolute; background-color: #FFFFFF; border-radius:15px; padding:5px' id='addProdutoPedido'><div style='position:absolute; float:left; left:95%'><img src='".URL."img/close.png' style='cursor:pointer' onclick=$('#addProdutoPedido').hide('fast')></div><h5>Adicionar Produto ao Pedido</h5><div id='adicionaProdutoPedido'></div></div></h5>
                     <table width='100%' cellpadding='0' cellspacing='0' border='0'>
                        <tr>
                            <th width='23%'>Nome do Produto</th>
                            <th width='23%'>Valor do Produto</th>
                            <th width='23%'>Quant.</th>
                            <th width='23%'>Valor Total</th>
                            <th width='8%'></th>
                        </tr>
                        ";
                $produtos = 0;
                $valePresentes = 0;
                $valorTotal = 0;
                while ($rowItens = mysqli_fetch_array($query)){
                    $lista = $rowItens['lista'];
                    echo "<tr";
                    if ($i % 2 == 0){
                        echo " style='background-color:#F7F7F7'";
                    }
                    echo ">
                            <td>".utf8_encode($rowItens['name']);
                    echo "</td>
                            <td>R$ ".number_format($rowItens['value'], 2, ',', '.')."</td>
                            <td>".$rowItens['quantity']."</td>
                            <td>R$ ".number_format($rowItens['value'] * $rowItens['quantity'], 2, ',', '.')."</td>
                            <td>";
                    if ($rowItens['vale']){
                        echo "<img src='" . URL . "img/visualizar.svg' width='20' title='Visualizar Vale' style='cursor:pointer' onclick=visualizarVale('" . $rowItens['vale'] . "','" . URL . "')><div id='vale' style='position:absolute; display:none; width:495px; height:390px; background-color:#FFFFFF; border:1px solid #E7E7E7; border-radius:15px;'>Oi</div>";
                    }
                    if ($row['status'] <= 3) {
                        echo "<img src='" . URL . "img/excluir.png' width='20' title='Excluir Produto' style='cursor:pointer' onclick=excluirProdutoPedido('" . $rowItens['id'] . "','" . URL . "','" . $_REQUEST['idUser'] . "','" . $_REQUEST['id'] . "')>";
                    }
                    echo "</td>
                         </tr>";
                    $i++;
                    if (!preg_match("/Vale Presente/", $rowItens['name'])){
                        $produtos++;
                        $total += $rowItens['value'] * $rowItens['quantity'];
                        $peso += $rowItens['peso'] * $rowItens['quantity'];
                        $altura += $rowItens['altura'] * $rowItens['quantity'];
                        $largura += $rowItens['largura'] * $rowItens['quantity'];
                        $comprimento += $rowItens['comprimento'] * $rowItens['quantity'];
                        $diametro += $rowItens['diametro'] * $rowItens['quantity'];
                    }
                    else{
                        $valePresentes++;
                    }
                    $valorTotal += $rowItens['value'] * $rowItens['quantity'];
                }
                echo "<tr>
                            <td colspan='4' style='text-align:right'>Total Carrinho: <b>R$ ".number_format($valorTotal, 2, ',','.')."</b></td>
                      </tr>
                      <tr>
                            <td colspan='4' style='text-align:right'>Cupom de Desconto: <b style='color:#003300' id='valorDesconto'>- R$ ".number_format($row['valueDiscount'], 2, ',','.')."</b>  ";
                if ($row['discount']) {
                    echo "<img src='" . URL . "img/informacao.png' width='20' style='cursor:pointer' onclick='abreFecha(\"informacoesCupomDesconto\")'><div id='informacoesCupomDesconto' style='display:none; position:absolute; border:1px solid #e7e7e7; background-color:#FFFFFF; text-align:left; width:100%; border-radius:15px'><div style='position:absolute; float:left; left:95%; cursor:pointer' onclick='fecha(\"informacoesCupomDesconto\")'>&times;</div><h3>Informações do Cupom de Desconto</h3>ID do Cupom: <b>".$row['discount'];
                    echo "</b><br>Código do Cupom: <b>" . $row['codigo'];
                    if ($row['tipo'] == 1){
                        $valorCupom = "R$ ".number_format($row['valor'], 2,',','.');
                    }
                    else{
                        $valorCupom = $row['valor']."%";
                    }
                    $vet = explode('-', $row['validade']);
                    $row['validade'] = $vet[2]."/".$vet[1]."/".$vet[0];
                    echo "</b><br>Valor do Cupom: <b>" . $valorCupom . "</b><br>Validade do Cupom: <b>".$row['validade']."</b></div>";
                }
                if ($row['vale']) {
                    echo "<img src='" . URL . "img/informacao.png' width='20' style='cursor:pointer' onclick='abreFecha(\"informacoesValePresente\")'><div id='informacoesValePresente' style='display:none; position:absolute; border:1px solid #e7e7e7; background-color:#FFFFFF; text-align:left; width:100%; border-radius:15px'><div style='position:absolute; float:left; left:95%; cursor:pointer' onclick='fecha(\"informacoesValePresente\")'>&times;</div><h3>Informações do Vale Presente</h3>ID do Vale: <b>".$row['vale'];
                    echo "</b><br>Código do Vale: <b>" . $row['code'];
                    $valorCupom = "R$ ".number_format($row['valorVale'], 2,',','.');
                    $vet = explode('-', $row['validade2']);
                    $row['validade'] = $vet[2]."/".$vet[1]."/".$vet[0];
                    echo "</b><br>Valor do Vale: <b>" . $valorCupom . "</b><br>Validade do Vale: <b>".$row['validade']."</b></div>";
                }
                    echo "</td>
                      </tr>
                      <tr>
                            <td colspan='4' style='text-align:right'>Total: <b style='color:#000033' id='valorTotal'>R$ ".number_format($valorTotal - $row['valueDiscount'], 2, ',','.')."</b></td>
                      </tr>
                     </table>
                     <h5>Dados do Cliente</h5>
                     <select name='clienteEditar' id='clienteEditar' class='form-control' onchange='selecionaCliente(this.value,\"".URL."\")'";
                if ($row['status'] > 3){
                    echo " disabled";
                }
                echo "><option value=''>Selecione o cliente corretamente...</option>";
                $sql = "SELECT a.*, b.name, c.nomeFantasia FROM clients a LEFT JOIN pessoa_fisicas b ON (a.id = b.client) LEFT JOIN pessoa_juridicas c ON (a.id = c.client)";
                $query2 = mysqli_query($con, $sql);
                if (mysqli_num_rows($query2)){
                    while ($row2 = mysqli_fetch_array($query2)){
                        echo "<option value='".$row2['id']."'";
                        if ($row2['id'] == $row['client']){
                            echo " selected";
                        }
                        echo '>';
                        if ($row2['name']){
                            echo ($row2['name']);
                        }
                        else{
                            echo ($row2['nomeFantasia']);
                        }
                        echo "</option>";
                    }
                }
                echo "</select>
               <span id='dadosCliente'>";
                if ($row['type_person'] == 'F'){
                    echo "Nome do Cliente: <b>".($row['name'])."</b><br>
                    Email do Cliente: <b>".($row['email'])."</b><br>
                    Telefone do Cliente: <b>".($row['cel'])."</b><br>
                    CPF do Cliente: <b>".($row['cpf'])."</b><br>
                    RG do Cliente: <b>".($row['rg'])."</b><br>
                    Nacionalidade do Cliente: <b>".($row['nacionalidade'])."</b><br>
                    Data de Nascimento do Cliente: <b>".($row['dtNasc'])."</b>";
                }
                else{
                    echo "Razão Social: <b>".$row['razaoSocial']."</b><br>
                    Nome Fantasia: <b>".($row['nomeFantasia'])."</b><br>
                    Nome do Contato: <b>".($row['contato'])."</b><br>
                    Email: <b>".($row['email'])."</b><br>
                    CNPJ: <b>".($row['cnpj'])."</b><br>
                    Inscrição Estadual: <b>".($row['ie'])."</b><br>
                    Inscrição Municipal: <b>".($row['im'])."</b><br>                    
                    Nacionalidade da Empresa: <b>".($row['nacionalidadeEmpresa'])."</b><br>
                    Data de Abertura da Empresa: <b>".($row['dataAbertura'])."</b><br>
                    Telefone: <b>".($row['telefone'])."</b><br>
                    Celular: <b>".($row['cel2'])."</b>";
                }
                echo "
                </span><h5>Mensagens ";
                if ($row['status'] <= 3){
                    echo "<img src='".URL."img/mais.png' width='25' style='cursor:pointer' onClick='abre(\"addMensagemPedido\")'>";
                }
                echo "</h5>
                <div id='addMensagemPedido' style='display:none; position:absolute; background-color:#FFFFFF; width:100%; border-radius:15px'><div style='position:absolute; float:left; left:95%; cursor:pointer' onclick='fecha(\"addMensagemPedido\")'>&times;</div><h5>Adicionar Mensagem ao Pedido</h5><div class='col-3' style='float: left; width:33%'><input type='checkbox' id='msInterna' name='mgInterna'> <label for='msInterna'>Mensagem Interna</label></div><div class='col-3' style='float: left; width:33%'><input type='checkbox' id='msExterna' name='msExterna'> <label for='msExterna'>Mensagem Externa</label></div><div class='col-3' style='float: left; width:33%'><input type='checkbox' id='msEmail' name='msEmail'> <label for='msEmail'>Mensagem de Email</label></div><br><br><br><br><label for='mensagem'>Mensagem</label><textarea class='form-control' name='mensagem' id='mensagem'></textarea><div style='text-align:right'><button class='btn btn-primary' onclick='cadastraMensagemPedido(\"".$row['id']."\",\"".URL."\")'>Cadastrar</button> <button class='btn btn-danger' onclick='fecha(\"addMensagemPedido\")'>Fechar</button></div></div>
                <div id='mensagens'>
                <h5>Mensagens Internas (vista só no admin)</h5>";
                if ($row['msInterna']){
                    echo nl2br($row['msInterna']);
                }
                else{
                    echo "<span style='color:#FF0000; font-weight:bold'>Sem nenhuma mensagem encontrada!</span>";
                }
                echo "<h5>Mensagens Externas (vista no admin e por usuário)</h5>";
                if ($row['msExterna']){
                    echo nl2br($row['msExterna']);
                }
                else{
                    echo "<span style='color:#FF0000; font-weight:bold'>Sem nenhuma mensagem encontrada!</span>";
                }
                echo "<h5>Mensagens de Email</h5>";
                if ($row['msEmail']){
                    echo nl2br($row['msEmail']);
                }
                else{
                    echo "<span style='color:#FF0000; font-weight:bold'>Sem nenhuma mensagem encontrada!</span>";
                }
                echo "</div><h5>Dados do Endereço à Retirar o Orçamento</h5>
                <p>Imprima e leve este comprovante até a nossa loja, no endereço abaixo, para retirar os seus produtos.</p>
                <b>".utf8_encode($parametrosSite['endereco1']."<br>".$parametrosSite['endereco2']."<br>".$parametrosSite['endereco3'])."</b>";
                $artigo = "o";
                break;
            case 'imovel':
                $sql = "SELECT * FROM properties WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $sql = "SELECT * FROM properties_addresses WHERE property = '".$row['id']."'";
                $query2 = mysqli_query($con, $sql);
                $row2 = mysqli_fetch_array($query2);
                echo "1|-|".$row['id']."|-|".$row['name']."|-|".$row['description']."|-|".number_format($row['value'], 2, ',','.')."|-|".$row['status']."|-|".$row2['zip']."|-|".$row2['address']."|-|".$row2['number']."|-|".$row2['complement']."|-|".$row2['neighborhood']."|-|".$row2['city']."|-|".$row2['state']."|-|".$row['metragem']."|-|".$row['quartos']."|-|".$row['suites']."|-|".$row['vagas']."|-|".URL."paginas/imagensImovel.php?idImovel=".$row['id']."|-|".$row['banheiros'];
                break;
            case 'newsletter':
                $sql = "SELECT * FROM newsletters WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".$row['email']."|-|".$row['status']);
                break;
            case 'presentes':
                $sql = "SELECT * FROM presents_lists_products WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['product']."|-|".$row['product_item']."|-|".$row['quantity']."|-|".$row['id']);
                break;
            case 'convidados':
                $sql = "SELECT * FROM presents_lists_guests WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['name']."|-|".$row['email']."|-|".$row['cel']."|-|".$row['id']);
                break;
            case 'listaPresente':
                $sql = "SELECT * FROM presents_lists WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['nomeAniversariante']."|-|".$row['client']."|-|".$row['dataAniversario']."|-|".$row['nomeMae']."|-|".$row['nomePai']."|-|".$row['idade']."|-|".$row['cep']."|-|".$row['address']."|-|".$row['number']."|-|".$row['complement']."|-|".$row['neighborhood']."|-|".$row['city']."|-|".$row['state']);
                break;
            case 'comentarioProduto':
                $sql = "SELECT * FROM products_reviews WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['nome']."|-|".$row['status']."|-|".$row['email']."|-|".$row['avaliacao']."|-|".($row['mensagem']));
                break;
            case 'solicitacaoComentario':
                $sql = "SELECT * FROM products_reviews_solicitas WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['nome']."|-|".$row['status']."|-|".$row['email']."|-|".$row['avaliacao']."|-|".($row['mensagem']));
                break;
            case 'cupomDesconto':
                $sql = "SELECT * FROM coupon_discounts WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                if ($row['tipo'] == 1){
                    $row['valor'] = number_format($row['valor'], 2, ',', '.');
                }
                echo utf8_encode("1|-|".$row['id']."|-|".$row['codigo']."|-|".$row['tipo']."|-|".$row['valor']."|-|".$row['validade']."|-|".$row['utilizavel']);
                break;
            case 'valePresente':
                $sql = "SELECT * FROM vales WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $row['value'] = number_format($row['value'], 2, ',', '.');
                echo utf8_encode("1|-|".$row['id']."|-|".$row['code']."|-|".$row['value']."|-|".$row['validade']);
                break;
            case 'bugTracking':
                $sql = "SELECT * FROM bug_trackings WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".$row['email']."|-|".$row['status']."|-|".$row['title']."|-|".$row['typeService']."|-|".$row['typeVersion']."|-|".$row['priority']."|-|".$row['category']."|-|".$row['message']."|-|".$row['answer']);
                break;
            case 'faleConosco':
                $sql = "SELECT * FROM messages WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".$row['email']."|-|".$row['status']."|-|".$row['subject']."|-|".$row['phone']."|-|".$row['text']."|-|".$row['answer']);
                break;
            case 'anuncie':
                $sql = "SELECT * FROM anuncie_aqui WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".$row['email']."|-|".$row['status']."|-|".$row['subject']."|-|".$row['phone']."|-|".$row['text']."|-|".$row['answer']."|-|".$row['nome_banner']."|-|".$row['link_banner']."|-|".$row['target_banner']."|-|".$row['posicao_banner']."|-|".$row['tipo_banner']);
                break;
            case 'statusPedido':
                $sql = "SELECT * FROM requests_statuses WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['sigla']."|-|".$row['name']."|-|".$row['color']."|-|".$row['background']."|-|".$row['send_email']."|-|".$row['email']);
                break;
            case 'tipoDocumento':
                $sql = "SELECT * FROM type_documents WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']);
                break;
            case 'clientes':
                $sql = "SELECT a.*, b.name, b.cpf, b.rg, b.dtNasc, b.cel AS celular, b.nationality, c.razaoSocial, c.nomeFantasia, c.contato, c.cnpj, c.ie, c.im, c.nationality AS nacionalidadeEmpresa, c.dataAbertura, c.cel, c.telefone FROM clients a LEFT JOIN pessoa_fisicas b ON (a.id = b.client) LEFT JOIN pessoa_juridicas c ON (a.id = c.client) WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                if ($row['name']) {
                    $htmlPessoa = '<label for="nomeEdicao">Nome: </label><input type="text" name="nomeEdicao" id="nomeEdicao" class="form-control" value="'.utf8_decode($row['name']).'" required>
                                   <label for="cpfEdicao">CPF: </label><input type="text" name="cpfEdicao" id="cpfEdicao" class="form-control" value="'.$row['cpf'].'" onkeyup="formataCampo(this, \'###.###.###-##\', event)" maxlength="14" required>
                                   <label for="rgEdicao">RG: </label><input type="text" name="rgEdicao" id="rgEdicao" class="form-control" value="'.$row['rg'].'" required>
                                   <label for="nacionalidadeEdicao">Nacionalidade: </label><select name="nacionalidadeEdicao" id="nacionalidadeEdicao" class="form-control" required>
                                        <option value="">Selecione a nacionalidade corretamente...</option>';
                                   $sql = 'SELECT * FROM nationalities ORDER BY padrao DESC, name ASC';
                                   $query2 = mysqli_query($con, $sql);
                                   if (mysqli_num_rows($query2)){
                                       while ($row2 = mysqli_fetch_array($query2)){
                                           $htmlPessoa .= '<option value="'.$row2['id'].'" ';
                                           if ($row2['id'] == $row['nationality']){
                                               $htmlPessoa .= 'selected';
                                           }
                                           $htmlPessoa .= '>'.utf8_decode($row2['name']).'</option>';
                                       }
                                   }
                                   $htmlPessoa .= '</select>
                                   <label for="dtNascEdicao">Data de Nascimento: </label><input type="date" name="dtNascEdicao" id="dtNascEdicao" class="form-control" value="'.$row['dtNasc'].'" required>
                                   <label for="celEdicao">Celular: </label><input type="text" name="celEdicao" id="celEdicao" class="form-control" value="'.$row['celular'].'" onkeyup="formataCampo(this, \'(XX)XXXXX-XXXX\', event)" maxlength="14" required>';
                }
                else{
                    $htmlPessoa = '<label for="razaoSocialEdicao">'.utf8_decode("Razão Social").': </label><input type="text" name="razaoSocialEdicao" id="razaoSocialEdicao" class="form-control" value="'.utf8_decode($row['razaoSocial']).'" required>
                                   <label for="nomeFantasiaEdicao">Nome Fantasia: </label><input type="text" name="nomeFantasiaEdicao" id="nomeFantasiaEdicao" class="form-control" value="'.utf8_decode($row['nomeFantasia']).'" required>
                                   <label for="contatoEdicao">Contato: </label><input type="text" name="contatoEdicao" id="contatoEdicao" class="form-control" value="'.utf8_decode($row['contato']).'" required>
                                   <label for="cnpjEdicao">CNPJ: </label><input type="text" name="cnpjEdicao" id="cnpjEdicao" class="form-control" value="'.$row['cnpj'].'" onkeyup="formataCampo(this, \'##.###.###/####-##\', event)" maxlength="18" required>
                                   <label for="ieEdicao">'.utf8_decode("Inscrição Estadual").': </label><input type="text" name="ieEdicao" id="ieEdicao" class="form-control" value="'.$row['ie'].'" required><sup>* Informe "ISENTO" caso '.utf8_decode("não").' posssua esse dado.</sup><br>
                                   <label for="imEdicao">'.utf8_decode("Inscrição Municipal").': </label><input type="text" name="imEdicao" id="imEdicao" class="form-control" value="'.$row['im'].'" required><sup>* Informe "ISENTO" caso '.utf8_decode("não").' posssua esse dado.</sup><br>
                                   <label for="nacionalidadeEmpresaEdicao">Nacionalidade: </label>
                                   <select name="nacionalidadeEmpresaEdicao" id="nacionalidadeEmpresaEdicao" class="form-control" required>
                                        <option value="">Selecione a nacionalidade corretamente...</option>';
                                   $sql = 'SELECT * FROM nationalities ORDER BY padrao DESC, name ASC';
                                   $query2 = mysqli_query($con, $sql);
                                   if (mysqli_num_rows($query2)){
                                       while ($row2 = mysqli_fetch_array($query2)){
                                           $htmlPessoa .= '<option value="'.$row2['id'].'" ';
                                           if ($row2['id'] == $row['nacionalidadeEmpresa']){
                                               $htmlPessoa .= 'selected';
                                           }
                                           $htmlPessoa .= '>'.utf8_decode($row2['name']).'</option>';
                                       }
                                   }
                                   $htmlPessoa .= '</select>
                                   <label for="dataAberturaEdicao">Data de Abertura: </label><input type="date" name="dataAberturaEdicao" id="dataAberturaEdicao" class="form-control" value="'.$row['dataAbertura'].'" required>
                                   <label for="telefoneEdicao">Telefone: </label><input type="text" name="telefoneEdicao" id="telefoneEdicao" class="form-control" value="'.$row['telefone'].'" onkeyup="formataCampo(this, \'(XX)XXXX-XXXX\', event)" maxlength="13" required>
                                   <label for="celEdicao">Celular: </label><input type="text" name="celEdicao" id="celEdicao" class="form-control" value="'.$row['cel'].'" onkeyup="formataCampo(this, \'(XX)XXXXX-XXXX\', event)" maxlength="14" required>';
                }
                echo utf8_encode("1|-|".$row['id']."|-|".$row['email']."|-|".$row['type_person']."|-|".$htmlPessoa);
                break;
            case 'tiposProduto':
                $sql = "SELECT * FROM types_products WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']);
                break;
            case 'produto':
                $sql = "SELECT * FROM products WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $sql = "SELECT * FROM products_brands WHERE product = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row2 = mysqli_fetch_array($query);
                $sql = "SELECT a.*, b.name, b.idPai FROM products_departaments a INNER JOIN departaments b ON (a.departament = b.id) WHERE a.product = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                while ($row3 = mysqli_fetch_array($query)){
                    $productDepartament[] = $row3;
                }
                $sql = "SELECT a.* FROM departaments a";
                $query = mysqli_query($con, $sql);
                while ($row4 = mysqli_fetch_array($query)){
                    $departaments[] = $row4;
                }
                $sql = "SELECT a.* FROM products_suggestions a INNER JOIN suggestions b ON (a.suggestion = b.id) WHERE a.product = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                while ($row5 = mysqli_fetch_array($query)){
                    $products_suggestions[] = $row5;
                }
                $sql = "SELECT a.* FROM suggestions a";
                $query = mysqli_query($con, $sql);
                while ($row6 = mysqli_fetch_array($query)){
                    $suggestions[] = $row6;
                }
                $sql = "SELECT a.* FROM products_stamps a INNER JOIN stamps b ON (a.stamp = b.id) WHERE a.product = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                while ($row7 = mysqli_fetch_array($query)){
                    $products_stamps[] = $row7;
                }
                $sql = "SELECT a.* FROM products_relationships a INNER JOIN relationships b ON (a.relationship = b.id) WHERE a.product = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                while ($row8 = mysqli_fetch_array($query)){
                    $products_relationships[] = $row8;
                }
                $sql = "SELECT a.* FROM products_attributes a INNER JOIN attributes b ON (a.attribute = b.id) WHERE a.product = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                while ($row9 = mysqli_fetch_array($query)){
                    $products_attributes[] = $row9;
                }
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']."|-|".$row['description']."|-|".$row['apareceVitrine']."|-|".$row['destaque']."|-|".$row['compreAgora']."|-|".$row['freteGratis']."|-|".$row['mostraCarrinho']."|-|".$row['valorContaParaOFrete']."|-|".$row2['brand']."|-|");
                if (count($productDepartament)){
                    foreach ($productDepartament as $key => $value){
                        if ($value['idPai'] == 0) {
                            echo $value['departament']."*|*";
                        }
                    }
                }
                echo "|-|";
                if (count($productDepartament)){
                    foreach ($productDepartament as $key => $value){
                        if ($value['idPai']) {
                            echo $value['departament']."*|*";
                        }
                    }
                }
                echo "|-|";
                if (count($products_suggestions)){
                    foreach ($products_suggestions as $key => $value){
                        echo $value['suggestion']."*|*";
                    }
                }
                echo "|-|";
                if (count($products_stamps)){
                    foreach ($products_stamps as $key => $value){
                        echo $value['stamp']."*|*";
                    }
                }
                echo "|-|";
                if (count($products_relationships)){
                    foreach ($products_relationships as $key => $value){
                        echo $value['relationship']."*|*";
                    }
                }
                echo "|-|";
                if (count($products_attributes)){
                    foreach ($products_attributes as $key => $value){
                        echo $value['attribute']."*|*";
                    }
                }
                echo "|-|";
                echo URL."admin/paginas/estoqueProduto.php?idProduto=".$_REQUEST['id'];
                echo "|-|";
                echo URL."admin/paginas/imagensProduto.php?idProduto=".$_REQUEST['id'];
                echo "|-|";
                echo URL."admin/paginas/videosProduto.php?idProduto=".$_REQUEST['id']."|-|".$row['promocao']."|-|".$row['itemRecomendado'];
                break;
            case 'formaPagamento':
                $sql = "SELECT * FROM payment_methods WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".number_format($row['vlParcelaMinima'], 2, ',', '.')."|-|".$row['parcelas']);
                break;
            case 'formaFrete':
                $sql = "SELECT * FROM shipping_methods WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".number_format($row['value'], 2, ',', '.')."|-|".$row['code']."|-|".$row['status']);
                break;
            case 'banner':
                $sql = "SELECT * FROM banners WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']."|-|".$row['description']."|-|".$row['position']."|-|".$row['link']."|-|".$row['target']."|-|".$row['position']."|-|".$row['validade']);
                break;
            case 'feriados':
                $sql = "SELECT * FROM holidays WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']."|-|".$row['date']);
                break;
            case 'parceiros':
                $sql = "SELECT * FROM partners WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']."|-|".$row['description']."|-|".$row['link']."|-|".$row['cliques']);
                break;
            case 'nacionalidade':
                $sql = "SELECT * FROM nationalities WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']."|-|".$row['padrao']);
                break;
            case 'pais':
                $sql = "SELECT * FROM countries WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']."|-|".$row['padrao']);
                break;
            case 'redesSociais':
                $sql = "SELECT * FROM social_networks WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']."|-|".$row['description']."|-|".$row['link']."|-|".$row['cliques']);
                break;
            case 'marcas':
                $sql = "SELECT * FROM brands WHERE id = '".
                    $_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']."|-|".$row['description']);
                break;
            case 'selos':
                $sql = "SELECT * FROM stamps WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']."|-|".$row['description']);
                break;
            case 'sugestoes':
                $sql = "SELECT * FROM suggestions WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']."|-|".$row['description']);
                break;
            case 'pagina':
                $sql = "SELECT * FROM pages WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']."|-|".$row['description']."|-|".$row['subname']."|-|".$row['appearsMenu']."|-|".$row['appearsSite']);
                break;
            case 'pagina_description':
                $sql = "SELECT * FROM pages_descriptions WHERE page = '".$_REQUEST['id']."' ORDER BY num ASC";
                $query = mysqli_query($con, $sql);
				$total = mysqli_num_rows($query);
                while($row = mysqli_fetch_array($query)){
					$html .= "<label for='tipo".$row['num']."Edicao'>".utf8_decode("Tipo da Descrição")." ".$row['num']."</label>
					<select name='tipo".$row['num']."Edicao' id='tipo".$row['num']."Edicao' class='form-control'>
						<option value=''>Selecione o tipo abaixo corretamente...</option>
						<option value='h1' ";
					if ($row['type'] == 'h1'){
						$html .= "selected";
					}
					$html .= ">Título 1</option>
							<option value='h2' ";
					if ($row['type'] == 'h2'){
						$html .= "selected";
					}
					$html .= ">Título 2</option>
							<option value='h3' ";
					if ($row['type'] == 'h3'){
						$html .= "selected";
					}
					$html .= ">Título 3</option>
							<option value='h4' ";
					if ($row['type'] == 'h4'){
						$html .= "selected";
					}
					$html .= ">Título 4</option>
							<option value='h5' ";
					if ($row['type'] == 'h5'){
						$html .= "selected";
					}
					$html .= ">Título 5</option>
							<option value='p' ";
					if ($row['type'] == 'p'){
						$html .= "selected";
					}
					$html .= ">Parágrafo</option>
					</select>
					<label for='description".$row['num']."Edicao'>".utf8_decode("Descrição")." ".$row['num']."</label>
					<textarea name='description".$row['num']."Edicao' id='description".$row['num']."Edicao' class='form-control'>".($row['text'])."</textarea>
					<img src='".URL."img/excluir.svg' width='20' style='cursor:pointer' onclick=excluirDescricaoPagina('".$row['id']."','".$row['page']."','".URL."')><br>";
				}
				$adiciona = $total + 1;
				$html .= "<div id='addDescricaoEdicao".$adiciona."'><a style='cursor:pointer' onclick=addDescricaoEdicao('".$adiciona."','".URL."')><img src='".URL_SITE."img/plus.png' width='20'> Adicionar ".utf8_decode("Descrição")."</a></div>";
                echo utf8_encode("1|-|".$total."|-|".$html);
                break;
			case 'produto_description':
                $sql = "SELECT * FROM products_descriptions WHERE product = '".$_REQUEST['id']."' ORDER BY num ASC";
                $query = mysqli_query($con, $sql);
				$total = mysqli_num_rows($query);
                while($row = mysqli_fetch_array($query)){
					$html .= "<label for='tipo".$row['num']."Edicao'>".utf8_decode("Tipo da Descrição")." ".$row['num']."</label>
					<select name='tipo".$row['num']."Edicao' id='tipo".$row['num']."Edicao' class='form-control'>
						<option value=''>Selecione o tipo abaixo corretamente...</option>
						<option value='h1' ";
					if ($row['type'] == 'h1'){
						$html .= "selected";
					}
					$html .= utf8_decode(">Título 1</option>
							<option value='h2' ");
					if ($row['type'] == 'h2'){
						$html .= "selected";
					}
					$html .= utf8_decode(">Título 2</option>
							<option value='h3' ");
					if ($row['type'] == 'h3'){
						$html .= "selected";
					}
					$html .= utf8_decode(">Título 3</option>
							<option value='h4' ");
					if ($row['type'] == 'h4'){
						$html .= "selected";
					}
					$html .= utf8_decode(">Título 4</option>
							<option value='h5' ");
					if ($row['type'] == 'h5'){
						$html .= "selected";
					}
					$html .= utf8_decode(">Título 5</option>
							<option value='p' ");
					if ($row['type'] == 'p'){
						$html .= "selected";
					}
					$html .= utf8_decode(">Parágrafo")."</option>
					</select>
					<label for='description".$row['num']."Edicao'>".utf8_decode("Descrição")." ".$row['num']."</label>
					<textarea name='description".$row['num']."Edicao' id='description".$row['num']."Edicao' class='form-control'>".($row['text'])."</textarea>
					<img src='".URL."img/excluir.svg' width='20' style='cursor:pointer' onclick=excluirDescricaoPagina('".$row['id']."','".$row['page']."','".URL."')><br>";
				}
				$adiciona = $total + 1;
				$html .= "<div id='addDescricaoEdicao".$adiciona."'><a style='cursor:pointer' onclick=addDescricaoEdicao('".$adiciona."','".URL."')><img src='".URL_SITE."img/plus.png' width='20'> Adicionar ".utf8_decode("Descrição")."</a></div>";
                echo utf8_encode("1|-|".$total."|-|".$html);
                break;
            case 'produuto_description':
                $sql = "SELECT * FROM products_descriptions WHERE product = '".$_REQUEST['id']."' ORDER BY num ASC";
                $query = mysqli_query($con, $sql);
				$total = mysqli_num_rows($query);
                while($row = mysqli_fetch_array($query)){
					$html .= "<label for='tipo".$row['num']."Edicao'>".utf8_decode("Tipo da Descrição")." ".$row['num']."</label>
					<select name='tipo".$row['num']."Edicao' id='tipo".$row['num']."Edicao' class='form-control'>
						<option value=''>Selecione o tipo abaixo corretamente...</option>
						<option value='h1' ";
					if ($row['type'] == 'h1'){
						$html .= "selected";
					}
					$html .= ">Título 1</option>
							<option value='h2' ";
					if ($row['type'] == 'h2'){
						$html .= "selected";
					}
					$html .= ">Título 2</option>
							<option value='h3' ";
					if ($row['type'] == 'h3'){
						$html .= "selected";
					}
					$html .= ">Título 3</option>
							<option value='h4' ";
					if ($row['type'] == 'h4'){
						$html .= "selected";
					}
					$html .= ">Título 4</option>
							<option value='h5' ";
					if ($row['type'] == 'h5'){
						$html .= "selected";
					}
					$html .= ">Título 5</option>
							<option value='p' ";
					if ($row['type'] == 'p'){
						$html .= "selected";
					}
					$html .= ">Parágrafo</option>
					</select>
					<label for='description".$row['num']."Edicao'>".utf8_decode("Descrição")." ".$row['num']."</label>
					<textarea name='description".$row['num']."Edicao' id='description".$row['num']."Edicao' class='form-control'>".($row['text'])."</textarea>
					<img src='".URL."img/excluir.svg' width='20' style='cursor:pointer' onclick=excluirDescricaoPagina('".$row['id']."','".$row['page']."','".URL."')><br>";
				}
				$adiciona = $total + 1;
				$html .= "<div id='addDescricaoEdicao".$adiciona."'><a style='cursor:pointer' onclick=addDescricaoEdicao('".$adiciona."','".URL."')><img src='".URL_SITE."img/plus.png' width='20'> Adicionar ".utf8_decode("Descrição")."</a></div>";
                echo utf8_encode("1|-|".$total."|-|".$html);
                break;
            case 'subitem':
                $sql = "SELECT * FROM subitems WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']."|-|".$row['description']."|-|".$row['subname']."|-|".$row['appearsImg']."|-|".$row['page']);
                break;
            case 'tipoServico':
                $sql = "SELECT * FROM types_services WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']);
                break;
            case 'prioridade':
                $sql = "SELECT * FROM priorities WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']);
                break;
            case 'tipoVersao':
                $sql = "SELECT * FROM type_versions WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['typeService']."|-|".$row['name']."|-|".$row['status']);
                break;
            case 'departamentos':
                $sql = "SELECT * FROM departaments WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['idPai']."|-|".$row['name']."|-|".$row['status']);
                break;
            case 'relacionamentos':
                $sql = "SELECT * FROM relationships WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['idPai']."|-|".$row['name']."|-|".$row['status']);
                break;
            case 'atributo':
                $sql = "SELECT * FROM attributes WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo utf8_encode("1|-|".$row['id']."|-|".$row['idPai']."|-|".$row['name']."|-|".$row['status']);
                break;
            case 'parametroAdmin':
                $sql = "SELECT * FROM  param_admins WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['value']);
                break;
            case 'parametroSite':
                $sql = "SELECT * FROM param_sites WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
		$html .= '<label for="valorEdicao">Valor: </label>';
		if ($row['type'] == 'select'){
		    $html .= '<select name="valorEdicao" name="valorEdicao" class="form-control">
			<option value="0"';
			if (!$row['value']){
			    $html .= "selected";
			}
			$html .= '>Não</option>
			<option value="1"';
			if ($row['value'] == 1){
			    $html .= " selected";
			}
			$html .= '>Sim</option>
		    </select>';
		}
		elseif($row['type'] == 'textarea'){
		    $html .= '<textarea name="valorEdicao" id="valorEdicao" required class="form-control">'.$row['value'].'</textarea>';
		}
		else{
		    $html .= '<input type="'.$row['type'].'" class="form-control" required value="'.$row['value'].'" name="valorEdicao" id="valorEdicao">';
		}
		$row['value'] = $html;
                echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".$row['value']."|-|".$row['status']."|-|".$row['type']);
                break;
            case 'versao':
                $sql = "SELECT * FROM versions WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['description']."|-|".$row['date']);
                break;
            case 'tipoModulo':
                $sql = "SELECT * FROM type_modules WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']);
                break;
            case 'modulo':
                $sql = "SELECT * FROM modules WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']."|-|".$row['typeModule']."|-|".$row['slug']);
                break;
            case 'usuarios':
                $sql = "SELECT * FROM users WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['email']);
                break;
            case 'usuariosPre':
                $sql = "SELECT * FROM user_pres WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['email']);
                break;
        }
        break;
	case "excluirDescricaoPagina":
		$sql = "DELETE FROM pages_descriptions WHERE id = '".$_REQUEST['id']."'";
		mysqli_query($con, $sql);
		$sql = "SELECT * FROM pages_descriptions WHERE page = '".$_REQUEST['page']."' ORDER BY num ASC";
		$query = mysqli_query($con, $sql);
		$i = 1;
		$total = mysqli_num_rows($query);
		if ($total){
			while($row = mysqli_fetch_array($query)){
				$sql = "UPDATE pages_descriptions SET num = '".$i."' WHERE id = '".$row['id']."'";
				mysqli_query($con, $sql);
				$i++;
			}
			$sql = "SELECT * FROM pages_descriptions WHERE page = '".$_REQUEST['page']."' ORDER BY num ASC";
			$query = mysqli_query($con, $sql);
			while ($row = mysqli_fetch_array($query)){
				$html .= "<label for='tipo".$row['num']."Edicao'>".utf8_decode("Tipo da Descrição")." ".$row['num']."</label>
					<select name='tipo".$row['num']."Edicao' id='tipo".$row['num']."Edicao' class='form-control'>
						<option value=''>Selecione o tipo abaixo corretamente...</option>
						<option value='h1' ";
				if ($row['type'] == 'h1'){
					$html .= "selected";
				}
				$html .= ">Título 1</option>
						<option value='h2' ";
				if ($row['type'] == 'h2'){
					$html .= "selected";
				}
				$html .= ">Título 2</option>
						<option value='h3' ";
				if ($row['type'] == 'h3'){
					$html .= "selected";
				}
				$html .= ">Título 3</option>
						<option value='h4' ";
				if ($row['type'] == 'h4'){
					$html .= "selected";
				}
				$html .= ">Título 4</option>
						<option value='h5' ";
				if ($row['type'] == 'h5'){
					$html .= "selected";
				}
				$html .= ">Título 5</option>
						<option value='p' ";
				if ($row['type'] == 'p'){
					$html .= "selected";
				}
				$html .= ">Parágrafo</option>
					</select>
					<label for='description".$row['num']."Edicao'>".utf8_decode("Descrição")." ".$row['num']."</label>
					<textarea name='description".$row['num']."Edicao' id='description".$row['num']."Edicao' class='form-control'>".($row['text'])."</textarea>
					<img src='".URL."img/excluir.svg' width='20' style='cursor:pointer' onclick=excluirDescricaoPagina('".$row['id']."','".$row['page']."','".URL."')><br>";
			}
		}
		$adiciona = $total + 1;
		$html .= "<div id='addDescricaoEdicao".$adiciona."'><a style='cursor:pointer' onclick=addDescricaoEdicao('".$adiciona."','".URL."')><img src='".URL_SITE."img/plus.png' width='20'> Adicionar ".utf8_decode("Descrição")."</a></div>";
		echo utf8_encode("1|-|".$total."|-|".$html);
		break;
    case "excluir":
        if ($_REQUEST['table'] == 'pages'){
            $sql = "DELETE FROM pages_descriptions WHERE page = '".$_REQUEST['id']."'";
            mysqli_query($con, $sql) or die(mysqli_error($con));
        }
        if ($_REQUEST['table'] == 'clients'){
            $sql = "DELETE FROM pessoa_fisicas WHERE client = '".$_REQUEST['id']."'";
            mysqli_query($con, $sql) or die(mysqli_error($con));
            $sql = "DELETE FROM pessoa_juridicas WHERE client = '".$_REQUEST['id']."'";
            mysqli_query($con, $sql) or die(mysqli_error($con));
        }
        if ($_REQUEST['table'] == 'presents_lists'){
            $sql = "DELETE FROM presents_lists_products WHERE lista = '".$_REQUEST['id']."'";
            mysqli_query($con, $sql) or die(mysqli_error($con));
            $sql = "DELETE FROM presents_lists_guests WHERE lista = '".$_REQUEST['id']."'";
            mysqli_query($con, $sql) or die(mysqli_error($con));
        }
        $sql = "SELECT * FROM ".$_REQUEST['table']." WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $sql = "UPDATE ".$_REQUEST['table']." SET deleted_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        $acao = "Excluiu ".$_REQUEST['artigo']." ".$_REQUEST['tabela']." ".$_REQUEST['id'];
        $sql = "INSERT INTO logs (action, user, created_at, updated_at) VALUES ('".$acao."', '".$_REQUEST['idUser']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1";
        break;
    case "cadastrarImagem":
        $sql = "INSERT INTO properties_photos (property, name, created_at, updated_at) VALUES ('".$_REQUEST['property']."', '".$_REQUEST['name']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        $query = mysqli_query($con, $sql);
        $_REQUEST['id'] = mysqli_insert_id($con);
        if ($_FILES['imagem']['error'] == 0 && $_FILES['imagem']['tmp_name']){
            unlink(DIRETORIO."img/upload/imovel".$_REQUEST['property']."_".$_REQUEST['id'].".jpg");
            unlink(DIRETORIO."img/upload/imovel".$_REQUEST['property']."_".$_REQUEST['id'].".jpg");
            if(preg_match("/.jpg/", $_FILES['imagem']['name'])){
                $img = "imovel".$_REQUEST['product']."_".$_REQUEST['id'].".jpg";
            }
            elseif(preg_match("/.jpeg/", $_FILES['imagem']['name'])){
                $img = "imovel".$_REQUEST['property']."_".$_REQUEST['id'].".jpeg";
            }
            elseif(preg_match("/.gif/", $_FILES['imagem']['name'])){
                $img = "imovel".$_REQUEST['property']."_".$_REQUEST['id'].".gif";
            }
            elseif(preg_match("/.png/", $_FILES['imagem']['name'])){
                $img = "imovel".$_REQUEST['property']."_".$_REQUEST['id'].".png";
            }
            elseif(preg_match("/.bmp/", $_FILES['imagem']['name'])){
                $img = "imovel".$_REQUEST['property']."_".$_REQUEST['id'].".bmp";
            }
            elseif(preg_match("/.svg/", $_FILES['imagem']['name'])){
                $img = "imovel".$_REQUEST['property']."_".$_REQUEST['id'].".svg";
            }
            elseif(preg_match("/.webp/", $_FILES['imagem']['name'])){
                $img = "imovel".$_REQUEST['property']."_".$_REQUEST['id'].".webp";
            }
            if ($img) {
                copy($_FILES['imagem']['tmp_name'], DIRETORIO."img/upload/".$img);
                $sql = "UPDATE properties_photos SET img = '".$img."' WHERE id = '".$_REQUEST['id']."'";
                mysqli_query($con, $sql);
            }
        }
        echo "1";
        break;
    case "cadastrarVideo":
        $sql = "INSERT INTO products_videos (product, name, v, status, created_at, updated_at) VALUES ('".$_REQUEST['product']."', '".$_REQUEST['name']."', '".$_REQUEST['v']."', '".$_REQUEST['status']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        $query = mysqli_query($con, $sql);
        echo "1";
        break;
    case 'pegaSubs':
        $sql = "SELECT a.*, b.name AS nomeDepto FROM departaments a INNER JOIN departaments b ON (a.idPai = b.id) ";
        $query = mysqli_query($con, $sql);
        $entrou = 0;
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                $vet = explode('|-|', $_REQUEST['depto']);
                if (count($vet)){
                    foreach ($vet as $key => $value){
                        $vet2 = explode('*|*', $value);
                        if ($vet2[1] == "true"){
                            if ($vet2[0] == $row['idPai']) {
                                $entrou++;
                                $sql = "SELECT * FROM products_departaments WHERE product = '".$_REQUEST['product']."' AND departament = '".$row['id']."'";
                                $query2 = mysqli_query($con, $sql);
                                $total = mysqli_num_rows($query2);
                                $html .= '<input type="checkbox" name="subdeptoEditar' . $row['id'] . '" id="subdeptoEditar' . $row['id'] . '" ';
                                if ($total == 1){
                                    $html .= "checked";
                                }
                                $html .= '> <label for="subdeptoEditar' . $row['id'] . '">' . utf8_encode($row['nomeDepto'] . ' - ' . $row['name']) . '</label><br>';
                            }
                        }
                    }
                }
            }
        }
        if (!$entrou){
            $html = "Selecione algum departamento acima corretamente...";
        }
        echo "1|-|".$html;
        break;
	case 'aprovar':
		switch ($_REQUEST['table']){
			case "products_reviews_solicitas":
				$sql = "SELECT a.*, c.email, d.name, e.nomeFantasia, f.slug
				FROM products_reviews_solicitas a
				INNER JOIN products_reviews b ON (a.id_product_review = b.id)
				LEFT JOIN clients c ON (b.email = c.email)
				LEFT JOIN pessoa_fisicas d ON (c.id = d.client)
				LEFT JOIN pessoa_juridicas e ON (c.id = e.client)
				LEFT JOIN products f ON (b.product = f.id)
				WHERE a.id = '".$_REQUEST['id']."'";
				$query = mysqli_query($con, $sql) or die(mysqli_error($con));
				$row = mysqli_fetch_array($query);
				$sql = "UPDATE products_reviews SET avaliacao = '".$row['avaliacao']."', mensagem = '".$row['mensagem']."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$row['id_product_review']."'";
				mysqli_query($con, $sql);
				$sql = "DELETE FROM products_reviews_solicitas WHERE id = '".$_REQUEST['id']."'";
				mysqli_query($con, $sql);
				if ($row['email']){
					$nomeCliente = ($row['name']) ? $row['name'] : $row['nomeFantasia'];
					$assunto = $parametrosSite['title']." - Alteração em Comentário de Produto!";
					$htmlEmail = '<html><head><title>'.$parametrosSite['title'].' - Alteração em Comentário de Produto!</title></head><body><table border="0" width="100%" cellpadding="0" cellspacing="0"><tr><td width="200" valign="top"><img src="'.URL.'img/logo.png" width="100%"></td><td valign="top">Olá <b>'.$nomeCliente.'</b>,<br><br>Esse email é para informar que foi a alteração no comentário de um produto, foi aprovada e já está aparecendo em nosso site.<br><br>Para ver essa comentário, <a href="'.URL.'produto/'.$row['slug'].'">clique aqui</a>.<br><br>Atenciosamente,<br><br>Equipe '.$parametrosSite['title'].'</td></tr></table><hr noshade><center>Email Desenvolvido Pela <a href="https://www.bhcommerce.com.br/">BH Commerce</a></center><hr noshade></body></html>';
                    $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
                    $cabecalhoEmail .= "From: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>\nReply-To: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>";
                    mail($nomeCliente."<".$row['email'].">", $assunto, $htmlEmail, $cabecalhoEmail);
                    //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $row['email'], $nomeCliente, utf8_decode($assunto), utf8_decode($htmlEmail));
				}
				echo "1";
				break;
		}
		break;
    case 'verificaNovamente':
        $html = "";
        $totalPginacao = "";
        $paginacaoAnterior = "";
        switch ($_REQUEST['tela']) {
            case 'index':
                $sql = "SELECT * FROM requests WHERE status = '3'";
                $query = mysqli_query($con, $sql);
                $pedidosAP = mysqli_num_rows($query);;
                $sql = "SELECT * FROM newsletters WHERE deleted_at IS NULL";
                $query = mysqli_query($con, $sql);
                $newsletter = mysqli_num_rows($query);
                $sql = "SELECT * FROM messages WHERE status = '1' AND deleted_at IS NULL";
                $query = mysqli_query($con, $sql);
                $messages = mysqli_num_rows($query);
                $sql = "SELECT * FROM clients";
                $query = mysqli_query($con, $sql);
                $clients = mysqli_num_rows($query);
                $sql = "SELECT * FROM products_reviews_solicitas WHERE deleted_at IS NULL";
                $query = mysqli_query($con, $sql);
                $products_reviews_solicita = mysqli_num_rows($query);
                $sql = "SELECT * FROM counters WHERE created_at LIKE '".date('Y-m')."%' ORDER BY data DESC";
                $query = mysqli_query($con, $sql);
                $html = '
                    <div class="col-lg-3 col-3">
                        <!-- small box -->
                        <div class="small-box bg-info">
                            <div class="inner">
                                <h3>'.$pedidosAP.'</h3>

                                <p>Pedidos Aguardando Pagamento</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-edit"></i>
                            </div>
                            <a href="'.URL.'admin/listarPedidos" class="small-box-footer">Maiores Informações <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->
                    <div class="col-lg-3 col-3">
                        <!-- small box -->
                        <div class="small-box bg-success">
                            <div class="inner">
                                <h3>'.$newsletter.'</h3>

                                <p>Cadastros em Newsletter</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-stats-bars"></i>
                            </div>
                            <a href="'.URL.'admin/newsletter" class="small-box-footer">Maiores Informações <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->
                    <div class="col-lg-3 col-3">
                        <!-- small box -->
                        <div class="small-box bg-warning">
                            <div class="inner">
                                <h3>'.$clients.'</h3>

                                <p>Clientes Cadastrados</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-person-add"></i>
                            </div>
                            <a href="'.URL.'admin/clientes" class="small-box-footer">Maiores Informações <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->
                    <div class="col-lg-3 col-3">
                        <!-- small box -->
                        <div class="small-box bg-danger">
                            <div class="inner">
                                <h3>'.$messages.'</h3>

                                <p>Fale Conosco à Responder</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-pie-graph"></i>
                            </div>
                            <a href="'.URL.'admin/faleConosco" class="small-box-footer">Maiores Informações <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->
                    <div class="col-lg-3 col-3">
                        <!-- small box -->
                        <div class="small-box bg-primary">
                            <div class="inner">
                                <h3>'.$products_reviews_solicita.'</h3>
                                <p>Solicitações de Comentários de Produto à Aprovar</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-code"></i>
                            </div>
                            <a href="'.URL.'admin/solicitacaoComentario" class="small-box-footer">Maiores Informações <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>|-|
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>

                <th>Data de Acesso</th>

                <th>Quantidade de Acessos</th>

            </tr>
            </thead>
            <tbody>';
                while ($value = mysqli_fetch_object($query)) {
                    $vet = explode('-', $value->data);
                    $value->data = $vet[2]."/".$vet[1]."/".$vet[0];
                    $html .= '
                            <tr>
                            <td>'.$value->data.'</td>
                                <td>'.$value->acessos.'</td>
                            </tr>   ';
                }
                $html .= '
                            </tbody>
                        </table>';
                break;
            case 'contador':
                $sql = "SELECT * FROM counters ";
                if ($_REQUEST['dataFiltro'] && $_REQUEST['dataFimFiltro']) {
                    $sql .= "WHERE data >= '" . $_REQUEST['dataFiltro'] . "' AND data <= '".$_REQUEST['dataFimFiltro']."'";
                }
                $sql .= "ORDER BY data DESC ";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html = '
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>

                <th>Data de Acesso</th>

                <th>Quantidade de Acessos</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($counter = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td>' . date('d/m/Y', strtotime($counter->data)) . '</td>

                    <td>' . $counter->acessos . '</td>

                </tr>';
                        $key++;
                    }
                    $html .= '
            <//tbody>
        </table>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'contadorPagina':
                $sql = "SELECT a.*, b.name AS nomePagina FROM counters_pages a INNER JOIN pages b ON (a.page = b.id) ";
                if ($_REQUEST['dataFiltro'] && $_REQUEST['dataFimFiltro']) {
                    $sql .= "WHERE a.data >= '" . $_REQUEST['dataFiltro'] . "' && a.data <= '".$_REQUEST['dataFimFiltro']."' ";
                    $where = 1;
                }
                if ($_REQUEST['paginaFiltro']) {
                    if ($where) {
                        $sql .= "AND ";
                    } else {
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.page = '" . $_REQUEST['paginaFiltro'] . "' ";
                }
                $sql .= "ORDER BY a.data DESC ";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html = '<table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>

                <th>Data de Acesso</th>
                <th>Nome da Página</th>

                <th>Quantidade de Acessos</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($counter = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . date('d/m/Y', strtotime($counter->data)) . '</td>

                    <td style="padding:5px">' . utf8_encode($counter->nomePagina) . '</td>

                    <td style="padding:5px">' . $counter->acessos . '</td>

                </tr>';
                        $key++;
                    }
                    $html .= '
            </tbody>
        </table>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'contadorSubitem':
                $sql = "SELECT a.*, b.name AS nomeSubitem FROM counters_subitems a INNER JOIN subitems b ON (a.subitem = b.id) ";
                if ($_REQUEST['dataFiltro'] && $_REQUEST['dataFimFiltro']) {
                    $sql .= "WHERE a.data >= '" . $_REQUEST['dataFiltro'] . "' && a.data <= '".$_REQUEST['dataFimFiltro']."' ";
                    $where = 1;
                }
                if ($_REQUEST['subitemFiltro']) {
                    if ($where) {
                        $sql .= "AND ";
                    } else {
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.subitem = '" . $_REQUEST['subitemFiltro'] . "' ";
                }
                $sql .= "ORDER BY a.data DESC ";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html = '<table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>

                <th>Data de Acesso</th>

                <th>Nome do Subítem</th>

                <th>Quantidade de Acessos</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($counter = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . date('d/m/Y', strtotime($counter->data)) . '</td>

                    <td style="padding:5px">' . utf8_encode($counter->nomeSubitem) . '</td>

                    <td style="padding:5px">' . $counter->acessos . '</td>

                </tr>';
                        $key++;
                    }
                    $html .= '
                </tbody>
        </table>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'contadorDepartamento':
                $sql = "SELECT a.*, b.name AS nomeDepto, c.name AS nomePai FROM counters_departaments a INNER JOIN departaments b ON (a.departament = b.id) LEFT JOIN departaments c ON (c.id = b.idPai) ";
                if ($_REQUEST['dataFiltro'] && $_REQUEST['dataFimFiltro']) {
                    $sql .= "WHERE a.data >= '" . $_REQUEST['dataFiltro'] . "' && a.data <= '".$_REQUEST['dataFimFiltro']."' ";
                    $where = 1;
                }
                if ($_REQUEST['departamentoFiltro']) {
                    if ($where) {
                        $sql .= "AND ";
                    } else {
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.departament = '" . $_REQUEST['departamentoFiltro'] . "' ";
                }
                $sql .= "ORDER BY a.data DESC ";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html = '<table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>

                <th>Data de Acesso</th>

                <th>Nome do Departamento</th>

                <th>Quantidade de Acessos</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($counter = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . date('d/m/Y', strtotime($counter->data)) . '</td>

                    <td style="padding:5px">';
                        if ($counter->nomePai){
                            $html .= utf8_encode($counter->nomePai." - ");
                        }
                        $html .= utf8_encode($counter->nomeDepto) . '</td>

                    <td style="padding:5px">' . $counter->acessos . '</td>

                </tr>';
                        $key++;
                    }
                    $html .= '
                </tbody>
        </table>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'contadorBanner':
                $sql = "SELECT a.*, b.name AS nomeBanner FROM counters_banners a INNER JOIN banners b ON (a.banner = b.id) ";
                if ($_REQUEST['dataFiltro'] && $_REQUEST['dataFimFiltro']) {
                    $sql .= "WHERE a.data >= '" . $_REQUEST['dataFiltro'] . "' && a.data <= '".$_REQUEST['dataFimFiltro']."' ";
                    $where = 1;
                }
                if ($_REQUEST['bannerFiltro']) {
                    if ($where) {
                        $sql .= "AND ";
                    } else {
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.banner = '" . $_REQUEST['bannerFiltro'] . "' ";
                }
                $sql .= "ORDER BY a.data DESC ";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html = '
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>Data do Acesso</th>
                                    <th>Nome do Banner</th>
                                    <th>Quantidade de Acessos</th>
                                </tr>
                                </thead>
                                <tbody>';
                    $key = 0;
                    while ($counter = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . date('d/m/Y', strtotime($counter->data)) . '</td>

                    <td style="padding:5px">' . utf8_encode($counter->nomeBanner) . '</td>

                    <td style="padding:5px">' . $counter->acessos . '</td>

                </tr>';
                        $key++;
                    }
                    $html .= '
</tbody>
        </table>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'contadorMarca':
                $sql = "SELECT a.*, b.name AS nomeMarca FROM counters_brands a INNER JOIN brands b ON (a.brand = b.id) ";
                if ($_REQUEST['dataFiltro'] && $_REQUEST['dataFimFiltro']) {
                    $sql .= "WHERE a.data >= '" . $_REQUEST['dataFiltro'] . "' && a.data <= '".$_REQUEST['dataFimFiltro']."' ";
                    $where = 1;
                }
                if ($_REQUEST['marcaFiltro']) {
                    if ($where) {
                        $sql .= "AND ";
                    } else {
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.brand = '" . $_REQUEST['marcaFiltro'] . "' ";
                }
                $sql .= "ORDER BY a.data DESC ";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html = '<table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>

                <th>Data de Acesso</th>

                <th>Nome da Marca</th>

                <th>Quantidade de Acessos</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($counter = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . date('d/m/Y', strtotime($counter->data)) . '</td>

                    <td style="padding:5px">';
                        $html .= utf8_encode($counter->nomeMarca) . '</td>

                    <td style="padding:5px">' . $counter->acessos . '</td>

                </tr>';
                        $key++;
                    }
                    $html .= '
                </tbody>
        </table>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'contadorSugestao':
                $sql = "SELECT a.*, b.name AS nomeSugestao FROM counters_suggestions a INNER JOIN suggestions b ON (a.suggestion = b.id) ";
                if ($_REQUEST['dataFiltro'] && $_REQUEST['dataFimFiltro']) {
                    $sql .= "WHERE a.data >= '" . $_REQUEST['dataFiltro'] . "' && a.data <= '".$_REQUEST['dataFimFiltro']."' ";
                    $where = 1;
                }
                if ($_REQUEST['sugestaoFiltro']) {
                    if ($where) {
                        $sql .= "AND ";
                    } else {
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.suggestion = '" . $_REQUEST['sugestaoFiltro'] . "' ";
                }
                $sql .= "ORDER BY a.data DESC ";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html = '<table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>

                <th>Data de Acesso</th>

                <th>Nome da Sugestão</th>

                <th>Quantidade de Acessos</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($counter = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . date('d/m/Y', strtotime($counter->data)) . '</td>

                    <td style="padding:5px">';
                        $html .= utf8_encode($counter->nomeSugestao) . '</td>

                    <td style="padding:5px">' . $counter->acessos . '</td>

                </tr>';
                        $key++;
                    }
                    $html .= '
                </tbody>
        </table>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
                case 'contadorBusca':
                    $sql = "SELECT a.* FROM counters_search a ";
                    if ($_REQUEST['dataFiltro'] && $_REQUEST['dataFimFiltro']) {
                        $sql .= "WHERE a.data >= '" . $_REQUEST['dataFiltro'] . "' && a.data <= '".$_REQUEST['dataFimFiltro']."' ";
                        $where = 1;
                    }
                    if ($_REQUEST['buscaFiltro']) {
                        if ($where) {
                            $sql .= "AND ";
                        } else {
                            $sql .= "WHERE ";
                        }
                        $sql .= "a.search LIKE '" . $_REQUEST['buscaFiltro'] . "' ";
                    }
                    $sql .= "ORDER BY a.data DESC ";
                    $query = mysqli_query($con, $sql);
                    if (mysqli_num_rows($query)) {
                        $html = '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>
    
                    <th>Data de Acesso</th>
    
                    <th>Busca</th>
    
                    <th>Quantidade de Acessos</th>
    
                </tr>
                </thead>
                <tbody>';
                        $key = 0;
                        while ($counter = mysqli_fetch_object($query)) {
                            $html .= '<tr>
    
                        <td style="padding:5px">' . date('d/m/Y', strtotime($counter->data)) . '</td>
    
                        <td style="padding:5px">';
                            $html .= utf8_encode($counter->search) . '</td>
    
                        <td style="padding:5px">' . $counter->acessos . '</td>
    
                    </tr>';
                            $key++;
                        }
                        $html .= '
                    </tbody>
            </table>';
                    } else {
                        $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                    }
                    break;
                    case 'contadorProduto':
                        $sql = "SELECT a.*, b.name AS nomeProduto FROM counters_products a INNER JOIN products b ON (a.product = b.id) ";
                        if ($_REQUEST['dataFiltro'] && $_REQUEST['dataFimFiltro']) {
                            $sql .= "WHERE a.data >= '" . $_REQUEST['dataFiltro'] . "' && a.data <= '".$_REQUEST['dataFimFiltro']."' ";
                            $where = 1;
                        }
                        if ($_REQUEST['produtoFiltro']) {
                            if ($where) {
                                $sql .= "AND ";
                            } else {
                                $sql .= "WHERE ";
                            }
                            $sql .= "a.product = '" . $_REQUEST['produtoFiltro'] . "' ";
                        }
                        $sql .= "ORDER BY a.data DESC ";
                        $query = mysqli_query($con, $sql);
                        if (mysqli_num_rows($query)) {
                            $html = '<table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                    <tr>
        
                        <th>Data de Acesso</th>
        
                        <th>Nome do Produto</th>
        
                        <th>Quantidade de Acessos</th>
        
                    </tr>
                    </thead>
                    <tbody>';
                            $key = 0;
                            while ($counter = mysqli_fetch_object($query)) {
                                $html .= '<tr>
        
                            <td style="padding:5px">' . date('d/m/Y', strtotime($counter->data)) . '</td>
        
                            <td style="padding:5px">';
                                $html .= utf8_encode($counter->nomeProduto) . '</td>
        
                            <td style="padding:5px">' . $counter->acessos . '</td>
        
                        </tr>';
                                $key++;
                            }
                            $html .= '
                        </tbody>
                </table>';
                        } else {
                            $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                        }
                        break;
            case 'newsletter':
                $sql = "SELECT a.* FROM newsletters a WHERE a.deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['emailFiltro']) {
                    $sql .= "AND ";
                    $sql .= "a.email LIKE '%" . $_REQUEST['emailFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['dataFiltro']) {
                    $sql .= "AND ";
                    $sql .= "a.created_at LIKE '" . $_REQUEST['dataFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.created_at DESC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Nome</th>
                                    <th>Email</th>
                                    <th>Ações</th>
                                </tr>
                                </thead>
                                <tbody>';
                    $key = 0;
                    while ($newsletter = mysqli_fetch_object($query)) {
                        $vet = explode(' ', $newsletter->created_at);
                        $vet2 = explode('-', $vet[0]);
                        $newsletter->created_at = $vet2[2] . "/" . $vet2[1] . "/" . $vet2[0];
                        $html .= '<tr>

                    <td style="padding:5px">' . $newsletter->created_at . '</td>

                    <td style="padding:5px">' . utf8_encode($newsletter->name) . '</td>

                    <td style="padding:5px">' . utf8_encode($newsletter->email) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarNewsletter("' . $newsletter->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarNewsletter("' . $newsletter->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirNewsletter("' . $newsletter->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","a","newsletter")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</table>
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("newsletter","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("newsletter","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("newsletter","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("newsletter","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("newsletter","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("newsletter","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("newsletter","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("newsletter","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("newsletter","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'bugTracking':
                $sql = "SELECT a.* FROM bug_trackings a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['emailFiltro']) {
                    if ($where) {
                        $sql .= "AND ";
                    } else {
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.email LIKE '%" . $_REQUEST['emailFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.created_at DESC";;
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">Data</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Email</th>

                <th style="padding:5px">Status</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($bugTracking = mysqli_fetch_object($query)) {
                        $vet = explode(' ', $bugTracking->created_at);
                        $vet2 = explode('-', $vet[0]);
                        $bugTracking->created_at = $vet2[2] . "/" . $vet2[1] . "/" . $vet2[0];
                        $status = ($bugTracking->status == 1) ? "<div style='background-color: #FFFF00; color: #000000; float:left; padding:5px'>Enviado</div>" : "<div style='background-color: #000033; color: #FFFFFF;  float:left; padding:5px'>Respondido</div>";
                        $html .= '<tr>

                    <td style="padding:5px">' . $bugTracking->created_at . '</td>

                    <td style="padding:5px">' . utf8_encode($bugTracking->name) . '</td>

                    <td style="padding:5px">' . utf8_encode($bugTracking->email) . '</td>

                    <td style="padding:5px">' . ($status) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarBugTracking("' . $bugTracking->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarBugTracking("' . $bugTracking->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirBugTracking("' . $bugTracking->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","bugTacking")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card">
              <div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("bugTracking","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("bugTracking","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("bugTracking","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("bugTracking","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("bugTracking","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("bugTracking","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("bugTracking","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("bugTracking","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("bugTracking","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
                case 'faleConosco':
                    $sql = "SELECT a.* FROM messages a WHERE a.deleted_at IS NULL ";
                    if ($_REQUEST['nomeFiltro']) {
                        $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                        $where = 1;
                    }
                    if ($_REQUEST['emailFiltro']) {
                        $sql .= "AND ";
                        $sql .= "a.email LIKE '%" . $_REQUEST['emailFiltro'] . "%' ";
                        $where = 1;
                    }
                    $sql .= "ORDER BY a.created_at DESC";
                    $query = mysqli_query($con, $sql);
                    $total = mysqli_num_rows($query);
                    $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                    $totalPaginacao = ceil($total / 15);
                    if ($totalPaginacao == $_REQUEST['pagina']) {
                        $paginacaoProxima = $_REQUEST['pagina'];
                    } elseif ($totalPaginacao > 1) {
                        $paginacaoProxima = $_REQUEST['pagina'] + 1;
                    } else {
                        $paginacaoAnterior = 1;
                    }
                    if ($_REQUEST['pagina'] <= 10) {
                        $inicial = 1;
                    } else {
                        $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                    }
                    $final = $inicial + 10;
                    $sql .= " LIMIT " . $offSet . ", 15";
                    $query = mysqli_query($con, $sql);
                    if (mysqli_num_rows($query)) {
                        $html .= '
                                <table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                    <tr>
    
                    <th style="padding:5px">Data</th>
    
                    <th style="padding:5px">Nome</th>
    
                    <th style="padding:5px">Email</th>
    
                    <th style="padding:5px">Status</th>
    
                    <th style="padding:5px">Ações</th>
                </tr>
                </thead>
                <tbody>';
                        $key = 0;
                        while ($faleConosco = mysqli_fetch_object($query)) {
                            $vet = explode(' ', $faleConosco->created_at);
                            $vet2 = explode('-', $vet[0]);
                            $faleConosco->created_at = $vet2[2] . "/" . $vet2[1] . "/" . $vet2[0];
                            $status = ($faleConosco->status == 1) ? "<div style='background-color: #FFFF00; color: #000000; float:left; padding:5px'>Enviado</div>" : "<div style='background-color: #000033; color: #FFFFFF;  float:left; padding:5px'>Respondido</div>";
                            $html .= '<tr>
    
                        <td style="padding:5px">' . $faleConosco->created_at . '</td>
    
                        <td style="padding:5px">' . utf8_encode($faleConosco->name) . '</td>
    
                        <td style="padding:5px">' . utf8_encode($faleConosco->email) . '</td>
    
                        <td style="padding:5px">' . ($status) . '</td>
    
                        <td style="padding:5px">
                             <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarFaleConosco("' . $faleConosco->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                             <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarFaleConosco("' . $faleConosco->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                            <a style="cursor:pointer" onclick=excluirFaleConosco("' . $faleConosco->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","FaleConosco")><img src="' . URL . 'img/excluir.png" width="20"></a>
                        </td>
    
                    </tr>';
                            $key++;
                        }
                        $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                        $html .= '</tbody></table>|-|<div class="card">
                  <div class="card-header">
                    <h3 class="card-title">
                      <i class="ion pagination mr-1"></i>
                      Paginação
                    </h3>
    
                    <div class="card-tools">
                        <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("faleConosco","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("faleConosco","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                            ';
                        $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("faleConosco","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                        if ($_REQUEST['pagina'] >= 11) {
                            $proxima2 = $inicial - 1;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("faleConosco","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                       ';
                        }
                        for ($j = $inicial; $j < $final; $j++) {
                            if ($j < $totalPaginacao && $j > 1) {
                                $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("faleConosco","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                            ';
                            }
                        }
                        if ($totalPaginacao > 11) {
                            $vaiAte = (floor($totalPaginacao / 10)) * 10;
                            if ($vaiAte >= $_REQUEST['pagina']) {
                                $proxima2 = $final;
                                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("faleConosco","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                            }
                        }
                        if ($totalPaginacao > 1) {
                            $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("faleConosco","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                       ';
                            $proxima = $_REQUEST['pagina'] + 1;
                            if ($proxima > $totalPaginacao) {
                                $proxima = $totalPginacao;
                            }
                        } else {
                            $proxima = 2;
                            if ($proxima > $totalPaginacao) {
                                $proxima = $totalPginacao;
                            }
                        }
                        $html .= '
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("faleConosco","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("faleConosco","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                       </ul></div>
                        </div>
                        </div>';
                    } else {
                        $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                    }
                    break;
            case 'anuncie':
                $sql = "SELECT a.* FROM anuncie_aqui a WHERE deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['emailFiltro']) {
                    $sql .= "AND ";
                    $sql .= "a.email LIKE '%" . $_REQUEST['emailFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.created_at DESC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">Data</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Email</th>

                <th style="padding:5px">Status</th>

                <th style="padding:5px">Ações</th>
            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($faleConosco = mysqli_fetch_object($query)) {
                        $vet = explode(' ', $faleConosco->created_at);
                        $vet2 = explode('-', $vet[0]);
                        $faleConosco->created_at = $vet2[2] . "/" . $vet2[1] . "/" . $vet2[0];
                        $status = ($faleConosco->status == 1) ? "<div style='background-color: #FFFF00; color: #000000; float:left; padding:5px'>Enviado</div>" : "<div style='background-color: #000033; color: #FFFFFF;  float:left; padding:5px'>Respondido</div>";
                        $html .= '<tr>

                    <td style="padding:5px">' . $faleConosco->created_at . '</td>

                    <td style="padding:5px">' . utf8_encode($faleConosco->name) . '</td>

                    <td style="padding:5px">' . utf8_encode($faleConosco->email) . '</td>

                    <td style="padding:5px">' . ($status) . '</td>

                    <td style="padding:5px">';
                    if (!$faleConosco->aprovado){
                        $html .= '<a href="#" onclick=aprovarAnuncie("' . $faleConosco->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/sucesso.png" width="20"></a>';
                    }
                    $html .= '<a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarAnuncie("' . $faleConosco->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                        <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarAnuncie("' . $faleConosco->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirAnuncie("' . $faleConosco->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","anuncie_aqui")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card">
              <div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("anuncie","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("anuncie","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("anuncie","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("anuncie","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("anuncie","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("anuncie","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("anuncie","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("anuncie","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("anuncie","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'pedido':
                $sql = "SELECT DISTINCT a.id, a.*, b.name AS nomeStatus, b.sigla, b.color, b.background, e.name AS nomeCliente, f.nomeFantasia
                        FROM requests a
                        INNER JOIN requests_statuses b ON (a.status = b.id)
                        INNER JOIN clients c ON (a.client = c.id)
                        LEFT JOIN pessoa_fisicas g ON (c.id = g.client)
                        LEFT JOIN pessoa_juridicas h ON (c.id = h.client)
                        LEFT JOIN requests_items d ON (a.id = d.request)
                        LEFT JOIN pessoa_fisicas e ON (c.id = e.client)
                        LEFT JOIN pessoa_juridicas f ON (c.id = f.client) ";
                if ($_REQUEST['idFiltro']) {
                    $sql .= "WHERE a.id LIKE '%" . $_REQUEST['idFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['dataFiltro']) {
                    if ($where){
                        $sql .= "AND ";
                    }
                    else{
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.created_at LIKE '%" . $_REQUEST['dataFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['formaPagamentoFiltro'] && $_REQUEST['formaPagamentoFiltro'] != 'undefined') {
                    if ($where){
                        $sql .= "AND ";
                    }
                    else{
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.paymentMethod = '" . $_REQUEST['formaPagamentoFiltro'] . "' ";
                    $where = 1;
                }
                if ($_REQUEST['statusFiltro']) {
                    if ($where){
                        $sql .= "AND ";
                    }
                    else{
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.status = '" . $_REQUEST['statusFiltro'] . "' ";
                    $where = 1;
                }
                if ($_REQUEST['nomeFiltro']) {
                    if ($where){
                        $sql .= "AND ";
                    }
                    else{
                        $sql .= "WHERE ";
                    }
                    $sql .= "(g.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' OR h.razaoSocial LIKE '%".$_REQUEST['nomeFiltro']."%' OR h.nomeFantasia LIKE '%".$_REQUEST['nomeFiltro']."%' OR h.contato LIKE '%".$_REQUEST['nomeFiltro']."%')";
                    $where = 1;
                }
                if ($_REQUEST['emailFiltro']) {
                    if ($where){
                        $sql .= "AND ";
                    }
                    else{
                        $sql .= "WHERE ";
                    }
                    $sql .= "c.email LIKE '%" . $_REQUEST['emailFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['nomeProdutoFiltro']) {
                    if ($where){
                        $sql .= "AND ";
                    }
                    else{
                        $sql .= "WHERE ";
                    }
                    $sql .= "d.name LIKE '%" . $_REQUEST['nomeProdutoFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['idProdutoFiltro']) {
                    if ($where){
                        $sql .= "AND ";
                    }
                    else{
                        $sql .= "WHERE ";
                    }
                    $sql .= "d.product = '" . $_REQUEST['idProdutoFiltro'] . "' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id DESC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Data / Hora</th>

                <th style="padding:5px">Status do Orçamento</th>

                <th style="padding:5px">Nome do Cliente</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($pedido = mysqli_fetch_object($query)) {
                        $vet = explode(' ', $pedido->created_at);
                        $vet2 = explode('-', $vet[0]);
                        $pedido->created_at = $vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h";
                        $html .= '<tr>

                    <td style="padding:5px">' . sprintf("%06s\n", $pedido->id) . '</td>

                    <td style="padding:5px">' . $pedido->created_at . '</td>

                    <td style="padding:5px"><span style="background-color:'.$pedido->background;
                        $nomeCliente = ($pedido->nomeCliente) ? utf8_encode($pedido->nomeCliente) : utf8_encode($pedido->nomeFantasia);
                        $html .= '; color:'.$pedido->color.'; padding: 7px" title="'.utf8_encode($pedido->nomeStatus).'">' . $pedido->sigla . '</span></td>

                    <td style="padding:5px">' . utf8_decode($nomeCliente) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarPedido("' . $pedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarPedido("' . $pedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card">
              <div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pedido","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("pedido","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("pedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("pedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'statusPedido':
                $sql = "SELECT a.* FROM requests_statuses a  ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($statusPedido = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $statusPedido->id . '</td>

                    <td style="padding:5px">' . utf8_encode($statusPedido->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarStatusPedido("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarStatusPedido("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("statusPedido","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("statusPedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("statusPedido","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("statusPedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("statusPedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("statusPedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("statusPedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("statusPedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("statusPedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'valorVendidoPorStatus':
                $sql = "SELECT a.* FROM requests_statuses a  ";
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Valor Vendido</th>

                <th style="padding:5px">Número Total de Pedidos</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($statusPedido = mysqli_fetch_object($query)) {
                        $sql = "SELECT SUM(valueTotal) AS valor, count(id) AS totalPedidosStatus FROM requests WHERE status = '".$statusPedido->id."' ";
                        if ($_REQUEST['dataFiltro'] && $_REQUEST['dataFimFiltro']){
                            $sql .= "AND created_at >= '".$_REQUEST['dataFiltro']." 00:00:00' AND created_at <= '".$_REQUEST['dataFimFiltro']." 23:59:59' ";
                        }
                        $sql .= "GROUP BY status";
                        $query2 = mysqli_query($con, $sql);
                        $row2 = mysqli_fetch_array($query2);
                        $row2['totalPedidosStatus'] = ($row2['totalPedidosStatus']) ? $row2['totalPedidosStatus'] : "0";
                        $html .= '<tr>

                    <td style="padding:5px"><div style="background-color:'.$statusPedido->background.'; color: '.$statusPedido->color.'; padding:5px; text-align:center">' . utf8_encode($statusPedido->name) . '</div></td>

                    <td style="padding:5px">R$'.number_format($row2['valor'],2,',','.').'
                    </td>
                    <td style="padding:5px">'.$row2['totalPedidosStatus'].'
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'tiposDocumento':
                $sql = "SELECT a.* FROM type_documents a  ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($tiposDocumento = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $tiposDocumento->id . '</td>

                    <td style="padding:5px">' . utf8_encode($tiposDocumento->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarTipoDocumento("' . $tiposDocumento->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarTipoDocumento("' . $tiposDocumento->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirTipoDocumento("' . $tiposDocumento->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","tipo_de_documento")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposDocumento","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposDocumento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tiposDocumento","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposDocumento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tiposDocumento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposDocumento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tiposDocumento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposDocumento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposDocumento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'clientes':
                $sql = "SELECT a.*, b.name, c.nomeFantasia FROM clients a LEFT JOIN pessoa_fisicas b ON (a.id = b.client) LEFT JOIN pessoa_juridicas c ON (a.id = c.client) ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE (b.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' OR c.nomeFantasia LIKE '%" . $_REQUEST['nomeFiltro'] . "%') ";
                    $where = 1;
                }
                if ($_REQUEST['emailFiltro']) {
                    if ($where) {
                        $sql .= "AND ";
                    } else {
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.email LIKE '%" . $_REQUEST['emailFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome / Nome Fantasia</th>

                <th style="padding:5px">Email</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($clientes = mysqli_fetch_object($query)) {
                        $nome = ($clientes->name) ? utf8_encode($clientes->name) : utf8_encode($clientes->nomeFantasia);
                        $html .= '<tr>

                    <td style="padding:5px">' . $clientes->id . '</td>

                    <td style="padding:5px">' . utf8_decode($nome) . '</td>

                    <td style="padding:5px">' . utf8_encode($clientes->email) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarClientes("' . $clientes->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarClientes("' . $clientes->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                    </td>

                </tr>

                <div class="modal fade" id="modalEndereco' . $clientes->id . '" tabindex="-1" role="dialog" aria-labelledby="modalEndereco' . $clientes->id . '" aria-hidden="true" style="z-index:99999999">

                    <div class="modal-dialog" role="document">

                        <div class="modal-content">

                            <div class="modal-header">

                                <h5 class="modal-title" id="exampleModalLabel">Visualização de Endereços</h5>

                                <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">

                                    <span aria-hidden="true">&times;</span>

                                </button>

                            </div>

                            <div class="modal-body" id="htmlVisualizaEnderecos' . $clientes->id . '">...

                            </div>

                            <div class="modal-footer">

                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>

                            </div>

                        </div>

                    </div>

                </div>
';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("clientes","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("clientes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("clientes","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("clientes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("clientes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("clientes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("clientes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("clientes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("clientes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'tiposProduto':
                $sql = "SELECT a.* FROM types_products a  ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($tiposProduto = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $tiposProduto->id . '</td>

                    <td style="padding:5px">' . utf8_encode($tiposProduto->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarTiposProduto("' . $tiposProduto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarTiposProduto("' . $tiposProduto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirTiposProduto("' . $tiposProduto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","tipo_de_produto")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposProduto","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tiposProduto","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tiposProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tiposProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'produto':
                $sql = "SELECT a.* FROM products a WHERE a.deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($produto = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $produto->id . '</td>

                    <td style="padding:5px">' . utf8_encode($produto->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarProdutos("' . $produto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarProdutos("' . $produto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '");vaiProduto("edicaoProduto")><img src="' . URL . 'img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirProdutos("' . $produto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","produto")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("produto","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("produto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("produto","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("produto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("produto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("produto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("produto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("produto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("produto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'comentariosProduto':
                $sql = "SELECT a.*, b.name AS nomeProduto FROM products_reviews a INNER JOIN products b ON (a.product = b.id) WHERE a.deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.nome LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST["produtoFiltro"]) {
                    if ($where){
                        $sql .= "AND ";
                    }
                    else{
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.product = '".$_REQUEST['produtoFiltro']."' ";
                    $where = 1;
                }
                if ($_REQUEST["emailFiltro"]) {
                    if ($where){

                    }
                    else{
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.email LIKE '%".$_REQUEST['emailFiltro']."%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.status ASC, a.created_at DESC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome do Avaliador</th>

                <th style="padding:5px">Nome do Produto</th>

                <th style="padding:5px">Mensagem</th>

                <th style="padding:5px">Status</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($comentarioProduto = mysqli_fetch_object($query)) {
                        $status = ($comentarioProduto->status == 0) ? "<span style='color:#FF0000; font-weight:bold'>Não Aprovado</span>" : "<span style='color:#000033; font-weight:bold'>Aprovado</span>";
                        $html .= '<tr>

                    <td style="padding:5px">' . $comentarioProduto->id . '</td>

                    <td style="padding:5px">' . utf8_encode($comentarioProduto->nome) . '</td>

                    <td style="padding:5px">' . utf8_encode($comentarioProduto->nomeProduto) . '</td>

                    <td style="padding:5px">' . utf8_encode(nl2br($comentarioProduto->mensagem)) . '</td>

                    <td style="padding:5px">' . ($status) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarComentarioProduto("' . $comentarioProduto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarComentarioProduto("' . $comentarioProduto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '");vaiProduto("edicaoProduto")><img src="' . URL . 'img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirComentarioProduto("' . $comentarioProduto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","comentario_do_produto")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("comentariosProduto","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("comentariosProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("comentariosProduto","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("comentariosProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("comentariosProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("comentariosProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("comentariosProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("comentariosProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("comentariosProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'solicitacaoComentario':
                $sql = "SELECT a.*, b.nome AS nomeDoComentarista, b.email AS emailDoComentarista FROM products_reviews_solicitas a INNER JOIN products_reviews b ON (a.id_product_review = b.id) WHERE a.deleted_at IS NULL ";
                $sql .= " ORDER BY a.created_at DESC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome do Comentarista</th>

                <th style="padding:5px">Email do Comentarista</th>

                <th style="padding:5px">Nota</th>

                <th style="padding:5px">Mensagem</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($comentarioProduto = mysqli_fetch_object($query)) {
                        $status = ($comentarioProduto->status == 0) ? "<span style='color:#FF0000; font-weight:bold'>Não Aprovado</span>" : "<span style='color:#000033; font-weight:bold'>Aprovado</span>";
                        $html .= '<tr>

                    <td style="padding:5px">' . $comentarioProduto->id . '</td>

                    <td style="padding:5px">' . ($comentarioProduto->nomeDoComentarista) . '</td>

                    <td style="padding:5px">' . utf8_encode($comentarioProduto->emailDoComentarista) . '</td>

                    <td style="padding:5px">' . ($comentarioProduto->avaliacao) . '</td>

                    <td style="padding:5px">' . nl2br($comentarioProduto->mensagem) . '</td>

                    <td style="padding:5px">
                         <a href="#" onclick=aprovarSolicitacaoComentario("' . $comentarioProduto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/sucesso.png" width="20" title="Aprovar"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarSolicitacaoComentario("' . $comentarioProduto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '");vaiProduto("edicaoProduto")><img src="' . URL . 'img/editar.png" width="20" title="Editar"></a>
                         <a style="cursor:pointer" onclick=excluirSolicitacaoComentario("' . $comentarioProduto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","a","solicitacao-de-comentario")><img src="' . URL . 'img/excluir.png" width="20" title="Excluir"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("solicitacaoComentario","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("solicitacaoComentario","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("solicitacaoComentario","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("solicitacaoComentario","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("solicitacaoComentario","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("solicitacaoComentario","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("solicitacaoComentario","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("solicitacaoComentario","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("solicitacaoComentario","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'formasFrete':
                $sql = "SELECT a.* FROM shipping_methods a  ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($formasFrete = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $formasFrete->id . '</td>

                    <td style="padding:5px">' . utf8_encode($formasFrete->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarFormaFrete("' . $formasFrete->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarFormaFrete("' . $formasFrete->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirFormaFrete("' . $formasFrete->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","a","forma_de_pagamento")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("formasFrete","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("formasFrete","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("formasFrete","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("formasFrete","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("formasFrete","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("formasFrete","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("formasFrete","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("formasFrete","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("formasFrete","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'formasPagamento':
                $sql = "SELECT a.* FROM payment_methods a  ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($formasPagamento = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $formasPagamento->id . '</td>

                    <td style="padding:5px">' . utf8_encode($formasPagamento->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarFormaPagamento("' . $formasPagamento->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarFormaPagamento("' . $formasPagamento->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirFormaPagamento("' . $formasPagamento->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","a","forma_de_pagamento")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("formasPagamento","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("formasPagamento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("formasPagamento","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("formasPagamento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("formasPagamento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("formasPagamento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("formasPagamento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("formasPagamento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("formasPagamento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'banners':
                $sql = "SELECT a.* FROM banners a WHERE a.deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($banners = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $banners->id . '</td>

                    <td style="padding:5px">' . utf8_encode($banners->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarBanner("' . $banners->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarBanner("' . $banners->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirBanner("' . $banners->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","banner")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("banners","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("banners","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("banners","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("banners","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("banners","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("banners","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("banners","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("banners","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("banners","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'pagina':
                $sql = "SELECT a.* FROM pages a WHERE a.deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($pagina = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $pagina->id . '</td>

                    <td style="padding:5px">' . utf8_encode($pagina->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarPagina("' . $pagina->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarPagina("' . $pagina->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirPagina("' . $pagina->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","a","pagina")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAntaerior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pagina","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pagina","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("pagina","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pagina","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("pagina","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pagina","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("pagina","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pagina","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pagina","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'listasPresentes':
                $sql = "SELECT a.* FROM presents_lists a  ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.dataAniversario DESC, a.nomeAniversariante ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome do Aniversariante</th>

                <th style="padding:5px">Data do Aniversário</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($listasPresentes = mysqli_fetch_object($query)) {
                        $vet = explode('-', $listasPresentes->dataAniversario);
                        $listasPresentes->dataAniversario = $vet[2]."/".$vet[1]."/".$vet[0];
                        $html .= '<tr>

                    <td style="padding:5px">' . $listasPresentes->id . '</td>

                    <td style="padding:5px">' . utf8_encode($listasPresentes->nomeAniversariante) . '</td>

                    <td style="padding:5px">' . utf8_encode($listasPresentes->dataAniversario) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalPresents" onclick=visualizarPresentes("' . $listasPresentes->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/presentes.png" title="Lista de Presentes" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalGuests" onclick=visualizarConvidados("' . $listasPresentes->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/convidados.png" title="Lista de Convidados" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarListasPresentes("' . $listasPresentes->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarListasPresentes("' . $listasPresentes->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirListasPresentes("' . $listasPresentes->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","a","listaPresente")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAntaerior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("listasPresentes","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("listasPresentes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("listasPresentes","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("listasPresentes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("listasPresentes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("listasPresentes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("listasPresentes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("listasPresentes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("listasPresentes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'subitem':
                $sql = "SELECT a.*, b.name AS nomePagina FROM subitems a INNER JOIN pages b ON (b.id = a.page) WHERE a.deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['paginaFiltro']) {
                    if ($where){
                        $sql .= "AND ";
                    }
                    else{
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.page = '" . $_REQUEST['paginaFiltro'] . "' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.page ASC, a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Página</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($subitem = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $subitem->id . '</td>

                    <td style="padding:5px">' . utf8_encode($subitem->nomePagina) . '</td>

                    <td style="padding:5px">' . utf8_encode($subitem->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarSubitem("' . $subitem->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarSubitem("' . $subitem->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirSubitem("' . $subitem->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","subitem")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("subitem","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("subitem","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("subitem","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("subitem","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("subitem","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("subitem","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("subitem","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("subitem","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("subitem","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'tipoServico':
                $sql = "SELECT a.* FROM types_services a  ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>';
                    $key = 0;
                    while ($tipoServico = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $tipoServico->id . '</td>

                    <td style="padding:5px">' . utf8_encode($tipoServico->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarTipoServico("' . $tipoServico->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarTipoServico("' . $tipoServico->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirTipoServico("' . $tipoServico->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","tipo_de_servico")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoServico","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoServico","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tipoServico","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoServico","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tipoServico","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoServico","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tipoServico","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoServico","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoServico","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'prioridade':
                $sql = "SELECT a.* FROM priorities a  ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($prioridade = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $prioridade->id . '</td>

                    <td style="padding:5px">' . utf8_encode($prioridade->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarPrioridade("' . $prioridade->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarPrioridade("' . $prioridade->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirPrioridade("' . $prioridade->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","a","prioridade")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("prioridade","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("prioridade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("prioridade","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("prioridade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("prioridade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("prioridade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("prioridade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("prioridade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("prioridade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'tipoVersao':
                $sql = "SELECT a.*, b.name AS nomeTipoServico FROM type_versions a INNER JOIN types_services b ON (a.typeService = b.id) ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['tipoServicoFiltro']) {
                    if ($where) {
                        $sql .= "AND ";
                    } else {
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.typeService = '" . $_REQUEST['tipoServicoFiltro'] . "' ";
                    $where = 1;
                }
                $sql .= "ORDER BY b.id ASC, a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome do Tipo de Serviço</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($statusPedido = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $statusPedido->id . '</td>

                    <td style="padding:5px">' . utf8_encode($statusPedido->nomeTipoServico) . '</td>

                    <td style="padding:5px">' . utf8_encode($statusPedido->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarTipoVersao("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarTipoVersao("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirTipoVersao("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","tipo_de_versao")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoVersao","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoVersao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tipoVersao","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoVersao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tipoVersao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoVersao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tipoVersao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoVersao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoVersao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'departamentos':
                $sql = "SELECT a.* FROM departaments a WHERE a.deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['departamentoFiltro']) {
                    $sql .= "AND a.idPai = '" . $_REQUEST['departamentoFiltro'] . "' ";
                    $where = 1;
                }
                else{
                    if ($where) {
                        $sql .= "AND ";
                    } else {
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.idPai = '0' ";
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            </tbody>';
                    $key = 0;
                    while ($departamentos = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $departamentos->id . '</td>

                    <td style="padding:5px">' . utf8_encode($departamentos->name) . '</td>

                    <td style="padding:5px">
                    ';
                        $sql = "SELECT * FROM departaments WHERE idPai = '".$departamentos->id."'";
                        $querySubs = mysqli_query($con, $sql);
                        if (mysqli_num_rows($querySubs)){
                            $html .= '<a style="cursor:pointer" onclick=abreFecha("subdeptosDepartamentos'.$departamentos->id.'");><img src="'.URL.'img/sucesso.png" width="20"></a>
                                        <div style="position: absolute; background-color: #F7f7f7; width:90%; display:none; left:100px; text-align:center; z-index:9999999999999999999" id="subdeptosDepartamentos'.$departamentos->id.'"">
                                            <div style="position:absolute; float:left; left:95%"><a style="cursor:pointer" onclick=$("#subdeptosDepartamentos'.$departamentos->id.'").hide("fast")>&times;</a></div>
                                            <h3>Sub-departamentos de '.utf8_encode($departamentos->name).'</h3>
                                            <table id="example2" class="table table-bordered table-hover" style="z-index:9999999999">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            </tbody>';
                            while ($rowSubs = mysqli_fetch_object($querySubs)){
                                $html .= '<tr>

                    <td style="padding:5px">' . $rowSubs->id . '</td>

                    <td style="padding:5px">' . utf8_encode($rowSubs->name) . '</td>

                    <td style="padding:5px"><a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarDepartamentos("' . $rowSubs->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarDepartamentos("' . $rowSubs->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirDepartamentos("' . $rowSubs->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","departamento")><img src="' . URL . 'img/excluir.png" width="20"></a></td>
                    </tr>
                    ';
                            }
                            $html .= '</table>
                                        </div>';
                        }
                        $html .= '
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarDepartamentos("' . $departamentos->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarDepartamentos("' . $departamentos->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirDepartamentos("' . $departamentos->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","departamento")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("departamentos","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("departamentos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("departamentos","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("departamentos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("departamentos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("departamentos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("departamentos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("departamentos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("departamentos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'atributos':
                $sql = "SELECT a.* FROM attributes a WHERE a.deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['atributoFiltro']) {
                    $sql .= "AND a.idPai = '" . $_REQUEST['atributoFiltro'] . "' ";
                    $where = 1;
                }
                else{
                    $sql .= "AND a.idPai = '0' ";
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            </tbody>';
                    $key = 0;
                    while ($atributos = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $atributos->id . '</td>

                    <td style="padding:5px">' . utf8_encode($atributos->name) . '</td>

                    <td style="padding:5px">
                    ';
                        $sql = "SELECT * FROM attributes WHERE idPai = '".$atributos->id."' AND deleted_at IS NULL";
                        $querySubs = mysqli_query($con, $sql);
                        if (mysqli_num_rows($querySubs)){
                            $html .= '<a style="cursor:pointer" onclick=abreFecha("subdeptosAtributos'.$atributos->id.'");><img src="'.URL.'img/sucesso.png" width="20"></a>
                                        <div style="position: absolute; background-color: #F7f7f7; width:90%; display:none; left:100px; text-align:center; z-index:9999999999999999999" id="subdeptosAtributos'.$atributos->id.'"">
                                            <div style="position:absolute; float:left; left:95%"><a style="cursor:pointer" onclick=$("#subdeptosAtributos'.$atributos->id.'").hide("fast")>&times;</a></div>
                                            <h3>Sub-atributos de '.utf8_encode($atributos->name).'</h3>
                                            <table id="example2" class="table table-bordered table-hover" style="z-index:9999999999">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            </tbody>';
                            while ($rowSubs = mysqli_fetch_object($querySubs)){
                                $html .= '<tr>

                    <td style="padding:5px">' . $rowSubs->id . '</td>

                    <td style="padding:5px">' . utf8_encode($rowSubs->name) . '</td>

                    <td style="padding:5px"><a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarAtributos("' . $rowSubs->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarAtributos("' . $rowSubs->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirAtributos("' . $rowSubs->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","atributo")><img src="' . URL . 'img/excluir.png" width="20"></a></td>
                    </tr>
                    ';
                            }
                            $html .= '</table>
                                        </div>';
                        }
                        $html .= '
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarAtributos("' . $atributos->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarAtributos("' . $atributos->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirAtributos("' . $atributos->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","atributo")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("atributos","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("atributos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("atributos","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("atributos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("atributos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("atributos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("atributos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("atributos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("atributos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'marcas':
                $sql = "SELECT a.* FROM brands a WHERE deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($marcas = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $marcas->id . '</td>

                    <td style="padding:5px">' . utf8_encode($marcas->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarMarcas("' . $marcas->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarMarcas("' . $marcas->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirMarcas("' . $marcas->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","a","marca")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("marcas","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("marcas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("marcas","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("marcas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("marcas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("marcas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("marcas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("marcas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("marcas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'feriados':
                $sql = "SELECT a.* FROM holidays a WHERE a.date LIKE '".date('Y')."%' ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.date ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($feriados = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $feriados->id . '</td>

                    <td style="padding:5px">' . utf8_encode($feriados->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarFeriados("' . $feriados->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarFeriados("' . $feriados->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirFeriados("' . $feriados->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","feriado")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("feriados","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("feriados","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("feriados","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("feriados","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("feriados","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("feriados","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("feriados","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("feriados","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("feriados","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'parceiros':
                $sql = "SELECT a.* FROM partners a WHERE a.deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Cliques</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($parceiros = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $parceiros->id . '</td>

                    <td style="padding:5px">' . utf8_encode($parceiros->name) . '</td>

                    <td style="padding:5px">' . utf8_encode($parceiros->cliques) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarParceiros("' . $parceiros->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarParceiros("' . $parceiros->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirParceiros("' . $parceiros->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","parceiro")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("parceiros","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("parceiros","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("parceiros","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("parceiros","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("parceiros","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("parceiros","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("parceiros","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("parceiros","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("parceiros","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'nacionalidade':
                $sql = "SELECT a.* FROM nationalities a WHERE a.deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.padrao DESC, a.name ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($nacionalidade = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $nacionalidade->id . '</td>

                    <td style="padding:5px">' . $nacionalidade->name . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarNacionalidade("' . $nacionalidade->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarNacionalidade("' . $nacionalidade->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirNacionalidade("' . $nacionalidade->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","a","nacionalidade")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("nacionalidade","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("nacionalidade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("nacionalidade","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("nacionalidade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("nacionalidade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("nacionalidade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("nacionalidade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("nacionalidade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("nacionalidade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'pais':
                $sql = "SELECT a.* FROM countries a WHERE a.deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.padrao DESC, a.name ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($pais = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $pais->id . '</td>

                    <td style="padding:5px">' . $pais->name . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarPais("' . $pais->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarPais("' . $pais->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirPais("' . $pais->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","pais")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pais","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("pais","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("pais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("pais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'redesSociais':
                $sql = "SELECT a.* FROM social_networks a WHERE a.deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Cliques</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($redesSociais = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $redesSociais->id . '</td>

                    <td style="padding:5px">' . utf8_encode($redesSociais->name) . '</td>

                    <td style="padding:5px">' . utf8_encode($redesSociais->cliques) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarRedesSociais("' . $redesSociais->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarRedesSociais("' . $redesSociais->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirRedesSociais("' . $redesSociais->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","a","redeSocial")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("redesSociais","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("redesSociais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("redesSociais","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("redesSociais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("redesSociais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("redesSociais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("redesSociais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("redesSociais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("redesSociais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'cupomDesconto':
                $sql = "SELECT a.* FROM coupon_discounts a WHERE a.deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.codigo LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Código</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($cupomDesconto = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $cupomDesconto->id . '</td>

                    <td style="padding:5px">' . utf8_encode($cupomDesconto->codigo) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarCupomDesconto("' . $cupomDesconto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarCupomDesconto("' . $cupomDesconto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirCupomDesconto("' . $cupomDesconto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","cupomDesconto")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("cupomDesconto","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("cupomDesconto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("cupomDesconto","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("cupomDesconto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("cupomDesconto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("cupomDesconto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("cupomDesconto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("cupomDesconto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("cupomDesconto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'valePresente':
                $sql = "SELECT a.* FROM vales a  ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.code LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Código</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($valePresente = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $valePresente->id . '</td>

                    <td style="padding:5px">' . utf8_encode($valePresente->code) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarValePresente("' . $valePresente->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarValePresente("' . $valePresente->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirValePresente("' . $valePresente->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","valePresente")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("valePresente","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("valePresente","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("valePresente","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("valePresente","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("valePresente","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("valePresente","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("valePresente","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("valePresente","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("valePresente","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'selos':
                $sql = "SELECT a.* FROM stamps a WHERE a.deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($selos = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $selos->id . '</td>

                    <td style="padding:5px">' . utf8_encode($selos->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarSelos("' . $selos->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarSelos("' . $selos->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirSelos("' . $selos->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","selo")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("selos","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("selos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("selos","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("selos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("selos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("selos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("selos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("selos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("selos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'sugestoes':
                $sql = "SELECT a.* FROM suggestions a WHERE a.deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($sugestoes = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $sugestoes->id . '</td>

                    <td style="padding:5px">' . utf8_encode($sugestoes->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarSugestoes("' . $sugestoes->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarSugestoes("' . $sugestoes->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirSugestoes("' . $sugestoes->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","selo")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("sugestoes","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("sugestoes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("sugestoes","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("sugestoes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("sugestoes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("sugestoes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("sugestoes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("sugestoes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("sugestoes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
                case 'relacionamentos':
                    $sql = "SELECT a.* FROM relationships a WHERE a.deleted_at IS NULL ";
                    if ($_REQUEST['nomeFiltro']) {
                        $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                        $where = 1;
                    }
                    $sql .= "ORDER BY a.id ASC";
                    $query = mysqli_query($con, $sql);
                    $total = mysqli_num_rows($query);
                    $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                    $totalPaginacao = ceil($total / 15);
                    if ($totalPaginacao == $_REQUEST['pagina']) {
                        $paginacaoProxima = $_REQUEST['pagina'];
                    } elseif ($totalPaginacao > 1) {
                        $paginacaoProxima = $_REQUEST['pagina'] + 1;
                    } else {
                        $paginacaoAnterior = 1;
                    }
                    if ($_REQUEST['pagina'] <= 10) {
                        $inicial = 1;
                    } else {
                        $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                    }
                    $final = $inicial + 10;
                    $sql .= " LIMIT " . $offSet . ", 15";
                    $query = mysqli_query($con, $sql);
                    if (mysqli_num_rows($query)) {
                        $html .= '<table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                    <tr>
    
                    <th style="padding:5px">ID</th>
    
                    <th style="padding:5px">Nome</th>
    
                    <th style="padding:5px">Ações</th>
    
                </tr>
                </thead>
                </tbody>';
                        $key = 0;
                        while ($relacionamentos = mysqli_fetch_object($query)) {
                            $html .= '<tr>
    
                        <td style="padding:5px">' . $relacionamentos->id . '</td>
    
                        <td style="padding:5px">' . utf8_encode($relacionamentos->name) . '</td>
    
                        <td style="padding:5px">
                        ';
                            $html .= '
                             <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarRelacionamento("' . $relacionamentos->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                             <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarRelacionamento("' . $relacionamentos->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                            <a style="cursor:pointer" onclick=excluirRelacionamento("' . $relacionamentos->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","departamento")><img src="' . URL . 'img/excluir.png" width="20"></a>
                        </td>
    
                    </tr>';
                            $key++;
                        }
                        $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                        $html .= '</tbody></table>|-|<div class="card-header">
                    <h3 class="card-title">
                      <i class="ion pagination mr-1"></i>
                      Paginação
                    </h3>
    
                    <div class="card-tools">
                        <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("relacionamentos","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("relacionamentos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                            ';
                        $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("relacionamentos","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                        if ($_REQUEST['pagina'] >= 11) {
                            $proxima2 = $inicial - 1;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("relacionamentos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                       ';
                        }
                        for ($j = $inicial; $j < $final; $j++) {
                            if ($j < $totalPaginacao && $j > 1) {
                                $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("relacionamentos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                            ';
                            }
                        }
                        if ($totalPaginacao > 11) {
                            $vaiAte = (floor($totalPaginacao / 10)) * 10;
                            if ($vaiAte >= $_REQUEST['pagina']) {
                                $proxima2 = $final;
                                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("relacionamentos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                            }
                        }
                        if ($totalPaginacao > 1) {
                            $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("relacionamentos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                       ';
                            $proxima = $_REQUEST['pagina'] + 1;
                            if ($proxima > $totalPaginacao) {
                                $proxima = $totalPginacao;
                            }
                        } else {
                            $proxima = 2;
                            if ($proxima > $totalPaginacao) {
                                $proxima = $totalPginacao;
                            }
                        }
                        $html .= '
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("relacionamentos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("relacionamentos","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                       </ul></div>
                        </div>
                        </div>';
                    } else {
                        $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                    }
                    break;
                    case 'imoveis':
                        $sql = "SELECT a.* FROM properties a WHERE a.deleted_at IS NULL ";
                        if ($_REQUEST['nomeFiltro']) {
                            $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                            $where = 1;
                        }
                        $sql .= "ORDER BY a.id DESC";
                        $query = mysqli_query($con, $sql);
                        $total = mysqli_num_rows($query);
                        $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                        $totalPaginacao = ceil($total / 15);
                        if ($totalPaginacao == $_REQUEST['pagina']) {
                            $paginacaoProxima = $_REQUEST['pagina'];
                        } elseif ($totalPaginacao > 1) {
                            $paginacaoProxima = $_REQUEST['pagina'] + 1;
                        } else {
                            $paginacaoAnterior = 1;
                        }
                        if ($_REQUEST['pagina'] <= 10) {
                            $inicial = 1;
                        } else {
                            $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                        }
                        $final = $inicial + 10;
                        $sql .= " LIMIT " . $offSet . ", 15";
                        $query = mysqli_query($con, $sql);
                        if (mysqli_num_rows($query)) {
                            $html .= '<table id="example2" class="table table-bordered table-hover">
                                        <thead>
                                        <tr>
        
                        <th style="padding:5px">ID</th>
        
                        <th style="padding:5px">Nome</th>
        
                        <th style="padding:5px">Ações</th>
        
                    </tr>
                    </thead>
                    </tbody>';
                            $key = 0;
                            while ($imoveis = mysqli_fetch_object($query)) {
                                $html .= '<tr>
        
                            <td style="padding:5px">' . $imoveis->id . '</td>
        
                            <td style="padding:5px">' . utf8_encode($imoveis->name) . '</td>
        
                            <td style="padding:5px">
                            ';
                                $html .= '
                                 <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarImoveis("' . $imoveis->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                                 <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarImoveis("' . $imoveis->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                                <a style="cursor:pointer" onclick=excluirImoveis("' . $imoveis->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","departamento")><img src="' . URL . 'img/excluir.png" width="20"></a>
                            </td>
        
                        </tr>';
                                $key++;
                            }
                            $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                            $html .= '</tbody></table>|-|<div class="card-header">
                        <h3 class="card-title">
                          <i class="ion pagination mr-1"></i>
                          Paginação
                        </h3>
        
                        <div class="card-tools">
                            <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                                <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("imoveis","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                                <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("imoveis","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                                ';
                            $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("imoveis","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                            if ($_REQUEST['pagina'] >= 11) {
                                $proxima2 = $inicial - 1;
                                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("imoveis","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                           ';
                            }
                            for ($j = $inicial; $j < $final; $j++) {
                                if ($j < $totalPaginacao && $j > 1) {
                                    $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("imoveis","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                                ';
                                }
                            }
                            if ($totalPaginacao > 11) {
                                $vaiAte = (floor($totalPaginacao / 10)) * 10;
                                if ($vaiAte >= $_REQUEST['pagina']) {
                                    $proxima2 = $final;
                                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("imoveis","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                                }
                            }
                            if ($totalPaginacao > 1) {
                                $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("imoveis","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                           ';
                                $proxima = $_REQUEST['pagina'] + 1;
                                if ($proxima > $totalPaginacao) {
                                    $proxima = $totalPginacao;
                                }
                            } else {
                                $proxima = 2;
                                if ($proxima > $totalPaginacao) {
                                    $proxima = $totalPginacao;
                                }
                            }
                            $html .= '
                                <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("imoveis","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                                <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("imoveis","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                           </ul></div>
                            </div>
                            </div>';
                        } else {
                            $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                        }
                        break;
            case 'paramSite':
                $sql = "SELECT a.* FROM param_sites a WHERE a.deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($parametroSite = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $parametroSite->id . '</td>

                    <td style="padding:5px">' . utf8_encode($parametroSite->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarParametroSite("' . $parametroSite->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarParametroSite("' . $parametroSite->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirParametroSite("' . $parametroSite->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","parametro_do_site")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramSite","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramSite","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("paramSite","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramSite","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("paramSite","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramSite","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("paramSite","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramSite","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramSite","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'paramAdmin':
                $sql = "SELECT a.* FROM  param_admins a WHERE a.deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $totalPginacao = 0;
                $html = "";
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>';
                    $key = 0;
                    while ($parametroAdmin = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $parametroAdmin->id . '</td>

                    <td style="padding:5px">' . utf8_encode($parametroAdmin->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarParametroAdmin("' . $parametroAdmin->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarParametroAdmin("' . $parametroAdmin->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirParametroAdmin("' . $parametroAdmin->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","parametro_do_administrativo")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramAdmin","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramAdmin","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("paramAdmin","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramAdmin","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("paramAdmin","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramAdmin","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("paramAdmin","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramAdmin","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramAdmin","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'versao':
                $sql = "SELECT a.* FROM versions a WHERE a.deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>';
                    $key = 0;
                    while ($parametroAdmin = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $parametroAdmin->id . '</td>

                    <td style="padding:5px">' . utf8_encode($parametroAdmin->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarVersao("' . $parametroAdmin->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarVersao("' . $parametroAdmin->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirVersao("' . $parametroAdmin->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","a","versao")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("versao","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("versao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("versao","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("versao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("versao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("versao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("versao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("versao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("versao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'usuarios':
                $sql = "SELECT a.* FROM users a WHERE a.deleted_at IS NULL  ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['emailFiltro']) {
                    $sql .= "AND ";
                    $sql .= "a.email = '" . $_REQUEST['emailFiltro'] . "' ";
                    $where = 1;
                }
                if ($_REQUEST['idUser'] != 1) {
                    $sql .= "AND ";
                    $sql .= "a.id = '" . $_REQUEST['idUser'] . "' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Email</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($usuarios = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $usuarios->id . '</td>

                    <td style="padding:5px">' . ($usuarios->name) . '</td>

                    <td style="padding:5px">' . ($usuarios->email) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarUsuarios("' . $usuarios->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarUsuarios("' . $usuarios->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirUsuarios("' . $usuarios->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","usuário")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios","\'' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("usuarios","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("usuarios","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("usuarios","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
                case 'itensExcluidos':
                    $sql = "SELECT * FROM modules WHERE status = '1' ORDER BY typeModule ASC, created_at ASC";
                    $query = mysqli_query($con, $sql);
                    $modules = mysqli_num_rows($query);
                    if ($modules){
                        $i = 0;
                        while ($row = mysqli_fetch_array($query)){
                            if ($i >= 10 && $i != 13 && $i != 14 && $i != 15 && $i != 16 && $i != 30 && $i != 41 && $i != 42){
                                if ($row['slug'] == 'newsletter'){
                                    $table = 'newsletters';
                                    $artigo = "o";
                                }
                                elseif ($row['slug'] == 'anuncie'){
                                    $table = 'anuncie_aqui';
                                    $artigo = "o";
                                }
                                elseif ($row['slug'] == 'faleConosco'){
                                    $table = 'messages';                                
                                    $artigo = "o";
                                }
                                elseif ($row['slug'] == 'comentariosProduto'){
                                    $table = 'products_reviews';
                                    $artigo = "o";
                                }
                                elseif ($row['slug'] == 'solicitacaoComentario'){
                                    $table = 'products_reviews_solicitas';
                                    $artigo = "a";
                                }
                                elseif ($row['slug'] == 'bairrosEntrega'){
                                    $table = 'bairros_entrega';
                                    $artigo = "o";
                                }
                                elseif ($row['slug'] == 'formas-pagamento'){
                                    $table = 'payment_methods';
                                    $artigo = "a";
                                }
                                elseif ($row['slug'] == 'banner'){
                                    $table = 'banners';
                                    $artigo = "o";
                                }
                                elseif ($row['slug'] == 'pagina'){
                                    $table = 'pages';
                                    $artigo = "a";
                                }
                                elseif ($row['slug'] == 'subitems'){
                                    $table = 'subitems';
                                    $artigo = "o";
                                }
                                elseif ($row['slug'] == 'atributos'){
                                    $table = 'attributes';
                                    $artigo = "o";
                                }
                                elseif ($row['slug'] == 'departamentos'){
                                    $table = 'departaments';
                                    $artigo = "o";
                                }
                                elseif ($row['slug'] == 'selos'){
                                    $table = 'stamps';
                                    $artigo = "o";
                                }
                                elseif ($row['slug'] == 'sugestoes'){
                                    $table = 'suggestions';
                                    $artigo = "a";
                                }
                                elseif ($row['slug'] == 'relacionamentos'){
                                    $table = 'relationships';
                                    $artigo = "o";
                                }
                                elseif ($row['slug'] == 'produto'){
                                    $table = 'products';
                                    $artigo = "o";
                                }
                                elseif ($row['slug'] == 'cupomDesconto'){
                                    $table = 'coupon_discounts';
                                    $artigo = "o";
                                }
                                elseif ($row['slug'] == 'paramSite'){
                                    $table = 'param_sites';
                                    $artigo = "o";
                                }
                                elseif ($row['slug'] == 'paramAdmin'){
                                    $table = 'param_admins';
                                    $artigo = "o";
                                }
                                elseif ($row['slug'] == 'versao'){
                                    $table = 'versions';
                                    $artigo = "a";
                                }
                                elseif ($row['slug'] == 'parceiros'){
                                    $table = 'partners';
                                    $artigo = "o";
                                }
                                elseif ($row['slug'] == 'nacionalidade'){
                                    $table = 'nationalities';
                                    $artigo = "a";
                                }
                                elseif ($row['slug'] == 'pais'){
                                    $table = 'countries';
                                    $artigo = "o";
                                }
                                elseif ($row['slug'] == 'redesSociais'){
                                    $table = 'social_networks';
                                    $artigo = "a";
                                }
                                elseif ($row['slug'] == 'usuarios'){
                                    $table = 'users';
                                    $artigo = "o";
                                }
                                elseif ($row['slug'] == 'tiposModulo'){
                                    $table = 'type_modules';
                                    $artigo = "o";
                                }
                                elseif ($row['slug'] == 'modulos'){
                                    $table = 'modules';
                                    $artigo = "o";
                                }
                                elseif ($row['slug'] == 'usuarios-pre'){
                                    $table = 'user_pres';
                                    $artigo = "o";
                                }
                                $sql = "SELECT * FROM ".$table." WHERE deleted_at IS NOT NULL";
                                $query2 = mysqli_query($con, $sql);
                                $rows = mysqli_num_rows($query2);
                            $html .= '
                            <div class="col-lg-3 col-3">
                                <!-- small box -->
                                <div class="small-box bg-';
                                if ($i % 4 == 0){
                                    $html .= 'info';
                                }
                                elseif ($i % 4 == 1){
                                    $html .= 'success';
                                }
                                elseif ($i % 4 == 2){
                                    $html .= 'warning';
                                }
                                elseif ($i % 4 == 3){
                                    $html .= 'danger';
                                }
                                $html .= '">
                                    <div class="inner">
                                        <h3>';
                                        $html .= $rows;
                                $html .= '</h3>
        
                                        <p>'.utf8_encode($row['name']).' excluíd'.$artigo.'s até o momento</p>
                                    </div>
                                    <div class="icon">
                                        <i class="ion ion-edit"></i>
                                    </div>
                                    <a href="'.URL.'admin/'.$row['slug'].'" class="small-box-footer">Ver as Informações de Cadastrados <i class="fas fa-arrow-circle-right"></i></a>
                                    ';
                                    if ($rows){
                                        $html .= '<a onclick=verificaTodosExcluidos("'.$table.'","'.str_replace(" ", "_", $row['name']).'","'.URL.'")  data-toggle="modal" data-target="#modalVerTodosExcluidos" style="cursor:pointer" class="small-box-footer">Ver Todos os Excluídos <i class="fas fa-arrow-circle-right"></i></a>';
                                        $html .= '<a onclick=voltarTodosExcluidos("'.$table.'","'.str_replace(" ", "_", $row['name']).'","'.URL.'") style="cursor:pointer" class="small-box-footer">Voltar Todos os Excluídos <i class="fas fa-arrow-circle-right"></i></a>';
                                        $html .= '<a onclick=excluirTodosExcluidos("'.$table.'","'.str_replace(" ", "_", $row['name']).'","'.URL.'") style="cursor:pointer" class="small-box-footer">Excluir Todos os Excluídos <i class="fas fa-arrow-circle-right"></i></a>';
                                    }
                                    $html .= '
                                    </div>
                            </div>
                            ';
                            }
                            $i++;
                        }
                    }
                    $sql = "SELECT * FROM products_items WHERE deleted_at IS NOT NULL";
                    $query = mysqli_query($con, $sql);
                    $rows = mysqli_num_rows($query);
                    $row['name'] = "Itens do Produto";
                    $row['slug'] = "produto";;
                    $table = "products_items";
                    $artigo = "o";
                    $html .= '
                    <div class="col-lg-3 col-3">
                        <!-- small box -->
                        <div class="small-box bg-info';
                        $html .= '">
                            <div class="inner">
                                <h3>';
                                $html .= $rows;
                        $html .= '</h3>
    
                                <p>'.$row['name'].' excluíd'.$artigo.'s até o momento</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-edit"></i>
                            </div>
                            <a href="'.URL.'admin/'.$row['slug'].'" class="small-box-footer">Ver as Informações de Cadastrados <i class="fas fa-arrow-circle-right"></i></a>
                            ';
                            if ($rows > 0){
                                $html .= '
                                <a onclick=verificaTodosExcluidos("'.$table.'","'.$row['name'].'","'.URL.'")  data-toggle="modal" data-target="#modalVerTodosExcluidos" style="cursor:pointer" class="small-box-footer">Ver Todos os Excluídos <i class="fas fa-arrow-circle-right"></i></a>';
                            }
                            $html .= '
                        </div>
                    </div>
                    ';
                    $sql = "SELECT * FROM products_images WHERE deleted_at IS NOT NULL";
                    $query = mysqli_query($con, $sql);
                    $rows = mysqli_num_rows($query);
                    $row['name'] = "Imagens_do_Produto";
                    $row['slug'] = "produto";
                    $table = "products_images";
                    $artigo = "a";
                    $html .= '
                    <div class="col-lg-3 col-3">
                        <!-- small box -->
                        <div class="small-box bg-success';
                        $html .= '">
                            <div class="inner">
                                <h3>';
                                $html .= $rows;
                        $html .= '</h3>
    
                                <p>'.$row['name'].' excluíd'.$artigo.'s até o momento</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-edit"></i>
                            </div>
                            <a href="'.URL.'admin/'.$row['slug'].'" class="small-box-footer">Ver as Informações de Cadastrados <i class="fas fa-arrow-circle-right"></i></a>
                            ';
                            if ($rows > 0){
                                $html .= '
                                <a onclick=verificaTodosExcluidos("'.$table.'","'.$row['name'].'","'.URL.'")  data-toggle="modal" data-target="#modalVerTodosExcluidos" style="cursor:pointer" class="small-box-footer">Ver Todos os Excluídos <i class="fas fa-arrow-circle-right"></i></a>';
                            }
                            $html .= '
                        </div>
                    </div>
                    ';
                    $sql = "SELECT * FROM products_videos WHERE deleted_at IS NOT NULL";
                    $query = mysqli_query($con, $sql);
                    $rows = mysqli_num_rows($query);
                    $row['name'] = "videos_do_Produto";
                    $row['slug'] = "produto";
                    $table = "products_videos";
                    $artigo = "o";
                    $html .= '
                    <div class="col-lg-3 col-3">
                        <!-- small box -->
                        <div class="small-box bg-warning';
                        $html .= '">
                            <div class="inner">
                                <h3>';
                                $html .= $rows;
                        $html .= '</h3>
    
                                <p>'.$row['name'].' excluíd'.$artigo.'s até o momento</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-edit"></i>
                            </div>
                            <a href="'.URL.'admin/'.$row['slug'].'" class="small-box-footer">Ver as Informações de Cadastrados <i class="fas fa-arrow-circle-right"></i></a>
                            ';
                            if ($rows > 0){
                                $html .= '
                                <a onclick=verificaTodosExcluidos("'.$table.'","'.$row['name'].'","'.URL.'")  data-toggle="modal" data-target="#modalVerTodosExcluidos" style="cursor:pointer" class="small-box-footer">Ver Todos os Excluídos <i class="fas fa-arrow-circle-right"></i></a>';
                            }
                            $html .= '
                        </div>
                    </div>
                    ';
                    break;
            case 'usuarios-pre':
                $sql = "SELECT a.* FROM user_pres a WHERE a.deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['emailFiltro']) {
                    $sql .= "AND ";
                    $sql .= "a.email = '" . $_REQUEST['emailFiltro'] . "' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Email</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($usuarios = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $usuarios->id . '</td>

                    <td style="padding:5px">' . ($usuarios->name) . '</td>

                    <td style="padding:5px">' . ($usuarios->email) . '</td>

                    <td style="padding:5px">
                         <a href="#" onclick=aprovaUsuario("'.$usuarios->id.'","'.URL.'","'.$_SESSION['user']['id'].'")><img src="' . URL . 'img/sucesso.png" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarUsuariosPre("' . $usuarios->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarUsuariosPre("' . $usuarios->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirUsuariosPre("' . $usuarios->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","usuário_pre")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios-pre","\'' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios-pre","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("usuarios-pre","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios-pre","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("usuarios-pre","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios-pre","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("usuarios-pre","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios-pre","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios-pre","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'tipoModulo':
                $sql = "SELECT a.* FROM type_modules a WHERE a.deleted_at IS NULL  ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($tipoModulo = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $tipoModulo->id . '</td>

                    <td style="padding:5px">' . ($tipoModulo->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarTipoModulo("' . $tipoModulo->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarTipoModulo("' . $tipoModulo->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirTipoModulo("' . $tipoModulo->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","tipoModulo")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoModulo","\'' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoModulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tipoModulo","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoModulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tipoModulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoModulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tipoModulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoModulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoModulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'modulo':
                $sql = "SELECT a.*, b.name AS nomeTipoModulo FROM modules a INNER JOIN type_modules b ON (a.typeModule = b.id) WHERE a.deleted_at IS NULL ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['tipoModuloFiltro']) {
                    $sql .= "AND ";
                    $sql .= "a.typeModule = '" . $_REQUEST['tipoModuloFiltro'] . "' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.typeModule ASC, a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                        $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Tipo de Módulo</th>
                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    ;$key = 0;
                    while ($modulo = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $modulo->id . '</td>

                    <td style="padding:5px">' . ($modulo->nomeTipoModulo) . '</td>

                    <td style="padding:5px">' . ($modulo->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarModulo("' . $modulo->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarModulo("' . $modulo->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirModulo("' . $modulo->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","modulo")><img src="' . URL . 'img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $html .= '</tbbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("modulo","\'' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("modulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                        $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("modulo","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                        if ($_REQUEST['pagina'] >= 11) {
                            $proxima2 = $inicial - 1;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("modulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                        }
                        for ($j = $inicial; $j < $final; $j++) {
                            if ($j < $totalPaginacao && $j > 1) {
                                $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("modulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                            }
                        }
                        if ($totalPaginacao > 11) {
                            $vaiAte = (floor($totalPaginacao / 10)) * 10;
                            if ($vaiAte >= $_REQUEST['pagina']) {
                                $proxima2 = $final;
                                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("modulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                            }
                        }
                        if ($totalPaginacao > 1) {
                            $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("modulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                            $proxima = $_REQUEST['pagina'] + 1;
                            if ($proxima > $totalPaginacao) {
                                $proxima = $totalPginacao;
                            }
                        } else {
                            $proxima = 2;
                            if ($proxima > $totalPaginacao) {
                                $proxima = $totalPginacao;
                            }
                        }
                        $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("modulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("modulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
                case 'logs':
                    $sql = "SELECT a.*, b.name AS nomeUsuario FROM logs a INNER JOIN users b ON (a.user = b.id) ";
                    if ($_REQUEST['usuarioFiltro']) {
                        $sql .= "WHERE a.user = '" . $_REQUEST['usuarioFiltro'] . "' ";
                        $where = 1;
                    }
                    if ($_REQUEST['acaoFiltro']) {
                        if ($where) {
                            $sql .= "AND ";
                        } else {
                            $sql .= "WHERE ";
                        }
                        $sql .= "a.action LIKE '%" . $_REQUEST['acaoFiltro'] . "%' ";
                        $where = 1;
                    }
                    if ($_REQUEST['idUser'] != 1) {
                        if ($where) {
                            $sql .= "AND ";
                        } else {
                            $sql .= "WHERE ";
                        }
                        $sql .= "a.user = '" . $_REQUEST['idUser'] . "' ";
                        $where = 1;
                    }
                    $sql .= "ORDER BY a.created_at DESC";
                    $query = mysqli_query($con, $sql);
                    $total = mysqli_num_rows($query);
                    $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                    $totalPaginacao = ceil($total / 15);
                    if ($totalPaginacao == $_REQUEST['pagina']) {
                        $paginacaoProxima = $_REQUEST['pagina'];
                    } elseif ($totalPaginacao > 1) {
                        $paginacaoProxima = $_REQUEST['pagina'] + 1;
                    } else {
                        $paginacaoAnterior = 1;
                    }
                    if ($_REQUEST['pagina'] <= 10) {
                        $inicial = 1;
                    } else {
                        $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                    }
                    $final = $inicial + 10;
                    $sql .= " LIMIT " . $offSet . ", 15";
                    $query = mysqli_query($con, $sql);
                    if (mysqli_num_rows($query)) {
                        $html .= '<table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                    <tr>
                                        <th>Nome do Usuário</th>
                                        <th>Ação</th>
                                        <th>Data / Hora</th>
                                    </tr>
                                    </thead>
                                    <tbody>';
                        $key = 0;
                        while ($usuarios = mysqli_fetch_object($query)) {
                            $vet = explode(' ', $usuarios->created_at);
                            $vet2 = explode('-', $vet[0]);
                            $usuarios->created_at = $vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h";
                            $html .= '<tr>
    
                        <td style="padding:5px">' . ($usuarios->nomeUsuario) . '</td>
    
                        <td style="padding:5px">' . ($usuarios->action) . '</td>
    
                        <td style="padding:5px">' . ($usuarios->created_at) . '</td>
    
                    </tr>';
                            $key++;
                        }
                        $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                        $html .= '</table>
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title">
                      <i class="ion pagination mr-1"></i>
                      Paginação
                    </h3>
    
                    <div class="card-tools">
                        <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("logs","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("logs","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                            ';
                        $background = ($_REQUEST['pagina'] == 1) ? "#CCCCCC" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("logs","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                        if ($_REQUEST['pagina'] >= 11) {
                            $proxima2 = $inicial - 1;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("logs","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                       ';
                        }
                        for ($j = $inicial; $j < $final; $j++) {
                            if ($j < $totalPaginacao && $j > 1) {
                                $background = ($_REQUEST['pagina'] == $j) ? "#CCCCCC" : "";
                                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("logs","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                            ';
                            }
                        }
                        if ($totalPaginacao > 11) {
                            $vaiAte = (floor($totalPaginacao / 10)) * 10;
                            if ($vaiAte >= $_REQUEST['pagina']) {
                                $proxima2 = $final;
                                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("logs","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                            }
                        }
                        if ($totalPaginacao > 1) {
                            $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#CCCCCC" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("logs","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                       ';
                            $proxima = $_REQUEST['pagina'] + 1;
                            if ($proxima > $totalPaginacao) {
                                $proxima = $totalPginacao;
                            }
                        } else {
                            $proxima = 2;
                            if ($proxima > $totalPaginacao) {
                                $proxima = $totalPginacao;
                            }
                        }
                        $html .= '
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("logs","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("logs","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                       </ul></div>
                        </div>
                        </div>';
                    } else {
                        $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                    }
                    break;
                    case 'logsClient':
                        $sql = "SELECT a.*, c.name AS nomeCliente, d.razaoSocial, d.contato FROM logs_clients a INNER JOIN clients b ON (a.client = b.id) LEFT JOIN pessoa_fisicas c ON (b.id = c.client) LEFT JOIN pessoa_juridicas d ON (b.id = d.client) ";
                        if ($_REQUEST['clienteFiltro']) {
                            $sql .= "WHERE (c.name LIKE '%" . $_REQUEST['clienteFiltro'] . "%' OR d.razaoSocial LIKE '%".$_REQUEST['clienteFiltro']."%' OR d.nomeFantasia LIKE '%".$_REQUEST['clienteFiltro']."%' OR d.contato LIKE '%".$_REQUEST['clienteFiltro']."%') ";
                            $where = 1;
                        }
                        if ($_REQUEST['acaoFiltro']) {
                            if ($where) {
                                $sql .= "AND ";
                            } else {
                                $sql .= "WHERE ";
                            }
                            $sql .= "a.action LIKE '%" . $_REQUEST['acaoFiltro'] . "%' ";
                            $where = 1;
                        }
                        if ($_REQUEST['dataFiltro']) {
                            if ($where) {
                                $sql .= "AND ";
                            } else {
                                $sql .= "WHERE ";
                            }
                            $sql .= "a.created_at LIKE '%" . $_REQUEST['dataFiltro'] . "%' ";
                            $where = 1;
                        }
                        $sql .= "ORDER BY a.created_at DESC";
                        $query = mysqli_query($con, $sql);
                        $total = mysqli_num_rows($query);
                        $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                        $totalPaginacao = ceil($total / 15);
                        if ($totalPaginacao == $_REQUEST['pagina']) {
                            $paginacaoProxima = $_REQUEST['pagina'];
                        } elseif ($totalPaginacao > 1) {
                            $paginacaoProxima = $_REQUEST['pagina'] + 1;
                        } else {
                            $paginacaoAnterior = 1;
                        }
                        if ($_REQUEST['pagina'] <= 10) {
                            $inicial = 1;
                        } else {
                            $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                        }
                        $final = $inicial + 10;
                        $sql .= " LIMIT " . $offSet . ", 15";
                        $query = mysqli_query($con, $sql);
                        if (mysqli_num_rows($query)) {
                            $html .= '<table id="example2" class="table table-bordered table-hover">
                                        <thead>
                                        <tr>
                                            <th>Nome do Cliente</th>
                                            <th>Ação</th>
                                            <th>Data / Hora</th>
                                        </tr>
                                        </thead>
                                        <tbody>';
                            $key = 0;
                            while ($usuarios = mysqli_fetch_object($query)) {
                                $vet = explode(' ', $usuarios->created_at);
                                $vet2 = explode('-', $vet[0]);
                                $usuarios->created_at = $vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h";
                                $nomeCliente = ($usuarios->nomeCliente) ? utf8_encode($usuarios->nomeCliente) : utf8_encode($usuarios->razaoSocial." - ".$usuarios->contato);
                                $html .= '<tr>
        
                            <td style="padding:5px">' . utf8_decode($nomeCliente). '</td>
        
                            <td style="padding:5px">' . utf8_encode($usuarios->action) . '</td>
        
                            <td style="padding:5px">' . ($usuarios->created_at) . '</td>
        
                        </tr>';
                                $key++;
                            }
                            $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                            $html .= '</table>
                    <div class="card">
                      <div class="card-header">
                        <h3 class="card-title">
                          <i class="ion pagination mr-1"></i>
                          Paginação
                        </h3>
        
                        <div class="card-tools">
                            <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                                <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("logsClient","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                                <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("logsClient","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                                ';
                            $background = ($_REQUEST['pagina'] == 1) ? "#CCCCCC" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("logsClient","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                            if ($_REQUEST['pagina'] >= 11) {
                                $proxima2 = $inicial - 1;
                                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("logsClient","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                           ';
                            }
                            for ($j = $inicial; $j < $final; $j++) {
                                if ($j < $totalPaginacao && $j > 1) {
                                    $background = ($_REQUEST['pagina'] == $j) ? "#CCCCCC" : "";
                                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("logsClient","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                                ';
                                }
                            }
                            if ($totalPaginacao > 11) {
                                $vaiAte = (floor($totalPaginacao / 10)) * 10;
                                if ($vaiAte >= $_REQUEST['pagina']) {
                                    $proxima2 = $final;
                                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("logsClient","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                                }
                            }
                            if ($totalPaginacao > 1) {
                                $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#CCCCCC" : "";
                                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("logsClient","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                           ';
                                $proxima = $_REQUEST['pagina'] + 1;
                                if ($proxima > $totalPaginacao) {
                                    $proxima = $totalPginacao;
                                }
                            } else {
                                $proxima = 2;
                                if ($proxima > $totalPaginacao) {
                                    $proxima = $totalPginacao;
                                }
                            }
                            $html .= '
                                <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("logsClient","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                                <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("logsClient","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                           </ul></div>
                            </div>
                            </div>';
                        } else {
                            $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                        }
                        break;
        }
        echo "1|-|".$html;
        break;
    case "editaProdutoPedido":
        $sql = "SELECT * FROM requests_items WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        echo "1|-|".$row['product']."|-|".$row['product_item']."|-|".$row['id'];
        break;
    case "excluirItemPedido":
        $sql = "DELETE FROM requests_items WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo "1";
        break;    
    case 'verRegistrosExcluidos':
        $sql = "SELECT * FROM ".$_REQUEST['table']." WHERE deleted_at IS NOT NULL";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $html .= '<h3 style="text-align:center">'.$_REQUEST['nome'].'</h3>
            <div style="width:100%; border:1px solid #e6e6e6; padding:5px;" id="mostraBotoesRegistroExcluido"><button class="btn btn-success" onclick=voltarTodosSelecionados("'.$_REQUEST['table'].'","'.$_REQUEST['nome'].'","'.URL.'")>Voltar Todos os Selecionados</button> <button class="btn btn-primary" onclick=excluirTodosSelecionados("'.$_REQUEST['table'].'","'.$_REQUEST['nome'].'","'.URL.'")>Excluir Todos os Selecionados</button></div>
            <table id="example2" class="table table-bordered table-hover" style="padding:15px">
            <tr>
            <th id="selDescTodas"><a style="cursor:pointer;" onclick=selecionarTodas("'.mysqli_num_rows($query).'","'.$_REQUEST['table'].'","'.$_REQUEST['nome'].'",false)>Desmarcar</a></th>
            <th>Nome</th>
            <th>Data da Exclusão</th>
            <th>Ações</th>
            </tr>
            ';
            $i = 1;
            $html .= '<input type="hidden" name="totalRegistrosExcluidos" id="totalRegistrosExcluidos" value="'.mysqli_num_rows($query).'">';
            while ($row = mysqli_fetch_array($query)){
                $vet = explode(' ', $row['deleted_at']);
                $vet2 = explode('-', $vet[0]);
                $row['deleted_at'] = $vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h";
                $html .= '<tr>
                    <td style="text-align:center"><input type="checkbox" name="selItem'.$i.'" id="selItem'.$i.'" checked onchange=selItemRegExcluidos("'.$row['id'].'","'.$i.'","'.URL.'","'.$_REQUEST['table'].'","'.$_REQUEST['nome'].'")></td>
                    <td>'.$row['name'].'</td>
                    <td>'.$row['deleted_at'].'</td>
                    <td><img src="'.URL.'img/voltar.png" width="20" style="cursor:pointer" onclick=voltarRegistroExcluido("'.$row['id'].'","'.$_REQUEST['table'].'","'.$_REQUEST['nome'].'","'.URL.'")> <img src="'.URL.'img/excluir.png" width="20" style="cursor:pointer" onclick=excluirRegistroExcluido("'.$row['id'].'","'.$_REQUEST['table'].'","'.$_REQUEST['nome'].'","'.URL.'")></td>
                </tr>';
                $i++;
            }
            $html .= '</table>';
        }
        echo "1|-|".$html;
        break;
        case 'voltarRegistroExcluidos':
            $sql = "UPDATE ".$_REQUEST['table']." SET deleted_at = NULL WHERE id = '".$_REQUEST['id']."'";
            mysqli_query($con, $sql);
            echo "1";
            break;
        case 'excluirRegistroExcluidos':
            $sql = "DELETE FROM ".$_REQUEST['table']." WHERE id = '".$_REQUEST['id']."'";
            mysqli_query($con, $sql);
            echo "1";
            break;
        case "voltarTodosSelecionados":
            $vet2 = explode('|-|', $_REQUEST['checkadas']);
            $sql = "SELECT * FROM ".$_REQUEST['table']." WHERE deleted_at IS NOT NULL";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                $i = 1;
                while ($row = mysqli_fetch_array($query)){
                    foreach ($vet2 as $key => $value){
                        if ($value == $i){
                            $sql =  "UPDATE ".$_REQUEST['table']." SET deleted_at = NULL WHERE id = '".$row['id']."'";
                            mysqli_query($con, $sql);
                        }
                    }
                    $i++;
                }
            }
             echo "1";
            break;
        case "excluirTodosSelecionados":
            $vet2 = explode('|-|', $_REQUEST['checkadas']);
            $sql = "SELECT * FROM ".$_REQUEST['table']." WHERE deleted_at IS NOT NULL";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                $i = 1;
                while ($row = mysqli_fetch_array($query)){
                    foreach ($vet2 as $key => $value){
                        if ($value == $i){
                            $sql =  "DELETE FROM ".$_REQUEST['table']." WHERE id = '".$row['id']."'";
                            mysqli_query($con, $sql);
                        }
                    }
                    $i++;
                }
            }
                echo "1";
            break;
        case "voltarTodosExcluidos":
            $sql = "UPDATE ".$_REQUEST['table']." SET deleted_at = NULL WHERE deleted_at IS NOT NULL";
            mysqli_query($con, $sql) or die(mysqli_error($con));
            echo "1";
            break;
        case "excluirTodosExcluidos":
            $sql = "DELETE FROM ".$_REQUEST['table']." WHERE deleted_at IS NOT NULL";
            mysqli_query($con, $sql) or die(mysqli_error($con));
            echo "1";
            break;
    case "incluirItemPedido":
        $sql = "SELECT * FROM products_items WHERE id = '".$_REQUEST['product_item']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $valor = ($row['promotion'] && $row['validity_promotion'] > date('Y-m-d')) ? $row['promotion'] : $row['value'];
        $sql = "INSERT INTO requests_items (request, product, ";
        for ($i = 1; $i <= 10; $i++){
            $sql .= "attribute".$i.", ";
        }
        $sql .= "name, domine, quantity, value, created_at, updated_at) VALUES ('".$_REQUEST['request']."', '".$_REQUEST['product']."', ";
        for ($i = 1; $i <= 10; $i++){
            $sql .= "'".$_REQUEST["attribute".$i]."'', ";
        }
        $sql .= " '".$row['name']."', '".$_REQUEST['domine']."', '1', '".$valor."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql);
        $idRequestItem = mysqli_insert_id($con);
        if ($_REQUEST['product'] == 3){
            $sql = "INSERT INTO cashier_system (razao_social, nome_fantasia, email, cnpj, cep, logradouro, numero, complemento, bairro, cidade, estado, tipoEstabelecimento, quantidade, numeroPessoasPorMesa, percentual) VALUES ('".$_REQUEST['razaoSocial']."', '".$_REQUEST['nomeFantasia']."', '".$_REQUEST['email']."', '".$_REQUEST['cnpj']."', '".$_REQUEST['cep']."', '".$_REQUEST['logradouro']."', '".$_REQUEST['numero']."', '".$_REQUEST['complemento']."', '".$_REQUEST['bairro']."', '".$_REQUEST['cidade']."', '".$_REQUEST['estado']."', '".$_REQUEST['tipoEstabelecimento']."', '".$_REQUEST['quantidade']."', '".$_REQUEST['numPessoas']."', '".$_REQUEST['perGarcom']."')";
            mysqli_query($con, $sql);
            $idSistemaCaixa = mysqli_insert_id($con);
            $sql = "UPDATE requests_items SET cashier_system = '".$idSistemaCaixa."' WHERE id = '".$idRequestItem."'";
            mysqli_query($con, $sql);
        }
        if ($_REQUEST['product'] == 4){
            $sql = "INSERT INTO school_system (nome, email, cep, logradouro, numero, complemento, bairro, cidade, estado, tipoNota, turno, letra) VALUES ('".$_REQUEST['nome']."', '".$_REQUEST['email']."', '".$_REQUEST['cep']."', '".$_REQUEST['logradouro']."', '".$_REQUEST['numero']."', '".$_REQUEST['complemento']."', '".$_REQUEST['bairro']."', '".$_REQUEST['cidade']."', '".$_REQUEST['estado']."', '".$_REQUEST['tipoNota']."', '".$_REQUEST['turno']."', '".$_REQUEST['letra']."')";
            mysqli_query($con, $sql);
            $idSistemaEscola = mysqli_insert_id($con);
            $sql = "UPDATE requests_items SET school_system = '".$idSistemaEscola."' WHERE id = '".$idRequestItem."'";
            mysqli_query($con, $sql);
        }
        echo "1";
        break;
    case "editarItemPedido":
        $sql = "SELECT * FROM products_items WHERE id = '".$_REQUEST['product_item']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $valor = ($row['promotion'] && $row['validity_promotion'] > date('Y-m-d')) ? $row['promotion'] : $row['value'];
        $sql = "UPDATE requests_items SET product = '".$_REQUEST['product']."', product_item = '".$_REQUEST['product_item']."', name = '".$row['name']."', domine = '".$_REQUEST['domine']."', quantity = '1', value = '".$valor."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "productItemCadastro":
        $sql = "SELECT * FROM products_items WHERE id = '".$_REQUEST['id']."' ";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        if ($row['product'] != 3 && $row['product'] != 4) {
            $html .= "<label for='domineCadastro'>Domínio:</label><input type='text' name='domineCadastro' id='domineCadastro' required class='form-control'>";
        }
        elseif ($row['product'] == 3){
            $html .= "
            <label for='razaoSocialCaixa'>Razão Social:</label>
            <input type='text' name='razaoSocialCaixa' id='razaoSocialCaixa' required class='form-control'>
            <label for='nomeFantasiaCaixa'>Nome Fantasia:</label>
            <input type='text' name='nomeFantasiaCaixa' id='nomeFantasiaCaixa' required class='form-control'>
            <label for='emailCaixa'>Email:</label>
            <input type='email' name='emailCaixa' id='emailCaixa' required class='form-control'>
            <label for='cnpjCaixa'>CNPJ:</label>
            <input type='text' name='cnpjCaixa' id='cnpjCaixa' required class='form-control' onkeypress=\"return mascara(this, '00.000.000/0000-00', event)\">
            <label for='cepCaixa'>CEP:</label>
            <input type='text' name='cepCaixa' id='cepCaixa' required class='form-control' onkeypress=\"return mascara(this, '00000-000', event)\" onkeyup=\"verificacepcaixa(this.value)\">
            <label for='logradouroCaixa'>Logradouro:</label>
            <input type='text' name='logradouroCaixa' id='logradouroCaixa' required class='form-control'>
            <label for='numeroCaixa'>Numero:</label>
            <input type='text' name='numeroCaixa' id='numeroCaixa' required class='form-control'>
            <label for='complementoCaixa'>Complemento:</label>
            <input type='text' name='complementoCaixa' id='complementoCaixa' class='form-control'>
            <label for='bairroCaixa'>Bairro:</label>
            <input type='text' name='bairroCaixa' id='bairroCaixa' required class='form-control'>
            <label for='cidadeCaixa'>Cidade:</label>
            <input type='text' name='cidadeCaixa' id='cidadeCaixa' required class='form-control'>
            <label for='estadoCaixa'>Estado:</label>
            <select name='estadoCaixa' id='estadoCaixa' required class='form-control'>
                <option value=''>Selecione o estado corretamente...</option>";
            $sql = "SELECT * FROM states ORDER BY sigla ASC";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                while ($row = mysqli_fetch_array($query)){
                    $html .= "<option value='".$row['sigla']."'>".$row['sigla']."</option>";
                }
            }
            $html .="
            </select>
            <label for='tipoEstabelecimentoCaixa'>Tipo do Estabelecimento:</label>
            <select name='tipoEstabelecimentoCaixa' id='tipoEstabelecimentoCaixa' required class='form-control' onchange='selecionaTipoEstabelecimento(this.value)'>
                <option value=''>Selecione o tipo do estabelecimento corretamente...</option>
                <option value='1'>Mesas</option>
                <option value='2'>Caixas</option>
            </select>
            <div id='tiposEstabelecimentoRealizarPedido'></div>";
        }
        elseif ($row['product'] == 4){
            $html .= "
            <label for='nomeEscola'>Nome da Escola:</label>
            <input type='text' name='nomeEscola' id='nomeEscola' required class='form-control'>
            <label for='emailEscola'>Email da Escola:</label>
            <input type='text' name='emailEscola' id='emailEscola' required class='form-control'>
            <label for='cepEscola'>CEP:</label>
            <input type='text' name='cepEscola' id='cepEscola' required class='form-control' onkeypress=\"return mascara(this, '00000-000', event)\" onkeyup=\"verificacepescolar(this.value)\">
            <label for='logradouroEscola'>Logradouro:</label>
            <input type='text' name='logradouroEscola' id='logradouroEscola' required class='form-control'>
            <label for='numeroEscola'>Numero:</label>
            <input type='text' name='numeroEscola' id='numeroEscola' required class='form-control'>
            <label for='complementoEscola'>Complemento:</label>
            <input type='text' name='complementoEscola' id='complementoEscola' class='form-control'>
            <label for='bairroEscola'>Bairro:</label>
            <input type='text' name='bairroEscola' id='bairroEscola' required class='form-control'>
            <label for='cidadeEscola'>Cidade:</label>
            <input type='text' name='cidadeEscola' id='cidadeEscola' required class='form-control'>
            <label for='estadoEscola'>Estado:</label>
            <select name='estadoEscola' id='estadoEscola' required class='form-control'>
                <option value=''>Selecione o estado corretamente...</option>";
            $sql = "SELECT * FROM states ORDER BY sigla ASC";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                while ($row = mysqli_fetch_array($query)){
                    $html .= "<option value='".$row['sigla']."'>".$row['sigla']."</option>";
                }
            }
            $html .="
            </select>
            <label for='tipoNotaEscola'>Tipo de Nota:</label>
            <select name='tipoNotaEscola' id='tipoNotaEscola' required class='form-control'>
                <option value=''>Selecione o tipo de nota corretamente...</option>
                <option value='1'>Bimestral</option>
                <option value='2'>Trimestral</option>
                <option value='3'>Semestral</option>
                <option value='4'>Anual</option>
            </select>
            <label for='turnoEscola'>Turno da Escola:</label>
            <select name='turnoEscola' id='turnoEscola' required class='form-control'>
                <option value=''>Selecione o turno da escola corretamente...</option>
                <option value='1'>Manhã</option>
                <option value='2'>Tarde</option>
                <option value='3'>Noite</option>
                <option value='4'>Único</option>
                <option value='5'>Todos</option>
            </select>
                <label for='letraEscola'>Letra da Escola:</label>
                     <select name='letraEscola' id='letraEscola' required class='form-control'>
                     <option value=''>Selecione até que letra a escola vai abaixo...</option>";
                     for($i = 0; $i <= 26; $i++) {
                         switch ($i){
                             case 0:
                                 $letra = "Única";
                                 $l = "Un";
                                 break;
                             case 1:
                                 $letra = "A";
                                 break;
                             case 2:
                                 $letra = "B";
                                 break;
                             case 3:
                                 $letra = "C";
                                 break;
                             case 4:
                                 $letra = "D";
                                 break;
                             case 5:
                                 $letra = "E";
                                 break;
                             case 6:
                                 $letra = "F";
                                 break;
                             case 7:
                                 $letra = "G";
                                 break;
                             case 8:
                                 $letra = "H";
                                 break;
                             case 9:
                                 $letra = "I";
                                 break;
                             case 10:
                                 $letra = "J";
                                 break;
                             case 11:
                                 $letra = "K";
                                 break;
                             case 12:
                                 $letra = "L";
                                 break;
                             case 13:
                                 $letra = "M";
                                 break;
                             case 14:
                                 $letra = "N";
                                 break;
                             case 15:
                                 $letra = "O";
                                 break;
                             case 16:
                                 $letra = "P";
                                 break;
                             case 17:
                                 $letra = "Q";
                                 break;
                             case 18:
                                 $letra = "R";
                                 break;
                             case 19:
                                 $letra = "S";
                                 break;
                             case 20:
                                 $letra = "T";
                                 break;
                             case 21:
                                 $letra = "U";
                                 break;
                             case 22:
                                 $letra = "V";
                                 break;
                             case 23:
                                 $letra = "W";
                                 break;
                             case 24:
                                 $letra = "X";
                                 break;
                             case 25:
                                 $letra = "Y";
                                 break;
                             case 26:
                                 $letra = "Z";
                                 break;
                         }
                         if ($i > 0){
                             $l = $letra;
                         }
                         $html .= "<option value='".$l."'>".$letra."</option>";
                     }
                     $html .= "
                     </select>";
        }
        $html .= "<br>
                            <button type=\"button\" onclick=\"incluirItem('".URL."')\"class=\"btn btn-primary\">Gravar</button>";
        echo "1|-|".$html;
        break;
    case "productItemEdita":
        $sql = "SELECT * FROM requests_items WHERE product_item = '".$_REQUEST['id']."' AND request = '".$_REQUEST['request']."' AND product = '".$_REQUEST['product']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        if ($row['product'] != 3 && $row['product'] != 4) {
            $html .= "<label for='domineEdita'>Domínio:</label><input type='text' name='domineEdita' id='domineEdita' required class='form-control' value='".$row['domine']."'>";
        }
        $html .= "<br>
                            <button type=\"button\" onclick=\"atualizarItem('".URL."')\"class=\"btn btn-primary\">Gravar</button>";
        echo "1|-|".$html;
        break;
    case "selecionaProdutoCadastro":
        $html = "<label for='productItemCadastro'>Item do Produto</label>
                 <select name='productItemCadastro' id='productItemCadastro' required class='form-control' onchange=selectProductItemCadastro(this.value,'".URL."')>
                    <option value=''>Selecione o item do produto abaixo...</option>";
        $sql = "SELECT * FROM products_items WHERE product = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                $valor = ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')) ? $row['promotion'] : $row['value'];
                $html .= "<option value='".$row['id']."'>".utf8_encode($row['name'])." - R$ ".number_format($valor, 2, ',', '.')."</option>";
            }
        }
        $html .= "</select><div id='productsItemCadastro'></div>";
        echo "1|-|".$html;
        break;
    case "selecionaEnderecoPedido":
        $sql = "SELECT * FROM addresses WHERE id = '" . $_REQUEST['id'] . "'";
        $query = mysqli_query($con, $sql);
        $endereco = mysqli_fetch_object($query);
        $html = "<b>Nome do Endereço:</b> " . utf8_encode($endereco->name) . "<br>
                                          <b>CEP do Endereço:</b> " . utf8_encode($endereco->cep) . "<br>
                                          <b>Logradouro do Endereço:</b> " . utf8_encode($endereco->address) . "<br>
                                          <b>Número do Endereço:</b> " . utf8_encode($endereco->number);
        if ($endereco->complement) {
            $html .= "<br>
                                          <b>Complemento do Endereço:</b> " . utf8_encode($endereco->complement);
        }
        $html .= "<br>
                                          <b>Bairro do Endereço:</b> " . utf8_encode($endereco->neighborhood);
        $html .= "<br>
                                          <b>Cidade do Endereço:</b> " . utf8_encode($endereco->city);
        $html .= "<br>
                                          <b>Estado do Endereço:</b> " . utf8_encode($endereco->state);
        echo "1|-|" . $html;
        break;
    case "pegaEnderecosCliente":
        $sql = "SELECT * FROM addresses WHERE idClient = '" . $_REQUEST['idCliente'] . "'";
        $query = mysqli_query($con, $sql);
        $html = "<label for='enderecoPedido'>Endereço do Cliente:</label><select name='enderecoPedido' id='enderecoPedido' class='form-control' required onchange=selecionaEnderecoPedido(this.value,'" . URL . "')><option value=''>Selecione o endereço abaixo corretamente...</option>";
        while ($value = mysqli_fetch_object($query)) {
            $html .= "<option value='$value->id'";
            if ($_REQUEST['idEndereco'] == $value->id) {
                $endereco = $value;
                $html .= " selected";
            }
            $html .= ">" . utf8_encode($value->name . " - " . $value->address . " ... " . $value->city . " - " . $value->state) . "</option>";
        }
        $html .= "</select>";
        if (count($endereco)) {
            $html2 = "<b>Nome do Endereço:</b> " . utf8_encode($endereco->name) . "<br>
                                          <b>CEP do Endereço:</b> " . utf8_encode($endereco->cep) . "<br>
                                          <b>Logradouro do Endereço:</b> " . utf8_encode($endereco->address) . "<br>
                                          <b>Número do Endereço:</b> " . utf8_encode($endereco->number);
            if ($endereco->complement) {
                $html2 .= "<br>
                                          <b>Complemento do Endereço:</b> " . utf8_encode($endereco->complement);
            }
            $html2 .= "<br>
                                          <b>Bairro do Endereço:</b> " . utf8_encode($endereco->neighborhood);
            $html2 .= "<br>
                                          <b>Cidade do Endereço:</b> " . utf8_encode($endereco->city);
            $html2 .= "<br>
                                          <b>Estado do Endereço:</b> " . utf8_encode($endereco->state);
        }
    echo "1|-|$html|-|".$html2;
    break;
    case "selecionaClientePedido":
        $sql = "SELECT a.*, b.name AS nameTypeDocument FROM clients a INNER JOIN type_documents b ON (a.typeDocument = b.id)  WHERE a.id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $cliente = mysqli_fetch_object($query);
        $html = "
                            <div class=\"media text-muted pt-3\">
                                <p><b>Nome do Cliente: </b>".utf8_encode($cliente->name)."</p>
                            </div>
                            <div class=\"media text-muted pt-3\">
                                <p><b>Email do Cliente: </b>".$cliente->email."</p>
                            </div>
                            <div class=\"media text-muted pt-3\">
                                <p><b>Celular do Cliente: </b>$cliente->cel</p>
                            </div>
                            <div class=\"media text-muted pt-3\">
                                <p><b>Tipo de Documento do Cliente: </b>$cliente->nameTypeDocument</p>
                            </div>
                            <div class=\"media text-muted pt-3\">
                                <p><b>Documento do Cliente: </b>$cliente->document</p>
                            </div>";
        echo "1|-|".$html;
        break;
    case "pegaItensPedido":
        $sql = "SELECT * FROM products WHERE status = '1'";
        $query = mysqli_query($con, $sql);
        while ($row = mysqli_fetch_array($query)){
            $products[] = $row;
        }
        $sql = "SELECT * FROM requests_items WHERE request = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $html .= '<table border="0" width="100%" cellpadding="0" cellspacing="0">';
            if ($_REQUEST['cadastrar']){
                $html .= "<tr><td colspan='6'><button class='btn btn-primary' onClick='abre(\"cadastrarItem\")'>Cadastrar Item</button><div id='cadastrarItem' style='position: absolute; display:none; float: left; width:70%; padding:10px; background-color:#FFFFFF; border:1px solid #e7e7e7'><div style='position:absolute; float:left; left:95%; cursor:pointer' onclick=fecha('cadastrarItem')>&times;</div><input type='hidden' value='".$_REQUEST['id']."' name='requestCadastro' id='requestCadastro'><h3>Cadastro de Item</h3><label for='productCadastro'>Produto: </label><select class='form-control' name='productCadastro' id='productCadastro' onchange=selectProductCadastro(this.value,'".URL."')><option value=''>Selecione o produto...</option>";
                foreach($products as $key => $value){
                    $html .= "<option value='".$value['id']."'>".utf8_encode($value['name'])."</option>";
                }
                $html .= "</select><div id='selecionadoProdutoCadastro'></div></td></tr>";
            }
            $html .= "<div id='atualizarItem' style='position: absolute; display:none; float: left; width:70%; padding:10px; background-color:#FFFFFF; border:1px solid #e7e7e7'><div style='position:absolute; float:left; left:95%; cursor:pointer' onclick=fecha('atualizarItem')>&times;</div><input type='hidden' value='' name='idEdita' id='idEdita'><input type='hidden' value='".$_REQUEST['id']."' name='requestEdita' id='requestEdita'><h3>Edição de Item</h3><label for='productEdita'>Produto: </label><select class='form-control' name='productEdita' id='productEdita' onchange=selecionaProdutoEdita(this.value,'".$_REQUEST['id']."','".$_REQUEST['product']."','','".URL."')><option value=''>Selecione o produto...</option>";
                foreach($products as $key => $value){
                    $html .= "<option value='".$value['id']."'>".utf8_encode($value['name'])."</option>";
                }
                $html .= "</select><div id='selecionadoProdutoEdita'></div>
                        <tr>
                            <th style='text-align: center'>ID do Produto</th>
                            <th style='text-align: center'>Nome do Produto</th>
                            <th style='text-align: center'>Valor Unitário do Produto</th>
                            <th style='text-align: center'>Quantidade</th>
                            <th style='text-align: center'>Valor Total</th>";
            if ($_REQUEST['editar'] == 1 || $_REQUEST['excluir'] == 1){
                $html .= '<th style="text-align: center">Ações</th>';
            }
            $HTML .= '
                        </tr>';
            while ($row = mysqli_fetch_array($query)){
                $background = ($i % 2 == 0) ? "#e7e7e7" : "#ffffff";
                $html .= '<tr>
                            <td style="text-align:center; padding:5px; background-color: '.$background.'">'.$row['product'].'</td>
                            <td style="text-align:center; padding:5px; background-color: '.$background.'">'.utf8_encode($row['name']);
                if ($row['cashier_system']){
                    $sql = "SELECT * FROM cashier_system WHERE id = '".$row['cashier_system']."'";
                    $query2 = mysqli_query($con, $sql);
                    $row2 = mysqli_fetch_array($query2);
                    $html .= ' - <a onclick=verInformacoesCaixa("'.$row['cashier_system'].'") style="cursor:pointer">Ver informações do sistema</a>
                             <div id="informacoesCaixa" style="display:none; position:absolute; width:50%; background-color: #FFFFFF; border:1px solid #e7e7e7">
                                <div style="position:absolute; float::left; left: 95%; cursor: pointer" onclick=fecha("informacoesCaixa")>&times;</div>
                                <h3>Informações do Sistema de Caixa</h3>
                                Razão Social: <b>'.$row2['razao_social'].'</b><br>
                                Nome Fantasia: <b>'.$row2['nome_fantasia'].'</b><br>
                                E-mail: <b>'.$row2['email'].'</b><br>
                                CNPJ: <b>'.$row2['cnpj'].'</b><br>
                                CEP: <b>'.$row2['cep'].'</b><br>
                                Logradouro: <b>'.$row2['logradouro'].'</b><br>
                                Número: <b>'.$row2['numero'].'</b><br>';
                    if ($row2['complemento']){
                        $html .= "Complemento: <b>".$row2['complemento']."</b><br>";
                    }
                    $html .= '  Bairro: <b>'.$row2['bairro'].'</b><br>
                                Cidade: <b>'.$row2['cidade'].'</b><br>
                                Estado: <b>'.$row2['estado'].'</b><br>
                                Tipo do Estabelecimento: <b>';
                    if ($row2['tipoEstabelecimento'] == 1){
                        $tipoEstabelecimento = "Mesas";
                    }
                    else{
                        $tipoEstabelecimento = "Caixas";
                    }
                    $html .= $tipoEstabelecimento;
                    $html .= '</b><br>
                                Quantidade de '.$tipoEstabelecimento.': <b>'.$row2['quantidade'].'</b>';
                    if ($row2['tipoEstabelecimento'] == 1){
                        $html .= '<br>Número de Pessoas Por Mesa: <b>'.$row2['numeroPessoasPorMesa'].'</b>
                                    <br>Gorjeta do Garçom: <b>'.$row2['percentual'].'%</b>';
                    }
                   $html .= '</div>';
                }
                if ($row['school_system']){
                    $sql = "SELECT * FROM school_system WHERE id = '".$row['school_system']."'";
                    $query2 = mysqli_query($con, $sql);
                    $row2 = mysqli_fetch_array($query2);
                    $html .= ' - <a onclick=verInformacoesEscolar("'.$row['school_system'].'") style="cursor:pointer">Ver informações do sistema</a>
                             <div id="informacoesEscolar" style="display:none; position:absolute; width:50%; background-color: #FFFFFF; border:1px solid #e7e7e7">
                                <div style="position:absolute; float::left; left: 95%; cursor: pointer" onclick=fecha("informacoesEscolar")>&times;</div>
                                <h3>Informações do Sistema Escolar</h3>
                                Nome: <b>'.$row2['nome'].'</b><br>
                                E-mail: <b>'.$row2['email'].'</b><br>
                                CEP: <b>'.$row2['cep'].'</b><br>
                                Logradouro: <b>'.$row2['logradouro'].'</b><br>
                                Número: <b>'.$row2['numero'].'</b><br>';
                    if ($row2['complemento']){
                        $html .= "Complemento: <b>".$row2['complemento']."</b><br>";
                    }
                    $html .= '  Bairro: <b>'.$row2['bairro'].'</b><br>
                                Cidade: <b>'.$row2['cidade'].'</b><br>
                                Estado: <b>'.$row2['estado'].'</b><br>
                                Tipo de Nota: <b>';
                    if ($row2['tipoNota'] == 1){
                        $html .= 'Bimestral';
                    }
                    elseif ($row2['tipoNota'] == 2){
                        $html .= 'Trimestral';
                    }
                    elseif ($row2['tipoNota'] == 3){
                        $html .= 'Semestral';
                    }
                    elseif ($row2['tipoNota'] == 4){
                        $html .= 'Anual';
                    }
                    $html .= '</b><br>Turno: <b>';
                    if ($row2['turno'] == 1){
                        $html .= 'Manhã';
                    }
                    elseif ($row2['turno'] == 2){
                        $html .= 'Tarde';
                    }
                    elseif ($row2['turno'] == 3){
                        $html .= 'Noite';
                    }
                    elseif ($row2['turno'] == 4){
                        $html .= 'Único';
                    }
                    elseif ($row2['turno'] == 5){
                        $html .= 'Todos';
                    }
                    $html .= '</b><br>Letra: <b>';
                    if ($row2['letra'] == 'Un'){
                        $html .= "Única";
                    }
                    else{
                        $html .= $row2['letra'];
                    }
                    $html .= '</b></div>';
                }
                if ($row['domine']){
                    $html .= ' - <a href="'.$row['domine'].'" target="_blank" title="'.$row['domine'].'">'.substr($row['domine'], 0, 15)."...</a>";
                }
                $html .= '</td>
                            <td style="text-align:center; padding:5px; background-color: '.$background.'">R$'.number_format($row['value'], 2, ',', '.').'</td>
                            <td style="text-align:center; padding:5px; background-color: '.$background.'">'.$row['quantity'].'</td>
                            <td style="text-align:center; padding:5px; background-color: '.$background.'">R$'.number_format($row['value'] * $row['quantity'], 2, ',', '.').'</td>';
                if ($_REQUEST['editar'] == 1 || $_REQUEST['excluir'] == 1){
                    $html .= '<td style="text-align: center; padding:5px; background-color: '.$background.'">';
                    /*if ($_REQUEST['editar'] == 1){
                        $html .= '<img src="'.URL.'img/editar.png" style="cursor:pointer" onclick=editaProdutoPedido("'.$row['id'].'","'.$_REQUEST['id'].'","'.URL.'") width="15">';
                    }*/
                    if ($_REQUEST['excluir'] == 1){
                        $html .= '<img src="'.URL.'img/excluir.png" style="cursor:pointer" onclick=excluirItemPedido("'.$row['id'].'","'.$_REQUEST['id'].'","'.URL.'") width="15">';
                    }
                    $html .= '</td>';
                }

                $html .= '
                        </tr>';
                $i++;
                $valorTotal += $row['value'] * $row['quantity'];
            }
            $html .= '<tr>
                            <td style="padding:5px; text-align:center; width: 100%; background-color:#0069D9; color:#FFFFFF" colspan="6">Valor Total do Pedido: R$ '.number_format($valorTotal, 2, ',','.').'</td>
                        </tr></table>';
        }
        else{
            $html = "<div style='padding:5px; text-align:center; width: 100%; color:#FFFFFF; background-color: #FF0000'>Sem nenhum item encontrado!</div>";
        }
        echo "1|-|".$html;
        break;
    case "addPermissao":
        if ($_REQUEST['field'] == 'view'){
            $permissao = "visualizar";
        }
        elseif ($_REQUEST['field'] == 'register'){
            $permissao = "cadastrar";
        }
        elseif ($_REQUEST['field'] == 'delete'){
            $permissao = "excluir";
        }
        $sql = "INSERT INTO logs (user, action, created_at, updated_at) VALUES ('".$_REQUEST['userLog']."', '".utf8_decode("Adicionou a permissão de ".$permissao." o módulo ".$_REQUEST['module']."  do usuário  ").$_REQUEST['user']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql);
        $sql = "SELECT * FROM permissions WHERE module = '".$_REQUEST['module']."' AND user = '".$_REQUEST['user']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $sql = "UPDATE permissions SET `".$_REQUEST['field']."` = '1' WHERE id = '".$row['id']."'";
        }
        else{
            $sql = "INSERT INTO permissions (module, user, `".$_REQUEST['field']."`, created_at, updated_at) VALUES ('".$_REQUEST['module']."', '".$_REQUEST['user']."', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        }
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1";
        break;
    case "removePermissao":
        if ($_REQUEST['field'] == 'view'){
            $permissao = "visualizar";
        }
        elseif ($_REQUEST['field'] == 'register'){
            $permissao = "cadastrar";
        }
        elseif ($_REQUEST['field'] == 'delete'){
            $permissao = "excluir";
        }
        $sql = "INSERT INTO logs (user, action, created_at, updated_at) VALUES ('".$_REQUEST['userLog']."', '".utf8_decode("Removeu a permissão de ".$permissao." o módulo ".$_REQUEST['module']."  do usuário  ").$_REQUEST['user']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql);
        $sql = "SELECT * FROM permissions WHERE module = '".$_REQUEST['module']."' AND user = '".$_REQUEST['user']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $sql = "UPDATE permissions SET `".$_REQUEST['field']."` = '0' WHERE id = '".$row['id']."'";
        }
        else{
            $sql = "INSERT INTO permissions (module, user, `".$_REQUEST['field']."`, created_at, updated_at) VALUES ('".$_REQUEST['module']."', '".$_REQUEST['user']."', '0', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        }
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1";
        break;
    case "pegaPermissaoUsuario":
        echo "1|-|";
        $sql = "INSERT INTO logs (user, action, created_at, updated_at) VALUES ('".$_REQUEST['user']."', '".utf8_decode("Visualizou as permissões do usuário  ").$_REQUEST['id']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql);
        $sql = "SELECT a.*, b.name AS nameTypeModule FROM modules a INNER JOIN type_modules b ON (a.typeModule = b.id) ORDER BY a.typeModule ASC, a.id ASC";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            echo '
          <div style="float:left; width:25%">Módulo</div>
          <div style="float:left; width:25%">Visualiar</div>
          <div style="float:left; width:25%">Cadastrar</div>
          <div style="float:left; width:25%">Excluir</div> <br>
    ';
            while($row = mysqli_fetch_array($query)){
                $sql = "SELECT * FROM permissions WHERE user = '".$_REQUEST['id']."' AND module = '".$row['id']."'";
                $query2 = mysqli_query($con, $sql);
                $row2 = mysqli_fetch_array($query2);
                echo '<div style="float: left; width:25%; height:50px;';
                if ($i % 2 == 0){
                    echo 'background-color: #e7e7e7';
                }
                echo '">'.utf8_encode($row['nameTypeModule'].' => '.$row['name']).'</div>
    <div style="float: left; width:25%; height:50px; ';
                if ($i % 2 == 0){
                    echo 'background-color: #e7e7e7';
                }
                echo '" id="view'.$row['id'].$_REQUEST['id'].'">';
                if ($row2['view']){
                    echo '<img src="'.URL.'img/sucesso.png" width="20" style="cursor:pointer" onclick=removePermissao("'.$_REQUEST['id'].'","'.$row['id'].'","view","'.URL.'","'.$_REQUEST['user'].'")>';
                }
                else{
                    echo '<img src="'.URL.'img/erro.ico" width="20" style="cursor:pointer" onclick=adicionaPermissao("'.$_REQUEST['id'].'","'.$row['id'].'","view","'.URL.'","'.$_REQUEST['user'].'")>';
                }
                echo '</div>
    <div style="float: left; width:25%; height:50px; ';
                if ($i % 2 == 0){
                    echo 'background-color: #e7e7e7';
                }
                echo '" id="register'.$row['id'].$_REQUEST['id'].'">';
                if ($row2['register']){
                    echo '<img src="'.URL.'img/sucesso.png" width="20" style="cursor:pointer" onclick=removePermissao("'.$_REQUEST['id'].'","'.$row['id'].'","register","'.URL.'","'.$_REQUEST['user'].'")>';
                }
                else{
                    echo '<img src="'.URL.'img/erro.ico" width="20" style="cursor:pointer" onclick=adicionaPermissao("'.$_REQUEST['id'].'","'.$row['id'].'","register","'.URL.'","'.$_REQUEST['user'].'")>';
                }
                echo '</div>
    <div style="float: left; width:25%; height:50px; ';
                if ($i % 2 == 0){
                echo 'background-color: #e7e7e7';
                }
                echo '" id="delete'.$row['id'].$_REQUEST['id'].'">';
                if ($row2['delete']){
                    echo '<img src="'.URL.'img/sucesso.png" width="20" style="cursor:pointer" onclick=removePermissao("'.$_REQUEST['id'].'","'.$row['id'].'","delete","'.URL.'","'.$_REQUEST['user'].'")>';
                }
                else{
                    echo '<img src="'.URL.'img/erro.ico" width="20" style="cursor:pointer" onclick=adicionaPermissao("'.$_REQUEST['id'].'","'.$row['id'].'","delete","'.URL.'","'.$_REQUEST['user'].'")>';
                }
                echo '</div><br>
';
                $i++;
            }
        }
        else{
            echo '<div style="text-align:center; padding:10px; color:#FFFFFF; background-color: #FF0000">Sem nenhum módulo encontrado!</div>';
        }
        break;
    case "contaAcessoBanner":
        $sql = "SELECT * FROM counters_banners WHERE data = '".date('Y-m-d')."' AND banner = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $acessos = $row['acessos'] + 1;
            $sql = "UPDATE counters_banners SET acessos = '".$acessos."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$row['id']."'";
            mysqli_query($con, $sql);
        }
        else{
            $sql = "INSERT INTO counters_banners (banner, data, acessos, created_at, updated_at) VALUES ('".$_REQUEST['id']."', '".date('Y-m-d')."', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql);
        }
        echo "1";
        break;
    case "contaAcessoBusca":
        $sql = "SELECT * FROM counters_search WHERE data = '".date('Y-m-d')."' AND search = '".$_REQUEST['busca']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $acessos = $row['acessos'] + 1;
            $sql = "UPDATE counters_search SET acessos = '".$acessos."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$row['id']."'";
            mysqli_query($con, $sql);
        }
        else{
            $sql = "INSERT INTO counters_search (search, data, acessos, created_at, updated_at) VALUES ('".$_REQUEST['busca']."', '".date('Y-m-d')."', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql);
        }
        echo "1";
        break;
    case "contaAcessoSubitem":
        $sql = "SELECT * FROM counters_subitems WHERE data = '".date('Y-m-d')."' AND subitem = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $acessos = $row['acessos'] + 1;
            $sql = "UPDATE counters_subitems SET acessos = '".$acessos."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$row['id']."'";
            mysqli_query($con, $sql);
        }
        else{
            $sql = "INSERT INTO counters_subitems (subitem, data, acessos, created_at, updated_at) VALUES ('".$_REQUEST['id']."', '".date('Y-m-d')."', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql);
        }
        echo "1";
        break;
    case "contaAcessoPagina":
        $sql = "SELECT * FROM counters_pages WHERE data = '".date('Y-m-d')."' AND page = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $acessos = $row['acessos'] + 1;
            $sql = "UPDATE counters_pages SET acessos = '".$acessos."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$row['id']."'";
            mysqli_query($con, $sql);
        }
        else{
            $sql = "INSERT INTO counters_pages (page, data, acessos, created_at, updated_at) VALUES ('".$_REQUEST['id']."', '".date('Y-m-d')."', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql);
        }
        echo "1";
        break;
    case "abreImagemProduto":
        $sql = "SELECT a.*, b.name AS nomeProduto FROM products_images a INNER JOIN products b ON (a.product = b.id) WHERE a.id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
		$i = 1;
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            echo "1|-|Foto do Produto ".utf8_encode($row['nomeProduto']."|-|<img src='".URL."img/upload/".$row['img']."' width='100%' style='cursor:pointer' data-dismiss='modal' aria-label='Fechar' title='".utf8_decode($row['name'])."'>".utf8_decode($row['name']))."|-|";
			$sql = "SELECT * FROM products_images WHERE product = '".$row['product']."' AND product_item = '".$row['product_item']."'";
			$query2 = mysqli_query($con, $sql);
			$tot = mysqli_num_rows($query2);
			if ($tot > 0){
				while ($row2 = mysqli_fetch_array($query2)){
					$fotos[$i] = $row2;
					if ($row2['id'] == $row['id']){
						$estaNa = $i;
					}
					$i++;
				}
			}
			$sql = "SELECT * FROM products_images WHERE product = '".$row['product']."' AND product_item = '".$row['product_item']."'";
			$query2 = mysqli_query($con, $sql);
			$tot = mysqli_num_rows($query2);
			if ($tot > 1){
				if ($estaNa == 1){
					$anterior = $tot;
					$proximo = $estaNa + 1;
				}
				elseif($estaNa == $tot){
					$anterior = $estaNa - 1;
					$proximo = 1;
				}
				else{
					$anterior = $estaNa - 1;
					$proximo = $estaNa + 1;
				}
				echo "<img src='".URL."img/esquerda.png' width='35' style='cursor:pointer' onclick=abreImagemProduto('".$fotos[$anterior]['id']."','".URL."')> <img src='".URL."img/direita.png' width='35' style='cursor:pointer' onclick=abreImagemProduto('".$fotos[$proximo]['id']."','".URL."')>";
			}
        }
        break;
    case "contaAcesso":
        if (!$_SESSION['contador']){
            $sql = "SELECT * FROM counters WHERE data = '".date('Y-m-d')."'";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                $row = mysqli_fetch_array($query);
                $acessos = $row['acessos'] + 1;
                $sql = "UPDATE counters SET acessos = '".$acessos."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$row['id']."'";
                mysqli_query($con, $sql);
            }
            else{
                $sql = "INSERT INTO counters (data, acessos, created_at, updated_at) VALUES ('".date('Y-m-d')."', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                mysqli_query($con, $sql);
            }
            $_SESSION['contador'] = 1;
        }
        if (!$_REQUEST['url']){
            $url = "pagina";
            $url2 = 'home';
        }
        else{
            $url = $_REQUEST['url'];
            $url2 = $_REQUEST['url2'];
        }
        if ($url == "pagina"){
            $table = "pages";
            $field = "page";
        }
        elseif ($url == "departamento"){
            $table = "departaments";
            $field = "departament";
        }
        elseif ($url == "marca"){
            $table = "brands";
            $field = "brand";
        }
        elseif ($url == "sugestao"){
            $table = "suggestions";
            $field = "suggestion";
        }
        elseif ($url == "produto"){
            $table = "products";
            $field = "product";
        }
        $sql = "SELECT * FROM ".$table." WHERE slug = '".$url2."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $qual = $row['id'];
        $sql = "SELECT * FROM counters_".$table." WHERE data = '".date('Y-m-d')."' AND ".$field." = '".$qual."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $acessos = $row['acessos'] + 1;
            $sql = "UPDATE counters_".$table." SET acessos = '".$acessos."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$row['id']."'";
            mysqli_query($con, $sql);
        }
        else{
            $sql = "INSERT INTO counters_".$table." (".$field.", data, acessos, created_at, updated_at) VALUES ('".$qual."', '".date('Y-m-d')."', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql);
        }
        echo "1";
        break;
    case "editaEstoque":
        $sql = "SELECT * FROM products_items WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        echo utf8_encode("1|-|".$row['id']."|-|".$row['code']."|-|".$row['name']."|-|".number_format($row['value'], 2, ',', '.')."|-|".number_format($row['promotion'], 2, ',', '.')."|-|".$row['validity_promotion']."|-|".$row['status']."|-|".$row['estoque']);
        for ($i = 1; $i <= 10; $i++){
            echo "|-|".$row['attribute'.$i];
        }
        echo "|-|".$row['peso']."|-|".$row['largura']."|-|".$row['altura']."|-|".$row['comprimento']."|-|".$row['diametro'];
        break;
    case "editaImagem":
        $sql = "SELECT * FROM properties_photos WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['property']);
        break;
    case "editaVideos":
        $sql = "SELECT * FROM products_videos WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        echo ("1|-|".$row['id']."|-|".$row['v']."|-|".$row['name']."|-|".$row['status']);
        break;
    case "listarEstoque":
        $sql = "SELECT * FROM products_items WHERE product = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        echo "1|-|";
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                ?><div style="width:100%; padding:10px"id="estoque<?php echo $row['id']?>" onmouseover="this.style.backgroundColor='#F7F7F7'" onmouseout="this.style.backgroundColor='#FFFFFF'"><?php echo utf8_encode($row['name'])?> <img src="<?php echo URL?>img/editar.png" width="20" style="cursor:pointer" onclick="editaEstoque('<?php echo $row['id']?>', '<?php echo URL?>', '<?php echo $_REQUEST['id']?>')"> <img src="<?php echo URL?>img/excluir.png" width="20" style="cursor:pointer" onclick="excluirEstoque('<?php echo $row['id']?>', '<?php echo URL?>', '<?php echo $_REQUEST['id']?>')"></div><?php
            }
        }
        break;
    case "listarImagens":
        $sql = "SELECT a.*, b.name AS nomeItem FROM products_images a INNER JOIN products_items b ON (a.product_item = b.id) WHERE a.product = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        echo "1|-|";
        if (mysqli_num_rows($query)){
            $produtos = 0;
            while ($row = mysqli_fetch_array($query)) {
                if (!$produto || $product_item != $row['product_item']){
                    $produto = $row['product'];
                    $product_item = $row['product_item'];
                    $produtos++;
                }
            }
            if ($produtos == 1){
                ?><button type="button" class="btn btn-primary" onclick="replicarTodas('<?php echo $produto?>', '<?php echo $product_item?>', '<?php echo URL?>')">Replicar Todas</button><?php
            }
            $query = mysqli_query($con, $sql);
            while ($row = mysqli_fetch_array($query)){
                ?><div style="width:100%; padding:10px"id="estoque<?php echo $row['id']?>" onmouseover="this.style.backgroundColor='#F7F7F7'" onmouseout="this.style.backgroundColor='#FFFFFF'"><img src="<?php echo URL?>img/upload/<?php echo $row['img']?>" width="200"> <?php echo utf8_encode($row['nomeItem'])." - ".$row['name']?> <img src="<?php echo URL?>img/editar.png" width="20" style="cursor:pointer" onclick="editaImagem('<?php echo $row['id']?>', '<?php echo URL?>', '<?php echo $_REQUEST['id']?>')"> <img src="<?php echo URL?>img/excluir.png" width="20" style="cursor:pointer" onclick="excluirImagem('<?php echo $row['id']?>', '<?php echo URL?>', '<?php echo $_REQUEST['id']?>')"></div><?php
            }
        }
        break;
    case "listarVideos":
        $sql = "SELECT a.* FROM products_videos a WHERE a.product = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        echo "1|-|";
        if (mysqli_num_rows($query)){
            $query = mysqli_query($con, $sql);
            while ($row = mysqli_fetch_array($query)){
                ?><div style="width:100%; padding:10px"id="videos<?php echo $row['id']?>" onmouseover="this.style.backgroundColor='#F7F7F7'" onmouseout="this.style.backgroundColor='#FFFFFF'"><iframe width="100%" height="200" src="https://www.youtube.com/embed/<?php echo $row['v']?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe><br><?php echo ($row['name'])?> <img src="<?php echo URL?>img/editar.png" width="20" style="cursor:pointer" onclick="editaVideos('<?php echo $row['id']?>', '<?php echo URL?>', '<?php echo $_REQUEST['id']?>')"> <img src="<?php echo URL?>img/excluir.png" width="20" style="cursor:pointer" onclick="excluirVideos('<?php echo $row['id']?>', '<?php echo URL?>', '<?php echo $_REQUEST['id']?>')"></div><?php
            }
        }
        break;
    case "cadastrarEstoque":
        $_REQUEST['value'] = str_replace('.', '', $_REQUEST['value']);
        $_REQUEST['value'] = str_replace(',', '.', $_REQUEST['value']);
        $_REQUEST['promotion'] = str_replace('.', '', $_REQUEST['promotion']);
        $_REQUEST['promotion'] = str_replace(',', '.', $_REQUEST['promotion']);
        $sql = "INSERT INTO products_items (product, ";
        for ($i = 1; $i <= 10; $i++){
            $sql .= "attribute".$i.", ";
        }
        $sql .= "code, name, value, promotion, validity_promotion, status, estoque, created_at, updated_at) VALUES ('".$_REQUEST['product']."', ";
        for ($i = 1; $i <= 10; $i++){
            $sql .= "'".$_REQUEST["attribute".$i]."', ";
        }
        $sql .= utf8_decode("'".$_REQUEST['code']."', '".$_REQUEST['name']."', '".$_REQUEST['value']."', '".$_REQUEST['promotion']."', '".$_REQUEST['validity_promotion']."', '".$_REQUEST['status']."', '".$_REQUEST['estoque']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
        mysqli_query($con, $sql);
        echo "1|-|";
        break;
    case "editarEstoque":
        $_REQUEST['value'] = str_replace('.', '', $_REQUEST['value']);
        $_REQUEST['value'] = str_replace(',', '.', $_REQUEST['value']);
        $_REQUEST['promotion'] = str_replace('.', '', $_REQUEST['promotion']);
        $_REQUEST['promotion'] = str_replace(',', '.', $_REQUEST['promotion']);
        $sql = utf8_decode("UPDATE products_items SET code = '".$_REQUEST['code']."', name = '".$_REQUEST['name']."', value = '".$_REQUEST['value']."', promotion = '".$_REQUEST['promotion']."', validity_promotion = '".$_REQUEST['validity_promotion']."', status = '".$_REQUEST['status']."', estoque = '".$_REQUEST['estoque']."', peso = '".$_REQUEST['peso']."', altura = '".$_REQUEST['altura']."', largura = '".$_REQUEST['largura']."', comprimento = '".$_REQUEST['comprimento']."', diametro = '".$_REQUEST['diametro']."', ");
        for ($i = 1; $i <= 10; $i++){
            $sql .= " attribute".$i." = '".$_REQUEST['attribute'.$i]."',";
        }
        $sql .= " updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo "1|-|";
        break;
    case "editarImagem":
        $sql = "UPDATE properties_photos SET name = '".$_REQUEST['name']."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if ($_FILES['imagem']['error'] == 0 && $_FILES['imagem']['tmp_name']){
            if(preg_match("/.jpg/", $_FILES['imagem']['name'])){
                $img = "imovel".$_REQUEST['property']."_".$_REQUEST['id'].".jpg";
            }
            elseif(preg_match("/.jpeg/", $_FILES['imagem']['name'])){
                $img = "imovel".$_REQUEST['property']."_".$_REQUEST['id'].".jpeg";
            }
            elseif(preg_match("/.gif/", $_FILES['imagem']['name'])){
                $img = "imovel".$_REQUEST['property']."_".$_REQUEST['id'].".gif";
            }
            elseif(preg_match("/.png/", $_FILES['imagem']['name'])){
                $img = "imovel".$_REQUEST['property']."_".$_REQUEST['id'].".png";
            }
            elseif(preg_match("/.bmp/", $_FILES['imagem']['name'])){
                $img = "imovel".$_REQUEST['property']."_".$_REQUEST['id'].".bmp";
            }
            elseif(preg_match("/.svg/", $_FILES['imagem']['name'])){
                $img = "imovel".$_REQUEST['property']."_".$_REQUEST['id'].".svg";
            }
            elseif(preg_match("/.webp/", $_FILES['imagem']['name'])){
                $img = "imovel".$_REQUEST['property']."_".$_REQUEST['id'].".webp";
            }
            if ($img) {
                unlink(DIRETORIO."img/upload/imovel".$_REQUEST['property']."_".$_REQUEST['id'].".jpg");
                unlink(DIRETORIO."img/upload/imovel".$_REQUEST['property']."_".$_REQUEST['id'].".jpeg");
                unlink(DIRETORIO."img/upload/imovel".$_REQUEST['property']."_".$_REQUEST['id'].".gif");
                unlink(DIRETORIO."img/upload/imovel".$_REQUEST['property']."_".$_REQUEST['id'].".png");
                unlink(DIRETORIO."img/upload/imovel".$_REQUEST['property']."_".$_REQUEST['id'].".bmp");
                unlink(DIRETORIO."img/upload/imovel".$_REQUEST['property']."_".$_REQUEST['id'].".svg");
                unlink(DIRETORIO."img/upload/imovel".$_REQUEST['property']."_".$_REQUEST['id'].".webp");
                copy($_FILES['imagem']['tmp_name'], DIRETORIO."img/upload/".$img);
                $sql = "UPDATE properties_photos SET img = '".$img."' WHERE id = '".$_REQUEST['id']."'";
                mysqli_query($con, $sql);
            }
        }
        echo "1";
        break;
    case "editarVideos":
        $sql = "UPDATE products_videos SET v = '".$_REQUEST['v']."', name = '".$_REQUEST['name']."', status = '".$_REQUEST['status']."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        echo "1";
        break;
    case "excluirEstoque":
        $sql = "DELETE FROM products_items WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo "1|-|";
        break;
    case "excluirImagem":
        $sql = "SELECT * FROM products_images WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        unlink(DIRETORIO."img/upload/".$row['img']);
        $sql = "DELETE FROM products_images WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo "1|-|";
        break;
    case "excluirVideos":
        $sql = "DELETE FROM products_videos WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo "1|-|";
        break;
    case "replicarTodas":
        $sql = "SELECT * FROM products_images WHERE product = '".$_REQUEST['product']."' AND product_item = '".$_REQUEST['product_item']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                $imagens[] = $row;
            }
        }
        $sql = "SELECT * FROM products_items WHERE product = '".$_REQUEST['product']."' AND id != '".$_REQUEST['product_item']."'";
        $query2 = mysqli_query($con, $sql);
        if (mysqli_num_rows($query2)){
            while ($row2 = mysqli_fetch_array($query2)){
                foreach ($imagens as $key => $value){
                    $sql = "INSERT INTO products_images (product, product_item, name, status, created_at, updated_at) VALUES ('".$_REQUEST['product']."', '".$row2['id']."', '".$value['name']."', '".$value['status']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                    mysqli_query($con, $sql);
                    $id = mysqli_insert_id($con);
                    $vet = explode('.', $value['img']);
                    $imagem = "produto".$_REQUEST['product']."_".$id.".".$vet[count($vet) - 1];
                    copy(DIRETORIO."img/upload/".$value['img'], DIRETORIO."img/upload/".$imagem);
                    $sql = "UPDATE products_images SET img = '".$imagem."' WHERE id = '".$id."'";
                    mysqli_query($con, $sql);
                }
            }
        }
        echo "1";
        break;
    case "mostra_comprovante":
        echo "1|-|";
        $idRequest = $_REQUEST['request_id'];
        $client = $_SESSION['cliente']['id'];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, URL."comprovante.php?id=".$idRequest."&semRodape=1&client=".$client);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        echo curl_exec($ch);
        curl_close($ch);
        break;
    case "comprar":
        $sql = "SELECT * FROM cart WHERE session_id = '".session_id()."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            while ($row = mysqli_fetch_array($query)) {
                $subtotal += $row['value'] * $row['quantity'];
            }
        }
        $sql = "INSERT INTO requests (client, paymentMethod, address, valuePayment, status, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', '".$_REQUEST['payment_method']."', '".$_REQUEST['address']."', '".$subtotal."', '3', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        $query = mysqli_query($con, $sql);
        $idPedido = mysqli_insert_id($con);
        $sql = "SELECT * FROM cart WHERE session_id = '".session_id()."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                $sql = "INSERT INTO requests_items (request, product, product_item, school_system, cashier_system, name, domine, quantity, value, created_at, updated_at) VALUES ('".$idPedido."', '".$row['product']."', '".$row['product_item']."', '".$row['school_system']."', '".$row['cashier_system']."', '".$row['name']."', '".$row['domine']."', '".$row['quantity']."', '".$row['value']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                $query2 = mysqli_query($con, $sql);
            }
        }
        $sql = "DELETE FROM cart WHERE session_id = '".session_id()."'";
        $query = mysqli_query($con, $sql);
        echo '1|-|<img src="'.URL.'img/loader.gif" width="20"> Aguarde... Carregando Comprovante...|-|'.$idPedido;
        break;
    case "enderecosCompra":
        $sql = "SELECT * FROM payment_methods WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        echo "1|-|Forma de Pagamento escolhida: <b>".utf8_encode($row['name'])."</b><input type='hidden' name='formaPagamentoCompra' id='formaPagamentoCompra' value='".$row['id']."'><br>
                  <label for='enderecoCompra'>Endereço:</label> ";
        $sql = "SELECT * FROM addresses WHERE idClient = '".$_SESSION['cliente']['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            echo "<select name='enderecoCompra' id='enderecoCompra' class='form-control' required>
            <option value=''>Seleione o endereço corretamente...</option>";
            while ($row = mysqli_fetch_array($query)){
                echo "<option value='".$row['id']."'>".utf8_encode($row['name']." - ".$row['address'].", ".$row['number']);
                if ($row['complement']){
                    echo utf8_encode(", ".$row['complement']);
                }
                echo utf8_encode(" - B. ".$row['neighborhood']." - ".$row['city']." - ".$row['state']."</option>");
            }
            echo '</select>
            <br>
            <button type="button" class="btn btn-secondary" onClick="fecha(\'finalizarPedido\')">Fechar</button>
            <button type="button" class="btn btn-primary" onclick="comprar(\''.URL.'\')">Realizar Compra</button>';
            mysqli_num_rows($query);
        }
        else{
            echo "Sem endereço encontrado para o cliente! Cadastre um novo agora!";
        }
        break;
    case "finalizarPedido":
        echo '1|-|<button type="button" class="close" onClick=fecha("finalizarPedido")><span aria-hidden="true">&times;</span></button>Escolha a forma de pagamento abaixo:
            <table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>';
            $sql = "SELECT * FROM payment_methods";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                while ($row = mysqli_fetch_array($query)){
                    echo '<td style="width: 50%; text-align: center; cursor:pointer" onclick="selecionaFormaPagamento(\''.$row['id'].'\', \''.URL.'\', this)" id="formaPagamento'.$row['id'].'">
                    <img src="'.URL.'img/upload/'.$row['img'].'" width="200">
                    '.utf8_encode($row['name']).'
                    </td>';
                }
            }
        echo '</tr></table><div id="enderecosCompra"></div>';
        break;
    case "limparCarrinho":
        $sql .= "DELETE FROM cart WHERE session_id = '".session_id()."'";
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "excluirCarrinho":
        $sql .= "DELETE FROM cart WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "mostraCarrinhoDeCompras":
        echo '1|-|';
        $sql = "SELECT a.* FROM cart a WHERE a.session_id = '".session_id()."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            echo "<h5>Produtos no Carrinho</h5>";
            echo '<table width="100%" border="0" cellpadding="0" cellspacing="0">
                      <tr>
                           <th>Nome do Produto</th>
                           <th>Valor do Produto</th>
                           <th>Quantidade</th>
                           <th>Valor Total</th>
                           <th>Excluir</th>
                      </tr>';
            $i = 0;
            while ($row = mysqli_fetch_array($query)){
                $backgroundColor = ($i % 2 == 1) ? "#E7E7E7" : "";
                echo utf8_encode('<tr style="background-color:'.$backgroundColor.'">
                    <td style="text-align: center">'.$row['name']);
                if($row['domine']) {
                    echo utf8_encode(' - <a href="' . $row['domine'] . '" target="_blank">' . substr($row['domine'], 0, 15) . '...</a>');
                }
                if ($row['school_system']){
                    $sql = "SELECT * FROM school_system WHERE id = '".$row['school_system']."'";
                    $query2 = mysqli_query($con, $sql);
                    $rowSistemaEscolar = mysqli_fetch_array($query2);
                    if ($rowSistemaEscolar['tipoNota'] == 1){
                        $rowSistemaEscolar['tipoNota'] = "Bimestral";
                    }
                    elseif ($rowSistemaEscolar['tipoNota'] == 2){
                        $rowSistemaEscolar['tipoNota'] = "Trimestral";
                    }
                    elseif ($rowSistemaEscolar['tipoNota'] == 3){
                        $rowSistemaEscolar['tipoNota'] = "Semestral";
                    }
                    elseif ($rowSistemaEscolar['tipoNota'] == 4){
                        $rowSistemaEscolar['tipoNota'] = "Anual";
                    }
                    if ($rowSistemaEscolar['turno'] == 1){
                        $rowSistemaEscolar['turno'] = "Manhã";
                    }
                    elseif ($rowSistemaEscolar['turno'] == 2){
                        $rowSistemaEscolar['turno'] = "Tarde";
                    }
                    elseif ($rowSistemaEscolar['turno'] == 3){
                        $rowSistemaEscolar['turno'] = "Noite";
                    }
                    elseif ($rowSistemaEscolar['turno'] == 4){
                        $rowSistemaEscolar['turno'] = "Único";
                    }
                    elseif ($rowSistemaEscolar['turno'] == 5){
                        $rowSistemaEscolar['turno'] = "Todos";
                    }
                    if ($rowSistemaEscolar['letra'] == "Un"){
                        $rowSistemaEscolar['letra'] = "Única";
                    }
                    echo ' - <a onclick="verInformacoesSistemaEscolar(\''.$row['school_system'].'\')" style="color: #0077A4; cursor: pointer" title="Ver informações do sistema">Ver Informações do Sistema</a>
                            <div id="informacoesSistemaEscolar'.$row['school_system'].'" style="display: none; position:absolute; width:92%; background-color:#FFFFFF">
                                <button type"button" class="close" onClick=fecha("informacoesSistemaEscolar'.$row['school_system'].'")><span aria-hidden="true">&times;</span></button>
                                <h3>Informações do Sistema Escolar</h3>
                                <b>Nome da Escola:</b> '.$rowSistemaEscolar['nome'].'<br>
                                <b>Email da Escola:</b> '.$rowSistemaEscolar['email'].'<br>
                                <b>CEP da Escola:</b> '.$rowSistemaEscolar['cep'].'<br>
                                <b>Logradouro da Escola:</b> '.$rowSistemaEscolar['logradouro'].'<br>
                                <b>Número da Escola:</b> '.$rowSistemaEscolar['numero'].'<br>';
                    if ($rowSistemaEscolar['complemento']){
                        echo '<b>Complemento:</b> '.$rowSistemaEscolar['complemento'].'<br>';
                    }
                    echo '<b>Bairro da Escola:</b> '.$rowSistemaEscolar['bairro'].'<br>
                                <b>Cidade da Escola:</b> '.$rowSistemaEscolar['cidade'].'<br>
                                <b>Estado da Escola:</b> '.$rowSistemaEscolar['estado'].'<br>
                                <b>Tipo de Nota da Escola:</b> '.$rowSistemaEscolar['tipoNota'].'<br>
                                <b>Turno da Escola:</b> '.$rowSistemaEscolar['turno'].'<br>
                                <b>Letra da Escola:</b> '.$rowSistemaEscolar['letra'].'
                            </div>';
                }
                if ($row['cashier_system']) {
                    $sql = "SELECT * FROM cashier_system WHERE id = '" . $row['cashier_system'] . "'";
                    $query2 = mysqli_query($con, $sql);
                    $rowSistemaCaixa = mysqli_fetch_array($query2);
                    echo ' - <a onclick="verInformacoesSistemaCaixa(' . $row['cashier_system'] . ')" style="color: #0077A4; cursor: pointer" title="Ver informações do sistema">Ver Informações do Sistema</a>
                    <div id="informacoesSistemaCaixa' . $row['cashier_system'] . '" style="display: none; position:absolute; width:92%; background-color:#FFFFFF">
                                <button type"button" class="close" onClick=fecha("informacoesSistemaCaixa' . $row['cashier_system'] . '")><span aria-hidden="true">&times;</span></button>
                                <h3>Informações do Sistema de Caixa</h3>
                                <b>Razão Social:</b> ' . $rowSistemaCaixa['razao_social'] . '<br>
                                <b>Nome Fantasia:</b> ' . $rowSistemaCaixa['nome_fantasia'] . '<br>
                                <b>Email:</b> ' . $rowSistemaCaixa['email'] . '<br>
                                <b>CNPJ:</b> ' . $rowSistemaCaixa['cnpj'] . '<br>
                                <b>CEP:</b> ' . $rowSistemaCaixa['cep'] . '<br>
                                <b>Logradouro:</b> ' . $rowSistemaCaixa['logradouro'] . '<br>
                                <b>Número:</b> ' . $rowSistemaCaixa['numero'] . '<br>';
                    if ($rowSistemaCaixa['complemento']) {
                        echo '<b>Complemento:</b> ' . $rowSistemaCaixa['complemento'] . '<br>';
                    }
                    echo '<b>Bairro:</b> ' . $rowSistemaCaixa['bairro'] . '<br>
                                <b>Cidade:</b> ' . $rowSistemaCaixa['cidade'] . '<br>
                                <b>Estado:</b> ' . $rowSistemaCaixa['estado'] . '<br>
                                <b>Tipo de Estabelecimento:</b> ';
                    if ($rowSistemaCaixa['tipoEstabelecimento'] == 1) {
                        echo 'Mesa';
                    } else {
                        echo 'Caixa';
                    }
                    echo '<br>
                                <b>Quantidade de ';
                    if ($rowSistemaCaixa['tipoEstabelecimento'] == 1) {
                        echo 'Mesas';
                    } else {
                        echo 'Caixas';
                    }
                    echo ':</b> ' . $rowSistemaCaixa['quantidade'];
                    if ($rowSistemaCaixa['tipoEstabelecimento'] == 1) {
                        echo '<br>
                                <b>Número Pessoas Por Mesa:</b> ' . $rowSistemaCaixa['numeroPessoasPorMesa'] . '<br>
                                <b>Gorjeta do Garçom:</b> ' . $rowSistemaCaixa['percentual'] . '%
                            </div>';
                    }
                }
                    echo utf8_encode('</td>
                    <td style="text-align: center">R$'.number_format($row['value'], 2, ',', '.').'</td>
                    <td style="text-align: center">'.$row['quantity'].'</td>
                    <td style="text-align: center">R$'.number_format($row['value'] * $row['quantity'], 2, ',', '.').'</td>
                    <td style="text-align: center"><img src="'.URL.'img/excluir.png" width="20" style="cursor:pointer;" onclick=excluirCarrinho("'.$row['id'].'","'.URL.'")></td>
                </tr>');
                $i++;
            }
            echo '</table>';
        }
        else {
            echo '<div style="padding:10px; text-align: center; background-color:#FF0000; color:#FFFFFF"><h5>Sem nenhum produto no carrinho no momento!</h5></div>';
        }
        echo  '<input type="hidden" id="numProdutosCarrinho" name="numProdutosCarrinho" value="0">|-|'.mysqli_num_rows($query);
        break;
        case "salvarCarrinho":
            $sql = 'SELECT * FROM products_items WHERE id = "'.$_REQUEST['produtoItemRealizarPedido'].'"';
            $query = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($query);
            $valor = ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')) ? $row['promotion'] : $row['value'];
            $sql = "INSERT INTO cart (product, product_item, session_id, domine, name, quantity, value, created_at, updated_at) VALUES ('".$_REQUEST['produtoRealizarPedido']."', '".$_REQUEST['produtoItemRealizarPedido']."', '".session_id()."', '".$_REQUEST['domineRealizarPedido']."', '".$row['name']."', '1', '".$valor."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql);
            $idCarrinho = mysqli_insert_id($con);
            if ($_REQUEST['hostingRealizarPedido']){
                $sql = 'SELECT * FROM products_items WHERE id = "'.$_REQUEST['hostingRealizarPedido'].'"';
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $valor = ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')) ? $row['promotion'] : $row['value'];
                $sql = "INSERT INTO cart (product, product_item, session_id, domine, name, quantity, value, created_at, updated_at) VALUES ('".$row['product']."', '".$_REQUEST['hostingRealizarPedido']."', '".session_id()."', '".$_REQUEST['domineRealizarPedido']."', '".$row['name']."', '1', '".$valor."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                mysqli_query($con, $sql);
            }
            if ($_REQUEST['registroRealizarPedido']){
                $sql = 'SELECT * FROM products_items WHERE id = "'.$_REQUEST['registroRealizarPedido'].'"';
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $valor = ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')) ? $row['promotion'] : $row['value'];
                $sql = "INSERT INTO cart (product, product_item, session_id, domine, name, quantity, value, created_at, updated_at) VALUES ('".$row['product']."', '".$_REQUEST['registroRealizarPedido']."', '".session_id()."', '".$_REQUEST['domineRealizarPedido']."', '".$row['name']."', '1', '".$valor."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                mysqli_query($con, $sql);
            }
            if ($_REQUEST['modelSiteRealizarPedido']){
                $sql = 'SELECT * FROM subitems WHERE id = "'.$_REQUEST['modelSiteRealizarPedido'].'"';
                $query = mysqli_query($con, $sql);
                $row2 = mysqli_fetch_array($query);
                $sql = 'SELECT * FROM products_items WHERE product = "8"';
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $valor = ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')) ? $row['promotion'] : $row['value'];
                $sql = "INSERT INTO cart (product, product_item, session_id, domine, name, quantity, value, created_at, updated_at) VALUES ('8', '".$_REQUEST['modelSiteRealizarPedido']."', '".session_id()."', '".$_REQUEST['domineRealizarPedido']."', '".$row['name']." - ".$row2['name']."', '1', '".$valor."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                mysqli_query($con, $sql);
            }
            if ($_REQUEST['produtoRealizarPedido'] == 3) {
                $sql = "INSERT INTO cashier_system (razao_social, nome_fantasia, email, cnpj, cep, logradouro, numero, complemento, bairro, cidade, estado, tipoEstabelecimento, quantidade, numeroPessoasPorMesa, percentual, created_at, updated_at) VALUES ('" . $_REQUEST['nomeFantasiaRealizarPedido'] . "', '" . $_REQUEST['nomeFantasiaRealizarPedido'] . "', '".$_REQUEST['emailEmpresaRealizarPedido']."', '" . $_REQUEST['cnpjEmpresaRealizarPedido'] . "', '" . $_REQUEST['cepRealizarPedido'] . "', '" . $_REQUEST['logadouroRealizarPedido'] . "', '" . $_REQUEST['numeroRealizarPedido'] . "', '" . $_REQUEST['complementoRealizarPedido'] . "', '" . $_REQUEST['bairroRealizarPedido'] . "', '" . $_REQUEST['cidadeRealizarPedido'] . "', '" . $_REQUEST['estadoRealizarPedido'] . "', '" . $_REQUEST['tipoEstabelecimentoRealizarPedido'] . "', '" . $_REQUEST['quantidadeRealizarPedido'] . "', '" . $_REQUEST['numPessoasRealizarPedido'] . "', '" . $_REQUEST['perGarcomRealizarPedido'] . "', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                mysqli_query($con, $sql) or die(mysqli_error($con));
                $cashier_system = mysqli_insert_id($con);
                $sql = "UPDATE cart SET cashier_system = '".$cashier_system."' WHERE id = '".$idCarrinho."'";
                mysqli_query($con, $sql) or die(mysqli_error($con));
            }
            if ($_REQUEST['produtoRealizarPedido'] == 4) {
                $sql = "INSERT INTO school_system (nome, email, cep, logradouro, numero, complemento, bairro, cidade, estado, tipoNota, turno, letra, created_at, updated_at) VALUES ('" . $_REQUEST['nomeEscolaRealizarPedido'] . "', '" . $_REQUEST['emailEscolaRealizarPedido'] . "', '" . $_REQUEST['cepEscolaRealizarPedido'] . "', '" . $_REQUEST['logadouroEscolaRealizarPedido'] . "', '" . $_REQUEST['numeroEscolaRealizarPedido'] . "', '" . $_REQUEST['complementoEscolaRealizarPedido'] . "', '" . $_REQUEST['bairroEscolaRealizarPedido'] . "', '" . $_REQUEST['cidadeEscolaRealizarPedido'] . "', '" . $_REQUEST['estadoEscolaRealizarPedido'] . "', '" . $_REQUEST['tipoNotaRealizarPedido'] . "', '" . $_REQUEST['turnoEscolaRealizarPedido'] . "', '" . $_REQUEST['letraEscolaRealizarPedido'] . "', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                mysqli_query($con, $sql) or die(mysqli_error($con));
                $school_system = mysqli_insert_id($con);
                $sql = "UPDATE cart SET school_system = '".$school_system."' WHERE id = '".$idCarrinho."'";
                mysqli_query($con, $sql) or die(mysqli_error($con));
            }
        echo "1";
        break;
    case "selecionaPasso03":
        if ($_REQUEST['product'] != 3 && $_REQUEST['product'] != 4) {
            $html = '<label for="domineRealizarPedido">Domínio:</label>
                     <input type="text" name="domineRealizarPedido" id="domineRealizarPedido" required class="form-control" placeholder="Informe aqui o domínio que você comprou ou ainda vai comprar...">';
            if ($_REQUEST['product'] <= 5) {
                $html .= '
                     <label for="hostingRealizarPedido">Hospedagem:</label>
                     <select name="hostingRealizarPedido" id="hostingRealizarPedido" class="form-control">
                        <option value="">Selecione uma hospedagem para o seu site, ou deixe assim se já possuir a hospedagem...</option>
                        ';
                $sql = "SELECT * FROM products_items WHERE product = '6' AND status = '1'";
                $query = mysqli_query($con, $sql);
                while ($row = mysqli_fetch_array($query)) {
                    $valor = ($row['promotion'] && $row['validity_promotion'] && $row['validity_promotion'] >= date('Y-m-d')) ? $row['promotion'] : $row['value'];
                    $html .= '<option value="' . $row['id'] . '">' . utf8_encode($row['name']) . ' - R$' . number_format($valor, 2, ',', '.') . '</option>';
                }
                $html .= '</select>
                     ';
            }
            if ($_REQUEST['product'] <= 6) {
                $html .= '<label for="registroRealizarPedido">Registro do Domínio:</label>
                     <select name="registroRealizarPedido" id="registroRealizarPedido" class="form-control">
                        <option value="">Selecione um registro para o seu site, ou deixe assim se já possuir o domínio...</option>
                        ';
                $sql = "SELECT * FROM products_items WHERE product = '7' AND status = '1'";
                $query = mysqli_query($con, $sql);
                while ($row = mysqli_fetch_array($query)) {
                    $valor = ($row['promotion'] && $row['validity_promotion'] && $row['validity_promotion'] >= date('Y-m-d')) ? $row['promotion'] : $row['value'];
                    $html .= '<option value="' . $row['id'] . '">' . utf8_encode($row['name']) . ' - R$' . number_format($valor, 2, ',', '.') . '</option>';
                }
                $html .= '</select>';
            }
            if ($_REQUEST['product'] <= 5) {
                $html .= '<label for="modelSiteRealizarPedido">Modelo de Site:</label>
                     <select name="modelSiteRealizarPedido" id="modelSiteRealizarPedido" class="form-control">
                        <option value="">Selecione um modelo de site, ou deixe assim se já possuir um modelo...</option>
                        ';
                $sql = "SELECT * FROM subitems WHERE page = '5' AND status = '1'";
                $query = mysqli_query($con, $sql);
                while ($row = mysqli_fetch_array($query)) {
                    $sql = "SELECT * FROM products_items WHERE product = '8' AND status = '1'";
                    $query2 = mysqli_query($con, $sql);
                    $rowProductItem = mysqli_fetch_array($query2);
                    $valor = ($rowProductItem['promotion'] && $rowProductItem['validity_promotion'] && $rowProductItem['validity_promotion'] >= date('Y-m-d')) ? $rowProductItem['promotion'] : $rowProductItem['value'];
                    $html .= '<option value="' . $row['id'] . '">' . utf8_encode($row['name']) . ' - R$' . number_format($valor, 2, ',', '.') . '</option>';
                }
                $html .= '</select>';
            }
        }
        if ($_REQUEST['product'] == 3){
            $html = '<label for="razaoSocialRealizarPedido">Razão Social:</label>
                     <input type="text" name="razaoSocialRealizarPedido" id="razaoSocialRealizarPedido" required class="form-control" placeholder="Informe aqui a razão social da empresa...">
                     <label for="nomeFantasiaRealizarPedido">Nome Fantasia:</label>
                     <input type="text" name="nomeFantasiaRealizarPedido" id="nomeFantasiaRealizarPedido" required class="form-control" placeholder="Informe aqui o nome fantasia da empresa...">
                     <label for="emailEmpresaRealizarPedido">Email:</label>
                     <input type="email" name="emailEmpresaRealizarPedido" id="emailEmpresaRealizarPedido" required class="form-control" placeholder="Informe aqui o email da empresa...">
                     <label for="cnpjEmpresaRealizarPedido">CNPJ:</label>
                     <input type="text" name="cnpjEmpresaRealizarPedido" id="cnpjEmpresaRealizarPedido" onkeypress="return mascara(this, \'00.000.000/0000-00\', event)" required class="form-control" placeholder="Informe aqui o cnpj da empresa... Somente Números...">
                     <label for="cepRealizarPedido">CEP:</label>
                     <input type="text" name="cepRealizarPedido" id="cepRealizarPedido" onkeyup="pesquisacepRealizarPedido(this.value)" onkeypress="return mascara(this, \'00000-000\', event)" required class="form-control" placeholder="Informe aqui o cep da empresa... Somente Números...">
                     <label for="logadouroRealizarPedido">Logradouro:</label>
                     <input type="text" name="logadouroRealizarPedido" id="logadouroRealizarPedido" required class="form-control" placeholder="Informe aqui o logradouro da empresa...">
                     <label for="numeroRealizarPedido">Número:</label>
                     <input type="text" name="numeroRealizarPedido" id="numeroRealizarPedido" required class="form-control" placeholder="Informe aqui o número da empresa...">
                     <label for="complementoRealizarPedido">Complemento:</label>
                     <input type="text" name="complementoRealizarPedido" id="complementoRealizarPedido" class="form-control" placeholder="Informe aqui o complemento da empresa...">
                     <label for="bairroRealizarPedido">Bairro:</label>
                     <input type="text" name="bairroRealizarPedido" id="bairroRealizarPedido" required class="form-control" placeholder="Informe aqui o bairro da empresa..">
                     <label for="cidadeRealizarPedido">Cidade:</label>
                     <input type="text" name="cidadeRealizarPedido" id="cidadeRealizarPedido" required class="form-control" placeholder="Informe aqui a cidade da empresa..">
                     <label for="estadoRealizarPedido">Estado:</label>
                     <select name="estadoRealizarPedido" id="estadoRealizarPedido" required class="form-control">
                     <option value="">UF</option>
                    ';
        $sql = "SELECT * FROM states ORDER BY sigla ASC";
        $query2 = mysqli_query($con, $sql);
        while ($row2 = mysqli_fetch_array($query2)) {
            $html .= '<option value="'.$row2['sigla'].'">'.$row2['sigla'].'</option>';
        }
                $html .= '
                </select>
                <label for="tipoEstabelecimentoRealizarPedido">Tipo do Estabelecimento:</label>
                     <select name="tipoEstabelecimentoRealizarPedido" id="tipoEstabelecimentoRealizarPedido" required class="form-control" onchange="selecionaTipoEstabelecimento(this.value)">
                     <option value="">Selecione o tipo do estabelecimento abaixo...</option>
                     <option value="1">Mesas</option>
                     <option value="2">Caixa</option>
                     </select>
                     <span id="tiposEstabelecimentoRealizarPedido">Selecione o tipo do estabelecimento acima...</span>';
        }
        if ($_REQUEST['product'] == 4){
            $html = '<label for="nomeEscolaRealizarPedido">Nome da Escola:</label>
                     <input type="text" name="nomeEscolaRealizarPedido" id="nomeEscolaRealizarPedido" required class="form-control" placeholder="Informe aqui o nome da escola..">
                     <label for="emailEscolaRealizarPedido">Email da Escola:</label>
                     <input type="text" name="emailEscolaRealizarPedido" id="emailEscolaRealizarPedido" required class="form-control" placeholder="Informe aqui o email da escola..">
                     <label for="cepEscolaRealizarPedido">CEP:</label>
                     <input type="text" name="cepEscolaRealizarPedido" id="cepEscolaRealizarPedido" onkeyup="pesquisacepEscolaRealizarPedido(this.value)" onkeypress="return mascara(this, \'00000-000\', event)" required class="form-control" placeholder="Informe aqui o cep da escola... Somente Números...">
                     <label for="logadouroEscolaRealizarPedido">Logradouro:</label>
                     <input type="text" name="logadouroEscolaRealizarPedido" id="logadouroEscolaRealizarPedido" required class="form-control" placeholder="Informe aqui o logradouro da escola...">
                     <label for="numeroEscolaRealizarPedido">Número:</label>
                     <input type="text" name="numeroEscolaRealizarPedido" id="numeroEscolaRealizarPedido" required class="form-control" placeholder="Informe aqui o número da escola...">
                     <label for="complementoEscolaRealizarPedido">Complemento:</label>
                     <input type="text" name="complementoEscolaRealizarPedido" id="complementoEscolaRealizarPedido" class="form-control" placeholder="Informe aqui o complemento da escola...">
                     <label for="bairroEscolaRealizarPedido">Bairro:</label>
                     <input type="text" name="bairroEscolaRealizarPedido" id="bairroEscolaRealizarPedido" required class="form-control" placeholder="Informe aqui o bairro da escola..">
                     <label for="cidadeEscolaRealizarPedido">Cidade:</label>
                     <input type="text" name="cidadeEscolaRealizarPedido" id="cidadeEscolaRealizarPedido" required class="form-control" placeholder="Informe aqui a cidade da escola..">
                     <label for="estadoEscolaRealizarPedido">Estado:</label>
                     <select name="estadoEscolaRealizarPedido" id="estadoEscolaRealizarPedido" required class="form-control">
                     <option value="">UF</option>
                    ';
        $sql = "SELECT * FROM states ORDER BY sigla ASC";
        $query2 = mysqli_query($con, $sql);
        while ($row2 = mysqli_fetch_array($query2)) {
            $html .= '<option value="'.$row2['sigla'].'">'.$row2['sigla'].'</option>';
        }
                $html .= '
                </select>
                <label for="tipoNotaRealizarPedido">Tipo de Nota:</label>
                     <select name="tipoNotaRealizarPedido" id="tipoNotaRealizarPedido" required class="form-control">
                     <option value="">Selecione o tipo de nota abaixo...</option>
                     <option value="1">Bimestral</option>
                     <option value="2">Trimestral</option>
                     <option value="3">Semestral</option>
                     <option value="4">Anual</option>
                     </select>
                <label for="turnoEscolaRealizarPedido">Turno da Escola:</label>
                     <select name="turnoEscolaRealizarPedido" id="turnoEscolaRealizarPedido" required class="form-control">
                     <option value="">Selecione o turno da escola abaixo...</option>
                     <option value="1">Manhã</option>
                     <option value="2">Tarde</option>
                     <option value="3">Noite</option>
                     <option value="4">Único</option>
                     <option value="5">Todos</option>
                     </select>
                <label for="letraEscolaRealizarPedido">Letra da Escola:</label>
                     <select name="letraEscolaRealizarPedido" id="letraEscolaRealizarPedido" required class="form-control">
                     <option value="">Selecione até que letra a escola vai abaixo...</option>';
                     for($i = 0; $i <= 26; $i++) {
                         switch ($i){
                             case 0:
                                 $letra = "Única";
                                 $l = "Un";
                                 break;
                             case 1:
                                 $letra = "A";
                                 break;
                             case 2:
                                 $letra = "B";
                                 break;
                             case 3:
                                 $letra = "C";
                                 break;
                             case 4:
                                 $letra = "D";
                                 break;
                             case 5:
                                 $letra = "E";
                                 break;
                             case 6:
                                 $letra = "F";
                                 break;
                             case 7:
                                 $letra = "G";
                                 break;
                             case 8:
                                 $letra = "H";
                                 break;
                             case 9:
                                 $letra = "I";
                                 break;
                             case 10:
                                 $letra = "J";
                                 break;
                             case 11:
                                 $letra = "K";
                                 break;
                             case 12:
                                 $letra = "L";
                                 break;
                             case 13:
                                 $letra = "M";
                                 break;
                             case 14:
                                 $letra = "N";
                                 break;
                             case 15:
                                 $letra = "O";
                                 break;
                             case 16:
                                 $letra = "P";
                                 break;
                             case 17:
                                 $letra = "Q";
                                 break;
                             case 18:
                                 $letra = "R";
                                 break;
                             case 19:
                                 $letra = "S";
                                 break;
                             case 20:
                                 $letra = "T";
                                 break;
                             case 21:
                                 $letra = "U";
                                 break;
                             case 22:
                                 $letra = "V";
                                 break;
                             case 23:
                                 $letra = "W";
                                 break;
                             case 24:
                                 $letra = "X";
                                 break;
                             case 25:
                                 $letra = "Y";
                                 break;
                             case 26:
                                 $letra = "Z";
                                 break;
                         }
                         if ($i > 0){
                             $l = $letra;
                         }
                         $html .= '<option value="'.$l.'">'.$letra.'</option>';
                     }
                     $html .= '
                     </select>';
        }
        echo "1|-|".$html;
        break;
    case "selecionaProduto":
        $sql = "SELECT * FROM products_items WHERE product = '".$_REQUEST['product']."' AND status = '1'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $html = '<label for="produtoItemRealizarPedido">Selecione o item do produto:</label>
                                            <select name="produtoItemRealizarPedido" id="produtoItemRealizarPedido" required class="form-control" onchange="selecionaProdutoItem(\''.$_REQUEST['product'].'\', \''.URL.'\', this.value)">
                                                <option value="">Selecione o item do produto abaixo corretamente...</option>
                                                ';
            while ($row = mysqli_fetch_array($query)) {
                $valor = (date('Y-m-d') > $row['validaty_promotion']) ? $row['promotion'] : $row['value'];
                $html .= '<option value="'.$row['id'].'">'.utf8_encode($row['name']).' - R$'.number_format($valor, 2, ',', '.').'</option>
';
            }
                                                $html .= '</select><div id="passo03" style="display: none"></div>';
        }
        else{
            $html = "Sem nenhum item do produto encontrado em nossa base de dados!";
        }
        echo "1|-|".$html;
        break;
    case "detalhesPedido":
        $sql = "SELECT a.*, b.email AS emailCliente,
                e.name AS nomeStatus, g.name AS nomeCliente, g.cpf, g.rg, g.dtNasc, g.cel AS celular, h.razaoSocial, h.nomeFantasia, h.contato, h.cnpj, h.ie, h.im, h.dataAbertura, h.cel, h.telefone, k.name AS nacionalidade, l.name AS nacionalidadeEmpresa,
                i.codigo, i.tipo, i.valor, i.validade, j.code, j.value AS valorVale, j.validade AS validade2
                FROM requests a
                INNER JOIN clients b ON (a.client = b.id)
                INNER JOIN requests_statuses e ON (a.status = e.id)
                LEFT JOIN pessoa_fisicas g ON (a.client = g.client)
                LEFT JOIN pessoa_juridicas h ON (a.client = h.client)
                LEFT JOIN coupon_discounts i ON (a.discount = i.id)
                LEFT JOIN vales j ON (a.vale = j.id)
                LEFT JOIN nationalities k ON (k.id = g.nationality)
                LEFT JOIN nationalities l ON (l.id = h.nationality)
                WHERE a.id = '".$_REQUEST['id']."'";

        $query = mysqli_query($con, $sql);
        $rowPedido = mysqli_fetch_array($query);
        if (isset($rowPedido['dataAbertura'])){
            $vet2 = explode('-', $rowPedido['dataAbertura']);
            $rowPedido['dataAbertura'] = $vet2[2]."/".$vet2[1]."/".$vet2[0];
        }
        if (isset($rowPedido['dtNasc'])){
            $vet2 = explode('-', $rowPedido['dtNasc']);
            $rowPedido['dtNasc'] = $vet2[2]."/".$vet2[1]."/".$vet2[0];
        }
        $sql = "SELECT a.* FROM requests_items a WHERE a.request = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        while($rowItensPedido = mysqli_fetch_array($query)){
            $pedidosItens[] = $rowItensPedido;
            $lista = $rowItensPedido['lista'];
        }
        echo '1|-|';
        if (!$_REQUEST['meusPedidos']) {
            echo '<button type"button" class="close" onClick=fecha("detalhesPedido")><span aria-hidden="true">&times;</span></button>';
        }
        else{
            echo "<div style='position:absolute; float:left; left:95%; cursor:pointer' onclick=$('#detalhesPedido').hide('fast')>&times;</div>";
        }
        echo '<h5>Detalhes do Orçamento '.sprintf("%06s\n", $_REQUEST['id']).'</h5>
            <h6><img src="'.URL.'img/cliente.png" width="30"> Dados do Cliente</h6>';
        if ($rowPedido['nomeCliente']) {
            echo '<table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tr>
                    <th>Nome do cliente</th>
                    <th>Email do cliente</th>
                </tr>
                <tr>
                    <td style="text-align:center">' . $rowPedido['nomeCliente'] . '</td>
                    <td style="text-align:center">' . $rowPedido['emailCliente'] . '</td>
                </tr>
               <tr>
                   <th>CPF do cliente</th>
                   <th>RG do cliente</th>
                </tr>
                    <td style="text-align:center">' . $rowPedido['cpf'] . '</td>
                    <td style="text-align:center">' . $rowPedido['rg'] . '</td>
                </tr>
                <tr>
                    <th>Data de Nascimento do cliente</th>
                    <th>Celular do cliente</th>
                 </tr>
                 <tr>
                     <td style="text-align:center">' . $rowPedido['dtNasc'] . '</td>
                     <td style="text-align:center">' . $rowPedido['celular'] . '</td>
                 </tr>
                 <tr>
                     <th>Nacionalidade do cliente</th>
                     <th>&nbsp;</th>
                  </tr>
                  <tr>
                      <td style="text-align:center">' . $rowPedido['nacionalidade'] . '</td>
                      <td style="text-align:center">&nbsp;</td>
                  </tr>
            </table>';
        }
        else{
            echo '<table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tr>
                    <th>Razão Social da Empresa</th>
                    <th>Nome Fantasia da Empresa</th>
                </tr>
                <tr>
                    <td style="text-align:center">' . ($rowPedido['razaoSocial']) . '</td>
                    <td style="text-align:center">' . ($rowPedido['nomeFantasia']) . '</td>
                </tr>
               <tr>
                   <th>Nome do Contato da Empresa</th>
                   <th>Email da Empresa</th>
                </tr>
                <tr>
                    <td style="text-align:center">' . $rowPedido['contato'] . '</td>
                    <td style="text-align:center">' . $rowPedido['emailCliente'] . '</td>
                </tr>
               <tr>
                   <th>CNPJ da Empresa</th>
                   <th>Inscrição Estadual da Empresa</th>
                </tr>
                <tr>
                    <td style="text-align:center">' . $rowPedido['cnpj'] . '</td>
                    <td style="text-align:center">' . $rowPedido['ie'] . '</td>
                </tr>
               <tr>
                   <th>Inscrição Municipal da Empresa</th>
                   <th>Data de Abertura da Empresa</th>
                </tr>
                <tr>
                    <td style="text-align:center">' . $rowPedido['im'] . '</td>
                    <td style="text-align:center">' . $rowPedido['dataAbertura'] . '</td>
                </tr>
               <tr>
                   <th>Celular da Empresa</th>
                   <th>Telefone da Empresa</th>
                </tr>
                <tr>
                    <td style="text-align:center">' . $rowPedido['cel'] . '</td>
                    <td style="text-align:center">' . $rowPedido['telefone'] . '</td>
                </tr>
                <tr>
                    <th>Nacionalidade da Empresa</th>
                    <th>&nbsp;</th>
                 </tr>
                 <tr>
                     <td style="text-align:center">' . $rowPedido['nacionalidadeEmpresa'] . '</td>
                     <td style="text-align:center">&nbsp;</td>
                 </tr>
            </table>';
        }
        echo '<h6><img src="'.URL.'img/pedido.png" width="30"> Dados do Orçamento</h6>
            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tr>
                    <th>Número do Orçamento</th>
                    <th>Data do Orçamento</th>
                </tr>
                <tr>
                    <td style="text-align:center">'.sprintf("%06s\n", $rowPedido['id']).'</td>
                    <td style="text-align:center">';
        $vet = explode(" ", $rowPedido['created_at']);
        $vet2 = explode("-", $vet[0]);
        echo $vet2[2]."/".$vet2[1].'/'.$vet2[0].' às '.$vet[1].'h</td>
                </tr>
               <tr>
                   <th colspan="2">Status do Orçamento</th>
                </tr>
                <tr>
                    <td style="text-align:center" colspan="2">'.utf8_encode($rowPedido['nomeStatus']);
        echo '</td>
                </tr>
            </table>
            ';
        echo '<h6><img src="'.URL.'img/carrinho.png" width="30"> Produtos Comprados</h6>
            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tr>
                   <th style="text-align: center">ID do Item de Produto</th>
                   <th style="text-align: center">Nome Produto</th>
                   <th style="text-align: center">Quantidade</th>
                   <th style="text-align: center">Valor Unitário</th>
                   <th style="text-align: center">Valor Total</th>
                </tr>
                ';
                $valueSubtotal = 0;
        foreach ($pedidosItens as $key => $itens){
            foreach($itens as $chave => $valor){
                $itens[$chave] = utf8_encode($valor);
            }
            echo '<tr>
                        <td style="text-align: center">'.$itens['product_item'].'</td>
                        <td style="text-align: center">'.$itens['name'];
            if ($itens['vale']){
                echo " - <img src='".URL."img/visualizar.svg' width='25' style='cursor:pointer' onclick=visualizarVale('".$itens['vale']."','".URL."')><div id='vale' style='position:absolute; display:none; background-color:#FFFFFF; border:1px solid #e7e7e7; border-radius:15px'></div>";
            }
            echo '</td>
                 <td style="text-align: center">'.$itens['quantity'].'</td>
                 <td style="text-align: center">R$ '.number_format($itens['value'], 2, ',','.').'</td>
                 <td style="text-align: center">R$ '.number_format($itens['value'] * $itens['quantity'], 2, ',','.').'</td>
            </tr>';
            $valueSubtotal += $itens['value'] * $itens['quantity'];
        }
        echo '
            <tr>
                <td colspan="3" style="text-align:right">Subtotal Carrinho: </td>
                <td colspan="2" style="text-align:left; font-weight:bold">R$ '.number_format($valueSubtotal, 2, ',', '.').'</td>
            </tr>
            <tr>
                <td colspan="3" style="text-align:right">Cupom de Desconto: </td>
                <td colspan="2" style="text-align:left; font-weight:bold; color:#003300">- R$ '.number_format($rowPedido['valueDiscount'], 2, ',', '.').' ';
        if ($rowPedido['discount']){
            echo '<img src="'. URL. 'img/informacao.png" width="20" style="cursor:pointer" onclick=abreFecha("informacoesCupomDesconto")><div id=\'informacoesCupomDesconto\' style=\'display:none; position:absolute; border:1px solid #e7e7e7; background-color:#FFFFFF; text-align:left; width:300px; border-radius:15px\'><div style=\'position:absolute; float:left; left:95%; cursor:pointer\' onclick=\'fecha("informacoesCupomDesconto")\'>&times;</div><h3>Informações do Cupom de Desconto </h3>ID do Cupom: <b>'.$rowPedido['discount'].'</b><br>Código do Cupom: <b>'.$rowPedido['codigo'].'</b><br>Valor do Cupom: <b>';
            if ($rowPedido['tipo'] == 1){
                echo "R$ ".number_format($rowPedido['valor'], 2, ',', '.');
            }
            else{
                echo $rowPedido['valor']."%";
            }
            $vet = explode('-', $rowPedido['validade']);
            $rowPedido['validade'] = $vet[2]."/".$vet[1]."/".$vet[0];
            echo '</b><br>Validade do Cupom: <b>'.$rowPedido['validade'].'</b></div>';
        }
        elseif ($rowPedido['vale']){
            echo '<img src="'. URL. 'img/informacao.png" width="20" style="cursor:pointer" onclick=abreFecha("informacoesValePresente")><div id=\'informacoesValePresente\' style=\'display:none; position:absolute; border:1px solid #e7e7e7; background-color:#FFFFFF; text-align:left; width:300px; border-radius:15px\'><div style=\'position:absolute; float:left; left:95%; cursor:pointer\' onclick=\'fecha("informacoesValePresente")\'>&times;</div><h3>Informações do Vale Presente</h3>ID do Vale: <b>'.$rowPedido['vale'].'</b><br>Código do Vale: <b>'.$rowPedido['code'].'</b><br>Valor do Vale: <b>R$ '.number_format($rowPedido['valorVale'], 2,',','.');
            $vet = explode('-', $rowPedido['validade2']);
            $rowPedido['validade'] = $vet[2]."/".$vet[1]."/".$vet[0];
            echo '</b><br>Validade do Vale: <b>'.$rowPedido['validade'].'</b></div>';
        }
        echo '</td>
            </tr>
            <tr>
                <td colspan="3" style="text-align:right">Total: </td>
                <td colspan="2" style="text-align:left; font-weight:bold; color:#000033">R$ '.number_format($valueSubtotal - $rowPedido['valueDiscount'], 2, ',', '.').'</td>
            </tr>
            </table>
            <h6><img src="'.URL.'img/endereco.png" width="30"> Dados do Endereço à Retirar o Orçamento</h6>';
                echo 'Imprima e leve este comprovante até a nossa loja, no endereço abaixo, para retirar os seus produtos.<br><br><b>'.utf8_encode($parametrosSite['endereco1'].'<br>'.$parametrosSite['endereco2'].'<br>'.$parametrosSite['endereco3']).'</b><br>';
            if ($rowPedido['msExterna']){
                echo '<h6><img src="'.URL.'img/mensagem.png" width="30"> Mensagens</h6>
            '.nl2br($rowPedido['msExterna']).'<br>';
            }
            echo "<hr noshade><center><a href='".URL."imprimirComprovante/".base64_encode($rowPedido['id'])."' target='_blank'><img src='".URL."img/imprimir.png' height='35'> Imprimir Comprovante</a></center><hr noshade>";
            $sql = utf8_decode("INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', 'Visualizou os detalhes do orçamento ".$_REQUEST['id']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
            mysqli_query($con, $sql);
            break;
    case "pegaPedidos":
        $sql = "SELECT a.*, b.name AS nomeClient, c.name AS nomeStatus, d.name AS nomeFormaPagamento
                FROM requests a INNER JOIN clients b ON (a.client = b.id)
                INNER JOIN requests_statuses c ON (a.status = c.id)
                INNER JOIN payment_methods d ON (a.paymentMethod= d.id)
                WHERE a.client = '".$_REQUEST['idClient']."' ORDER BY a.created_at DESC";
        $query = mysqli_query($con, $sql);
        $html = "<a id='topoPedidos'></a>";
        if (!mysqli_num_rows($query)){
            $html .= '<div style="background-color: #FF0000; color: #FFFFFF; padding:15px; text-align: center"><h5>Nenhum pedido encontrado!</h5></div>';
        }
        else{
            while ($row = mysqli_fetch_array($query)) {
                if ($row['status'] == 1){
                    $backgroundColor = "#000000";
                    $color = "#FFFFFF";
                }
                elseif ($row['status'] == 2){
                    $backgroundColor = "#FFFF00";
                    $color = "#000000";
                }
                elseif ($row['status'] == 3){
                    $backgroundColor = "#006600";
                    $color = "#FFFFFF";
                }
                elseif ($row['status'] == 4){
                    $backgroundColor = "#000099";
                    $color = "#FFFFFF";
                }
                elseif ($row['status'] == 5){
                    $backgroundColor = "#000033";
                    $color = "#FFFFFF";
                }
                elseif ($row['status'] == 6){
                    $backgroundColor = "#FF0000";
                    $color = "#FFFFFF";
                }
                $html .= '<div onclick="detalhesPedido(\''.$row['id'].'\', \''.URL.'\'); location.href=\'#topoPedidos\'" style="float:left; width:33%; padding:15px; cursor:pointer; background-color: '.$backgroundColor.'; color: '.$color.'; text-align: center"><h5>Pedido '.sprintf("%06s\n", $row['id']).'</h5><p>Cliente: <b>'.utf8_encode($row['nomeClient']).'</b><br>Forma de Pagamento: <b>'.utf8_encode($row['nomeFormaPagamento']).'</b><br>Status do Pedido: <b>'.utf8_encode($row['nomeStatus']).'</b></p></div>';
            }
        }
        echo "1|-|".$html;
        break;
    case "pegaEnderecos":
        $html = '<button type="button" class="btn btn-primary" onclick="novoEndereco()">Cadastrar Novo</button>
        <div id="novoEndereco" style="display:none; position: absolute; background-color: #FFFFFF; width:97%">
            <h5>Cadastro de Endereço</h5>
            <button type="button" class="close" onClick=fecha("novoEndereco")>
                <span aria-hidden="true">&times;</span>
            </button>
            <form name="formCadastroEndereco" id="formCadastroEndereco" method="head">
                <input type="hidden" id="urlEndereco" nome="urlEndereco" value="'.URL.'">
                <input type="hidden" id="idClienteEndereco" nome="idClienteEndereco" value="'.$_REQUEST['idCliente'].'">
                <label for="nome">Nome do Endereço:</label>
                <input type="text" placeholder="Nome do Endereço..." name="nome" id="nome" required class="form-control">
                <label for="cepEndereco">Cep:</label>
                <input type="text" placeholder="Cep..." name="cepEndereco" onkeyup="pesquisacep(this.value)" onkeypress="return mascara(this, \'00000-000\', event)" id="cepEndereco" required class="form-control">
                <sup>Somente Números</sup><br>
                <label for="logradouroEndereco">Logradouro:</label>
                <input type="text" placeholder="Logradouro..." name="logradouroEndereco" id="logradouroEndereco" required class="form-control">
                <label for="numeroEndereco">Número:</label>
                <input type="text" placeholder="Número..." name="numeroEndereco" id="numeroEndereco" required class="form-control">
                <label for="complementoEndereco">Complemento:</label>
                <input type="text" placeholder="Complemento..." name="complementoEndereco" id="complementoEndereco" class="form-control">
                <label for="bairroEndereco">Bairro:</label>
                <input type="text" placeholder="Bairro..." name="bairroEndereco" id="bairroEndereco" required class="form-control">
                <label for="cidadeEndereco">Cidade:</label>
                <input type="text" placeholder="Cidade..." name="cidadeEndereco" id="cidadeEndereco" required class="form-control">
                <label for="estadoEndereco">Estado:</label>
                <select name="estadoEndereco" id="estadoEndereco" required class="form-control">
                    <option value="">UF</option>
                    ';
        $sql = "SELECT * FROM states ORDER BY sigla ASC";
        $query2 = mysqli_query($con, $sql);
        while ($row2 = mysqli_fetch_array($query2)) {
            $html .= '<option value="'.$row2['sigla'].'">'.$row2['sigla'].'</option>';
        }
        $html .= '
                </select>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onClick=fecha("novoEndereco")>Fechar</button>
                    <button type="button" onclick=salvarEndereco("'.URL.'") class="btn btn-primary">Salvar Endereço</button>
                </div>
            </form>
        </div>';
        $html .= '<div id="editaEndereco" style="display:none; position: absolute; background-color: #FFFFFF; width:97%">
            <h5>Atualização de Endereço</h5>
            <button type="button" class="close" onClick=fecha("editaEndereco")>
                <span aria-hidden="true">&times;</span>
            </button>
            <form name="formEditaEndereco" id="formEditaEndereco" method="head">
                <input type="hidden" id="urlEditaEndereco" nome="urlEditaEndereco" value="'.URL.'">
                <input type="hidden" id="idClienteEditaEndereco" nome="idClienteEditaEndereco" value="'.$_REQUEST['idCliente'].'">
                <input type="hidden" id="idEditaEndereco" nome="idEditaEndereco" value="">
                <label for="nomeEdita">Nome do Endereço:</label>
                <input type="text" placeholder="Nome do Endereço..." name="nome" id="nomeEdita" required class="form-control">
                <label for="cepEditaEndereco">Cep:</label>
                <input type="text" placeholder="Cep..." name="cepEditaEndereco" onkeyup="pesquisacepedit(this.value)" onkeypress="return mascara(this, \'00000-000\', event)" id="cepEditaEndereco" required class="form-control">
                <sup>Somente Números</sup><br>
                <label for="logradouroEditaEndereco">Logradouro:</label>
                <input type="text" placeholder="Logradouro..." name="logradouroEditaEndereco" id="logradouroEditaEndereco" required class="form-control">
                <label for="numeroEditaEndereco">Número:</label>
                <input type="text" placeholder="Número..." name="numeroEditaEndereco" id="numeroEditaEndereco" required class="form-control">
                <label for="complementoEditaEndereco">Complemento:</label>
                <input type="text" placeholder="Complemento..." name="complementoEditaEndereco" id="complementoEditaEndereco" class="form-control">
                <label for="bairroEditaEndereco">Bairro:</label>
                <input type="text" placeholder="Bairro..." name="bairroEditaEndereco" id="bairroEditaEndereco" required class="form-control">
                <label for="cidadeEditaEndereco">Cidade:</label>
                <input type="text" placeholder="Cidade..." name="cidadeEditaEndereco" id="cidadeEditaEndereco" required class="form-control">
                <label for="estadoEditaEndereco">Estado:</label>
                <select name="estadoEditaEndereco" id="estadoEditaEndereco" required class="form-control">
                    <option value="">UF</option>
                ';
        $sql = "SELECT * FROM states ORDER BY sigla ASC";
        $query2 = mysqli_query($con, $sql);
        while ($row2 = mysqli_fetch_array($query2)) {
            $html .= '<option value="'.$row2['sigla'].'">'.$row2['sigla'].'</option>';
        }
        $html .= '
                </select>
                <div class="modal-footer" id="botoesEditaEndereco">
                    <button type="button" class="btn btn-secondary" onClick=fecha("editaEndereco")>Fechar</button>
                    <button type="button" onclick=editarEndereco("'.URL.'") class="btn btn-primary">Atualizar Endereço</button>
                </div>
            </form>
        </div>';
        $sql = "SELECT * FROM addresses WHERE idClient = '".$_REQUEST['idCliente']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $html .= '<table border="0" width="100%" cellpadding="0" cellspacing="0">
                <tr>
                    <th>Nome do Endereço</th>
                    <th>CEP do Endereço</th>
                    <th>Endereço</th>
                    <th>Ações</th>
                </tr>';
            while ($row = mysqli_fetch_array($query)){
                $html .= '<tr';
                if ($i % 2 == 0){
                    $html .= ' style="background-color:#e7e7e7"';
                }
                $html .= '><td>'.utf8_encode($row['name'].'</td><td>'.$row['cep'].'</td><td>'.$row['address'].' - '.$row['number']);
                if ($row['complement']){
                    $html .= ' - '.utf8_encode($row['complement']);
                }
                $html .= ' - '.utf8_encode($row['neighborhood'].' - '.$row['city'].' - '.$row['state']).'</td><td><img src="'.URL.'img/editar.png" width="20" onclick=\'abre("editaEndereco");editaEndereco("'.$row['id'].'","'.URL.'","'.$row['idClient'].'")\' style="cursor:pointer"> <img src="'.URL.'img/excluir.png" width="20" style="cursor:pointer" onclick=excluirEndereco("'.$row['id'].'","'.URL.'","'.$row['idClient'].'")></td></tr>';
                $i++;
            }
            $html .= "</table>";
        }
        else{
            $html .= "<center>Sem nenhum endereço cadastrado!</center>";
        }
        echo "1|-|".$html;
        break;
    case "editarEndereco":
        $sql = "SELECT * FROM addresses WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        echo utf8_encode("1|-|".$row['id']."|-|".$row['name']."|-|".$row['cep']."|-|".$row['address']."|-|".$row['number']."|-|".$row['complement']."|-|".$row['neighborhood']."|-|".$row['city']."|-|".$row['state']);
        break;
    case "excluirEndereco":
        $sql = "SELECT * FROM addresses WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $sql = "INSERT INTO logs (user, action, created_at, updated_at) VALUES ('".$_REQUEST['user']."', '".utf8_decode("Excluiu o endereço do cliente ").$row['idClient']." - ID: ".$_REQUEST['id']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql);
        $sql = "DELETE FROM addresses WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo '1';
        break;
    case "cadastraEndereco":
        $sql = utf8_decode("INSERT INTO addresses (idClient, name, cep, address, number, complement, neighborhood, city, state, country, created_at, updated_at) VALUES ('".$_REQUEST['idCliente']."', '".$_REQUEST['nome']."', '".$_REQUEST['cepEndereco']."', '".$_REQUEST['logradouroEndereco']."', '".$_REQUEST['numeroEndereco']."', '".$_REQUEST['complementoEndereco']."', '".$_REQUEST['bairroEndereco']."', '".$_REQUEST['cidadeEndereco']."', '".$_REQUEST['estadoEndereco']."', '".$_REQUEST['paisEndereco']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "salvarEndereco":
        $sql = utf8_decode("INSERT INTO addresses (idClient, name, cep, address, number, complement, neighborhood, city, state, created_at, updated_at) VALUES ('".$_REQUEST['idClienteEndereco']."', '".$_REQUEST['nome']."', '".$_REQUEST['cepEndereco']."', '".$_REQUEST['logradouroEndereco']."', '".$_REQUEST['numeroEndereco']."', '".$_REQUEST['complementoEndereco']."', '".$_REQUEST['bairroEndereco']."', '".$_REQUEST['cidadeEndereco']."', '".$_REQUEST['estadoEndereco']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "atualizarEndereco":
        $sql = "INSERT INTO logs (user, action, created_at, updated_at) VALUES ('".$_REQUEST['user']."', '".utf8_decode("Atualizou o endereço do cliente ").$_REQUEST['idCliente']." - ID: ".$_REQUEST['idEndereco']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql);
        $sql = utf8_decode("UPDATE addresses SET idClient = '".$_REQUEST['idCliente']."', name = '".$_REQUEST['nome']."', cep = '".$_REQUEST['cepEndereco']."', address = '".$_REQUEST['logradouroEndereco']."', number = '".$_REQUEST['numeroEndereco']."', complement = '".$_REQUEST['complementoEndereco']."', neighborhood = '".$_REQUEST['bairroEndereco']."', city = '".$_REQUEST['cidadeEndereco']."', state = '".$_REQUEST['estadoEndereco']."', country = '".$_REQUEST['paisEndereco']."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEndereco']."'");
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "visualizaEnderecos":
        echo '1|-|';
        $sql = "INSERT INTO logs (user, action, created_at, updated_at) VALUES ('".$_REQUEST['user']."', '".utf8_decode("Visualizou os endereços do cliente ").$_REQUEST['id']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql);
        echo '<button type="button" class="btn btn-primary" onclick=abre("modalCadastraEndereco")>Cadastrar novo</button>
                <div style="display:none; position:absolute; width: 100%" id="modalCadastraEndereco" tabindex="-1">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">'.("Cadastro de Endereço").'</h5>
                                <button type="button" class="close" onclick=fecha("modalCadastraEndereco")>
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form action="#" method="get" id="formAtualizaEndereco">
                                <div class="modal-body">
                                    <input type="hidden" id="idCliente" name="idCliente" value="'.$_REQUEST['id'].'">
                                    <input type="hidden" id="urlEndereco" nome="urlEndereco" value="'.URL.'">
                                    <label for="cepEndereco">Nome do Endereço:</label>
                                    <input type="text" placeholder="Nome do Endereço..." value="" name="nome" value="" id="nome" required class="form-control">
                                    <label for="cepEndereco">Cep:</label>
                                    <input type="text" placeholder="Cep..." name="cepEndereco" value="" onkeypress=mascara(this,"00000-000",event) id="cepEndereco" required class="form-control" onkeyup=verificacepcadastraendereco(this.value)>
                                    <sup>Somente Números</sup><br>
                                    <label for="logradouroEndereco">Logradouro:</label>
                                    <input type="text" placeholder="Logradouro..." value="" name="logradouroEndereco" id="logradouroEndereco" required class="form-control">
                                    <label for="numeroEndereco">Número:</label>
                                    <input type="text" placeholder="Número..." value="" name="numeroEndereco" id="numeroEndereco" required class="form-control">
                                    <label for="complementoEndereco">Complemento:</label>
                                    <input type="text" placeholder="Complemento..." value="" name="complementoEndereco" id="complementoEndereco" class="form-control">
                                    <label for="bairroEndereco">Bairro:</label>
                                    <input type="text" placeholder="Bairro..." value="" name="bairroEndereco" id="bairroEndereco" required class="form-control">
                                    <label for="cidadeEndereco">Cidade:</label>
                                    <input type="text" placeholder="Cidade..." value="" name="cidadeEndereco" id="cidadeEndereco" required class="form-control">
                                    <label for="estadoEndereco">Estado:</label>
                                    <select name="estadoEndereco" id="estadoEndereco" required class="form-control">
                                        <option value="">UF</option>
                                        ';
        $sql = "SELECT * FROM states ORDER BY sigla ASC";
        $query2 = mysqli_query($con, $sql);
        while ($row2 = mysqli_fetch_array($query2)) {
            echo '
                                        <option value="'.$row2['sigla'].'">'.$row2['sigla'].'</option>';
        }
        echo '
                                    </select>
                                    <label for="paisEndereco">País:</label>
                                    <select name="paisEndereco" id="paisEndereco" required class="form-control">
                                        <option value="">Selecione o país corretamente...</option>
                                        ';
        $sql = "SELECT * FROM countries ORDER BY padrao DESC, name ASC";
        $query2 = mysqli_query($con, $sql);
        while ($row2 = mysqli_fetch_array($query2)) {
            echo '
                                        <option value="'.$row2['id'].'" ';
            if ($row['country'] == $row2['id']){
                echo 'selected';
            }
            echo '>'.$row2['name'].'</option>';
        }
        echo '
                                    </select>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" onclick=fecha("modalCadastraEndereco")>Fechar</button>
                                    <button type="button" class="btn btn-primary" onClick=cadastrarEndereco("","'.URL.'","'.$_REQUEST['id'].'","'.$_REQUEST['user'].'")>Cadastrar Endereço</button>
                                </div>
                                </form>
                            </div>
                            </div>
                            </div>';
        $sql = "SELECT a.*, b.name AS nomePais FROM addresses a INNER JOIN countries b ON (a.country = b.id) WHERE a.idClient = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (!mysqli_num_rows($query)){
            echo "<div style='width:100%; background-color:#990000; color:#FFFFFF; text-align: center' id='registros'>Nenhum endereço encontrado!</div>";
        }
        else{
            echo '<table border="0" width="100%" cellpadding="0" cellspacing="0"><tr><th>Nome do Endereço</th><th>CEP do Endereço</th><th>Endereço</th><th>Ações</th></tr>';
            while($row = mysqli_fetch_array($query)){
                echo utf8_encode('<tr');
                if ($i % 2 == 1){
                    echo ' style="background-color:#e7e7e7"';
                }
                echo utf8_encode('><td>'.$row['name'].'</td><td>'.$row['cep'].'</td><td>'.$row['address'].' - '.$row['number']);
                if ($row['complement']){
                    echo utf8_encode(' - '.$row['complement']);
                }
                echo utf8_encode(' - B. '.$row['neighborhood'].' - '.$row['city'].' - '.$row['state'].' - '.utf8_decode($row['nomePais']).'</td><td><a onclick=abre("modalAtualizaEndereco'.$row['id'].$_REQUEST['id'].'") style="cursor:pointer"><img src="'.URL.'img/editar.png" width="20"></a> ');
                $sql = "SELECT * FROM requests WHERE address = '".$row['id']."'";
                $query2 = mysqli_query($con, $sql);
                if (!mysqli_num_rows($query2)) {
                    echo utf8_encode('<img src="' . URL . 'img/excluir.png" style="cursor: pointer" onclick=excluirEndereco("' . $row['id'] . '","' . URL . '","' . $_REQUEST['id'] . '","' . $_REQUEST['user'] . '") width="20">');
                }
                echo '</td></tr><script>
function retornoCEPAtualizaEndereco'.$row['id'].$_REQUEST['id'].'(conteudo) {
    if (!("erro" in conteudo)) {
        //Atualiza os campos com os valores.
        document.getElementById("logradouroEndereco'.$row['id'].$_REQUEST['id'].'").value=(conteudo.logradouro);
        document.getElementById(\'numeroEndereco'.$row['id'].$_REQUEST['id'].'\').value="";
        document.getElementById(\'complementoEndereco'.$row['id'].$_REQUEST['id'].'\').value="";
        document.getElementById(\'bairroEndereco'.$row['id'].$_REQUEST['id'].'\').value=(conteudo.bairro);
        document.getElementById(\'cidadeEndereco'.$row['id'].$_REQUEST['id'].'\').value=(conteudo.localidade);
        document.getElementById(\'estadoEndereco'.$row['id'].$_REQUEST['id'].'\').value=(conteudo.uf);
        document.getElementById(\'numeroEndereco'.$row['id'].$_REQUEST['id'].'\').focus();
    } //end if.
    else {
        //CEP não Encontrado.
        alert("CEP não encontrado. Digeite as informações manualmente!");
        document.getElementById(\'logradouroEndereco'.$row['id'].$_REQUEST['id'].'\').value="";
        document.getElementById(\'bairroEndereco'.$row['id'].$_REQUEST['id'].'\').value="";
        document.getElementById(\'numeroEndereco'.$row['id'].$_REQUEST['id'].'\').value="";
        document.getElementById(\'complementoEndereco'.$row['id'].$_REQUEST['id'].'\').value="";
        document.getElementById(\'cidadeEndereco'.$row['id'].$_REQUEST['id'].'\').value="";
        document.getElementById(\'estadoEndereco'.$row['id'].$_REQUEST['id'].'\').value="";
        document.getElementById(\'logradouroEndereco'.$row['id'].$_REQUEST['id'].'\').focus();
    }
}
                </script>
                <div style="display:none; position:absolute; width: 100%" id="modalAtualizaEndereco'.$row['id'].$_REQUEST['id'].'" tabindex="-1">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">'.("Atualização de Endereço").'</h5>
                                <button type="button" class="close" onclick=fecha("modalAtualizaEndereco'.$row['id'].$_REQUEST['id'].'")>
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form action="#" method="get" id="formAtualizaEndereco">
                                <div class="modal-body">
                                    <input type="hidden" id="idCliente'.$row['id'].$_REQUEST['id'].'" name="idCliente'.$row['id'].$_REQUEST['id'].'" value="'.$_REQUEST['id'].'">
                                    <input type="hidden" id="idEndereco'.$row['id'].$_REQUEST['id'].'" name="idEndereco'.$row['id'].$_REQUEST['id'].'" value="'.$row['id'].'">
                                    <input type="hidden" id="urlEndereco" nome="urlEndereco" value="'.URL.'">
                                    <label for="cepEndereco">Nome do Endereço:</label>
                                    <input type="text" placeholder="Nome do Endereço..." value="'.utf8_encode($row['name']).'" name="nome'.$row['id'].$_REQUEST['id'].'" value="'.$row['name'].'" id="nome'.$row['id'].$_REQUEST['id'].'" required class="form-control">
                                    <label for="cepEndereco">Cep:</label>
                                    <input type="text" placeholder="Cep..." name="cepEndereco'.$row['id'].$_REQUEST['id'].'" value="'.$row['cep'].'" onkeypress="return mascara(this, \'00000-000\', event)" id="cepEndereco'.$row['id'].$_REQUEST['id'].'" required class="form-control" onkeyup=verificacepatualizaendereco(this.value,"'.$row['id'].'","'.$_REQUEST['id'].'")>
                                    <sup>Somente Números</sup><br>
                                    <label for="logradouroEndereco">Logradouro:</label>
                                    <input type="text" placeholder="Logradouro..." value="'.utf8_encode($row['address']).'" name="logradouroEndereco'.$row['id'].$_REQUEST['id'].'" id="logradouroEndereco'.$row['id'].$_REQUEST['id'].'" required class="form-control">
                                    <label for="numeroEndereco">Número:</label>
                                    <input type="text" placeholder="Número..." value="'.utf8_encode($row['number']).'" name="numeroEndereco'.$row['id'].$_REQUEST['id'].'" id="numeroEndereco'.$row['id'].$_REQUEST['id'].'" required class="form-control">
                                    <label for="complementoEndereco">Complemento:</label>
                                    <input type="text" placeholder="Complemento..." value="'.utf8_encode($row['complement']).'" name="complementoEndereco'.$row['id'].$_REQUEST['id'].'" id="complementoEndereco'.$row['id'].$_REQUEST['id'].'" class="form-control">
                                    <label for="bairroEndereco">Bairro:</label>
                                    <input type="text" placeholder="Bairro..." value="'.utf8_encode($row['neighborhood']).'" name="bairroEndereco'.$row['id'].$_REQUEST['id'].'" id="bairroEndereco'.$row['id'].$_REQUEST['id'].'" required class="form-control">
                                    <label for="cidadeEndereco">Cidade:</label>
                                    <input type="text" placeholder="Cidade..." value="'.utf8_encode($row['city']).'" name="cidadeEndereco'.$row['id'].$_REQUEST['id'].'" id="cidadeEndereco'.$row['id'].$_REQUEST['id'].'" required class="form-control">
                                    <label for="estadoEndereco">Estado:</label>
                                    <select name="estadoEndereco'.$row['id'].$_REQUEST['id'].'" id="estadoEndereco'.$row['id'].$_REQUEST['id'].'" required class="form-control">
                                        <option value="">UF</option>
                                        ';
        $sql = "SELECT * FROM states ORDER BY sigla ASC";
        $query2 = mysqli_query($con, $sql);
        while ($row2 = mysqli_fetch_array($query2)) {
            echo '
                                        <option value="'.$row2['sigla'].'" ';
            if ($row['state'] == $row2['sigla']){
                echo 'selected';
            }
            echo '>'.$row2['sigla'].'</option>';
        }
        echo '
                                    </select>
                                <label for="paisEndereco">País:</label>
                                    <select name="paisEndereco'.$row['id'].$_REQUEST['id'].'" id="paisEndereco'.$row['id'].$_REQUEST['id'].'" required class="form-control">
                                        <option value="">Selecione o país corretamente...</option>
                                        ';
        $sql = "SELECT * FROM countries ORDER BY padrao DESC, name ASC";
        $query2 = mysqli_query($con, $sql);
        while ($row2 = mysqli_fetch_array($query2)) {
            echo '
                                        <option value="'.$row2['id'].'" ';
            if ($row['country'] == $row2['id']){
                echo 'selected';
            }
            echo '>'.$row2['name'].'</option>';
        }
        echo '
                                    </select>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                                    <button type="button" class="btn btn-primary" onClick=atualizarEndereco("'.$row['id'].'","'.URL.'","'.$_REQUEST['id'].'","'.$_REQUEST['user'].'")>Atualizar Endereço</button>
                                </div>
                                </form>
                            </div>
                            </div>';
                $i++;
            }
            echo '</table>
                 <p style="font-weight:bold; font-size:12px">* Não é possível excluir endereços com pedidos relacionados à ele.</p>';
        }   echo '</div>';
        break;
    case "cadastro":
        if (!$_REQUEST['idCliente']) {
            $sql = "SELECT * FROM clients WHERE email = '" . $_REQUEST['emailCadastro'] . "'";
            $query = mysqli_query($con, $sql);
            if (!mysqli_num_rows($query)) {
                $sql = utf8_decode("INSERT INTO clients (email, password, type_person, created_at, updated_at) VALUES ('" . $_REQUEST['emailCadastro'] . "', '" . md5($_REQUEST['senhaCadastro']) . "', '" . $_REQUEST['tipoCadastro'] . "', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
                $query = mysqli_query($con, $sql) or die(mysqli_error($con));
                $idCliente = mysqli_insert_id($con);
                $_SESSION['cliente']['id'] = $idCliente;
                if ($_REQUEST['tipoCadastro'] == 'F') {
                    $sql = "INSERT INTO pessoa_fisicas (client, name, cpf, rg, nationality, dtNasc, cel, status, created_at, updated_at) VALUES ('".$idCliente."', '".$_REQUEST['nomeCadastro']."', '".$_REQUEST['cpfCadastro']."', '".$_REQUEST['rgCadastro']."', '".$_REQUEST['nacionalidadeCadastro']."', '".$_REQUEST['dtNascCadastro']."', '(".$_REQUEST['dddCelularCadastro'].")".$_REQUEST['celularCadastro']."', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                    mysqli_query($con, $sql) or die(mysqli_error($con));
                    $_SESSION['cliente']['nome'] = utf8_decode($_REQUEST['nomeCadastro']);
                }
                else{
                    $sql = "INSERT INTO pessoa_juridicas (client, razaoSocial, nomeFantasia, contato, cnpj, ie, im, nationality, dataAbertura, cel, telefone, status, created_at, updated_at) VALUES ('".$idCliente."', '".$_REQUEST['razaoSocialCadastro']."', '".$_REQUEST['nomeFantasiaCadastro']."', '".$_REQUEST['contatoCadastro']."', '".$_REQUEST['cnpjCadastro']."', '".$_REQUEST['ieCadastro']."', '".$_REQUEST['imCadastro']."', '".$_REQUEST['nacionalidadeEmpresaCadastro']."', '".$_REQUEST['dataAberturaCadastro']."', '(".$_REQUEST['dddCelularCadastro'].")".$_REQUEST['celularCadastro']."', '(".$_REQUEST['dddTelefoneCadastro'].")".$_REQUEST['telefoneCadastro']."', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                    mysqli_query($con, $sql) or die(mysqli_error($con));
                    $_SESSION['cliente']['nome'] = utf8_decode($_REQUEST['nomeFantasiaCadastro']);
                }
                $_SESSION['cliente']['email'] = $_REQUEST['emailCadastro'];
                echo '1';
            } else {
                echo "0|-|Esse email já está cadastrado em nosso site! Feche esta janela e clique em 'Esqueceu sua senha?'!";
            }
        }
        break;
    case 'selecionaTipoPessoa':     
        $sql = "SELECT * FROM nationalities ORDER BY padrao DESC, created_at DESC, id ASC";   
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                $nacionalidade[] = $row;
            }
        }
        if($_REQUEST['tipo'] == 'F'){
            $html = '<input type="text" placeholder="Nome" required name="nomeCadastro" id="nomeCadastro" /><input type="text" placeholder="CPF (somente números)" required name="cpfCadastro" id="cpfCadastro" onkeyup="mascara(this, \'###.###.###-##\', event)" maxlength="14" /><input type="text" placeholder="RG" required name="rgCadastro" id="rgCadastro" /><select name="nacionalidadeCadastro" id="nacionalidadeCadastro"><option value="">Selecione a nacionalidade corretamente...</option>';
            foreach ($nacionalidade as $key => $value){
                $html .= '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
            $html .= '</select><br><br><input type="date" placeholder="Data de Nascimento" required name="dtNascCadastro" id="dtNascCadastro" title="Data de Nascimento" /><span style="float:left">(</span><input type="text" placeholder="DDD" required name="dddCelularCadastro" id="dddCelularCadastro" onkeyup="passaProximo(\'dddCelularCadastro\', 2, \'celularCadastro\')" style="float:left; width:9%" maxlength="2" /><span style="float:left">)</span><input type="text" placeholder="Celular (somente números)" required name="celularCadastro" id="celularCadastro" style="float:left; width:88%" onkeyup="passaProximo(\'celularCadastro\', 10, \'emailCadastro\'); mascara(this, \'#####-####\', event)" maxlength="10" />';
        }
        else{
            $html = '<input type="text" placeholder="Razão Social" required name="razaoSocialCadastro" id="razaoSocialCadastro" /><input type="text" placeholder="Nome Fantasia" required name="nomeFantasiaCadastro" id="nomeFantasiaCadastro" /><input type="text" placeholder="Nome do Contato" required name="contatoCadastro" id="contatoCadastro" /><input type="text" placeholder="CNPJ" required name="cnpjCadastro" id="cnpjCadastro" maxlength="18" onkeyup="mascara(this, \'##.###.###/####-##\', event)" /><input type="text" placeholder="Inscrição Estadual" required name="ieCadastro" id="ieCadastro" /><input type="text" placeholder="Inscrição Municipal" required name="imCadastro" id="imCadastro" /><select name="nacionalidadeEmpresaCadastro" id="nacionalidadeEmpresaCadastro"><option value="">Selecione a nacionalidade corretamente...</option>';
            foreach ($nacionalidade as $key => $value){
                $html .= '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
            $html .= '</select><br><br><input type="date" placeholder="Data de Abertura da Empresa" title="Data de Abertura da Empresa" required name="dataAberturaCadastro" id="dataAberturaCadastro" /><span style="float:left">(</span><input type="text" placeholder="DDD" required name="dddCelularCadastro" id="dddCelularCadastro" onkeyup="passaProximo(\'dddCelularCadastro\', 2, \'celularCadastro\')" style="float:left; width:9%" maxlength="2" /><span style="float:left">)</span><input type="text" placeholder="Celular (somente números)" required name="celularCadastro" id="celularCadastro" style="float:left; width:88%" onkeyup="passaProximo(\'celularCadastro\', 10, \'dddTelefoneCadastro\'); mascara(this, \'#####-####\', event)" maxlength="10" /><span style="float:left">(</span><input type="text" placeholder="DDD" required name="dddTelefoneCadastro" id="dddTelefoneCadastro" onkeyup="passaProximo(\'dddTelefoneCadastro\', 2, \'telefoneCadastro\')" style="float:left; width:9%" maxlength="2" /><span style="float:left">)</span><input type="text" placeholder="Telefone (somente números)" required name="telefoneCadastro" id="telefoneCadastro" style="float:left; width:88%" onkeyup="passaProximo(\'telefoneCadastro\', 9, \'emailCadastro\'); mascara(this, \'####-####\', event)" maxlength="9" />';
        }
        echo "1|-|".$html;
        break;
    case "atualizarCadastro":
        $sql = "SELECT * FROM clients WHERE id = '".$_SESSION['cliente']['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $sql = "SELECT * FROM clients WHERE id != '".$_SESSION['cliente']['id']."' AND email = '".$_REQUEST['emailAtualiza']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            echo "0|-|Já existe outro cliente cadastrado com esse email. Utilize outro.";
        }
        else{
            $sql = utf8_decode("UPDATE clients SET email = '".$_REQUEST['emailAtualiza']."', type_person = '".$_REQUEST['tipoAtualiza']."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_SESSION['cliente']['id']."'");
            mysqli_query($con, $sql);
            $sql = "DELETE FROM pessoa_fisicas WHERE client = '".$_SESSION['cliente']['id']."'";
            mysqli_query($con, $sql);
            $sql = "DELETE FROM pessoa_juridicas WHERE client = '".$_SESSION['cliente']['id']."'";
            mysqli_query($con, $sql);
            if ($_REQUEST['tipoAtualiza'] == 'F') {
                $sql = "INSERT INTO pessoa_fisicas (client, name, cpf, rg, nationality, dtNasc, cel, status, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', '".$_REQUEST['nomeAtualiza']."', '".$_REQUEST['cpfAtualiza']."', '".$_REQUEST['rgAtualiza']."', '".$_REQUEST['nacionalidadeAtualiza']."', '".$_REQUEST['dtNascAtualiza']."', '".$_REQUEST['celularAtualiza']."', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                mysqli_query($con, $sql) or die(mysqli_error($con));
                $_SESSION['cliente']['name'] = utf8_decode($_REQUEST['nomeAtualiza']);
            }
            else{
                $sql = "INSERT INTO pessoa_juridicas (client, razaoSocial, nomeFantasia, contato, cnpj, ie, im, nationality, dataAbertura, cel, telefone, status, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', '".$_REQUEST['razaoSocialAtualiza']."', '".$_REQUEST['nomeFantasiaAtualiza']."', '".$_REQUEST['contatoAtualiza']."', '".$_REQUEST['cnpjAtualiza']."', '".$_REQUEST['ieAtualiza']."', '".$_REQUEST['imAtualiza']."', '".$_REQUEST['nacionalidadeEmpresaAtualiza']."', '".$_REQUEST['dataAberturaAtualiza']."', '".$_REQUEST['celularAtualiza']."', '".$_REQUEST['telefoneAtualiza']."', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                mysqli_query($con, $sql) or die(mysqli_error($con));
                $_SESSION['cliente']['name'] = utf8_decode($_REQUEST['nomeFantasiaAtualiza']);
            }
            $sql = "INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', 'Atualizou o cadastro do cliente!', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql);
            echo '1|-|'.utf8_encode($_SESSION['cliente']['name']);
        }
        break;
    case "atualizarSenha":
        $sql = "SELECT * FROM clients WHERE id = '".$_SESSION['cliente']['id']."' AND password = '".md5($_REQUEST['senhaAtual'])."'";
        $query = mysqli_query($con, $sql);
        if (!mysqli_num_rows($query)){
            echo "0|-|Senha informada incorretamente!|-|senhaAtualAtualiza";
        }
        else{
            $sql = utf8_decode("UPDATE clients SET password = '".md5($_REQUEST['novaSenha'])."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_SESSION['cliente']['id']."'");
            mysqli_query($con, $sql);
            $sql = "INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', 'Atualizou a senha do cliente!', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql);
            echo '1';
        }
        break;
    case "alterarSenha":
        if ($_REQUEST['password'] != $_REQUEST['password2']){
            echo "0|-|Senhas digitadas não coincidem!";
        }
        else{
            $sql = "UPDATE clients SET password = '".md5($_REQUEST['password'])."', updated_at = '".date('Y-m-d H:i:s')."', remember_token = '' WHERE id = '".$_REQUEST['idCliente']."'";
            mysqli_query($con, $sql);
            $sql = "INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', 'Alterou a senha do cliente!', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql);
            $sql = "SELECT * FROM clients WHERE id = '".$_REQUEST['idCliente']."'";
            $query = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($query);
            $_SESSION['cliente']['id'] = $row['id'];
            $_SESSION['cliente']['name'] = $row['name'];
            $_SESSION['cliente']['email'] = $row['email'];
            echo "1|-|Senha alterada com sucesso!";
        }
        break;
    case "enviarEsqueceuSuaSenha":
        if ($_REQUEST['emailEsqueceuSuaSenha2']){
            $_REQUEST['emailEsqueceuSuaSenha'] = $_REQUEST['emailEsqueceuSuaSenha2'];
        }
        $sql = "SELECT a.*, b.name AS nomeCliente, c.nomeFantasia FROM clients a LEFT JOIN pessoa_fisicas b ON (a.id = b.client) LEFT JOIN pessoa_juridicas c ON (a.id = c.client) WHERE a.email = '".$_REQUEST['emailEsqueceuSuaSenha']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $row = mysqli_fetch_array($query);
            $nomeCliente = ($row['nomeCliente']) ? $row['nomeCliente'] : $row['nomeFantasia'];
            $rt = "";
            for ($i = 0; $i < 30; $i++) {
                $rt .= rand(0, 9);
            }
            $sql = "UPDATE clients SET remember_token = '".$rt."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$row['id']."'";
            mysqli_query($con, $sql);
            $htmlEmail = '<html><head><title>Email de recuperação de senha - '.$parametrosSite['title'].'</title></head><body><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td width="250" style="width: 250px; text-align: center;"><img src="'.URL.'img/logo.png" width="200"></td><td>Olá '.$nomeCliente.',<br><br>Para acessar o link para alterar a sua senha, <a href="'.URL.'alterar-senha-site.php?remember_token='.$rt.'&client='.base64_encode($row['id']).'">clique aqui</a>.<br><br>Atenciosamente,<br><br>Equipe '.$parametrosSite['title'].'<hr noshade><center>Email Desenvolvido Pela <a href="https://www.bhcommerce.com.br/">BH Commerce</a></center><hr noshade></td></tr></table></body></html>';
            //echo $htmlEmail;
            $assuntoEmail = "Email de recuperação de senha - ".$parametrosSite['title'];
            $paraEmail = $row['nome']."<".$row['email'].">";            $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
            $cabecalhoEmail .= "From: Contato - BH Commerce<contato@catalogobhcommerce.rf.gd>\nReply-To: Contato - BH Commerce<Contato - BH Commerce<contato@catalogobhcommerce.rf.gd>";
            //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $row['email'], $nomeCliente, utf8_decode($assuntoEmail), $htmlEmail);
			mail(utf8_decode($paraEmail), utf8_decode($assuntoEmail), utf8_decode($htmlEmail), utf8_decode($cabecalhoEmail));
            echo "1";
        }
        else{
            echo "0";
        }
        break;
    case "realizarLogin":
        if (isset($_REQUEST['emailLogin2'])){
            $_REQUEST['emailLogin'] = $_REQUEST['emailLogin2'];
        }
        if (isset($_REQUEST['passwordLogin2'])){
            $_REQUEST['passwordLogin'] = $_REQUEST['passwordLogin2'];
        }
        $sql = "SELECT * FROM clients  WHERE email = '".$_REQUEST['emailLogin']."' AND password = '".md5($_REQUEST['passwordLogin'])."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            if ($row['type_person'] == 'F'){
                $sql = "SELECT * FROM pessoa_fisicas WHERE client = '".$row['id']."'";
                $query2 = mysqli_query($con, $sql);
                $row2 = mysqli_fetch_array($query2);
                $_SESSION['cliente']['name'] = $row2['name'];
            }
            elseif ($row['type_person'] == 'J'){
                $sql = "SELECT * FROM pessoa_juridicas WHERE client = '".$row['id']."'";
                $query2 = mysqli_query($con, $sql);
                $row2 = mysqli_fetch_array($query2);
                $_SESSION['cliente']['name'] = $row2['nomeFantasia']." - ".$row2['contato'];
            }
            $_SESSION['cliente']['email'] = $row['email'];
            $_SESSION['cliente']['id'] = $row['id'];
            $sql = "INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$row['id']."', 'Se logou no site!', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql);
            echo "1";
        }
        else{
            echo "0|-|Não existe cliente com o email ou senha informados!";
        }
        break;
    case "insereLogClienteVisualiza":
        $acao = "Visualizou ";
        if ($_REQUEST['id'] == 67){
            $acao .= "o cadastro do cliente!"; 
        }
        elseif ($_REQUEST['id'] == 70){
            $acao .= "os seus endereços!"; 
        }
        elseif ($_REQUEST['id'] == 71){
            $acao .= "a tela de alterar a senha!"; 
        }
        elseif ($_REQUEST['id'] == 72){
            $acao .= "os seus orçamentos!"; 
        }
        elseif ($_REQUEST['id'] == 73){
            $acao .= "as suas listas de presentes!"; 
        }
        $sql = "INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', '".utf8_decode($acao)."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "logout":
        $sql = "INSERT INTO logs_clients (client, action, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', 'Efetuou logout no site!', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql);
        $_SESSION['cliente']['id'] = "";
        $_SESSION['cliente']['name'] = "";
        $_SESSION['cliente']['email'] = "";
        $_SESSION['idLista'] = "";
        echo "1";
        break;
    case "salvarNews":
        $email['nome'] = $parametrosSite['title']." <".$parametrosSite['email'].">";
        $email['assunto'] = "Email cadastrado na newsletter com sucesso! - ".$parametrosSite['title'];
        $email['cabecalho'] = "Content-Type: text/html; charset=iso-8859-1\n";
        $email['cabecalho'] .= "From: ".$parametrosSite['title']." <".$parametrosSite['email'].">\nReply-To: ".$parametrosSite['title']." <".$parametrosSite['email'].">";
        $email['corpo'] = '<html><head><title>'.$email['assunto'].'</title></head><body><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td width="250" style="width: 250px; text-align: center;"><img src="'.URL.'img/logo.png" width="200"></td><td>Olá, o email <b>"'.$_REQUEST['emailNews'].'"</b>, foi cadastrado em nosso site em '.date('d/m/Y H:i').'h.<br><br>Atenciosamente,<br><br>Equipe '.$parametrosSite['title'].'<hr noshade><center>Email Desenvolvido Pela <a href="https://www.bhcommerce.com.br/">BH Commerce</a></center><hr noshade></td></tr></table></body></html>';
        $sql = "SELECT * FROM newsletters WHERE email = '".$_REQUEST['emailNews']."'";
        $query = mysqli_query($con, $sql);
        //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $parametrosSite['email'], $parametrosSite['title'], $email['assunto'], $email['corpo']);
        mail($parametrosSite['title']."<".$parametrosSite['email'].">", utf8_decode($email['assunto']), utf8_decode($email['corpo']), $email['cabecalho']);
        if (!mysqli_num_rows($query)) {
            $sql = "INSERT INTO newsletters (name, email, status, created_at, updated_at) VALUES ('" . utf8_decode($_REQUEST['emailNews'] . "', '" . $_REQUEST['emailNews']) . "', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        }
        else{
            $sql = "UPDATE newsletters SET updated_at = '".date('Y-m-d H:i:s')."' WHERE email = '".$_REQUEST['emailNews']."'";
        }
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "salvarContato":
        $email['nome'] = $parametrosSite['title']." <".$parametrosSite['email'].">";
        $email['assunto'] = utf8_decode("Email enviado pelo formulário de Fale Conosco do Site - ".$parametrosSite['title']." - ".$_REQUEST['subject']);
        $email['cabecalho'] = "Content-Type: text/html; charset=iso-8859-1\n";
        $email['cabecalho'] .= "From: ".$parametrosSite['title']." <".$parametrosSite['email'].">\nReply-To: ".$parametrosSite['title']." <".$parametrosSite['email'].">";
        $email['corpo'] = utf8_decode('<html><head><title>'.$email['assunto'].'</title></head><body><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td width="250" style="width: 250px; text-align: center;"><img src="'.URL.'img/logo.png" width="200"></td><td>Olá, foi enviado um novo email a partir do formulário de fale conosco do site. <br><b>Nome: </b> '.$_REQUEST['name'].'<br><b>Email: </b> '.$_REQUEST['email'].'<br><b>Assunto: </b> '.$_REQUEST['subject'].'<br><b>Telefone: </b> '.$_REQUEST['phone'].'<br><b>Mensagem: </b> '.nl2br($_REQUEST['text']).'<br><br>Atenciosamente,<br><br>Equipe <a href="'.URL.'">'.$parametrosSite['title'].'</a><hr noshade><center>Email Desenvolvido Pela <a href="https://www.bhcommerce.com.br/">BH Commerce</a></center><hr noshade></td></tr></table></body></html>');
        mail($email['nome'], $email['assunto'], $email['corpo'], $email['cabecalho']);
        //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $parametrosSite['email'], $parametrosSite['title'], $email['assunto'], $email['corpo']);
        $sql = "INSERT INTO messages (name, email, subject, phone, text, status, created_at, updated_at) VALUES ('".utf8_decode($_REQUEST['name']."', '".$_REQUEST['email']."', '".$_REQUEST['subject']."', '".$_REQUEST['phone']."', '".$_REQUEST['text'])."', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "salvarBugTracking":
        $sql = "SELECT * FROM  types_services WHERE id = '".$_REQUEST['typeService']."'";
        $query = mysqli_query($con, $sql);
        $rowTipoServico = mysqli_fetch_array($query);
        $sql = "SELECT * FROM  type_versions WHERE id = '".$_REQUEST['typeVersion']."'";
        $query = mysqli_query($con, $sql);
        $rowTipoVersao = mysqli_fetch_array($query);
        $sql = "SELECT * FROM  priorities WHERE id = '".$_REQUEST['priority']."'";
        $query = mysqli_query($con, $sql);
        $rowPrioridade = mysqli_fetch_array($query);
        $sql = "SELECT * FROM  categories WHERE id = '".$_REQUEST['category']."'";
        $query = mysqli_query($con, $sql);
        $rowCategoria = mysqli_fetch_array($query);
        $email['nome'] = "Loja Virtual da BH Commerce <contato@bhcommerce.com.br>";
        $email['assunto'] = utf8_decode("Email enviado pelo formulário de Bug Tracking do Site - BH Commerce - ".$_REQUEST['titleBugTracking']);
        $email['cabecalho'] = "Content-Type: text/html; charset=iso-8859-1\n";
        $email['cabecalho'] .= "From: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>\nReply-To: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>";
        $email['corpo'] = utf8_decode('<html><head><title>'.$email['assunto'].'</title></head><body><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td width="250" style="width: 250px; text-align: center;" valign="top"><img src="'.URL.'img/logo.png" width="200"></td><td>Olá, foi enviado um novo email a partir do formulário de bug tracking do site. <br><b>Nome: </b> '.$_REQUEST['nameBugTracking'].'<br><b>Email: </b> '.$_REQUEST['emailBugTracking'].'<br><b>Título: </b> '.$_REQUEST['titleBugTracking'].'<br><b>Tipo de Serviço: </b> '.utf8_encode($rowTipoServico['name']).'<br><b>Versão: </b> '.utf8_encode($rowTipoVersao['name']).'<br><b>Prioridade: </b> '.utf8_encode($rowPrioridade['name']).'<br><b>Categoria: </b> '.utf8_encode($rowCategoria['name']).'<br><b>Mensagem: </b> '.nl2br($_REQUEST['message']).'<br><b>Status: </b>Enviado<br><br>Atenciosamente,<br><br>Equipe <a href="'.URL.'">'.$parametrosSite['title'].'</a><hr noshade><center>Email Desenvolvido Pela <a href="https://www.bhcommerce.com.br/">BH Commerce</a></center><hr noshade></td></tr></table></body></html>');
        mail($email['nome'], $email['assunto'], $email['corpo'], $email['cabecalho']);
        //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $parametrosSite['email'], $parametrosSite['title'], $email['assunto'], $email['corpo']);
        $sql = "INSERT INTO bug_trackings (typeService, typeVersion, priority, category, name, email, title, message, created_at, updated_at) VALUES ('".utf8_decode($_REQUEST['typeService']."', '".$_REQUEST['typeVersion']."', '".$_REQUEST['priority']."', '".$_REQUEST['category']."', '".$_REQUEST['nameBugTracking']."', '".$_REQUEST['emailBugTracking']."', '".$_REQUEST['titleBugTracking']."', '".$_REQUEST['message'])."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql) or die(mysqli_error($con)."<br>".$sql);
        echo "1";
        break;
    case 'selecionaTipoServiço':
        echo "1|-|<label class=\"form-label\">
                                Versão
                                <span class=\"text-danger\">*</span>
                            </label>

                            <select class=\"form-control\" name=\"typeVersion\" id=\"typeVersion\" required
                                    data-msg=\"Por Favor, informe a versão.\"
                                    data-error-class=\"u-has-error\"
                                    data-success-class=\"u-has-success\">
                                <option value=\"\">Selecione a versão corretamente</option>";
        $sql = "SELECT * FROM type_versions WHERE typeService = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                echo "<option value=\"".$row['id']."\">".$row['name']."</option>";
            }
        }
        echo "</select>|-|<label class=\"form-label\">Prioridade
                                <span class=\"text-danger\">*</span>
                            </label><select class=\"form-control\" name=\"priority\" id=\"priority\" required
                                    data-msg=\"Por Favor, informe a prioridade. \"
                                    data-error-class=\"u-has-error\"
                                    data-success-class=\"u-has-success\">
                                <option value=\"\">Selecione a prioridade corretamente</option>";
        $sql = "SELECT * FROM priorities";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                echo "<option value=\"".$row['id']."\" > ".utf8_encode($row['name'])."</option>";
            }
        }
        echo "</select>|-|<label class=\"form-label\">
                                Categoria
                                <span class=\"text-danger\">*</span>
                            </label>

                            <select class=\"form-control\" name=\"category\" id=\"category\" required
                                    data-msg=\"Por Favor, informe a categoria.\"
                                    data-error-class=\"u-has-error\"
                                    data-success-class=\"u-has-success\">
                                <option value=\"\">Selecione a categoria corretamente</option>";
        $sql = "SELECT * FROM categories WHERE typeService = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                echo "<option value=\"".$row['id']."\"> ".utf8_encode($row['name'])."</option>";
            }
        }
        echo "</select>";
        break;
    case 'selecionaTipoServiçoAdmin':
        echo "1|-|<select name=\"typeVersion\" id=\"typeVersion\" required class='form-control'>
                                <option value=\"\">Selecione a versão corretamente</option>";
        $sql = "SELECT * FROM type_versions WHERE typeService = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                echo "<option value=\"".$row['id']."\" ";
                if ($_REQUEST['version'] == $row['id']){
                    echo " selected";
                }
                echo ">".$row['name']."</option>";
            }
        }
        echo "</select>|-|<select name=\"priority\" id=\"priority\" required class='form-control'>
                       <option value=\"\">Selecione a prioridade corretamente</option>";
        $sql = "SELECT * FROM priorities";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                echo "<option value=\"".$row['id']."\" ";
                if ($_REQUEST['priority'] == $row['id']){
                    echo " selected";
                }
                echo "> ".utf8_encode($row['name'])."</option>";
            }
        }
        echo "</select>|-|<select name=\"category\" id=\"category\" required class='form-control'>
                                <option value=\"\">Selecione a categoria corretamente</option>";
        $sql = "SELECT * FROM categories WHERE typeService = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                echo "<option value=\"".$row['id']."\" ";
                if ($_REQUEST['category'] == $row['id']){
                    echo " selected";
                }
                echo "> ".utf8_encode($row['name'])."</option>";
            }
        }
        echo "</select>";
        break;
    case 'adicionaProdutoPedido':
        echo "1|-|<input type='hidden' id='pedidoAdd' name='pedidoAdd' value='".$_REQUEST['id']."'><input type='hidden' id='idUserAdd' name='idUserAdd' value='".$_REQUEST['idUser']."'><label for='produtoAdd'>Produto: </label>
                  <select name='produtoAdd' id='produtoAdd' class='form-control' onchange=selecionaProdutoPedido(this.value,'".URL."')><option value=''>Selecione o produto abaixo corretamente...</option>";
        $sql = "SELECT * FROM products";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                echo "<option value='".$row['id']."'>".utf8_encode($row['name'])."</option>";
            }
        }
        echo "</select><div id='itensProdutoPedido'></div>";
        break;
    case "selecionaProdutoPedido":
        echo "1|-|<label for='itemVendaAdd'>Item de Venda: </label>
                  <select name='itemVendaAdd' id='itemVendaAdd' class='form-control' onchange=selecionaItemVendaPedido(this.value,'".$_REQUEST['id']."','".URL."')><option value=''>Selecione o item de venda abaixo corretamente...</option>";
        $sql = "SELECT * FROM products_items WHERE product = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            while ($row = mysqli_fetch_array($query)) {
                echo "<option value='" . $row['id']."'>" . utf8_encode($row['name']) . " - ";
                if ($row['promotion'] != '0.00' && $row['vlidity_promotion'] <= date('Y-m-d')) {
                    echo "R$" . number_format($row['promotion'], 2, ',', '.');
                } else {
                    echo "R$" . number_format($row['value'], 2, ',', '.');
                }
                echo "</option>";
            }
        }
        echo "</select><div id='itensVendaPedidoProduto'></div>";
        break;
    case "selecionaItemVendaPedido":
        if ($_REQUEST['idProduto'] != 3 && $_REQUEST['idProduto'] != 4){
            $html = "<label for='dominioAdd'>Domínio: </label><input type='text' name='dominioAdd' id='dominioAdd' class='form-control'>";
        }
        elseif($_REQUEST['idProduto'] == 3){
            $html = "<label for='razaoSocialAdd'>Razão Social: </label><input type='text' name='razaoSocialAdd' id='razaoSocialAdd' class='form-control'>
                    <label for='nomeFantasiaAdd'>Nome Fantasia: </label><input type='text' name='nomeFantasiaAdd' id='nomeFantasiaAdd' class='form-control'>
                    <label for='cnpjAdd'>CNPJ: </label><input type='text' name='cnpjAdd' id='cnpjAdd' class='form-control' maxlength='18' onkeyup=formataCampo(this,'XX.XXX.XXX/XXXX-XX',event)>
                    <label for='emailAdd'>Email: </label><input type='email' name='emailaAdd' id='emailAdd' class='form-control'>
                    <label for='cepAdd'>CEP: </label><input type='cepAdd' name='cepAdd' id='cepAdd' class='form-control' maxlength='9' onkeyup=formataCampo(this,'XXXXX-XXX',event);verificaCepCaixa(this.value)>
                    <label for='logradouroAdd'>Logradouro </label><input type='text' name='logradouroAdd' id='logradouroAdd' class='form-control'>
                    <label for='numeroAdd'>Número </label><input type='text' name='numeroAdd' id='numeroAdd' class='form-control'>
                    <label for='complementoAdd'>Complemento </label><input type='text' name='complementoAdd' id='complementoAdd' class='form-control'>
                    <label for='bairroAdd'>Bairro </label><input type='text' name='bairroAdd' id='bairroAdd' class='form-control'>
                    <label for='cidadeAdd'>Cidade </label><input type='text' name='cidadeAdd' id='cidadeAdd' class='form-control'>
                    <label for='estadoAdd'>Estado </label><select name='estadoAdd' id='estadoAdd' class='form-control'><option value=''>Selecione o estado abaixo...</option>";
            $sql = "SELECT * FROM states ORDER BY sigla ASC";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                while ($row = mysqli_fetch_array($query)){
                    $html .= "<option value='".$row['sigla']."'>".utf8_encode($row['nome'])."</option>";
                }
            }
            $html .= "</select>
                    <label forr='tipoEstabelecimentoAdd'>Tipo do Estabelecimento: </label>
                    <select name='tipoEstabelecimentoAdd' id='tipoEstabelecimentoAdd' class='form-control' onchange='selecionaTipoEstabelecimentoAdd(this.value)'>
                        <option value=''>Selecione o tipo do estabelecimento abaixo...</option>
                        <option value='1'>Mesas</option>
                        <option value='2'>Caixas</option>
                    </select>
                    <div id='outrosItensAdd'></div>";
        }
        elseif($_REQUEST['idProduto'] == 3){
            $html = "<label for='razaoSocialAdd'>Razão Social: </label><input type='text' name='razaoSocialAdd' id='razaoSocialAdd' class='form-control'>
                    <label for='nomeFantasiaAdd'>Nome Fantasia: </label><input type='text' name='nomeFantasiaAdd' id='nomeFantasiaAdd' class='form-control'>
                    <label for='cnpjAdd'>CNPJ: </label><input type='text' name='cnpjAdd' id='cnpjAdd' class='form-control' maxlength='18' onkeyup=formataCampo(this,'XX.XXX.XXX/XXXX-XX',event)>
                    <label for='emailAdd'>Email: </label><input type='email' name='emailaAdd' id='emailAdd' class='form-control'>
                    <label for='cepAdd'>CEP: </label><input type='cepAdd' name='cepAdd' id='cepAdd' class='form-control' maxlength='9' onkeyup=formataCampo(this,'XXXXX-XXX',event);verificaCepCaixa(this.value)>
                    <label for='logradouroAdd'>Logradouro </label><input type='text' name='logradouroAdd' id='logradouroAdd' class='form-control'>
                    <label for='numeroAdd'>Número </label><input type='text' name='numeroAdd' id='numeroAdd' class='form-control'>
                    <label for='complementoAdd'>Complemento </label><input type='text' name='complementoAdd' id='complementoAdd' class='form-control'>
                    <label for='bairroAdd'>Bairro </label><input type='text' name='bairroAdd' id='bairroAdd' class='form-control'>
                    <label for='cidadeAdd'>Cidade </label><input type='text' name='cidadeAdd' id='cidadeAdd' class='form-control'>
                    <label for='estadoAdd'>Estado </label><select name='estadoAdd' id='estadoAdd' class='form-control'><option value=''>Selecione o estado abaixo...</option>";
            $sql = "SELECT * FROM states ORDER BY sigla ASC";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                while ($row = mysqli_fetch_array($query)){
                    $html .= "<option value='".$row['sigla']."'>".utf8_encode($row['nome'])."</option>";
                }
            }
            $html .= "</select>
                    <label forr='tipoEstabelecimentoAdd'>Tipo do Estabelecimento: </label>
                    <select name='tipoEstabelecimentoAdd' id='tipoEstabelecimentoAdd' class='form-control' onchange='selecionaTipoEstabelecimentoAdd(this.value)'>
                        <option value=''>Selecione o tipo do estabelecimento abaixo...</option>
                        <option value='1'>Mesas</option>
                        <option value='2'>Caixas</option>
                    </select>
                    <div id='outrosItensAdd'></div>";
        }
        elseif($_REQUEST['idProduto'] == 3){
            $html = "<label for='razaoSocialAdd'>Razão Social: </label><input type='text' name='razaoSocialAdd' id='razaoSocialAdd' class='form-control'>
                    <label for='nomeFantasiaAdd'>Nome Fantasia: </label><input type='text' name='nomeFantasiaAdd' id='nomeFantasiaAdd' class='form-control'>
                    <label for='cnpjAdd'>CNPJ: </label><input type='text' name='cnpjAdd' id='cnpjAdd' class='form-control' maxlength='18' onkeyup=formataCampo(this,'XX.XXX.XXX/XXXX-XX',event)>
                    <label for='emailAdd'>Email: </label><input type='email' name='emailaAdd' id='emailAdd' class='form-control'>
                    <label for='cepAdd'>CEP: </label><input type='cepAdd' name='cepAdd' id='cepAdd' class='form-control' maxlength='9' onkeyup=formataCampo(this,'XXXXX-XXX',event);verificaCepCaixa(this.value)>
                    <label for='logradouroAdd'>Logradouro </label><input type='text' name='logradouroAdd' id='logradouroAdd' class='form-control'>
                    <label for='numeroAdd'>Número </label><input type='text' name='numeroAdd' id='numeroAdd' class='form-control'>
                    <label for='complementoAdd'>Complemento </label><input type='text' name='complementoAdd' id='complementoAdd' class='form-control'>
                    <label for='bairroAdd'>Bairro </label><input type='text' name='bairroAdd' id='bairroAdd' class='form-control'>
                    <label for='cidadeAdd'>Cidade </label><input type='text' name='cidadeAdd' id='cidadeAdd' class='form-control'>
                    <label for='estadoAdd'>Estado </label><select name='estadoAdd' id='estadoAdd' class='form-control'><option value=''>Selecione o estado abaixo...</option>";
            $sql = "SELECT * FROM states ORDER BY sigla ASC";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                while ($row = mysqli_fetch_array($query)){
                    $html .= "<option value='".$row['sigla']."'>".utf8_encode($row['nome'])."</option>";
                }
            }
            $html .= "</select>
                    <label forr='tipoEstabelecimentoAdd'>Tipo do Estabelecimento: </label>
                    <select name='tipoEstabelecimentoAdd' id='tipoEstabelecimentoAdd' class='form-control' onchange='selecionaTipoEstabelecimentoAdd(this.value)'>
                        <option value=''>Selecione o tipo do estabelecimento abaixo...</option>
                        <option value='1'>Mesas</option>
                        <option value='2'>Caixas</option>
                    </select>
                    <div id='outrosItensAdd'></div>";
        }
        elseif($_REQUEST['idProduto'] == 4){
            $html = "<label for='nomeEscolaAdd'>Nome da Escola: </label><input type='text' name='nomeEscolaAdd' id='nomeEscolaAdd' class='form-control'>
                    <label for='emailAdd'>Email da Escola: </label><input type='email' name='emailAdd' id='emailAdd' class='form-control'>
                    <label for='cepAdd'>CEP da Escola: </label><input type='cepAdd' name='cepAdd' id='cepAdd' class='form-control' maxlength='9' onkeyup=formataCampo(this,'XXXXX-XXX',event);verificaCepCaixa(this.value)>
                    <label for='logradouroAdd'>Logradouro da Escola: </label><input type='text' name='logradouroAdd' id='logradouroAdd' class='form-control'>
                    <label for='numeroAdd'>Número da Escola: </label><input type='text' name='numeroAdd' id='numeroAdd' class='form-control'>
                    <label for='complementoAdd'>Complemento da Escola: </label><input type='text' name='complementoAdd' id='complementoAdd' class='form-control'>
                    <label for='bairroAdd'>Bairro da Escola: </label><input type='text' name='bairroAdd' id='bairroAdd' class='form-control'>
                    <label for='cidadeAdd'>Cidade da Escola: </label><input type='text' name='cidadeAdd' id='cidadeAdd' class='form-control'>
                    <label for='estadoAdd'>Estado da Escola: </label><select name='estadoAdd' id='estadoAdd' class='form-control'><option value=''>Selecione o estado abaixo...</option>";
            $sql = "SELECT * FROM states ORDER BY sigla ASC";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                while ($row = mysqli_fetch_array($query)){
                    $html .= "<option value='".$row['sigla']."'>".utf8_encode($row['nome'])."</option>";
                }
            }
            $html .= "</select>
                    <label forr='tipoNotaAdd'>Tipo de Nota: </label>
                    <select name='tipoNotaAdd' id='tipoNotaAdd' class='form-control'>
                        <option value=''>Selecione o tipo de nota abaixo...</option>
                        <option value='1'>Bimestral</option>
                        <option value='2'>Trimestral</option>
                        <option value='3'>Semestral</option>
                        <option value='4'>Anual</option>
                    </select>
                    <label forr='turnoAdd'>Turno da escola: </label>
                    <select name='turnoAdd' id='turnoAdd' class='form-control'>
                        <option value=''>Selecione o turno da escola abaixo...</option>
                        <option value='1'>Manhã</option>
                        <option value='2'>Tarde</option>
                        <option value='3'>Noite</option>
                        <option value='4'>Único</option>
                        <option value='5'>Todos</option>
                    </select>
                    <label forr='letraAdd'>Até que letra  as turmas da escola vão: </label>
                    <select name='letraAdd' id='letraAdd' class='form-control'>
                        <option value=''>Selecione a letra da escola abaixo...</option>
                        <option value='Un'>Única</option>
                        ";
           for ($i = 1; $i <= 26; $i++){
               if ($i == 1){
                   $letra = "a";
               }
               elseif ($i == 2){
                   $letra = "b";
               }
               elseif ($i == 3){
                   $letra = "c";
               }
               elseif ($i == 4){
                   $letra = "d";
               }
               elseif ($i == 5){
                   $letra = "e";
               }
               elseif ($i == 6){
                   $letra = "f";
               }
               elseif ($i == 7){
                   $letra = "g";
               }
               elseif ($i == 8){
                   $letra = "h";
               }
               elseif ($i == 9){
                   $letra = "i";
               }
               elseif ($i == 10){
                   $letra = "j";
               }
               elseif ($i == 11){
                   $letra = "k";
               }
               elseif ($i == 12){
                   $letra = "l";
               }
               elseif ($i == 13){
                   $letra = "m";
               }
               elseif ($i == 14){
                   $letra = "n";
               }
               elseif ($i == 15){
                   $letra = "o";
               }
               elseif ($i == 16){
                   $letra = "p";
               }
               elseif ($i == 17){
                   $letra = "q";
               }
               elseif ($i == 18){
                   $letra = "r";
               }
               elseif ($i == 19){
                   $letra = "s";
               }
               elseif ($i == 20){
                   $letra = "t";
               }
               elseif ($i == 21){
                   $letra = "u";
               }
               elseif ($i == 22){
                   $letra = "v";
               }
               elseif ($i == 23){
                   $letra = "w";
               }
               elseif ($i == 24){
                   $letra = "x";
               }
               elseif ($i == 25){
                   $letra = "y";
               }
               elseif ($i == 26){
                   $letra = "z";
               }
               $html .=  "<option value='".$letra."'>".$letra."</option>";
           }
           $html .= "
                    </select>";
        }
        $html .= "<input type='button' class='btn btn-primary' value='Cadastrar' onclick=adicionarProdutoPedido($('#produtoAdd').val(),$('#itemVendaAdd').val(),$('#dominioAdd').val(),'".URL."')>";
        echo "1|-|".$html;
        break;
    case 'adicionarProdutoPedido':
        if($_REQUEST['idProduto'] == 8){
            $sql = "SELECT * FROM products_items WHERE product = '" . $_REQUEST['idProduto'] . "'";
            $query = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($query);
            $sql = "SELECT * FROM subitems WHERE id = '". $_REQUEST['idItVenda'] ."'";
            $query2 = mysqli_query($con, $sql);
            $row2 = mysqli_fetch_array($query2);
            $row['name'] .= " - ".$row2['name'];
        }
        else {
            $sql = "SELECT * FROM products_items WHERE id = '" . $_REQUEST['idItVenda'] . "'";
            $query = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($query);
        }
        $valor = ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')) ? $row['promotion'] : $row['value'];
        $sql = "INSERT INTO requests_items (request, product, product_item, name, domine, quantity, value, created_at, updated_at) VALUES ('".$_REQUEST['idPedido']."', '".$_REQUEST['idProduto']."', '".$_REQUEST['idItVenda']."', '".$row['name']."', '".$_REQUEST['dominio']."', '1', '".$valor."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        //echo $sql;
        mysqli_query($con, $sql) or die(mysqli_error($con));
        $idRequestItem = mysqli_insert_id($con);
        if ($_REQUEST['idProduto'] == 3){
            $sql = "INSERT INTO cashier_system (razao_social, nome_fantasia, email, cnpj, cep, logradouro, numero, complemento, bairro, cidade, estado, tipoEstabelecimento, quantidade, numeroPessoasPorMesa, percentual, created_at, updated_at) VALUES ('".$_REQUEST['razaoSocial']."', '".$_REQUEST['nomeFantasia']."', '".$_REQUEST['email']."', '".$_REQUEST['cnpj']."', '".$_REQUEST['cep']."', '".$_REQUEST['logradouro']."', '".$_REQUEST['numero']."', '".$_REQUEST['complemento']."', '".$_REQUEST['bairro']."', '".$_REQUEST['cidade']."', '".$_REQUEST['estado']."', '".$_REQUEST['tipoEstabelecimento']."', '".$_REQUEST['quantidade']."', '".$_REQUEST['numPessoas']."', '".$_REQUEST['percentual']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql) or die(mysqli_error($con)." - ".$sql);
            $idCashierSystem = mysqli_insert_id($con);
            $sql = "UPDATE requests_items SET cashier_system = '".$idCashierSystem."' WHERE id = '".$idRequestItem."'";
            mysqli_query($con, $sql) or die(mysqli_error($con));
        }
        if ($_REQUEST['idProduto'] == 4){
            $sql = "INSERT INTO school_system (nome, email, cep, logradouro, numero, complemento, bairro, cidade, estado, tipoNota, turno, letra, created_at, updated_at) VALUES ('".$_REQUEST['nome']."', '".$_REQUEST['email']."', '".$_REQUEST['cep']."', '".$_REQUEST['logradouro']."', '".$_REQUEST['numero']."', '".$_REQUEST['complemento']."', '".$_REQUEST['bairro']."', '".$_REQUEST['cidade']."', '".$_REQUEST['estado']."', '".$_REQUEST['tipoNota']."', '".$_REQUEST['turno']."', '".$_REQUEST['letra']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql) or die(mysqli_error($con)." - ".$sql);
            $idSchoolSystem = mysqli_insert_id($con);
            $sql = "UPDATE requests_items SET school_system = '".$idSchoolSystem."' WHERE id = '".$idRequestItem."'";
            mysqli_query($con, $sql) or die(mysqli_error($con));
        }
        echo "1|-|".$idRequestItem."|-|".$idCashierSystem;
        break;
    case 'excluirProdutoPedido':
        $sql = "SELECT * FROM requests_items WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $sql = "SELECT * FROM products_items WHERE id = '".$row['product_item']."'";
        $query = mysqli_query($con, $sql);
        $row2 = mysqli_fetch_array($query);
        $estoque = $row['quantity'] + $row2['estoque'];
        $sql = "UPDATE products_items SET estoque = '".$estoque."' WHERE id = '".$row['product_item']."'";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        $sql = "DELETE FROM requests_items WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        $sql = "SELECT a.*, b.cep FROM requests a INNER JOIN addresses b ON (a.address = b.id) WHERE a.id = '".$row['request']."'";
        $query = mysqli_query($con, $sql);
        $row3 = mysqli_fetch_array($query);
        $sql = "SELECT a.*, b.peso, b.comprimento, b.largura, b.altura, b.diametro FROM requests_items a INNER JOIN products_items b ON (a.product_item = b.id) WHERE a.request = '".$row['request']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while($row = mysqli_fetch_array($query)){
                if (!preg_match('/Vale Presente/', $row['name'])) {
                    $valorSubtotal += $row['value'] * $row['quantity'];
                    $peso += $row['peso'] * $row['quantity'];
                    $diametro += $row['diametro'] * $row['quantity'];
                    $comprimento += $row['comprimento'] * $row['quantity'];
                    $largura += $row['largura'] * $row['quantity'];
                    $altura += $row['altura'] * $row['quantity'];
                }
            }
        }
        if ($row3['tipoFrete'] != 'Frete_Gratis') {
            if ($row3['tipoFrete'] == 'SEDEX'){
                $tipoFrete = 40010;
            }
            elseif ($row3['tipoFrete'] == 'PAC'){
                $tipoFrete = 41106;
            }
            elseif ($row3['tipoFrete'] == 'SEDEX_10'){
                $tipoFrete = 40215;
            }
            elseif ($row3['tipoFrete'] == 'SEDEX_Hoje'){
                $tipoFrete = 40290;
            }
            unset($data);
            $data['nCdEmpresa'] = '';
            $data['sDsSenha'] = '';
            $data['sCepOrigem'] = $parametrosSite['cepLoja'];
            $data['sCepDestino'] = str_replace('-', '', $row3['cep']);
            $data['nVlPeso'] = $peso;
            $data['nCdFormato'] = '1';
            $data['nVlComprimento'] = $comprimento;
            $data['nVlAltura'] = $altura;
            $data['nVlLargura'] = $largura;
            $data['nVlDiametro'] = $diametro;
            $data['sCdMaoPropria'] = 's';
            $data['nVlValorDeclarado'] = $valorSubtotal;
            $data['sCdAvisoRecebimento'] = 'n';
            $data['StrRetorno'] = 'xml';
            $data = http_build_query($data);
            $url = 'http://ws.correios.com.br/calculador/CalcPrecoPrazo.aspx';
            $curl = curl_init($url . '?' . $data."&nCdServico=".$tipoFrete);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

            $result = curl_exec($curl);

            $result = simplexml_load_string($result);

            foreach ($result->cServico as $row) {

                //Os dados de cada serviço estará aqui

                $retorno[$k] = $row;

            }
            foreach ($retorno as $key => $value) {
                $valorFrete = str_replace(".", "", $value->Valor);
                $valorFrete = str_replace(",", ".", $valorFrete);
            }
        }
        else{
            $valorFrete = 0;
        }
        $valorTotal = $valorSubtotal + $valorFrete - $row3['valurDiscount'];
        $sql = "UPDATE requests SET valueSubtotal = '".$valorSubtotal."', valueFrete = '".$valorFrete."', valueTotal = '".$valorTotal."' WHERE id = '".$row3['id']."'";
        mysqli_query($con, $sql);
        echo "1";
        break;
    case 'gerarAutomaticamente':
        echo "1|-|".rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9)."-LOJA-".rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9);
        break;
    case "redirecionaRedeSocial":
        $sql = "SELECT * FROM social_networks WHERE slug = '".$_REQUEST['slug']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $row = mysqli_fetch_array($query);
            $cliques = $row['cliques'] + 1;
            $sql = "UPDATE social_networks SET cliques = '" . $cliques . "' WHERE id = '" . $row['id'] . "'";
            mysqli_query($con, $sql);
            echo "1|-|" . $row['link'];
        }
        else{
            echo "0|-|Não foi encontrada nenhuma rede social com a url informada!";
        }
        break;
    case "importar":
        switch($_REQUEST['table']){
            case "nacionalidade":
                if ($_REQUEST['limparCampos']){
                    $sql = "TRUNCATE nationalities";
                    $query = mysqli_query($con, $sql);
                }
                $delimitador = ';';
                $cerca = '"';

                // Abrir arquivo para leitura
                $f = fopen($_FILES['arquivo']['tmp_name'], 'r');
                if ($f) {

                    // Enquanto nao terminar o arquivo
                    while (!feof($f)) {

                        // Ler uma linha do arquivo
                        $linha = fgetcsv($f, 0, $delimitador, $cerca);
                        if (!$linha) {
                            continue;
                        }

                        // Montar registro com valores indexados pelo cabecalho
                        $registro = array_combine($cabecalho, $linha);
                        if ($linha[0] != 'Nome'){
                            // Obtendo o nome
                            $sql = "SELECT * FROM nationalities WHERE name = '".utf8_encode(ucwords($linha[0]))."'";
                            $query = mysqli_query($con, $sql);
                            if (!mysqli_num_rows($query)) {
                                $vet = explode(' às ', utf8_encode($linha[2]));
                                $vet2 = explode('/', $vet[0]);
                                $linha[2] = $vet2[2]."-".$vet2[1]."-".$vet2[0]." ".str_replace('h', '', $vet[1]);
                                $vet = explode(' às ', utf8_encode($linha[3]));
                                $vet2 = explode('/', $vet[0]);
                                $linha[3] = $vet2[2]."-".$vet2[1]."-".$vet2[0]." ".str_replace('h', '', $vet[1]);
                                $padrao = ($linha[1] == 'Sim') ? '1' : '0';
                                $sql = "INSERT INTO nationalities (name, status, padrao, created_at, updated_at) VALUES ('" .utf8_encode(ucwords($linha[0])) . "', '1', '".$padrao."', '".$linha[1]."', '".$linha[2]."')";
                                mysqli_query($con, $sql);
                            }
                        }
                    }
                    fclose($f);
                }
                break;
            case "pais":
                if ($_REQUEST['limparCampos']){
                    $sql = "TRUNCATE countries";
                    $query = mysqli_query($con, $sql);
                }
                $delimitador = ';';
                $cerca = '"';

                // Abrir arquivo para leitura
                $f = fopen($_FILES['arquivo']['tmp_name'], 'r');
                if ($f) {

                    // Enquanto nao terminar o arquivo
                    while (!feof($f)) {

                        // Ler uma linha do arquivo
                        $linha = fgetcsv($f, 0, $delimitador, $cerca);
                        if (!$linha) {
                            continue;
                        }

                        // Montar registro com valores indexados pelo cabecalho
                        $registro = array_combine($cabecalho, $linha);
                        if ($linha[0] != "Nome"){
                            // Obtendo o nome
                            $sql = "SELECT * FROM countries WHERE name = '".utf8_encode(ucwords($linha[0]))."'";
                            $query = mysqli_query($con, $sql);
                            if (!mysqli_num_rows($query)) {
                                $vet = explode(' às ', utf8_encode($linha[2]));
                                $vet2 = explode('/', $vet[0]);
                                $linha[2] = $vet2[2]."-".$vet2[1]."-".$vet2[0]." ".str_replace('h', '', $vet[1]);
                                $vet = explode(' às ', utf8_encode($linha[3]));
                                $vet2 = explode('/', $vet[0]);
                                $linha[3] = $vet2[2]."-".$vet2[1]."-".$vet2[0]." ".str_replace('h', '', $vet[1]);
                                $padrao = ($linha[1] == 'Sim') ? "1" : "0";
                                $sql = "INSERT INTO countries (name, status, padrao, created_at, updated_at) VALUES ('" . utf8_encode(ucwords($linha[0])) . "', '1', '".$padrao."', '".$linha[1]."', '".$linha[2]."')";
                                mysqli_query($con, $sql);
                            }
                        }
                    }
                    fclose($f);
                }
                break;
        }
        echo "1";
        break;
    default:
        echo "0|-|Não foi encontrada a ação pesquisada!";
        break;
}
function retirarAcentos($name){
    $slug = utf8_encode(strtolower(str_replace(' ', '-', $name)));
    $slug = str_replace("+", "-", $slug);
    $slug = str_replace("/", "", $slug);
    $slug = str_replace("%", "", $slug);
    $slug = str_replace("&", "e", $slug);
    $slug = str_replace("?", "", $slug);
    $slug = str_replace("!", "", $slug);
    $slug = str_replace("á", "a", $slug);
    $slug = str_replace("à", "a", $slug);
    $slug = str_replace("ã", "a", $slug);
    $slug = str_replace("â", "a", $slug);
    $slug = str_replace("ª", "a", $slug);
    $slug = str_replace("é", "e", $slug);
    $slug = str_replace("è", "e", $slug);
    $slug = str_replace("ê", "e", $slug);
    $slug = str_replace("í", "i", $slug);
    $slug = str_replace("ì", "i", $slug);
    $slug = str_replace("ó", "o", $slug);
    $slug = str_replace("ò", "o", $slug);
    $slug = str_replace("ô", "o", $slug);
    $slug = str_replace("õ", "o", $slug);
    $slug = str_replace("º", "o", $slug);
    $slug = str_replace("ú", "u", $slug);
    $slug = str_replace("ù", "u", $slug);
    $slug = str_replace("û", "u", $slug);
    $slug = str_replace("ç", "c", $slug);
    $slug = str_replace(".", "", $slug);
    return $slug;
}

function enviarEmail($deEmail, $deNome, $paraEmail, $paraNome, $assunto, $mensagem){
    $urlEnvio = URL."enviaremail.php";
    // URL:
    $ch = curl_init($urlEnvio);
    // Obter retorno em $resultado:
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    // -F
    // Definir como POST:
    curl_setopt($ch, CURLOPT_POST, true);
    // -F
    // Definir corpo, como multipart/form-data:
    curl_setopt($ch, CURLOPT_POSTFIELDS, [
        'deEmail' => utf8_encode($deEmail),
        'deNome' => utf8_encode($deNome),
        'paraEmail' => ($paraEmail),
        'paraNome' => utf8_decode($paraNome),
        'assunto' => utf8_encode($assunto),
        'mensagem' => utf8_encode($mensagem)
    ]);
    // -u
    $resultado = curl_exec($ch);
    curl_close ($ch);
    return $resultado;
}
?>
