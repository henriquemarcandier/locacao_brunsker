<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Ítens Excluídos</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?=URL?>">Home</a></li>
                            <li class="breadcrumb-item">Cadastros</li>
                            <li class="breadcrumb-item"><a href="<?=URL?>itens-excluidos">Ítens Excluídos</a></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <!-- Small boxes (Stat box) -->
                <div class="row" id="conteudo">
                    <img src="<?=URL?>img/loader.gif" width="20"> Aguarde... Carregando...
                    <!-- ./col -->
                </div>
                <input type="hidden" name="idUserRegistrosExcluidos" id="idUserRegistrosExcluidos" value="<?=$_SESSION['user']['id']?>">
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
        <div class="modal fade" id="modalVerTodosExcluidos" tabindex="-1" role="dialog" aria-labelledby="modalCadastro" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ver todos os Excluídos</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar" id="fecharCadastro">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div id="conteudoVerExcluidos">
                        <img src="<?=URL?>img/loader.gif" width="20"> Aguarde... Carregando...
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>window.setInterval('verificaNovamente("itensExcluidos", "<?=URL?>")', 60000); window.setTimeout('verificaNovamente("itensExcluidos", "<?=URL?>")', 3000); </script>