<?php
require_once('../connect.php');

$sql = "SELECT a.*, b.name AS nomeUsuario FROM logs a INNER JOIN users b ON (a.user = b.id) ";
if ($_REQUEST['user'] > 1){
    $sql .= "WHERE a.user = '".$_REQUEST['user']."'";
    $where = "1";
}
if ($_REQUEST['usuarioFiltro']){
    if($where){
        $sql .= "AND ";
    }
    else{
        $sql .= "WHERE ";
    }
    $sql .= "a.user = '".$_REQUEST['usuarioFiltro']."' ";
    $where = "1";
}
if ($_REQUEST['acaoFiltro']){
    if($where){
        $sql .= "AND ";
    }
    else{
        $sql .= "WHERE ";
    }
    $sql .= "a.action LIKE '%".$_REQUEST['acaoFiltro']."%' ";
    $where = "1";
}
if ($_REQUEST['idUser'] != 1) {
    if ($where) {
        $sql .= "AND ";
    } else {
        $sql .= "WHERE ";
    }
    $sql .= "a.user = '" . $_REQUEST['idUser'] . "' ";
    $where = 1;
}
$sql .= "ORDER BY a.created_at DESC";
$query = mysqli_query($con, $sql);
$arquivo = utf8_decode('Nome do Usuário;Ação;Data / Hora')."\r\n";
if (mysqli_num_rows($query)){
    while($value = mysqli_fetch_object($query)){
        $arquivo .= utf8_decode($value->nomeUsuario).";".$value->action.";".$value->created_at."\r\n";
    }
}
$sql = "INSERT INTO logs (action, user, created_at, updated_at) VALUES ('Exportou os Logs de Acesso', '".$_REQUEST['idUser']."', now(), now())";
mysqli_query($con, $sql);
$fp = fopen(DIRETORIO_SITE."logs.csv", "w+");
fwrite($fp, $arquivo);
fclose($fp);


$fp = fopen(DIRETORIO_SITE."logs.csv", "r");
header('Content-type: text/csv');
header('Content-Disposition: attachment; filename=logs'.date('Y-m-d-H-i-s').'.csv');

while(!feof ($fp)) {

    echo fgets($fp); //LENDO A LINHA
}
fclose($fp);
unlink(DIRETORIO_SITE."logs.csv");
?>
