<?php
$sql = "SELECT * FROM users WHERE id = '".$_SESSION['user']['id']."'";
$query = mysqli_query($con, $sql);
$usuario = mysqli_fetch_object($query);
$sql = "SELECT * FROM users";
if ($_SESSION['user']['id'] > 1){
    $sql .= " WHERE id = '".$_SESSION['user']['id']."'"; 
}
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $users[] = $row;
    }
}
$sql = "SELECT * FROM type_modules WHERE status = '1' AND deleted_at IS NULL";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $typesModules[] = $row;
    }
}
$i = 0;
$sql = "SELECT * FROM modules WHERE status = '1' AND deleted_at IS NULL";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        if ($row->slug == $vet[1]){
            $moduloE = $row;
        }
        $modules[$i] = $row;
        $i++;
    }
}
if(count($moduloE)){
    $sql = "SELECT * FROM permissions WHERE user = '".$usuario->id."' AND module = '".$moduloE->id."'";
    $query = mysqli_query($con, $sql);
    $permissao = mysqli_fetch_object($query);
}
$sql = "SELECT * FROM permissions WHERE user = '".$_SESSION['user']['id']."' AND view = '1'";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $permission[$row->module] = $row;
    }
}
$i = 0;
$sql = "SELECT * FROM states WHERE status = '1' AND deleted_at IS NULL";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $states[] = $row;
    }
}
$i = 0;
$sql = "SELECT * FROM versions WHERE deleted_at IS NULL ORDER BY date DESC";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $versions[$i] = $row;
        $i++;
    }
}
$i = 0;
$sql = "SELECT * FROM param_admins WHERE deleted_at IS NULL";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $paramAdmin[$row->name] = ($row->value);
        $i++;
    }
}
if (!$vet[1] || $vet[1] == 'principal'){
    $acao = "Visualizou a tela inicial do sistema";
}
elseif ($vet[1] == 'itens-excluidos'){
    $acao = "Visualizou os ítens excluídos do site";
}
elseif ($vet[1] == 'cupomDesconto'){
    $acao = ("Visualizou os cupons de desconto do site");
}
elseif ($vet[1] == 'paramAdmin'){
    $acao = ("Visualizou os parâmetros do administrativo");
}
elseif ($vet[1] == 'versao'){
    $acao = ("Visualizou as versões do administrativo");
}
elseif ($vet[1] == 'imoveis'){
    $acao = "Visualizou os imóveis do sistema";
}
elseif ($vet[1] == 'usuarios'){
    $acao = ("Visualizou os usuários do sistema");
}
elseif ($vet[1] == 'tiposModulo'){
    $acao = ("Visualizou os tipos de módulo do sistema");
}
elseif ($vet[1] == 'modulos'){
    $acao = ("Visualizou os módulos do sistema");
}
elseif ($vet[1] == 'permissao'){
    $acao = ("Visualizou as permissões do sistema");
}
elseif ($vet[1] == 'logsAcesso'){
    $acao = ("Visualizou os logs de usuários do sistema");
}
if ($acao){
    $sql = "INSERT INTO logs (user, action, created_at, updated_at) VALUES ('".$_SESSION['user']['id']."', '".$acao."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
    mysqli_query($con, $sql);
}
?>